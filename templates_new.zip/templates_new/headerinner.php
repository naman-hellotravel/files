<?
function Page_URL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}
$url_name = Page_URL();
$url_name =explode('/',$url_name);
$u_name=$url_name[3];
if(isset($_COOKIE['aff_id']) && !empty($_COOKIE['aff_id']))
{
    $aff_id=$_COOKIE['aff_id'];
}
else if(isset($_GET['aff_id']) && !empty($_GET['aff_id']))
{
    $aff_id=$_GET['aff_id'];
    setcookie("aff_id",$aff_id, time() + (86400* 7),'/');
}
else
{
    $aff_id=1044;
} 
function get_country_iso($country_name)
{
	$country_arr =
	array('afghanistan' => 'AF','albania' => 'AL','algeria' => 'DZ','american samoa' => 'AS','andorra' => 'AD','angola' => 'AO','anguilla' => 'AI','antarctica' => 'AQ','antigua and barbuda' => 'AG','argentina' => 'AR','armenia' => 'AM','australia' => 'AU','austria' => 'AT','azerbaijan' => 'AZ','bahamas' => 'BS','bahrain' => 'BH','bangladesh' => 'BD','barbados' => 'BB','belarus' => 'BY','belgium' => 'BE','belize' => 'BZ','benin' => 'BJ','bermuda' => 'BM','bhutan' => 'BT','bolivia' => 'BO','bosnia & herzegovina' => 'BA','botswana' => 'BW','brazil' => 'BR','british indianocean' => 'IO','british virgin islands' => 'BVI','brunei' => 'BN','bulgaria' => 'BG','burkina faso' => 'BF','burundi' => 'BI','cambodia' => 'KH','cameroon' => 'CM','canada' => 'CA','cape verde' => 'CV','cayman islands' => 'KY','central african rep.' => 'CF','chad' => 'TD','chile' => 'CL','christmas island' => 'CX','cocos islands' => 'CC','colombia' => 'CO','comoros' => 'KM','congo' => 'CD','cook islands' => 'CK','costa rica' => 'CR','croatia' => 'HR','cuba' => 'CU','cyprus' => 'CY','czech republic' => 'CZ','denmark' => 'DK','djibouti' => 'DJ','dominica' => 'DM','dominican republic' => 'DO','east timor' => 'TL','ecuador' => 'EC','egypt' => 'EG','el salvador' => 'SV','equatorial guinea' => 'GQ','eritrea' => 'ER','estonia' => 'EE','ethiopia' => 'ET','falkland islands' => 'FK','faroe islands' => 'FO','fiji' => 'FJ','finland' => 'FI','france' => 'FR','french guiana' => 'GF','french polynesia' => 'PF','french southernterr.' => 'TF','gabon' => 'GA','gambia' => 'GM','georgia' => 'GE','germany' => 'DE','ghana' => 'GH','gibraltar' => 'GI','greece' => 'GR','greenland' => 'GL','grenada' => 'GD','guadeloupe' => 'GP','guam' => 'GU','guatemala' => 'GT','guinea' => 'GN','guinea-bissau' => 'GW','guyana' => 'GY','haiti' => 'HT','heard & mcdonald' => 'HM','honduras' => 'HN','hong kong' => 'HK','hungary' => 'HU','iceland' => 'IS','india' => 'IN','indonesia' => 'ID','iran' => 'IR','iraq' => 'IQ','ireland' => 'IE','israel' => 'IL','italy' => 'IT','ivory coast' => 'CI','jamaica' => 'JM','japan' => 'JP','jordan' => 'JO','kazakhstan' => 'KZ','kenya' => 'KE','kiribati' => 'KI','north korea' => 'KP','south korea' => 'KR','kuwait' => 'KW','kyrgyzstan' => 'KG','laos' => 'LA','latvia' => 'LV','lebanon' => 'LB','lesotho' => 'LS','liberia' => 'LR','libya' => 'LY','liechtenstein' => 'LI','lithuania' => 'LT','luxembourg' => 'LU','macau' => 'MO','madagascar' => 'MG','malawi' => 'MW','malaysia' => 'MY','maldives' => 'MV','mali' => 'ML','malta' => 'MT','marshall islands' => 'MH','martinique' => 'MQ','mauritania' => 'MR','mauritius' => 'MU','mayotte' => 'YT','mexico' => 'MX','micronesia' => 'FSM','moldova' => 'MD','monaco' => 'MC','mongolia' => 'MN','montserrat' => 'MS','morocco' => 'MA','mozambique' => 'MZ','myanmar' => 'MM','namibia' => 'NA','nauru' => 'NR','nepal' => 'NP','netherlands' => 'NL','netherlands antilles' => 'AN','new caledonia' => 'NC','new zealand' => 'NZ','nicaragua' => 'NI','niger' => 'NE','nigeria' => 'NG','niue' => 'NU','norfolk island' => 'NF','northern mariana isl.' => 'MP','norway' => 'NO','oman' => 'OM','pakistan' => 'PK','palau' => 'PW','panama' => 'PA','papua new guinea' => 'PG','paraguay' => 'PY','peru' => 'PE','philippines' => 'PH','pitcairn island' => 'PN','poland' => 'PL','portugal' => 'PT','puerto rico' => 'PR','qatar' => 'QA','reunion' => 'RE','romania' => 'RO','russia' => 'RU','rwanda' => 'RW','s.georgia and s.sand.' => 'GS','saint kitts & nevis' => 'KN','saint lucia' => 'LC','st.vincent &gren.' => 'VC','samoa' => 'WS','san marino' => 'SM','sao tome & principe' => 'ST','saudi arabia' => 'SA','senegal' => 'SN','seychelles' => 'SC','singapore' => 'SG','slovakia' => 'SK','slovenia' => 'SI','somalia' => 'SO','south africa' => 'ZA','spain' => 'ES','sri lanka' => 'LK','st. helena' => 'SH','st. pierre & miquelon' => 'PM','sudan' => 'SD','suriname' => 'SR','svalbard &j.mayen' => 'SJ','swaziland' => 'SZ','sweden' => 'SE','switzerland' => 'CH','syria' => 'SY','taiwan' => 'TW','tajikistan' => 'TJ','tanzania' => 'TZ','thailand' => 'TH','togo' => 'TG','tokelau' => 'TK','tonga' => 'TO','trinidad and tobago' => 'TT','tunisia' => 'TN','turkey' => 'TR','turkmenistan' => 'TM','turks & caicos isl.' => 'TC','tuvalu' => 'TV','u.s.minor outlying isl.' => 'UM','uganda' => 'UG','ukraine' => 'UA','united arab emirates' => 'AE','united kingdom' => 'UK','u.s.a.' => 'US','uruguay' => 'UY','uzbekistan' => 'UZ','vanuatu' => 'VU','vatican city' => 'VA','venezuela' => 'VE','vietnam' => 'VN','virgin islands' => 'VG','wallis & futuna isl.' => 'WF','western sahara' => 'VH','yemen' => 'YE','yugoslavia (former)' => 'YU','zaire' => 'ZR','zambia' => 'ZM','zimbabwe' => 'ZW','china' => 'CN','montenegro' => 'ME','palestine' => 'PS','aruba' => 'AW','serbia' => 'RS','solomon islands' => 'SB','macedonia' => 'MK','africa' => 'RAF','caribbean' => 'RCA','europe' => 'REU','far east' => 'RFE','indian subcontinent' => 'RIS','middleeast' => 'RME','north america' => 'RNA','pacific/oceania' => 'ROC','south america' => 'RSA','guernsey' => 'GG');
	return $country_arr[$country_name];
}
?>
<?php if($u_name=='reverify' || $u_name=='verify' || $u_name=='plan-cancelled') {  }
else {?>

<div class="main_sticky" id="main_sticky">
  <div class="side_sticky"> <a href="/plan-your-travel"></a> </div>
</div>
<script type="text/javascript">
function disn()
{
	updateDateField();
}
function fixd()
{
	document.getElementById("datepicker").style.position="fixed";
	
}
if (screen.width <= 1024)
{
	document.getElementById("main_sticky").style.display="none";	
}
else
{
	document.getElementById("main_sticky").style.display="block";	
}
</script>
<?php } ?>
<!--header-->
<!--top nav-->
<div class="top-nav" style="line-height:normal">
  <div class="w980 auto" style="background:none">
    <ul class="top-links">
      <li id="count">Helped <span>
        <?php include '/home3/indiamart/public_html/hellotravel-agents/count.php'; ?>
        </span> people plan their travel</li>
      <li><a href="/testimonials">Trip Reviews</a></li>
      <li id="last-child"><a href="/plan-your-travel">Plan Your Trip Now !</a></li>
    </ul>
    <ul class="search-box-right">
      <li>
        <div id="search">
          <form action="/search-result.php" id="cse-search-box">
            <input type="hidden" name="cx" value="partner-pub-7291254820386980:7296132994" />
            <input type="hidden" name="cof" value="FORID:10" />
            <input type="hidden" name="ie" value="UTF-8" />
            <input onfocus="if (this.value==this.defaultValue){ this.value = '';this.style.color='#ccc';}" onblur="if (this.value==''){ this.value = this.defaultValue;this.style.color='#949494';}" onclick="this.style.color='#949494';" value="Search" type="text" class="search" name="q">
          </form>
        </div>
      </li>
    </ul>
    <div class="cl" style="border:none;"></div>
  </div>
</div>
<!--end top nav-->
<!--main nav-->
<div class="main-nav">
  <div class="w980 auto" style="background:none; position:relative">
    <!--logo-->
    <div class="fll"> <a href="/"><img border="0" src="/sites/all/themes/newswire/images/logo-header.png" /></a> </div>
    <!--end logo-->
    <div class="main-links"> 
        <a href="/destinations" id="destinations-nav" class="link" > <b>DESTINATIONS</b><br />Guide <em></em></a>
        <a href="/deals" id="deals-nav" class="link" > <b>DEALS</b><br />We Offer <em></em></a>
        <a href="/thingstodo" id="thingstodo-nav" class="link" > <b>ACTIVITIES</b><br />To Do <em></em></a>
        <a href="/placestosee" id="placestosee-nav" class="link" > <b>PLACES</b><br />To See <em></em></a>
        <a href="/stories" id="stories-nav" class="link" > <b>STORIES</b><br />You'll Love <em></em></a>
        <a href="/events" id="events-nav" class="link" > <b>EVENTS</b><br />Like to visit <em></em></a>
        <a href="/luxury-stays" id="luxury-stays-nav" class="link" > <b>HOTELS</b><br />Luxury Stays <em></em></a>
     <div class="cl"></div>
    </div>
    <div class="cl"></div>
  </div>
</div>
<!--main nav-->
<!--end header-->
