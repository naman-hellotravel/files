var head=new Array();
var check = false;
(function ($) {
    if ($ === undefined) {
        return;
    }
    var defaultConfig = { num: 3, maxWidth: 250, maxHeight: 150, autoPlay: true, showTime: 1e3, animationTime: 300, scale: 0.8, distance: 50 };
    function getzIndexValue(num, direction) {
        var zIndexs = [];
        for (var i = 0; i < num; i++) {
            if (i <= (num - 1) / 2) {
                zIndexs.push(i);
            } else {
                zIndexs.push((num - 1) / 2 - i);
            }
        }
        if (direction === "left") {
            zIndexs.reverse();
            return zIndexs;
        }
        if (direction === "right") {
            return zIndexs;
        }
    }
    function scroll($container, direction) {
        if ($container.data("isanimating")) {
            return;
        }
        var config = $container.data("config");
        var halfShowNum = (config.num - 1) / 2;
        var scales, i, newIndex;
        var totalNum = $container.data("totalNum");
        var targetCss;
        var firstIndexBeforeScroll, lastIndexBeforeScroll;
        if (direction === "left") {
            newIndex = ($container.data("index") - 1 + totalNum) % totalNum;
        } else if (direction === "right") {
            newIndex = ($container.data("index") + 1) % $container.data("totalNum");
        } else {
            return;
        }
        var tempIndexsInfo = getShowIndexs($container);
        firstIndexBeforeScroll = tempIndexsInfo.indexs[0];
        lastIndexBeforeScroll = tempIndexsInfo.indexs[config.num - 1];
        $container.data("index", newIndex);
        var showIndexsInfo = getShowIndexs($container);
        var zIndexs = getzIndexValue(config.num, direction);
        if (totalNum === config.num) {
            animationTimeForEdge = 0;
        } else if (totalNum - config.num === 2) {
            animationTimeForEdge = config.animationTime / 2;
        } else {
            animationTimeForEdge = config.animationTime;
        }
        $container.find("ul li").each(function (index, element) {
            i = showIndexsInfo.hashIndexs[index];
            if (i !== undefined) {
                scales = Math.pow(config.scale, Math.abs(i - halfShowNum));
                $container.data("isanimating", true);
                $(element)
                    .css({ display: "block", "z-index": zIndexs[i] + 9999 })
                    .animate(
                        { width: scales * config.maxWidth, height: scales * config.maxHeight, left: i * config.distance + (1 - scales) * config.maxWidth * Number(i > halfShowNum), top: ((1 - scales) * config.maxHeight) / 2 },
                        config.animationTime,
                        function () {
                            $container.data("isanimating", false);
                        }
                    );
            } else {
                scales = Math.pow(config.scale, halfShowNum);
                targetCss = { display: "none", left: halfShowNum * config.distance + ((1 - scales) * config.maxWidth) / 2, top: 0 };
                if (direction === "left" && index === lastIndexBeforeScroll) {
                    $(element)
                        .css("z-index", -1)
                        .animate({ left: "-=" + config.distance + "px" }, config.animationTime, function () {
                            $(element).css(targetCss);
                        });
                } else if (direction === "right" && index === firstIndexBeforeScroll) {
                    $(element)
                        .css("z-index", -1)
                        .animate({ left: "+=" + config.distance + "px" }, config.animationTime, function () {
                            $(element).css(targetCss);
                        });
                } else {
                    $(element).css({ display: "none", width: scales * config.maxWidth, height: scales * config.maxHeight, left: halfShowNum * config.distance + ((1 - scales) * config.maxWidth) / 2, top: 0 });
                }
            }
        });
    }
    function getConfig(newConfig) {
        var config = null;
        if (typeof newConfig === "object" && newConfig !== null) {
            config = {};
            for (var prop in defaultConfig) {
                if (defaultConfig.hasOwnProperty(prop)) {
                    config[prop] = defaultConfig[prop];
                }
            }
            for (prop in newConfig) {
                if (newConfig.hasOwnProperty(prop) && config.hasOwnProperty(prop)) {
                    config[prop] = newConfig[prop];
                }
            }
        }
        return config;
    }
    function getShowIndexs($container) {
        var showIndexs = [];
        var temp;
        var halfShowNum = ($container.data("config").num - 1) / 2;
        var currentIndex = $container.data("index") || 0;
        var totalNum = $container.data("totalNum") || 0;
        for (var i = -halfShowNum; i <= halfShowNum; i++) {
            temp = currentIndex + i;
            showIndexs.push((temp < 0 ? temp + totalNum : temp) % totalNum);
        }
        var hashIndexs = {};
        for (i = 0; i < showIndexs.length; i++) {
            hashIndexs[showIndexs[i]] = i;
        }
        return { indexs: showIndexs, hashIndexs: hashIndexs };
    }
    function initStyle($container) {
        var showIndexsInfo = getShowIndexs($container);
        var zIndex = 9999;
        var scales;
        var config = $container.data("config");
        var halfShowNum = (config.num - 1) / 2;
        var listWidth = halfShowNum * config.distance * 2 + config.maxWidth;
        var containerWidth = $container.width();
        var containerHeight = $container.height();
        if (containerWidth < listWidth) {
            $container.width(listWidth);
        }
        if (containerHeight < config.maxHeight) {
            $container.height(config.maxHeight);
        }
        $container.find("ul li img").css({ width: "100%", height: "100%" });
        $container
            .find("ul")
            .css({ position: "relative", width: listWidth, height: config.maxHeight, "list-style": "none", padding: 0, margin: 0, marginLeft: "50%", left: -listWidth / 2, top: ($container.height() - config.maxHeight) / 2 });
        $container.find(".left").css({ position: "absolute", left: 10, top: "50%", "z-index": 9999 + $container.data("totalNum") + 1 });
        $container.find(".right").css({ position: "absolute", right: 10, top: "50%", "z-index": 9999 + $container.data("totalNum") + 1 });
        $container.find("ul li").each(function (index, element) {
            var i = showIndexsInfo.hashIndexs[index];
            if (i !== undefined) {
                scales = Math.pow(config.scale, Math.abs(i - halfShowNum));
                zIndex = 9999 + (i > halfShowNum ? config.num - 1 - i : i);
                $(element).css({
                    display: "block",
                    position: "absolute",
                    "z-index": zIndex,
                    overflow: "hidden",
                    width: scales * config.maxWidth,
                    height: scales * config.maxHeight,
                    left: i * config.distance + (1 - scales) * config.maxWidth * Number(i > halfShowNum),
                    top: ((1 - scales) * config.maxHeight) / 2,
                });
            } else {
                scales = Math.pow(config.scale, halfShowNum);
                $(element).css({
                    display: "none",
                    position: "absolute",
                    overflow: "hidden",
                    width: scales * config.maxWidth,
                    height: scales * config.maxHeight,
                    left: halfShowNum * config.distance + ((1 - scales) * config.maxWidth) / 2,
                    top: 0,
                });
            }
        });
    }
    $.fn.carousel = function (param) {
        var config;
        var totalNum;
        var $target;
        $(this).each(function (index, target) {
            $target = $(target);
            if (typeof param === "object" && param !== null) {
                config = getConfig(param);
                totalNum = $target.find("ul li").length;
                if (totalNum <= 0 || totalNum % 2 === 0) {
                    return;
                }
                if (config.num <= 0 || config.num > totalNum) {
                    config.num = totalNum;
                }
                $target.data("config", config);
                $target.data("index", 0);
                $target.data("totalNum", totalNum);
                initStyle($target);
                $target
                    .find(".left")
                    .off("click")
                    .on(
                        "click",
                        (function ($target) {
                            return function () {
                                scroll($target, "left");
                            };
                        })($target)
                    );
                $target
                    .find(".right")
                    .off("click")
                    .on(
                        "click",
                        (function ($target) {
                            return function () {
                                scroll($target, "right");
                            };
                        })($target)
                    );
                (function ($target) {
                    var autoPlay;
                    clearInterval($target.data("auto"));
                    if ($target.data("config").autoPlay) {
                        autoPlay = setInterval(function () {
                            scroll($target, "right");
                        }, $target.data("config").showTime);
                        $target.data("auto", autoPlay);
                        $target
                            .find("ul")
                            .off("mouseenter")
                            .on("mouseenter", function () {
                                clearInterval($target.data("auto"));
                            })
                            .off("mouseleave")
                            .on("mouseleave", function () {
                                autoPlay = setInterval(function () {
                                    scroll($target, "right");
                                }, $target.data("config").showTime);
                                $target.data("auto", autoPlay);
                            });
                    } else {
                        $target.find("ul").off("mouseenter").off("mouseleave");
                    }
                })($target);
            }
        });
    };
})(jQuery);
!(function (t, e) {
    "object" == typeof exports && "object" == typeof module ? (module.exports = e()) : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? (exports.Handlebars = e()) : (t.Handlebars = e());
})(this, function () {
    return (function (t) {
        function e(s) {
            if (r[s]) return r[s].exports;
            var i = (r[s] = { exports: {}, id: s, loaded: !1 });
            return t[s].call(i.exports, i, i.exports, e), (i.loaded = !0), i.exports;
        }
        var r = {};
        return (e.m = t), (e.c = r), (e.p = ""), e(0);
    })([
        function (t, e, r) {
            "use strict";
            function s() {
                var t = v();
                return (
                    (t.compile = function (e, r) {
                        return h.compile(e, r, t);
                    }),
                    (t.precompile = function (e, r) {
                        return h.precompile(e, r, t);
                    }),
                    (t.AST = c["default"]),
                    (t.Compiler = h.Compiler),
                    (t.JavaScriptCompiler = p["default"]),
                    (t.Parser = l.parser),
                    (t.parse = l.parse),
                    t
                );
            }
            var i = r(1)["default"];
            e.__esModule = !0;
            var n = r(2),
                a = i(n),
                o = r(35),
                c = i(o),
                l = r(36),
                h = r(41),
                u = r(42),
                p = i(u),
                f = r(39),
                d = i(f),
                m = r(34),
                g = i(m),
                v = a["default"].create,
                y = s();
            (y.create = s), g["default"](y), (y.Visitor = d["default"]), (y["default"] = y), (e["default"] = y), (t.exports = e["default"]);
        },
        function (t, e) {
            "use strict";
            (e["default"] = function (t) {
                return t && t.__esModule ? t : { default: t };
            }),
                (e.__esModule = !0);
        },
        function (t, e, r) {
            "use strict";
            function s() {
                var t = new o.HandlebarsEnvironment();
                return (
                    f.extend(t, o),
                    (t.SafeString = l["default"]),
                    (t.Exception = u["default"]),
                    (t.Utils = f),
                    (t.escapeExpression = f.escapeExpression),
                    (t.VM = m),
                    (t.template = function (e) {
                        return m.template(e, t);
                    }),
                    t
                );
            }
            var i = r(3)["default"],
                n = r(1)["default"];
            e.__esModule = !0;
            var a = r(4),
                o = i(a),
                c = r(21),
                l = n(c),
                h = r(6),
                u = n(h),
                p = r(5),
                f = i(p),
                d = r(22),
                m = i(d),
                g = r(34),
                v = n(g),
                y = s();
            (y.create = s), v["default"](y), (y["default"] = y), (e["default"] = y), (t.exports = e["default"]);
        },
        function (t, e) {
            "use strict";
            (e["default"] = function (t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                return (e["default"] = t), e;
            }),
                (e.__esModule = !0);
        },
        function (t, e, r) {
            "use strict";
            function s(t, e, r) {
                (this.helpers = t || {}), (this.partials = e || {}), (this.decorators = r || {}), c.registerDefaultHelpers(this), l.registerDefaultDecorators(this);
            }
            var i = r(1)["default"];
            (e.__esModule = !0), (e.HandlebarsEnvironment = s);
            var n = r(5),
                a = r(6),
                o = i(a),
                c = r(10),
                l = r(18),
                h = r(20),
                u = i(h),
                p = "4.0.10";
            e.VERSION = p;
            var f = 7;
            e.COMPILER_REVISION = f;
            var d = { 1: "<= 1.0.rc.2", 2: "== 1.0.0-rc.3", 3: "== 1.0.0-rc.4", 4: "== 1.x.x", 5: "== 2.0.0-alpha.x", 6: ">= 2.0.0-beta.1", 7: ">= 4.0.0" };
            e.REVISION_CHANGES = d;
            var m = "[object Object]";
            s.prototype = {
                constructor: s,
                logger: u["default"],
                log: u["default"].log,
                registerHelper: function (t, e) {
                    if (n.toString.call(t) === m) {
                        if (e) throw new o["default"]("Arg not supported with multiple helpers");
                        n.extend(this.helpers, t);
                    } else this.helpers[t] = e;
                },
                unregisterHelper: function (t) {
                    delete this.helpers[t];
                },
                registerPartial: function (t, e) {
                    if (n.toString.call(t) === m) n.extend(this.partials, t);
                    else {
                        if ("undefined" == typeof e) throw new o["default"]('Attempting to register a partial called "' + t + '" as undefined');
                        this.partials[t] = e;
                    }
                },
                unregisterPartial: function (t) {
                    delete this.partials[t];
                },
                registerDecorator: function (t, e) {
                    if (n.toString.call(t) === m) {
                        if (e) throw new o["default"]("Arg not supported with multiple decorators");
                        n.extend(this.decorators, t);
                    } else this.decorators[t] = e;
                },
                unregisterDecorator: function (t) {
                    delete this.decorators[t];
                },
            };
            var g = u["default"].log;
            (e.log = g), (e.createFrame = n.createFrame), (e.logger = u["default"]);
        },
        function (t, e) {
            "use strict";
            function r(t) {
                return h[t];
            }
            function s(t) {
                for (var e = 1; e < arguments.length; e++) for (var r in arguments[e]) Object.prototype.hasOwnProperty.call(arguments[e], r) && (t[r] = arguments[e][r]);
                return t;
            }
            function i(t, e) {
                for (var r = 0, s = t.length; s > r; r++) if (t[r] === e) return r;
                return -1;
            }
            function n(t) {
                if ("string" != typeof t) {
                    if (t && t.toHTML) return t.toHTML();
                    if (null == t) return "";
                    if (!t) return t + "";
                    t = "" + t;
                }
                return p.test(t) ? t.replace(u, r) : t;
            }
            function a(t) {
                return t || 0 === t ? (m(t) && 0 === t.length ? !0 : !1) : !0;
            }
            function o(t) {
                var e = s({}, t);
                return (e._parent = t), e;
            }
            function c(t, e) {
                return (t.path = e), t;
            }
            function l(t, e) {
                return (t ? t + "." : "") + e;
            }
            (e.__esModule = !0), (e.extend = s), (e.indexOf = i), (e.escapeExpression = n), (e.isEmpty = a), (e.createFrame = o), (e.blockParams = c), (e.appendContextPath = l);
            var h = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#x27;", "`": "&#x60;", "=": "&#x3D;" },
                u = /[&<>"'`=]/g,
                p = /[&<>"'`=]/,
                f = Object.prototype.toString;
            e.toString = f;
            var d = function (t) {
                return "function" == typeof t;
            };
            d(/x/) &&
                (e.isFunction = d = function (t) {
                    return "function" == typeof t && "[object Function]" === f.call(t);
                }),
                (e.isFunction = d);
            var m =
                Array.isArray ||
                function (t) {
                    return t && "object" == typeof t ? "[object Array]" === f.call(t) : !1;
                };
            e.isArray = m;
        },
        function (t, e, r) {
            "use strict";
            function s(t, e) {
                var r = e && e.loc,
                    a = void 0,
                    o = void 0;
                r && ((a = r.start.line), (o = r.start.column), (t += " - " + a + ":" + o));
                for (var c = Error.prototype.constructor.call(this, t), l = 0; l < n.length; l++) this[n[l]] = c[n[l]];
                Error.captureStackTrace && Error.captureStackTrace(this, s);
                try {
                    r && ((this.lineNumber = a), i ? Object.defineProperty(this, "column", { value: o, enumerable: !0 }) : (this.column = o));
                } catch (h) {}
            }
            var i = r(7)["default"];
            e.__esModule = !0;
            var n = ["description", "fileName", "lineNumber", "message", "name", "number", "stack"];
            (s.prototype = new Error()), (e["default"] = s), (t.exports = e["default"]);
        },
        function (t, e, r) {
            t.exports = { default: r(8), __esModule: !0 };
        },
        function (t, e, r) {
            var s = r(9);
            t.exports = function (t, e, r) {
                return s.setDesc(t, e, r);
            };
        },
        function (t, e) {
            var r = Object;
            t.exports = {
                create: r.create,
                getProto: r.getPrototypeOf,
                isEnum: {}.propertyIsEnumerable,
                getDesc: r.getOwnPropertyDescriptor,
                setDesc: r.defineProperty,
                setDescs: r.defineProperties,
                getKeys: r.keys,
                getNames: r.getOwnPropertyNames,
                getSymbols: r.getOwnPropertySymbols,
                each: [].forEach,
            };
        },
        function (t, e, r) {
            "use strict";
            function s(t) {
                a["default"](t), c["default"](t), h["default"](t), p["default"](t), d["default"](t), g["default"](t), y["default"](t);
            }
            var i = r(1)["default"];
            (e.__esModule = !0), (e.registerDefaultHelpers = s);
            var n = r(11),
                a = i(n),
                o = r(12),
                c = i(o),
                l = r(13),
                h = i(l),
                u = r(14),
                p = i(u),
                f = r(15),
                d = i(f),
                m = r(16),
                g = i(m),
                v = r(17),
                y = i(v);
        },
        function (t, e, r) {
            "use strict";
            e.__esModule = !0;
            var s = r(5);
            (e["default"] = function (t) {
                t.registerHelper("blockHelperMissing", function (e, r) {
                    var i = r.inverse,
                        n = r.fn;
                    if (e === !0) return n(this);
                    if (e === !1 || null == e) return i(this);
                    if (s.isArray(e)) return e.length > 0 ? (r.ids && (r.ids = [r.name]), t.helpers.each(e, r)) : i(this);
                    if (r.data && r.ids) {
                        var a = s.createFrame(r.data);
                        (a.contextPath = s.appendContextPath(r.data.contextPath, r.name)), (r = { data: a });
                    }
                    return n(e, r);
                });
            }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            var s = r(1)["default"];
            e.__esModule = !0;
            var i = r(5),
                n = r(6),
                a = s(n);
            (e["default"] = function (t) {
                t.registerHelper("each", function (t, e) {
                    function r(e, r, n) {
                        l && ((l.key = e), (l.index = r), (l.first = 0 === r), (l.last = !!n), h && (l.contextPath = h + e)), (c += s(t[e], { data: l, blockParams: i.blockParams([t[e], e], [h + e, null]) }));
                    }
                    if (!e) throw new a["default"]("Must pass iterator to #each");
                    var s = e.fn,
                        n = e.inverse,
                        o = 0,
                        c = "",
                        l = void 0,
                        h = void 0;
                    if ((e.data && e.ids && (h = i.appendContextPath(e.data.contextPath, e.ids[0]) + "."), i.isFunction(t) && (t = t.call(this)), e.data && (l = i.createFrame(e.data)), t && "object" == typeof t))
                        if (i.isArray(t)) for (var u = t.length; u > o; o++) o in t && r(o, o, o === t.length - 1);
                        else {
                            var p = void 0;
                            for (var f in t) t.hasOwnProperty(f) && (void 0 !== p && r(p, o - 1), (p = f), o++);
                            void 0 !== p && r(p, o - 1, !0);
                        }
                    return 0 === o && (c = n(this)), c;
                });
            }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            var s = r(1)["default"];
            e.__esModule = !0;
            var i = r(6),
                n = s(i);
            (e["default"] = function (t) {
                t.registerHelper("helperMissing", function () {
                    if (1 === arguments.length) return void 0;
                    throw new n["default"]('Missing helper: "' + arguments[arguments.length - 1].name + '"');
                });
            }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            e.__esModule = !0;
            var s = r(5);
            (e["default"] = function (t) {
                t.registerHelper("if", function (t, e) {
                    return s.isFunction(t) && (t = t.call(this)), (!e.hash.includeZero && !t) || s.isEmpty(t) ? e.inverse(this) : e.fn(this);
                }),
                    t.registerHelper("unless", function (e, r) {
                        return t.helpers["if"].call(this, e, { fn: r.inverse, inverse: r.fn, hash: r.hash });
                    });
            }),
                (t.exports = e["default"]);
        },
        function (t, e) {
            "use strict";
            (e.__esModule = !0),
                (e["default"] = function (t) {
                    t.registerHelper("log", function () {
                        for (var e = [void 0], r = arguments[arguments.length - 1], s = 0; s < arguments.length - 1; s++) e.push(arguments[s]);
                        var i = 1;
                        null != r.hash.level ? (i = r.hash.level) : r.data && null != r.data.level && (i = r.data.level), (e[0] = i), t.log.apply(t, e);
                    });
                }),
                (t.exports = e["default"]);
        },
        function (t, e) {
            "use strict";
            (e.__esModule = !0),
                (e["default"] = function (t) {
                    t.registerHelper("lookup", function (t, e) {
                        return t && t[e];
                    });
                }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            e.__esModule = !0;
            var s = r(5);
            (e["default"] = function (t) {
                t.registerHelper("with", function (t, e) {
                    s.isFunction(t) && (t = t.call(this));
                    var r = e.fn;
                    if (s.isEmpty(t)) return e.inverse(this);
                    var i = e.data;
                    return e.data && e.ids && ((i = s.createFrame(e.data)), (i.contextPath = s.appendContextPath(e.data.contextPath, e.ids[0]))), r(t, { data: i, blockParams: s.blockParams([t], [i && i.contextPath]) });
                });
            }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s(t) {
                a["default"](t);
            }
            var i = r(1)["default"];
            (e.__esModule = !0), (e.registerDefaultDecorators = s);
            var n = r(19),
                a = i(n);
        },
        function (t, e, r) {
            "use strict";
            e.__esModule = !0;
            var s = r(5);
            (e["default"] = function (t) {
                t.registerDecorator("inline", function (t, e, r, i) {
                    var n = t;
                    return (
                        e.partials ||
                            ((e.partials = {}),
                            (n = function (i, n) {
                                var a = r.partials;
                                r.partials = s.extend({}, a, e.partials);
                                var o = t(i, n);
                                return (r.partials = a), o;
                            })),
                        (e.partials[i.args[0]] = i.fn),
                        n
                    );
                });
            }),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            e.__esModule = !0;
            var s = r(5),
                i = {
                    methodMap: ["debug", "info", "warn", "error"],
                    level: "info",
                    lookupLevel: function (t) {
                        if ("string" == typeof t) {
                            var e = s.indexOf(i.methodMap, t.toLowerCase());
                            t = e >= 0 ? e : parseInt(t, 10);
                        }
                        return t;
                    },
                    log: function (t) {
                        if (((t = i.lookupLevel(t)), "undefined" != typeof console && i.lookupLevel(i.level) <= t)) {
                            var e = i.methodMap[t];
                            console[e] || (e = "log");
                            for (var r = arguments.length, s = Array(r > 1 ? r - 1 : 0), n = 1; r > n; n++) s[n - 1] = arguments[n];
                            console[e].apply(console, s);
                        }
                    },
                };
            (e["default"] = i), (t.exports = e["default"]);
        },
        function (t, e) {
            "use strict";
            function r(t) {
                this.string = t;
            }
            (e.__esModule = !0),
                (r.prototype.toString = r.prototype.toHTML = function () {
                    return "" + this.string;
                }),
                (e["default"] = r),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s(t) {
                var e = (t && t[0]) || 1,
                    r = y.COMPILER_REVISION;
                if (e !== r) {
                    if (r > e) {
                        var s = y.REVISION_CHANGES[r],
                            i = y.REVISION_CHANGES[e];
                        throw new v["default"](
                            "Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version (" + s + ") or downgrade your runtime to an older version (" + i + ")."
                        );
                    }
                    throw new v["default"]("Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version (" + t[1] + ").");
                }
            }
            function i(t, e) {
                function r(r, s, i) {
                    i.hash && ((s = m.extend({}, s, i.hash)), i.ids && (i.ids[0] = !0)), (r = e.VM.resolvePartial.call(this, r, s, i));
                    var n = e.VM.invokePartial.call(this, r, s, i);
                    if ((null == n && e.compile && ((i.partials[i.name] = e.compile(r, t.compilerOptions, e)), (n = i.partials[i.name](s, i))), null != n)) {
                        if (i.indent) {
                            for (var a = n.split("\n"), o = 0, c = a.length; c > o && (a[o] || o + 1 !== c); o++) a[o] = i.indent + a[o];
                            n = a.join("\n");
                        }
                        return n;
                    }
                    throw new v["default"]("The partial " + i.name + " could not be compiled when running in runtime-only mode");
                }
                function s(e) {
                    function r(e) {
                        return "" + t.main(i, e, i.helpers, i.partials, a, c, o);
                    }
                    var n = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                        a = n.data;
                    s._setup(n), !n.partial && t.useData && (a = l(e, a));
                    var o = void 0,
                        c = t.useBlockParams ? [] : void 0;
                    return t.useDepths && (o = n.depths ? (e != n.depths[0] ? [e].concat(n.depths) : n.depths) : [e]), (r = h(t.main, r, i, n.depths || [], a, c))(e, n);
                }
                if (!e) throw new v["default"]("No environment passed to template");
                if (!t || !t.main) throw new v["default"]("Unknown template object: " + typeof t);
                (t.main.decorator = t.main_d), e.VM.checkRevision(t.compiler);
                var i = {
                    strict: function (t, e) {
                        if (!(e in t)) throw new v["default"]('"' + e + '" not defined in ' + t);
                        return t[e];
                    },
                    lookup: function (t, e) {
                        for (var r = t.length, s = 0; r > s; s++) if (t[s] && null != t[s][e]) return t[s][e];
                    },
                    lambda: function (t, e) {
                        return "function" == typeof t ? t.call(e) : t;
                    },
                    escapeExpression: m.escapeExpression,
                    invokePartial: r,
                    fn: function (e) {
                        var r = t[e];
                        return (r.decorator = t[e + "_d"]), r;
                    },
                    programs: [],
                    program: function (t, e, r, s, i) {
                        var a = this.programs[t],
                            o = this.fn(t);
                        return e || i || s || r ? (a = n(this, t, o, e, r, s, i)) : a || (a = this.programs[t] = n(this, t, o)), a;
                    },
                    data: function (t, e) {
                        for (; t && e--; ) t = t._parent;
                        return t;
                    },
                    merge: function (t, e) {
                        var r = t || e;
                        return t && e && t !== e && (r = m.extend({}, e, t)), r;
                    },
                    nullContext: u({}),
                    noop: e.VM.noop,
                    compilerInfo: t.compiler,
                };
                return (
                    (s.isTop = !0),
                    (s._setup = function (r) {
                        r.partial
                            ? ((i.helpers = r.helpers), (i.partials = r.partials), (i.decorators = r.decorators))
                            : ((i.helpers = i.merge(r.helpers, e.helpers)), t.usePartial && (i.partials = i.merge(r.partials, e.partials)), (t.usePartial || t.useDecorators) && (i.decorators = i.merge(r.decorators, e.decorators)));
                    }),
                    (s._child = function (e, r, s, a) {
                        if (t.useBlockParams && !s) throw new v["default"]("must pass block params");
                        if (t.useDepths && !a) throw new v["default"]("must pass parent depths");
                        return n(i, e, t[e], r, 0, s, a);
                    }),
                    s
                );
            }
            function n(t, e, r, s, i, n, a) {
                function o(e) {
                    var i = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                        o = a;
                    return !a || e == a[0] || (e === t.nullContext && null === a[0]) || (o = [e].concat(a)), r(t, e, t.helpers, t.partials, i.data || s, n && [i.blockParams].concat(n), o);
                }
                return (o = h(r, o, t, a, s, n)), (o.program = e), (o.depth = a ? a.length : 0), (o.blockParams = i || 0), o;
            }
            function a(t, e, r) {
                return t ? t.call || r.name || ((r.name = t), (t = r.partials[t])) : (t = "@partial-block" === r.name ? r.data["partial-block"] : r.partials[r.name]), t;
            }
            function o(t, e, r) {
                var s = r.data && r.data["partial-block"];
                (r.partial = !0), r.ids && (r.data.contextPath = r.ids[0] || r.data.contextPath);
                var i = void 0;
                if (
                    (r.fn &&
                        r.fn !== c &&
                        !(function () {
                            r.data = y.createFrame(r.data);
                            var t = r.fn;
                            (i = r.data["partial-block"] = function (e) {
                                var r = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1];
                                return (r.data = y.createFrame(r.data)), (r.data["partial-block"] = s), t(e, r);
                            }),
                                t.partials && (r.partials = m.extend({}, r.partials, t.partials));
                        })(),
                    void 0 === t && i && (t = i),
                    void 0 === t)
                )
                    throw new v["default"]("The partial " + r.name + " could not be found");
                return t instanceof Function ? t(e, r) : void 0;
            }
            function c() {
                return "";
            }
            function l(t, e) {
                return (e && "root" in e) || ((e = e ? y.createFrame(e) : {}), (e.root = t)), e;
            }
            function h(t, e, r, s, i, n) {
                if (t.decorator) {
                    var a = {};
                    (e = t.decorator(e, a, r, s && s[0], i, n, s)), m.extend(e, a);
                }
                return e;
            }
            var u = r(23)["default"],
                p = r(3)["default"],
                f = r(1)["default"];
            (e.__esModule = !0), (e.checkRevision = s), (e.template = i), (e.wrapProgram = n), (e.resolvePartial = a), (e.invokePartial = o), (e.noop = c);
            var d = r(5),
                m = p(d),
                g = r(6),
                v = f(g),
                y = r(4);
        },
        function (t, e, r) {
            t.exports = { default: r(24), __esModule: !0 };
        },
        function (t, e, r) {
            r(25), (t.exports = r(30).Object.seal);
        },
        function (t, e, r) {
            var s = r(26);
            r(27)("seal", function (t) {
                return function (e) {
                    return t && s(e) ? t(e) : e;
                };
            });
        },
        function (t, e) {
            t.exports = function (t) {
                return "object" == typeof t ? null !== t : "function" == typeof t;
            };
        },
        function (t, e, r) {
            var s = r(28),
                i = r(30),
                n = r(33);
            t.exports = function (t, e) {
                var r = (i.Object || {})[t] || Object[t],
                    a = {};
                (a[t] = e(r)),
                    s(
                        s.S +
                            s.F *
                                n(function () {
                                    r(1);
                                }),
                        "Object",
                        a
                    );
            };
        },
        function (t, e, r) {
            var s = r(29),
                i = r(30),
                n = r(31),
                a = "prototype",
                o = function (t, e, r) {
                    var c,
                        l,
                        h,
                        u = t & o.F,
                        p = t & o.G,
                        f = t & o.S,
                        d = t & o.P,
                        m = t & o.B,
                        g = t & o.W,
                        v = p ? i : i[e] || (i[e] = {}),
                        y = p ? s : f ? s[e] : (s[e] || {})[a];
                    p && (r = e);
                    for (c in r)
                        (l = !u && y && c in y),
                            (l && c in v) ||
                                ((h = l ? y[c] : r[c]),
                                (v[c] =
                                    p && "function" != typeof y[c]
                                        ? r[c]
                                        : m && l
                                        ? n(h, s)
                                        : g && y[c] == h
                                        ? (function (t) {
                                              var e = function (e) {
                                                  return this instanceof t ? new t(e) : t(e);
                                              };
                                              return (e[a] = t[a]), e;
                                          })(h)
                                        : d && "function" == typeof h
                                        ? n(Function.call, h)
                                        : h),
                                d && ((v[a] || (v[a] = {}))[c] = h));
                };
            (o.F = 1), (o.G = 2), (o.S = 4), (o.P = 8), (o.B = 16), (o.W = 32), (t.exports = o);
        },
        function (t, e) {
            var r = (t.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")());
            "number" == typeof __g && (__g = r);
        },
        function (t, e) {
            var r = (t.exports = { version: "1.2.6" });
            "number" == typeof __e && (__e = r);
        },
        function (t, e, r) {
            var s = r(32);
            t.exports = function (t, e, r) {
                if ((s(t), void 0 === e)) return t;
                switch (r) {
                    case 1:
                        return function (r) {
                            return t.call(e, r);
                        };
                    case 2:
                        return function (r, s) {
                            return t.call(e, r, s);
                        };
                    case 3:
                        return function (r, s, i) {
                            return t.call(e, r, s, i);
                        };
                }
                return function () {
                    return t.apply(e, arguments);
                };
            };
        },
        function (t, e) {
            t.exports = function (t) {
                if ("function" != typeof t) throw TypeError(t + " is not a function!");
                return t;
            };
        },
        function (t, e) {
            t.exports = function (t) {
                try {
                    return !!t();
                } catch (e) {
                    return !0;
                }
            };
        },
        function (t, e) {
            (function (r) {
                "use strict";
                (e.__esModule = !0),
                    (e["default"] = function (t) {
                        var e = "undefined" != typeof r ? r : window,
                            s = e.Handlebars;
                        t.noConflict = function () {
                            return e.Handlebars === t && (e.Handlebars = s), t;
                        };
                    }),
                    (t.exports = e["default"]);
            }.call(
                e,
                (function () {
                    return this;
                })()
            ));
        },
        function (t, e) {
            "use strict";
            e.__esModule = !0;
            var r = {
                helpers: {
                    helperExpression: function (t) {
                        return "SubExpression" === t.type || (("MustacheStatement" === t.type || "BlockStatement" === t.type) && !!((t.params && t.params.length) || t.hash));
                    },
                    scopedId: function (t) {
                        return /^\.|this\b/.test(t.original);
                    },
                    simpleId: function (t) {
                        return 1 === t.parts.length && !r.helpers.scopedId(t) && !t.depth;
                    },
                },
            };
            (e["default"] = r), (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s(t, e) {
                if ("Program" === t.type) return t;
                (o["default"].yy = f),
                    (f.locInfo = function (t) {
                        return new f.SourceLocation(e && e.srcName, t);
                    });
                var r = new l["default"](e);
                return r.accept(o["default"].parse(t));
            }
            var i = r(1)["default"],
                n = r(3)["default"];
            (e.__esModule = !0), (e.parse = s);
            var a = r(37),
                o = i(a),
                c = r(38),
                l = i(c),
                h = r(40),
                u = n(h),
                p = r(5);
            e.parser = o["default"];
            var f = {};
            p.extend(f, u);
        },
        function (t, e) {
            "use strict";
            e.__esModule = !0;
            var r = (function () {
                function t() {
                    this.yy = {};
                }
                var e = {
                        trace: function () {},
                        yy: {},
                        symbols_: {
                            error: 2,
                            root: 3,
                            program: 4,
                            EOF: 5,
                            program_repetition0: 6,
                            statement: 7,
                            mustache: 8,
                            block: 9,
                            rawBlock: 10,
                            partial: 11,
                            partialBlock: 12,
                            content: 13,
                            COMMENT: 14,
                            CONTENT: 15,
                            openRawBlock: 16,
                            rawBlock_repetition_plus0: 17,
                            END_RAW_BLOCK: 18,
                            OPEN_RAW_BLOCK: 19,
                            helperName: 20,
                            openRawBlock_repetition0: 21,
                            openRawBlock_option0: 22,
                            CLOSE_RAW_BLOCK: 23,
                            openBlock: 24,
                            block_option0: 25,
                            closeBlock: 26,
                            openInverse: 27,
                            block_option1: 28,
                            OPEN_BLOCK: 29,
                            openBlock_repetition0: 30,
                            openBlock_option0: 31,
                            openBlock_option1: 32,
                            CLOSE: 33,
                            OPEN_INVERSE: 34,
                            openInverse_repetition0: 35,
                            openInverse_option0: 36,
                            openInverse_option1: 37,
                            openInverseChain: 38,
                            OPEN_INVERSE_CHAIN: 39,
                            openInverseChain_repetition0: 40,
                            openInverseChain_option0: 41,
                            openInverseChain_option1: 42,
                            inverseAndProgram: 43,
                            INVERSE: 44,
                            inverseChain: 45,
                            inverseChain_option0: 46,
                            OPEN_ENDBLOCK: 47,
                            OPEN: 48,
                            mustache_repetition0: 49,
                            mustache_option0: 50,
                            OPEN_UNESCAPED: 51,
                            mustache_repetition1: 52,
                            mustache_option1: 53,
                            CLOSE_UNESCAPED: 54,
                            OPEN_PARTIAL: 55,
                            partialName: 56,
                            partial_repetition0: 57,
                            partial_option0: 58,
                            openPartialBlock: 59,
                            OPEN_PARTIAL_BLOCK: 60,
                            openPartialBlock_repetition0: 61,
                            openPartialBlock_option0: 62,
                            param: 63,
                            sexpr: 64,
                            OPEN_SEXPR: 65,
                            sexpr_repetition0: 66,
                            sexpr_option0: 67,
                            CLOSE_SEXPR: 68,
                            hash: 69,
                            hash_repetition_plus0: 70,
                            hashSegment: 71,
                            ID: 72,
                            EQUALS: 73,
                            blockParams: 74,
                            OPEN_BLOCK_PARAMS: 75,
                            blockParams_repetition_plus0: 76,
                            CLOSE_BLOCK_PARAMS: 77,
                            path: 78,
                            dataName: 79,
                            STRING: 80,
                            NUMBER: 81,
                            BOOLEAN: 82,
                            UNDEFINED: 83,
                            NULL: 84,
                            DATA: 85,
                            pathSegments: 86,
                            SEP: 87,
                            $accept: 0,
                            $end: 1,
                        },
                        terminals_: {
                            2: "error",
                            5: "EOF",
                            14: "COMMENT",
                            15: "CONTENT",
                            18: "END_RAW_BLOCK",
                            19: "OPEN_RAW_BLOCK",
                            23: "CLOSE_RAW_BLOCK",
                            29: "OPEN_BLOCK",
                            33: "CLOSE",
                            34: "OPEN_INVERSE",
                            39: "OPEN_INVERSE_CHAIN",
                            44: "INVERSE",
                            47: "OPEN_ENDBLOCK",
                            48: "OPEN",
                            51: "OPEN_UNESCAPED",
                            54: "CLOSE_UNESCAPED",
                            55: "OPEN_PARTIAL",
                            60: "OPEN_PARTIAL_BLOCK",
                            65: "OPEN_SEXPR",
                            68: "CLOSE_SEXPR",
                            72: "ID",
                            73: "EQUALS",
                            75: "OPEN_BLOCK_PARAMS",
                            77: "CLOSE_BLOCK_PARAMS",
                            80: "STRING",
                            81: "NUMBER",
                            82: "BOOLEAN",
                            83: "UNDEFINED",
                            84: "NULL",
                            85: "DATA",
                            87: "SEP",
                        },
                        productions_: [
                            0,
                            [3, 2],
                            [4, 1],
                            [7, 1],
                            [7, 1],
                            [7, 1],
                            [7, 1],
                            [7, 1],
                            [7, 1],
                            [7, 1],
                            [13, 1],
                            [10, 3],
                            [16, 5],
                            [9, 4],
                            [9, 4],
                            [24, 6],
                            [27, 6],
                            [38, 6],
                            [43, 2],
                            [45, 3],
                            [45, 1],
                            [26, 3],
                            [8, 5],
                            [8, 5],
                            [11, 5],
                            [12, 3],
                            [59, 5],
                            [63, 1],
                            [63, 1],
                            [64, 5],
                            [69, 1],
                            [71, 3],
                            [74, 3],
                            [20, 1],
                            [20, 1],
                            [20, 1],
                            [20, 1],
                            [20, 1],
                            [20, 1],
                            [20, 1],
                            [56, 1],
                            [56, 1],
                            [79, 2],
                            [78, 1],
                            [86, 3],
                            [86, 1],
                            [6, 0],
                            [6, 2],
                            [17, 1],
                            [17, 2],
                            [21, 0],
                            [21, 2],
                            [22, 0],
                            [22, 1],
                            [25, 0],
                            [25, 1],
                            [28, 0],
                            [28, 1],
                            [30, 0],
                            [30, 2],
                            [31, 0],
                            [31, 1],
                            [32, 0],
                            [32, 1],
                            [35, 0],
                            [35, 2],
                            [36, 0],
                            [36, 1],
                            [37, 0],
                            [37, 1],
                            [40, 0],
                            [40, 2],
                            [41, 0],
                            [41, 1],
                            [42, 0],
                            [42, 1],
                            [46, 0],
                            [46, 1],
                            [49, 0],
                            [49, 2],
                            [50, 0],
                            [50, 1],
                            [52, 0],
                            [52, 2],
                            [53, 0],
                            [53, 1],
                            [57, 0],
                            [57, 2],
                            [58, 0],
                            [58, 1],
                            [61, 0],
                            [61, 2],
                            [62, 0],
                            [62, 1],
                            [66, 0],
                            [66, 2],
                            [67, 0],
                            [67, 1],
                            [70, 1],
                            [70, 2],
                            [76, 1],
                            [76, 2],
                        ],
                        performAction: function (t, e, r, s, i, n, a) {
                            var o = n.length - 1;
                            switch (i) {
                                case 1:
                                    return n[o - 1];
                                case 2:
                                    this.$ = s.prepareProgram(n[o]);
                                    break;
                                case 3:
                                    this.$ = n[o];
                                    break;
                                case 4:
                                    this.$ = n[o];
                                    break;
                                case 5:
                                    this.$ = n[o];
                                    break;
                                case 6:
                                    this.$ = n[o];
                                    break;
                                case 7:
                                    this.$ = n[o];
                                    break;
                                case 8:
                                    this.$ = n[o];
                                    break;
                                case 9:
                                    this.$ = { type: "CommentStatement", value: s.stripComment(n[o]), strip: s.stripFlags(n[o], n[o]), loc: s.locInfo(this._$) };
                                    break;
                                case 10:
                                    this.$ = { type: "ContentStatement", original: n[o], value: n[o], loc: s.locInfo(this._$) };
                                    break;
                                case 11:
                                    this.$ = s.prepareRawBlock(n[o - 2], n[o - 1], n[o], this._$);
                                    break;
                                case 12:
                                    this.$ = { path: n[o - 3], params: n[o - 2], hash: n[o - 1] };
                                    break;
                                case 13:
                                    this.$ = s.prepareBlock(n[o - 3], n[o - 2], n[o - 1], n[o], !1, this._$);
                                    break;
                                case 14:
                                    this.$ = s.prepareBlock(n[o - 3], n[o - 2], n[o - 1], n[o], !0, this._$);
                                    break;
                                case 15:
                                    this.$ = { open: n[o - 5], path: n[o - 4], params: n[o - 3], hash: n[o - 2], blockParams: n[o - 1], strip: s.stripFlags(n[o - 5], n[o]) };
                                    break;
                                case 16:
                                    this.$ = { path: n[o - 4], params: n[o - 3], hash: n[o - 2], blockParams: n[o - 1], strip: s.stripFlags(n[o - 5], n[o]) };
                                    break;
                                case 17:
                                    this.$ = { path: n[o - 4], params: n[o - 3], hash: n[o - 2], blockParams: n[o - 1], strip: s.stripFlags(n[o - 5], n[o]) };
                                    break;
                                case 18:
                                    this.$ = { strip: s.stripFlags(n[o - 1], n[o - 1]), program: n[o] };
                                    break;
                                case 19:
                                    var c = s.prepareBlock(n[o - 2], n[o - 1], n[o], n[o], !1, this._$),
                                        l = s.prepareProgram([c], n[o - 1].loc);
                                    (l.chained = !0), (this.$ = { strip: n[o - 2].strip, program: l, chain: !0 });
                                    break;
                                case 20:
                                    this.$ = n[o];
                                    break;
                                case 21:
                                    this.$ = { path: n[o - 1], strip: s.stripFlags(n[o - 2], n[o]) };
                                    break;
                                case 22:
                                    this.$ = s.prepareMustache(n[o - 3], n[o - 2], n[o - 1], n[o - 4], s.stripFlags(n[o - 4], n[o]), this._$);
                                    break;
                                case 23:
                                    this.$ = s.prepareMustache(n[o - 3], n[o - 2], n[o - 1], n[o - 4], s.stripFlags(n[o - 4], n[o]), this._$);
                                    break;
                                case 24:
                                    this.$ = { type: "PartialStatement", name: n[o - 3], params: n[o - 2], hash: n[o - 1], indent: "", strip: s.stripFlags(n[o - 4], n[o]), loc: s.locInfo(this._$) };
                                    break;
                                case 25:
                                    this.$ = s.preparePartialBlock(n[o - 2], n[o - 1], n[o], this._$);
                                    break;
                                case 26:
                                    this.$ = { path: n[o - 3], params: n[o - 2], hash: n[o - 1], strip: s.stripFlags(n[o - 4], n[o]) };
                                    break;
                                case 27:
                                    this.$ = n[o];
                                    break;
                                case 28:
                                    this.$ = n[o];
                                    break;
                                case 29:
                                    this.$ = { type: "SubExpression", path: n[o - 3], params: n[o - 2], hash: n[o - 1], loc: s.locInfo(this._$) };
                                    break;
                                case 30:
                                    this.$ = { type: "Hash", pairs: n[o], loc: s.locInfo(this._$) };
                                    break;
                                case 31:
                                    this.$ = { type: "HashPair", key: s.id(n[o - 2]), value: n[o], loc: s.locInfo(this._$) };
                                    break;
                                case 32:
                                    this.$ = s.id(n[o - 1]);
                                    break;
                                case 33:
                                    this.$ = n[o];
                                    break;
                                case 34:
                                    this.$ = n[o];
                                    break;
                                case 35:
                                    this.$ = { type: "StringLiteral", value: n[o], original: n[o], loc: s.locInfo(this._$) };
                                    break;
                                case 36:
                                    this.$ = { type: "NumberLiteral", value: Number(n[o]), original: Number(n[o]), loc: s.locInfo(this._$) };
                                    break;
                                case 37:
                                    this.$ = { type: "BooleanLiteral", value: "true" === n[o], original: "true" === n[o], loc: s.locInfo(this._$) };
                                    break;
                                case 38:
                                    this.$ = { type: "UndefinedLiteral", original: void 0, value: void 0, loc: s.locInfo(this._$) };
                                    break;
                                case 39:
                                    this.$ = { type: "NullLiteral", original: null, value: null, loc: s.locInfo(this._$) };
                                    break;
                                case 40:
                                    this.$ = n[o];
                                    break;
                                case 41:
                                    this.$ = n[o];
                                    break;
                                case 42:
                                    this.$ = s.preparePath(!0, n[o], this._$);
                                    break;
                                case 43:
                                    this.$ = s.preparePath(!1, n[o], this._$);
                                    break;
                                case 44:
                                    n[o - 2].push({ part: s.id(n[o]), original: n[o], separator: n[o - 1] }), (this.$ = n[o - 2]);
                                    break;
                                case 45:
                                    this.$ = [{ part: s.id(n[o]), original: n[o] }];
                                    break;
                                case 46:
                                    this.$ = [];
                                    break;
                                case 47:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 48:
                                    this.$ = [n[o]];
                                    break;
                                case 49:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 50:
                                    this.$ = [];
                                    break;
                                case 51:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 58:
                                    this.$ = [];
                                    break;
                                case 59:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 64:
                                    this.$ = [];
                                    break;
                                case 65:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 70:
                                    this.$ = [];
                                    break;
                                case 71:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 78:
                                    this.$ = [];
                                    break;
                                case 79:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 82:
                                    this.$ = [];
                                    break;
                                case 83:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 86:
                                    this.$ = [];
                                    break;
                                case 87:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 90:
                                    this.$ = [];
                                    break;
                                case 91:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 94:
                                    this.$ = [];
                                    break;
                                case 95:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 98:
                                    this.$ = [n[o]];
                                    break;
                                case 99:
                                    n[o - 1].push(n[o]);
                                    break;
                                case 100:
                                    this.$ = [n[o]];
                                    break;
                                case 101:
                                    n[o - 1].push(n[o]);
                            }
                        },
                        table: [
                            { 3: 1, 4: 2, 5: [2, 46], 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 1: [3] },
                            { 5: [1, 4] },
                            {
                                5: [2, 2],
                                7: 5,
                                8: 6,
                                9: 7,
                                10: 8,
                                11: 9,
                                12: 10,
                                13: 11,
                                14: [1, 12],
                                15: [1, 20],
                                16: 17,
                                19: [1, 23],
                                24: 15,
                                27: 16,
                                29: [1, 21],
                                34: [1, 22],
                                39: [2, 2],
                                44: [2, 2],
                                47: [2, 2],
                                48: [1, 13],
                                51: [1, 14],
                                55: [1, 18],
                                59: 19,
                                60: [1, 24],
                            },
                            { 1: [2, 1] },
                            { 5: [2, 47], 14: [2, 47], 15: [2, 47], 19: [2, 47], 29: [2, 47], 34: [2, 47], 39: [2, 47], 44: [2, 47], 47: [2, 47], 48: [2, 47], 51: [2, 47], 55: [2, 47], 60: [2, 47] },
                            { 5: [2, 3], 14: [2, 3], 15: [2, 3], 19: [2, 3], 29: [2, 3], 34: [2, 3], 39: [2, 3], 44: [2, 3], 47: [2, 3], 48: [2, 3], 51: [2, 3], 55: [2, 3], 60: [2, 3] },
                            { 5: [2, 4], 14: [2, 4], 15: [2, 4], 19: [2, 4], 29: [2, 4], 34: [2, 4], 39: [2, 4], 44: [2, 4], 47: [2, 4], 48: [2, 4], 51: [2, 4], 55: [2, 4], 60: [2, 4] },
                            { 5: [2, 5], 14: [2, 5], 15: [2, 5], 19: [2, 5], 29: [2, 5], 34: [2, 5], 39: [2, 5], 44: [2, 5], 47: [2, 5], 48: [2, 5], 51: [2, 5], 55: [2, 5], 60: [2, 5] },
                            { 5: [2, 6], 14: [2, 6], 15: [2, 6], 19: [2, 6], 29: [2, 6], 34: [2, 6], 39: [2, 6], 44: [2, 6], 47: [2, 6], 48: [2, 6], 51: [2, 6], 55: [2, 6], 60: [2, 6] },
                            { 5: [2, 7], 14: [2, 7], 15: [2, 7], 19: [2, 7], 29: [2, 7], 34: [2, 7], 39: [2, 7], 44: [2, 7], 47: [2, 7], 48: [2, 7], 51: [2, 7], 55: [2, 7], 60: [2, 7] },
                            { 5: [2, 8], 14: [2, 8], 15: [2, 8], 19: [2, 8], 29: [2, 8], 34: [2, 8], 39: [2, 8], 44: [2, 8], 47: [2, 8], 48: [2, 8], 51: [2, 8], 55: [2, 8], 60: [2, 8] },
                            { 5: [2, 9], 14: [2, 9], 15: [2, 9], 19: [2, 9], 29: [2, 9], 34: [2, 9], 39: [2, 9], 44: [2, 9], 47: [2, 9], 48: [2, 9], 51: [2, 9], 55: [2, 9], 60: [2, 9] },
                            { 20: 25, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 20: 36, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 4: 37, 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 39: [2, 46], 44: [2, 46], 47: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 4: 38, 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 44: [2, 46], 47: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 13: 40, 15: [1, 20], 17: 39 },
                            { 20: 42, 56: 41, 64: 43, 65: [1, 44], 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 4: 45, 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 47: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 5: [2, 10], 14: [2, 10], 15: [2, 10], 18: [2, 10], 19: [2, 10], 29: [2, 10], 34: [2, 10], 39: [2, 10], 44: [2, 10], 47: [2, 10], 48: [2, 10], 51: [2, 10], 55: [2, 10], 60: [2, 10] },
                            { 20: 46, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 20: 47, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 20: 48, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 20: 42, 56: 49, 64: 43, 65: [1, 44], 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 33: [2, 78], 49: 50, 65: [2, 78], 72: [2, 78], 80: [2, 78], 81: [2, 78], 82: [2, 78], 83: [2, 78], 84: [2, 78], 85: [2, 78] },
                            { 23: [2, 33], 33: [2, 33], 54: [2, 33], 65: [2, 33], 68: [2, 33], 72: [2, 33], 75: [2, 33], 80: [2, 33], 81: [2, 33], 82: [2, 33], 83: [2, 33], 84: [2, 33], 85: [2, 33] },
                            { 23: [2, 34], 33: [2, 34], 54: [2, 34], 65: [2, 34], 68: [2, 34], 72: [2, 34], 75: [2, 34], 80: [2, 34], 81: [2, 34], 82: [2, 34], 83: [2, 34], 84: [2, 34], 85: [2, 34] },
                            { 23: [2, 35], 33: [2, 35], 54: [2, 35], 65: [2, 35], 68: [2, 35], 72: [2, 35], 75: [2, 35], 80: [2, 35], 81: [2, 35], 82: [2, 35], 83: [2, 35], 84: [2, 35], 85: [2, 35] },
                            { 23: [2, 36], 33: [2, 36], 54: [2, 36], 65: [2, 36], 68: [2, 36], 72: [2, 36], 75: [2, 36], 80: [2, 36], 81: [2, 36], 82: [2, 36], 83: [2, 36], 84: [2, 36], 85: [2, 36] },
                            { 23: [2, 37], 33: [2, 37], 54: [2, 37], 65: [2, 37], 68: [2, 37], 72: [2, 37], 75: [2, 37], 80: [2, 37], 81: [2, 37], 82: [2, 37], 83: [2, 37], 84: [2, 37], 85: [2, 37] },
                            { 23: [2, 38], 33: [2, 38], 54: [2, 38], 65: [2, 38], 68: [2, 38], 72: [2, 38], 75: [2, 38], 80: [2, 38], 81: [2, 38], 82: [2, 38], 83: [2, 38], 84: [2, 38], 85: [2, 38] },
                            { 23: [2, 39], 33: [2, 39], 54: [2, 39], 65: [2, 39], 68: [2, 39], 72: [2, 39], 75: [2, 39], 80: [2, 39], 81: [2, 39], 82: [2, 39], 83: [2, 39], 84: [2, 39], 85: [2, 39] },
                            { 23: [2, 43], 33: [2, 43], 54: [2, 43], 65: [2, 43], 68: [2, 43], 72: [2, 43], 75: [2, 43], 80: [2, 43], 81: [2, 43], 82: [2, 43], 83: [2, 43], 84: [2, 43], 85: [2, 43], 87: [1, 51] },
                            { 72: [1, 35], 86: 52 },
                            { 23: [2, 45], 33: [2, 45], 54: [2, 45], 65: [2, 45], 68: [2, 45], 72: [2, 45], 75: [2, 45], 80: [2, 45], 81: [2, 45], 82: [2, 45], 83: [2, 45], 84: [2, 45], 85: [2, 45], 87: [2, 45] },
                            { 52: 53, 54: [2, 82], 65: [2, 82], 72: [2, 82], 80: [2, 82], 81: [2, 82], 82: [2, 82], 83: [2, 82], 84: [2, 82], 85: [2, 82] },
                            { 25: 54, 38: 56, 39: [1, 58], 43: 57, 44: [1, 59], 45: 55, 47: [2, 54] },
                            { 28: 60, 43: 61, 44: [1, 59], 47: [2, 56] },
                            { 13: 63, 15: [1, 20], 18: [1, 62] },
                            { 15: [2, 48], 18: [2, 48] },
                            { 33: [2, 86], 57: 64, 65: [2, 86], 72: [2, 86], 80: [2, 86], 81: [2, 86], 82: [2, 86], 83: [2, 86], 84: [2, 86], 85: [2, 86] },
                            { 33: [2, 40], 65: [2, 40], 72: [2, 40], 80: [2, 40], 81: [2, 40], 82: [2, 40], 83: [2, 40], 84: [2, 40], 85: [2, 40] },
                            { 33: [2, 41], 65: [2, 41], 72: [2, 41], 80: [2, 41], 81: [2, 41], 82: [2, 41], 83: [2, 41], 84: [2, 41], 85: [2, 41] },
                            { 20: 65, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 26: 66, 47: [1, 67] },
                            { 30: 68, 33: [2, 58], 65: [2, 58], 72: [2, 58], 75: [2, 58], 80: [2, 58], 81: [2, 58], 82: [2, 58], 83: [2, 58], 84: [2, 58], 85: [2, 58] },
                            { 33: [2, 64], 35: 69, 65: [2, 64], 72: [2, 64], 75: [2, 64], 80: [2, 64], 81: [2, 64], 82: [2, 64], 83: [2, 64], 84: [2, 64], 85: [2, 64] },
                            { 21: 70, 23: [2, 50], 65: [2, 50], 72: [2, 50], 80: [2, 50], 81: [2, 50], 82: [2, 50], 83: [2, 50], 84: [2, 50], 85: [2, 50] },
                            { 33: [2, 90], 61: 71, 65: [2, 90], 72: [2, 90], 80: [2, 90], 81: [2, 90], 82: [2, 90], 83: [2, 90], 84: [2, 90], 85: [2, 90] },
                            { 20: 75, 33: [2, 80], 50: 72, 63: 73, 64: 76, 65: [1, 44], 69: 74, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 72: [1, 80] },
                            { 23: [2, 42], 33: [2, 42], 54: [2, 42], 65: [2, 42], 68: [2, 42], 72: [2, 42], 75: [2, 42], 80: [2, 42], 81: [2, 42], 82: [2, 42], 83: [2, 42], 84: [2, 42], 85: [2, 42], 87: [1, 51] },
                            { 20: 75, 53: 81, 54: [2, 84], 63: 82, 64: 76, 65: [1, 44], 69: 83, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 26: 84, 47: [1, 67] },
                            { 47: [2, 55] },
                            { 4: 85, 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 39: [2, 46], 44: [2, 46], 47: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 47: [2, 20] },
                            { 20: 86, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 4: 87, 6: 3, 14: [2, 46], 15: [2, 46], 19: [2, 46], 29: [2, 46], 34: [2, 46], 47: [2, 46], 48: [2, 46], 51: [2, 46], 55: [2, 46], 60: [2, 46] },
                            { 26: 88, 47: [1, 67] },
                            { 47: [2, 57] },
                            { 5: [2, 11], 14: [2, 11], 15: [2, 11], 19: [2, 11], 29: [2, 11], 34: [2, 11], 39: [2, 11], 44: [2, 11], 47: [2, 11], 48: [2, 11], 51: [2, 11], 55: [2, 11], 60: [2, 11] },
                            { 15: [2, 49], 18: [2, 49] },
                            { 20: 75, 33: [2, 88], 58: 89, 63: 90, 64: 76, 65: [1, 44], 69: 91, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 65: [2, 94], 66: 92, 68: [2, 94], 72: [2, 94], 80: [2, 94], 81: [2, 94], 82: [2, 94], 83: [2, 94], 84: [2, 94], 85: [2, 94] },
                            { 5: [2, 25], 14: [2, 25], 15: [2, 25], 19: [2, 25], 29: [2, 25], 34: [2, 25], 39: [2, 25], 44: [2, 25], 47: [2, 25], 48: [2, 25], 51: [2, 25], 55: [2, 25], 60: [2, 25] },
                            { 20: 93, 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            {
                                20: 75,
                                31: 94,
                                33: [2, 60],
                                63: 95,
                                64: 76,
                                65: [1, 44],
                                69: 96,
                                70: 77,
                                71: 78,
                                72: [1, 79],
                                75: [2, 60],
                                78: 26,
                                79: 27,
                                80: [1, 28],
                                81: [1, 29],
                                82: [1, 30],
                                83: [1, 31],
                                84: [1, 32],
                                85: [1, 34],
                                86: 33,
                            },
                            {
                                20: 75,
                                33: [2, 66],
                                36: 97,
                                63: 98,
                                64: 76,
                                65: [1, 44],
                                69: 99,
                                70: 77,
                                71: 78,
                                72: [1, 79],
                                75: [2, 66],
                                78: 26,
                                79: 27,
                                80: [1, 28],
                                81: [1, 29],
                                82: [1, 30],
                                83: [1, 31],
                                84: [1, 32],
                                85: [1, 34],
                                86: 33,
                            },
                            { 20: 75, 22: 100, 23: [2, 52], 63: 101, 64: 76, 65: [1, 44], 69: 102, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 20: 75, 33: [2, 92], 62: 103, 63: 104, 64: 76, 65: [1, 44], 69: 105, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 33: [1, 106] },
                            { 33: [2, 79], 65: [2, 79], 72: [2, 79], 80: [2, 79], 81: [2, 79], 82: [2, 79], 83: [2, 79], 84: [2, 79], 85: [2, 79] },
                            { 33: [2, 81] },
                            { 23: [2, 27], 33: [2, 27], 54: [2, 27], 65: [2, 27], 68: [2, 27], 72: [2, 27], 75: [2, 27], 80: [2, 27], 81: [2, 27], 82: [2, 27], 83: [2, 27], 84: [2, 27], 85: [2, 27] },
                            { 23: [2, 28], 33: [2, 28], 54: [2, 28], 65: [2, 28], 68: [2, 28], 72: [2, 28], 75: [2, 28], 80: [2, 28], 81: [2, 28], 82: [2, 28], 83: [2, 28], 84: [2, 28], 85: [2, 28] },
                            { 23: [2, 30], 33: [2, 30], 54: [2, 30], 68: [2, 30], 71: 107, 72: [1, 108], 75: [2, 30] },
                            { 23: [2, 98], 33: [2, 98], 54: [2, 98], 68: [2, 98], 72: [2, 98], 75: [2, 98] },
                            { 23: [2, 45], 33: [2, 45], 54: [2, 45], 65: [2, 45], 68: [2, 45], 72: [2, 45], 73: [1, 109], 75: [2, 45], 80: [2, 45], 81: [2, 45], 82: [2, 45], 83: [2, 45], 84: [2, 45], 85: [2, 45], 87: [2, 45] },
                            { 23: [2, 44], 33: [2, 44], 54: [2, 44], 65: [2, 44], 68: [2, 44], 72: [2, 44], 75: [2, 44], 80: [2, 44], 81: [2, 44], 82: [2, 44], 83: [2, 44], 84: [2, 44], 85: [2, 44], 87: [2, 44] },
                            { 54: [1, 110] },
                            { 54: [2, 83], 65: [2, 83], 72: [2, 83], 80: [2, 83], 81: [2, 83], 82: [2, 83], 83: [2, 83], 84: [2, 83], 85: [2, 83] },
                            { 54: [2, 85] },
                            { 5: [2, 13], 14: [2, 13], 15: [2, 13], 19: [2, 13], 29: [2, 13], 34: [2, 13], 39: [2, 13], 44: [2, 13], 47: [2, 13], 48: [2, 13], 51: [2, 13], 55: [2, 13], 60: [2, 13] },
                            { 38: 56, 39: [1, 58], 43: 57, 44: [1, 59], 45: 112, 46: 111, 47: [2, 76] },
                            { 33: [2, 70], 40: 113, 65: [2, 70], 72: [2, 70], 75: [2, 70], 80: [2, 70], 81: [2, 70], 82: [2, 70], 83: [2, 70], 84: [2, 70], 85: [2, 70] },
                            { 47: [2, 18] },
                            { 5: [2, 14], 14: [2, 14], 15: [2, 14], 19: [2, 14], 29: [2, 14], 34: [2, 14], 39: [2, 14], 44: [2, 14], 47: [2, 14], 48: [2, 14], 51: [2, 14], 55: [2, 14], 60: [2, 14] },
                            { 33: [1, 114] },
                            { 33: [2, 87], 65: [2, 87], 72: [2, 87], 80: [2, 87], 81: [2, 87], 82: [2, 87], 83: [2, 87], 84: [2, 87], 85: [2, 87] },
                            { 33: [2, 89] },
                            { 20: 75, 63: 116, 64: 76, 65: [1, 44], 67: 115, 68: [2, 96], 69: 117, 70: 77, 71: 78, 72: [1, 79], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 33: [1, 118] },
                            { 32: 119, 33: [2, 62], 74: 120, 75: [1, 121] },
                            { 33: [2, 59], 65: [2, 59], 72: [2, 59], 75: [2, 59], 80: [2, 59], 81: [2, 59], 82: [2, 59], 83: [2, 59], 84: [2, 59], 85: [2, 59] },
                            { 33: [2, 61], 75: [2, 61] },
                            { 33: [2, 68], 37: 122, 74: 123, 75: [1, 121] },
                            { 33: [2, 65], 65: [2, 65], 72: [2, 65], 75: [2, 65], 80: [2, 65], 81: [2, 65], 82: [2, 65], 83: [2, 65], 84: [2, 65], 85: [2, 65] },
                            { 33: [2, 67], 75: [2, 67] },
                            { 23: [1, 124] },
                            { 23: [2, 51], 65: [2, 51], 72: [2, 51], 80: [2, 51], 81: [2, 51], 82: [2, 51], 83: [2, 51], 84: [2, 51], 85: [2, 51] },
                            { 23: [2, 53] },
                            { 33: [1, 125] },
                            { 33: [2, 91], 65: [2, 91], 72: [2, 91], 80: [2, 91], 81: [2, 91], 82: [2, 91], 83: [2, 91], 84: [2, 91], 85: [2, 91] },
                            { 33: [2, 93] },
                            { 5: [2, 22], 14: [2, 22], 15: [2, 22], 19: [2, 22], 29: [2, 22], 34: [2, 22], 39: [2, 22], 44: [2, 22], 47: [2, 22], 48: [2, 22], 51: [2, 22], 55: [2, 22], 60: [2, 22] },
                            { 23: [2, 99], 33: [2, 99], 54: [2, 99], 68: [2, 99], 72: [2, 99], 75: [2, 99] },
                            { 73: [1, 109] },
                            { 20: 75, 63: 126, 64: 76, 65: [1, 44], 72: [1, 35], 78: 26, 79: 27, 80: [1, 28], 81: [1, 29], 82: [1, 30], 83: [1, 31], 84: [1, 32], 85: [1, 34], 86: 33 },
                            { 5: [2, 23], 14: [2, 23], 15: [2, 23], 19: [2, 23], 29: [2, 23], 34: [2, 23], 39: [2, 23], 44: [2, 23], 47: [2, 23], 48: [2, 23], 51: [2, 23], 55: [2, 23], 60: [2, 23] },
                            { 47: [2, 19] },
                            { 47: [2, 77] },
                            {
                                20: 75,
                                33: [2, 72],
                                41: 127,
                                63: 128,
                                64: 76,
                                65: [1, 44],
                                69: 129,
                                70: 77,
                                71: 78,
                                72: [1, 79],
                                75: [2, 72],
                                78: 26,
                                79: 27,
                                80: [1, 28],
                                81: [1, 29],
                                82: [1, 30],
                                83: [1, 31],
                                84: [1, 32],
                                85: [1, 34],
                                86: 33,
                            },
                            { 5: [2, 24], 14: [2, 24], 15: [2, 24], 19: [2, 24], 29: [2, 24], 34: [2, 24], 39: [2, 24], 44: [2, 24], 47: [2, 24], 48: [2, 24], 51: [2, 24], 55: [2, 24], 60: [2, 24] },
                            { 68: [1, 130] },
                            { 65: [2, 95], 68: [2, 95], 72: [2, 95], 80: [2, 95], 81: [2, 95], 82: [2, 95], 83: [2, 95], 84: [2, 95], 85: [2, 95] },
                            { 68: [2, 97] },
                            { 5: [2, 21], 14: [2, 21], 15: [2, 21], 19: [2, 21], 29: [2, 21], 34: [2, 21], 39: [2, 21], 44: [2, 21], 47: [2, 21], 48: [2, 21], 51: [2, 21], 55: [2, 21], 60: [2, 21] },
                            { 33: [1, 131] },
                            { 33: [2, 63] },
                            { 72: [1, 133], 76: 132 },
                            { 33: [1, 134] },
                            { 33: [2, 69] },
                            { 15: [2, 12] },
                            { 14: [2, 26], 15: [2, 26], 19: [2, 26], 29: [2, 26], 34: [2, 26], 47: [2, 26], 48: [2, 26], 51: [2, 26], 55: [2, 26], 60: [2, 26] },
                            { 23: [2, 31], 33: [2, 31], 54: [2, 31], 68: [2, 31], 72: [2, 31], 75: [2, 31] },
                            { 33: [2, 74], 42: 135, 74: 136, 75: [1, 121] },
                            { 33: [2, 71], 65: [2, 71], 72: [2, 71], 75: [2, 71], 80: [2, 71], 81: [2, 71], 82: [2, 71], 83: [2, 71], 84: [2, 71], 85: [2, 71] },
                            { 33: [2, 73], 75: [2, 73] },
                            { 23: [2, 29], 33: [2, 29], 54: [2, 29], 65: [2, 29], 68: [2, 29], 72: [2, 29], 75: [2, 29], 80: [2, 29], 81: [2, 29], 82: [2, 29], 83: [2, 29], 84: [2, 29], 85: [2, 29] },
                            { 14: [2, 15], 15: [2, 15], 19: [2, 15], 29: [2, 15], 34: [2, 15], 39: [2, 15], 44: [2, 15], 47: [2, 15], 48: [2, 15], 51: [2, 15], 55: [2, 15], 60: [2, 15] },
                            { 72: [1, 138], 77: [1, 137] },
                            { 72: [2, 100], 77: [2, 100] },
                            { 14: [2, 16], 15: [2, 16], 19: [2, 16], 29: [2, 16], 34: [2, 16], 44: [2, 16], 47: [2, 16], 48: [2, 16], 51: [2, 16], 55: [2, 16], 60: [2, 16] },
                            { 33: [1, 139] },
                            { 33: [2, 75] },
                            { 33: [2, 32] },
                            { 72: [2, 101], 77: [2, 101] },
                            { 14: [2, 17], 15: [2, 17], 19: [2, 17], 29: [2, 17], 34: [2, 17], 39: [2, 17], 44: [2, 17], 47: [2, 17], 48: [2, 17], 51: [2, 17], 55: [2, 17], 60: [2, 17] },
                        ],
                        defaultActions: {
                            4: [2, 1],
                            55: [2, 55],
                            57: [2, 20],
                            61: [2, 57],
                            74: [2, 81],
                            83: [2, 85],
                            87: [2, 18],
                            91: [2, 89],
                            102: [2, 53],
                            105: [2, 93],
                            111: [2, 19],
                            112: [2, 77],
                            117: [2, 97],
                            120: [2, 63],
                            123: [2, 69],
                            124: [2, 12],
                            136: [2, 75],
                            137: [2, 32],
                        },
                        parseError: function (t, e) {
                            throw new Error(t);
                        },
                        parse: function (t) {
                            function e() {
                                var t;
                                return (t = r.lexer.lex() || 1), "number" != typeof t && (t = r.symbols_[t] || t), t;
                            }
                            var r = this,
                                s = [0],
                                i = [null],
                                n = [],
                                a = this.table,
                                o = "",
                                c = 0,
                                l = 0,
                                h = 0;
                            this.lexer.setInput(t), (this.lexer.yy = this.yy), (this.yy.lexer = this.lexer), (this.yy.parser = this), "undefined" == typeof this.lexer.yylloc && (this.lexer.yylloc = {});
                            var u = this.lexer.yylloc;
                            n.push(u);
                            var p = this.lexer.options && this.lexer.options.ranges;
                            "function" == typeof this.yy.parseError && (this.parseError = this.yy.parseError);
                            for (var f, d, m, g, v, y, k, S, b, _ = {}; ; ) {
                                if (
                                    ((m = s[s.length - 1]),
                                    this.defaultActions[m] ? (g = this.defaultActions[m]) : ((null === f || "undefined" == typeof f) && (f = e()), (g = a[m] && a[m][f])),
                                    "undefined" == typeof g || !g.length || !g[0])
                                ) {
                                    var P = "";
                                    if (!h) {
                                        b = [];
                                        for (y in a[m]) this.terminals_[y] && y > 2 && b.push("'" + this.terminals_[y] + "'");
                                        (P = this.lexer.showPosition
                                            ? "Parse error on line " + (c + 1) + ":\n" + this.lexer.showPosition() + "\nExpecting " + b.join(", ") + ", got '" + (this.terminals_[f] || f) + "'"
                                            : "Parse error on line " + (c + 1) + ": Unexpected " + (1 == f ? "end of input" : "'" + (this.terminals_[f] || f) + "'")),
                                            this.parseError(P, { text: this.lexer.match, token: this.terminals_[f] || f, line: this.lexer.yylineno, loc: u, expected: b });
                                    }
                                }
                                if (g[0] instanceof Array && g.length > 1) throw new Error("Parse Error: multiple actions possible at state: " + m + ", token: " + f);
                                switch (g[0]) {
                                    case 1:
                                        s.push(f),
                                            i.push(this.lexer.yytext),
                                            n.push(this.lexer.yylloc),
                                            s.push(g[1]),
                                            (f = null),
                                            d ? ((f = d), (d = null)) : ((l = this.lexer.yyleng), (o = this.lexer.yytext), (c = this.lexer.yylineno), (u = this.lexer.yylloc), h > 0 && h--);
                                        break;
                                    case 2:
                                        if (
                                            ((k = this.productions_[g[1]][1]),
                                            (_.$ = i[i.length - k]),
                                            (_._$ = { first_line: n[n.length - (k || 1)].first_line, last_line: n[n.length - 1].last_line, first_column: n[n.length - (k || 1)].first_column, last_column: n[n.length - 1].last_column }),
                                            p && (_._$.range = [n[n.length - (k || 1)].range[0], n[n.length - 1].range[1]]),
                                            (v = this.performAction.call(_, o, l, c, this.yy, g[1], i, n)),
                                            "undefined" != typeof v)
                                        )
                                            return v;
                                        k && ((s = s.slice(0, -1 * k * 2)), (i = i.slice(0, -1 * k)), (n = n.slice(0, -1 * k))),
                                            s.push(this.productions_[g[1]][0]),
                                            i.push(_.$),
                                            n.push(_._$),
                                            (S = a[s[s.length - 2]][s[s.length - 1]]),
                                            s.push(S);
                                        break;
                                    case 3:
                                        return !0;
                                }
                            }
                            return !0;
                        },
                    },
                    r = (function () {
                        var t = {
                            EOF: 1,
                            parseError: function (t, e) {
                                if (!this.yy.parser) throw new Error(t);
                                this.yy.parser.parseError(t, e);
                            },
                            setInput: function (t) {
                                return (
                                    (this._input = t),
                                    (this._more = this._less = this.done = !1),
                                    (this.yylineno = this.yyleng = 0),
                                    (this.yytext = this.matched = this.match = ""),
                                    (this.conditionStack = ["INITIAL"]),
                                    (this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }),
                                    this.options.ranges && (this.yylloc.range = [0, 0]),
                                    (this.offset = 0),
                                    this
                                );
                            },
                            input: function () {
                                var t = this._input[0];
                                (this.yytext += t), this.yyleng++, this.offset++, (this.match += t), (this.matched += t);
                                var e = t.match(/(?:\r\n?|\n).*/g);
                                return e ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, (this._input = this._input.slice(1)), t;
                            },
                            unput: function (t) {
                                var e = t.length,
                                    r = t.split(/(?:\r\n?|\n)/g);
                                (this._input = t + this._input), (this.yytext = this.yytext.substr(0, this.yytext.length - e - 1)), (this.offset -= e);
                                var s = this.match.split(/(?:\r\n?|\n)/g);
                                (this.match = this.match.substr(0, this.match.length - 1)), (this.matched = this.matched.substr(0, this.matched.length - 1)), r.length - 1 && (this.yylineno -= r.length - 1);
                                var i = this.yylloc.range;
                                return (
                                    (this.yylloc = {
                                        first_line: this.yylloc.first_line,
                                        last_line: this.yylineno + 1,
                                        first_column: this.yylloc.first_column,
                                        last_column: r ? (r.length === s.length ? this.yylloc.first_column : 0) + s[s.length - r.length].length - r[0].length : this.yylloc.first_column - e,
                                    }),
                                    this.options.ranges && (this.yylloc.range = [i[0], i[0] + this.yyleng - e]),
                                    this
                                );
                            },
                            more: function () {
                                return (this._more = !0), this;
                            },
                            less: function (t) {
                                this.unput(this.match.slice(t));
                            },
                            pastInput: function () {
                                var t = this.matched.substr(0, this.matched.length - this.match.length);
                                return (t.length > 20 ? "..." : "") + t.substr(-20).replace(/\n/g, "");
                            },
                            upcomingInput: function () {
                                var t = this.match;
                                return t.length < 20 && (t += this._input.substr(0, 20 - t.length)), (t.substr(0, 20) + (t.length > 20 ? "..." : "")).replace(/\n/g, "");
                            },
                            showPosition: function () {
                                var t = this.pastInput(),
                                    e = new Array(t.length + 1).join("-");
                                return t + this.upcomingInput() + "\n" + e + "^";
                            },
                            next: function () {
                                if (this.done) return this.EOF;
                                this._input || (this.done = !0);
                                var t, e, r, s, i;
                                this._more || ((this.yytext = ""), (this.match = ""));
                                for (var n = this._currentRules(), a = 0; a < n.length && ((r = this._input.match(this.rules[n[a]])), !r || (e && !(r[0].length > e[0].length)) || ((e = r), (s = a), this.options.flex)); a++);
                                return e
                                    ? ((i = e[0].match(/(?:\r\n?|\n).*/g)),
                                      i && (this.yylineno += i.length),
                                      (this.yylloc = {
                                          first_line: this.yylloc.last_line,
                                          last_line: this.yylineno + 1,
                                          first_column: this.yylloc.last_column,
                                          last_column: i ? i[i.length - 1].length - i[i.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length,
                                      }),
                                      (this.yytext += e[0]),
                                      (this.match += e[0]),
                                      (this.matches = e),
                                      (this.yyleng = this.yytext.length),
                                      this.options.ranges && (this.yylloc.range = [this.offset, (this.offset += this.yyleng)]),
                                      (this._more = !1),
                                      (this._input = this._input.slice(e[0].length)),
                                      (this.matched += e[0]),
                                      (t = this.performAction.call(this, this.yy, this, n[s], this.conditionStack[this.conditionStack.length - 1])),
                                      this.done && this._input && (this.done = !1),
                                      t ? t : void 0)
                                    : "" === this._input
                                    ? this.EOF
                                    : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), { text: "", token: null, line: this.yylineno });
                            },
                            lex: function () {
                                var t = this.next();
                                return "undefined" != typeof t ? t : this.lex();
                            },
                            begin: function (t) {
                                this.conditionStack.push(t);
                            },
                            popState: function () {
                                return this.conditionStack.pop();
                            },
                            _currentRules: function () {
                                return this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules;
                            },
                            topState: function () {
                                return this.conditionStack[this.conditionStack.length - 2];
                            },
                            pushState: function (t) {
                                this.begin(t);
                            },
                        };
                        return (
                            (t.options = {}),
                            (t.performAction = function (t, e, r, s) {
                                function i(t, r) {
                                    return (e.yytext = e.yytext.substr(t, e.yyleng - r));
                                }
                                switch (r) {
                                    case 0:
                                        if (("\\\\" === e.yytext.slice(-2) ? (i(0, 1), this.begin("mu")) : "\\" === e.yytext.slice(-1) ? (i(0, 1), this.begin("emu")) : this.begin("mu"), e.yytext)) return 15;
                                        break;
                                    case 1:
                                        return 15;
                                    case 2:
                                        return this.popState(), 15;
                                    case 3:
                                        return this.begin("raw"), 15;
                                    case 4:
                                        return this.popState(), "raw" === this.conditionStack[this.conditionStack.length - 1] ? 15 : ((e.yytext = e.yytext.substr(5, e.yyleng - 9)), "END_RAW_BLOCK");
                                    case 5:
                                        return 15;
                                    case 6:
                                        return this.popState(), 14;
                                    case 7:
                                        return 65;
                                    case 8:
                                        return 68;
                                    case 9:
                                        return 19;
                                    case 10:
                                        return this.popState(), this.begin("raw"), 23;
                                    case 11:
                                        return 55;
                                    case 12:
                                        return 60;
                                    case 13:
                                        return 29;
                                    case 14:
                                        return 47;
                                    case 15:
                                        return this.popState(), 44;
                                    case 16:
                                        return this.popState(), 44;
                                    case 17:
                                        return 34;
                                    case 18:
                                        return 39;
                                    case 19:
                                        return 51;
                                    case 20:
                                        return 48;
                                    case 21:
                                        this.unput(e.yytext), this.popState(), this.begin("com");
                                        break;
                                    case 22:
                                        return this.popState(), 14;
                                    case 23:
                                        return 48;
                                    case 24:
                                        return 73;
                                    case 25:
                                        return 72;
                                    case 26:
                                        return 72;
                                    case 27:
                                        return 87;
                                    case 28:
                                        break;
                                    case 29:
                                        return this.popState(), 54;
                                    case 30:
                                        return this.popState(), 33;
                                    case 31:
                                        return (e.yytext = i(1, 2).replace(/\\"/g, '"')), 80;
                                    case 32:
                                        return (e.yytext = i(1, 2).replace(/\\'/g, "'")), 80;
                                    case 33:
                                        return 85;
                                    case 34:
                                        return 82;
                                    case 35:
                                        return 82;
                                    case 36:
                                        return 83;
                                    case 37:
                                        return 84;
                                    case 38:
                                        return 81;
                                    case 39:
                                        return 75;
                                    case 40:
                                        return 77;
                                    case 41:
                                        return 72;
                                    case 42:
                                        return (e.yytext = e.yytext.replace(/\\([\\\]])/g, "$1")), 72;
                                    case 43:
                                        return "INVALID";
                                    case 44:
                                        return 5;
                                }
                            }),
                            (t.rules = [
                                /^(?:[^\x00]*?(?=(\{\{)))/,
                                /^(?:[^\x00]+)/,
                                /^(?:[^\x00]{2,}?(?=(\{\{|\\\{\{|\\\\\{\{|$)))/,
                                /^(?:\{\{\{\{(?=[^\/]))/,
                                /^(?:\{\{\{\{\/[^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=[=}\s\/.])\}\}\}\})/,
                                /^(?:[^\x00]*?(?=(\{\{\{\{)))/,
                                /^(?:[\s\S]*?--(~)?\}\})/,
                                /^(?:\()/,
                                /^(?:\))/,
                                /^(?:\{\{\{\{)/,
                                /^(?:\}\}\}\})/,
                                /^(?:\{\{(~)?>)/,
                                /^(?:\{\{(~)?#>)/,
                                /^(?:\{\{(~)?#\*?)/,
                                /^(?:\{\{(~)?\/)/,
                                /^(?:\{\{(~)?\^\s*(~)?\}\})/,
                                /^(?:\{\{(~)?\s*else\s*(~)?\}\})/,
                                /^(?:\{\{(~)?\^)/,
                                /^(?:\{\{(~)?\s*else\b)/,
                                /^(?:\{\{(~)?\{)/,
                                /^(?:\{\{(~)?&)/,
                                /^(?:\{\{(~)?!--)/,
                                /^(?:\{\{(~)?![\s\S]*?\}\})/,
                                /^(?:\{\{(~)?\*?)/,
                                /^(?:=)/,
                                /^(?:\.\.)/,
                                /^(?:\.(?=([=~}\s\/.)|])))/,
                                /^(?:[\/.])/,
                                /^(?:\s+)/,
                                /^(?:\}(~)?\}\})/,
                                /^(?:(~)?\}\})/,
                                /^(?:"(\\["]|[^"])*")/,
                                /^(?:'(\\[']|[^'])*')/,
                                /^(?:@)/,
                                /^(?:true(?=([~}\s)])))/,
                                /^(?:false(?=([~}\s)])))/,
                                /^(?:undefined(?=([~}\s)])))/,
                                /^(?:null(?=([~}\s)])))/,
                                /^(?:-?[0-9]+(?:\.[0-9]+)?(?=([~}\s)])))/,
                                /^(?:as\s+\|)/,
                                /^(?:\|)/,
                                /^(?:([^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=([=~}\s\/.)|]))))/,
                                /^(?:\[(\\\]|[^\]])*\])/,
                                /^(?:.)/,
                                /^(?:$)/,
                            ]),
                            (t.conditions = {
                                mu: { rules: [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44], inclusive: !1 },
                                emu: { rules: [2], inclusive: !1 },
                                com: { rules: [6], inclusive: !1 },
                                raw: { rules: [3, 4, 5], inclusive: !1 },
                                INITIAL: { rules: [0, 1, 44], inclusive: !0 },
                            }),
                            t
                        );
                    })();
                return (e.lexer = r), (t.prototype = e), (e.Parser = t), new t();
            })();
            (e["default"] = r), (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s() {
                var t = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
                this.options = t;
            }
            function i(t, e, r) {
                void 0 === e && (e = t.length);
                var s = t[e - 1],
                    i = t[e - 2];
                return s ? ("ContentStatement" === s.type ? (i || !r ? /\r?\n\s*?$/ : /(^|\r?\n)\s*?$/).test(s.original) : void 0) : r;
            }
            function n(t, e, r) {
                void 0 === e && (e = -1);
                var s = t[e + 1],
                    i = t[e + 2];
                return s ? ("ContentStatement" === s.type ? (i || !r ? /^\s*?\r?\n/ : /^\s*?(\r?\n|$)/).test(s.original) : void 0) : r;
            }
            function a(t, e, r) {
                var s = t[null == e ? 0 : e + 1];
                if (s && "ContentStatement" === s.type && (r || !s.rightStripped)) {
                    var i = s.value;
                    (s.value = s.value.replace(r ? /^\s+/ : /^[ \t]*\r?\n?/, "")), (s.rightStripped = s.value !== i);
                }
            }
            function o(t, e, r) {
                var s = t[null == e ? t.length - 1 : e - 1];
                if (s && "ContentStatement" === s.type && (r || !s.leftStripped)) {
                    var i = s.value;
                    return (s.value = s.value.replace(r ? /\s+$/ : /[ \t]+$/, "")), (s.leftStripped = s.value !== i), s.leftStripped;
                }
            }
            var c = r(1)["default"];
            e.__esModule = !0;
            var l = r(39),
                h = c(l);
            (s.prototype = new h["default"]()),
                (s.prototype.Program = function (t) {
                    var e = !this.options.ignoreStandalone,
                        r = !this.isRootSeen;
                    this.isRootSeen = !0;
                    for (var s = t.body, c = 0, l = s.length; l > c; c++) {
                        var h = s[c],
                            u = this.accept(h);
                        if (u) {
                            var p = i(s, c, r),
                                f = n(s, c, r),
                                d = u.openStandalone && p,
                                m = u.closeStandalone && f,
                                g = u.inlineStandalone && p && f;
                            u.close && a(s, c, !0),
                                u.open && o(s, c, !0),
                                e && g && (a(s, c), o(s, c) && "PartialStatement" === h.type && (h.indent = /([ \t]+$)/.exec(s[c - 1].original)[1])),
                                e && d && (a((h.program || h.inverse).body), o(s, c)),
                                e && m && (a(s, c), o((h.inverse || h.program).body));
                        }
                    }
                    return t;
                }),
                (s.prototype.BlockStatement = s.prototype.DecoratorBlock = s.prototype.PartialBlockStatement = function (t) {
                    this.accept(t.program), this.accept(t.inverse);
                    var e = t.program || t.inverse,
                        r = t.program && t.inverse,
                        s = r,
                        c = r;
                    if (r && r.chained) for (s = r.body[0].program; c.chained; ) c = c.body[c.body.length - 1].program;
                    var l = { open: t.openStrip.open, close: t.closeStrip.close, openStandalone: n(e.body), closeStandalone: i((s || e).body) };
                    if ((t.openStrip.close && a(e.body, null, !0), r)) {
                        var h = t.inverseStrip;
                        h.open && o(e.body, null, !0), h.close && a(s.body, null, !0), t.closeStrip.open && o(c.body, null, !0), !this.options.ignoreStandalone && i(e.body) && n(s.body) && (o(e.body), a(s.body));
                    } else t.closeStrip.open && o(e.body, null, !0);
                    return l;
                }),
                (s.prototype.Decorator = s.prototype.MustacheStatement = function (t) {
                    return t.strip;
                }),
                (s.prototype.PartialStatement = s.prototype.CommentStatement = function (t) {
                    var e = t.strip || {};
                    return { inlineStandalone: !0, open: e.open, close: e.close };
                }),
                (e["default"] = s),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s() {
                this.parents = [];
            }
            function i(t) {
                this.acceptRequired(t, "path"), this.acceptArray(t.params), this.acceptKey(t, "hash");
            }
            function n(t) {
                i.call(this, t), this.acceptKey(t, "program"), this.acceptKey(t, "inverse");
            }
            function a(t) {
                this.acceptRequired(t, "name"), this.acceptArray(t.params), this.acceptKey(t, "hash");
            }
            var o = r(1)["default"];
            e.__esModule = !0;
            var c = r(6),
                l = o(c);
            (s.prototype = {
                constructor: s,
                mutating: !1,
                acceptKey: function (t, e) {
                    var r = this.accept(t[e]);
                    if (this.mutating) {
                        if (r && !s.prototype[r.type]) throw new l["default"]('Unexpected node type "' + r.type + '" found when accepting ' + e + " on " + t.type);
                        t[e] = r;
                    }
                },
                acceptRequired: function (t, e) {
                    if ((this.acceptKey(t, e), !t[e])) throw new l["default"](t.type + " requires " + e);
                },
                acceptArray: function (t) {
                    for (var e = 0, r = t.length; r > e; e++) this.acceptKey(t, e), t[e] || (t.splice(e, 1), e--, r--);
                },
                accept: function (t) {
                    if (t) {
                        if (!this[t.type]) throw new l["default"]("Unknown type: " + t.type, t);
                        this.current && this.parents.unshift(this.current), (this.current = t);
                        var e = this[t.type](t);
                        return (this.current = this.parents.shift()), !this.mutating || e ? e : e !== !1 ? t : void 0;
                    }
                },
                Program: function (t) {
                    this.acceptArray(t.body);
                },
                MustacheStatement: i,
                Decorator: i,
                BlockStatement: n,
                DecoratorBlock: n,
                PartialStatement: a,
                PartialBlockStatement: function (t) {
                    a.call(this, t), this.acceptKey(t, "program");
                },
                ContentStatement: function () {},
                CommentStatement: function () {},
                SubExpression: i,
                PathExpression: function () {},
                StringLiteral: function () {},
                NumberLiteral: function () {},
                BooleanLiteral: function () {},
                UndefinedLiteral: function () {},
                NullLiteral: function () {},
                Hash: function (t) {
                    this.acceptArray(t.pairs);
                },
                HashPair: function (t) {
                    this.acceptRequired(t, "value");
                },
            }),
                (e["default"] = s),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s(t, e) {
                if (((e = e.path ? e.path.original : e), t.path.original !== e)) {
                    var r = { loc: t.path.loc };
                    throw new g["default"](t.path.original + " doesn't match " + e, r);
                }
            }
            function i(t, e) {
                (this.source = t), (this.start = { line: e.first_line, column: e.first_column }), (this.end = { line: e.last_line, column: e.last_column });
            }
            function n(t) {
                return /^\[.*\]$/.test(t) ? t.substr(1, t.length - 2) : t;
            }
            function a(t, e) {
                return { open: "~" === t.charAt(2), close: "~" === e.charAt(e.length - 3) };
            }
            function o(t) {
                return t.replace(/^\{\{~?\!-?-?/, "").replace(/-?-?~?\}\}$/, "");
            }
            function c(t, e, r) {
                r = this.locInfo(r);
                for (var s = t ? "@" : "", i = [], n = 0, a = "", o = 0, c = e.length; c > o; o++) {
                    var l = e[o].part,
                        h = e[o].original !== l;
                    if (((s += (e[o].separator || "") + l), h || (".." !== l && "." !== l && "this" !== l))) i.push(l);
                    else {
                        if (i.length > 0) throw new g["default"]("Invalid path: " + s, { loc: r });
                        ".." === l && (n++, (a += "../"));
                    }
                }
                return { type: "PathExpression", data: t, depth: n, parts: i, original: s, loc: r };
            }
            function l(t, e, r, s, i, n) {
                var a = s.charAt(3) || s.charAt(2),
                    o = "{" !== a && "&" !== a,
                    c = /\*/.test(s);
                return { type: c ? "Decorator" : "MustacheStatement", path: t, params: e, hash: r, escaped: o, strip: i, loc: this.locInfo(n) };
            }
            function h(t, e, r, i) {
                s(t, r), (i = this.locInfo(i));
                var n = { type: "Program", body: e, strip: {}, loc: i };
                return { type: "BlockStatement", path: t.path, params: t.params, hash: t.hash, program: n, openStrip: {}, inverseStrip: {}, closeStrip: {}, loc: i };
            }
            function u(t, e, r, i, n, a) {
                i && i.path && s(t, i);
                var o = /\*/.test(t.open);
                e.blockParams = t.blockParams;
                var c = void 0,
                    l = void 0;
                if (r) {
                    if (o) throw new g["default"]("Unexpected inverse block on decorator", r);
                    r.chain && (r.program.body[0].closeStrip = i.strip), (l = r.strip), (c = r.program);
                }
                return (
                    n && ((n = c), (c = e), (e = n)),
                    { type: o ? "DecoratorBlock" : "BlockStatement", path: t.path, params: t.params, hash: t.hash, program: e, inverse: c, openStrip: t.strip, inverseStrip: l, closeStrip: i && i.strip, loc: this.locInfo(a) }
                );
            }
            function p(t, e) {
                if (!e && t.length) {
                    var r = t[0].loc,
                        s = t[t.length - 1].loc;
                    r && s && (e = { source: r.source, start: { line: r.start.line, column: r.start.column }, end: { line: s.end.line, column: s.end.column } });
                }
                return { type: "Program", body: t, strip: {}, loc: e };
            }
            function f(t, e, r, i) {
                return s(t, r), { type: "PartialBlockStatement", name: t.path, params: t.params, hash: t.hash, program: e, openStrip: t.strip, closeStrip: r && r.strip, loc: this.locInfo(i) };
            }
            var d = r(1)["default"];
            (e.__esModule = !0),
                (e.SourceLocation = i),
                (e.id = n),
                (e.stripFlags = a),
                (e.stripComment = o),
                (e.preparePath = c),
                (e.prepareMustache = l),
                (e.prepareRawBlock = h),
                (e.prepareBlock = u),
                (e.prepareProgram = p),
                (e.preparePartialBlock = f);
            var m = r(6),
                g = d(m);
        },
        function (t, e, r) {
            "use strict";
            function s() {}
            function i(t, e, r) {
                if (null == t || ("string" != typeof t && "Program" !== t.type)) throw new h["default"]("You must pass a string or Handlebars AST to Handlebars.precompile. You passed " + t);
                (e = e || {}), "data" in e || (e.data = !0), e.compat && (e.useDepths = !0);
                var s = r.parse(t, e),
                    i = new r.Compiler().compile(s, e);
                return new r.JavaScriptCompiler().compile(i, e);
            }
            function n(t, e, r) {
                function s() {
                    var s = r.parse(t, e),
                        i = new r.Compiler().compile(s, e),
                        n = new r.JavaScriptCompiler().compile(i, e, void 0, !0);
                    return r.template(n);
                }
                function i(t, e) {
                    return n || (n = s()), n.call(this, t, e);
                }
                if ((void 0 === e && (e = {}), null == t || ("string" != typeof t && "Program" !== t.type))) throw new h["default"]("You must pass a string or Handlebars AST to Handlebars.compile. You passed " + t);
                (e = u.extend({}, e)), "data" in e || (e.data = !0), e.compat && (e.useDepths = !0);
                var n = void 0;
                return (
                    (i._setup = function (t) {
                        return n || (n = s()), n._setup(t);
                    }),
                    (i._child = function (t, e, r, i) {
                        return n || (n = s()), n._child(t, e, r, i);
                    }),
                    i
                );
            }
            function a(t, e) {
                if (t === e) return !0;
                if (u.isArray(t) && u.isArray(e) && t.length === e.length) {
                    for (var r = 0; r < t.length; r++) if (!a(t[r], e[r])) return !1;
                    return !0;
                }
            }
            function o(t) {
                if (!t.path.parts) {
                    var e = t.path;
                    t.path = { type: "PathExpression", data: !1, depth: 0, parts: [e.original + ""], original: e.original + "", loc: e.loc };
                }
            }
            var c = r(1)["default"];
            (e.__esModule = !0), (e.Compiler = s), (e.precompile = i), (e.compile = n);
            var l = r(6),
                h = c(l),
                u = r(5),
                p = r(35),
                f = c(p),
                d = [].slice;
            s.prototype = {
                compiler: s,
                equals: function (t) {
                    var e = this.opcodes.length;
                    if (t.opcodes.length !== e) return !1;
                    for (var r = 0; e > r; r++) {
                        var s = this.opcodes[r],
                            i = t.opcodes[r];
                        if (s.opcode !== i.opcode || !a(s.args, i.args)) return !1;
                    }
                    e = this.children.length;
                    for (var r = 0; e > r; r++) if (!this.children[r].equals(t.children[r])) return !1;
                    return !0;
                },
                guid: 0,
                compile: function (t, e) {
                    (this.sourceNode = []), (this.opcodes = []), (this.children = []), (this.options = e), (this.stringParams = e.stringParams), (this.trackIds = e.trackIds), (e.blockParams = e.blockParams || []);
                    var r = e.knownHelpers;
                    if (((e.knownHelpers = { helperMissing: !0, blockHelperMissing: !0, each: !0, if: !0, unless: !0, with: !0, log: !0, lookup: !0 }), r)) for (var s in r) s in r && (this.options.knownHelpers[s] = r[s]);
                    return this.accept(t);
                },
                compileProgram: function (t) {
                    var e = new this.compiler(),
                        r = e.compile(t, this.options),
                        s = this.guid++;
                    return (this.usePartial = this.usePartial || r.usePartial), (this.children[s] = r), (this.useDepths = this.useDepths || r.useDepths), s;
                },
                accept: function (t) {
                    if (!this[t.type]) throw new h["default"]("Unknown type: " + t.type, t);
                    this.sourceNode.unshift(t);
                    var e = this[t.type](t);
                    return this.sourceNode.shift(), e;
                },
                Program: function (t) {
                    this.options.blockParams.unshift(t.blockParams);
                    for (var e = t.body, r = e.length, s = 0; r > s; s++) this.accept(e[s]);
                    return this.options.blockParams.shift(), (this.isSimple = 1 === r), (this.blockParams = t.blockParams ? t.blockParams.length : 0), this;
                },
                BlockStatement: function (t) {
                    o(t);
                    var e = t.program,
                        r = t.inverse;
                    (e = e && this.compileProgram(e)), (r = r && this.compileProgram(r));
                    var s = this.classifySexpr(t);
                    "helper" === s
                        ? this.helperSexpr(t, e, r)
                        : "simple" === s
                        ? (this.simpleSexpr(t), this.opcode("pushProgram", e), this.opcode("pushProgram", r), this.opcode("emptyHash"), this.opcode("blockValue", t.path.original))
                        : (this.ambiguousSexpr(t, e, r), this.opcode("pushProgram", e), this.opcode("pushProgram", r), this.opcode("emptyHash"), this.opcode("ambiguousBlockValue")),
                        this.opcode("append");
                },
                DecoratorBlock: function (t) {
                    var e = t.program && this.compileProgram(t.program),
                        r = this.setupFullMustacheParams(t, e, void 0),
                        s = t.path;
                    (this.useDecorators = !0), this.opcode("registerDecorator", r.length, s.original);
                },
                PartialStatement: function (t) {
                    this.usePartial = !0;
                    var e = t.program;
                    e && (e = this.compileProgram(t.program));
                    var r = t.params;
                    if (r.length > 1) throw new h["default"]("Unsupported number of partial arguments: " + r.length, t);
                    r.length || (this.options.explicitPartialContext ? this.opcode("pushLiteral", "undefined") : r.push({ type: "PathExpression", parts: [], depth: 0 }));
                    var s = t.name.original,
                        i = "SubExpression" === t.name.type;
                    i && this.accept(t.name), this.setupFullMustacheParams(t, e, void 0, !0);
                    var n = t.indent || "";
                    this.options.preventIndent && n && (this.opcode("appendContent", n), (n = "")), this.opcode("invokePartial", i, s, n), this.opcode("append");
                },
                PartialBlockStatement: function (t) {
                    this.PartialStatement(t);
                },
                MustacheStatement: function (t) {
                    this.SubExpression(t), t.escaped && !this.options.noEscape ? this.opcode("appendEscaped") : this.opcode("append");
                },
                Decorator: function (t) {
                    this.DecoratorBlock(t);
                },
                ContentStatement: function (t) {
                    t.value && this.opcode("appendContent", t.value);
                },
                CommentStatement: function () {},
                SubExpression: function (t) {
                    o(t);
                    var e = this.classifySexpr(t);
                    "simple" === e ? this.simpleSexpr(t) : "helper" === e ? this.helperSexpr(t) : this.ambiguousSexpr(t);
                },
                ambiguousSexpr: function (t, e, r) {
                    var s = t.path,
                        i = s.parts[0],
                        n = null != e || null != r;
                    this.opcode("getContext", s.depth), this.opcode("pushProgram", e), this.opcode("pushProgram", r), (s.strict = !0), this.accept(s), this.opcode("invokeAmbiguous", i, n);
                },
                simpleSexpr: function (t) {
                    var e = t.path;
                    (e.strict = !0), this.accept(e), this.opcode("resolvePossibleLambda");
                },
                helperSexpr: function (t, e, r) {
                    var s = this.setupFullMustacheParams(t, e, r),
                        i = t.path,
                        n = i.parts[0];
                    if (this.options.knownHelpers[n]) this.opcode("invokeKnownHelper", s.length, n);
                    else {
                        if (this.options.knownHelpersOnly) throw new h["default"]("You specified knownHelpersOnly, but used the unknown helper " + n, t);
                        (i.strict = !0), (i.falsy = !0), this.accept(i), this.opcode("invokeHelper", s.length, i.original, f["default"].helpers.simpleId(i));
                    }
                },
                PathExpression: function (t) {
                    this.addDepth(t.depth), this.opcode("getContext", t.depth);
                    var e = t.parts[0],
                        r = f["default"].helpers.scopedId(t),
                        s = !t.depth && !r && this.blockParamIndex(e);
                    s
                        ? this.opcode("lookupBlockParam", s, t.parts)
                        : e
                        ? t.data
                            ? ((this.options.data = !0), this.opcode("lookupData", t.depth, t.parts, t.strict))
                            : this.opcode("lookupOnContext", t.parts, t.falsy, t.strict, r)
                        : this.opcode("pushContext");
                },
                StringLiteral: function (t) {
                    this.opcode("pushString", t.value);
                },
                NumberLiteral: function (t) {
                    this.opcode("pushLiteral", t.value);
                },
                BooleanLiteral: function (t) {
                    this.opcode("pushLiteral", t.value);
                },
                UndefinedLiteral: function () {
                    this.opcode("pushLiteral", "undefined");
                },
                NullLiteral: function () {
                    this.opcode("pushLiteral", "null");
                },
                Hash: function (t) {
                    var e = t.pairs,
                        r = 0,
                        s = e.length;
                    for (this.opcode("pushHash"); s > r; r++) this.pushParam(e[r].value);
                    for (; r--; ) this.opcode("assignToHash", e[r].key);
                    this.opcode("popHash");
                },
                opcode: function (t) {
                    this.opcodes.push({ opcode: t, args: d.call(arguments, 1), loc: this.sourceNode[0].loc });
                },
                addDepth: function (t) {
                    t && (this.useDepths = !0);
                },
                classifySexpr: function (t) {
                    var e = f["default"].helpers.simpleId(t.path),
                        r = e && !!this.blockParamIndex(t.path.parts[0]),
                        s = !r && f["default"].helpers.helperExpression(t),
                        i = !r && (s || e);
                    if (i && !s) {
                        var n = t.path.parts[0],
                            a = this.options;
                        a.knownHelpers[n] ? (s = !0) : a.knownHelpersOnly && (i = !1);
                    }
                    return s ? "helper" : i ? "ambiguous" : "simple";
                },
                pushParams: function (t) {
                    for (var e = 0, r = t.length; r > e; e++) this.pushParam(t[e]);
                },
                pushParam: function (t) {
                    var e = null != t.value ? t.value : t.original || "";
                    if (this.stringParams)
                        e.replace && (e = e.replace(/^(\.?\.\/)*/g, "").replace(/\//g, ".")),
                            t.depth && this.addDepth(t.depth),
                            this.opcode("getContext", t.depth || 0),
                            this.opcode("pushStringParam", e, t.type),
                            "SubExpression" === t.type && this.accept(t);
                    else {
                        if (this.trackIds) {
                            var r = void 0;
                            if ((!t.parts || f["default"].helpers.scopedId(t) || t.depth || (r = this.blockParamIndex(t.parts[0])), r)) {
                                var s = t.parts.slice(1).join(".");
                                this.opcode("pushId", "BlockParam", r, s);
                            } else
                                (e = t.original || e),
                                    e.replace &&
                                        (e = e
                                            .replace(/^this(?:\.|$)/, "")
                                            .replace(/^\.\//, "")
                                            .replace(/^\.$/, "")),
                                    this.opcode("pushId", t.type, e);
                        }
                        this.accept(t);
                    }
                },
                setupFullMustacheParams: function (t, e, r, s) {
                    var i = t.params;
                    return this.pushParams(i), this.opcode("pushProgram", e), this.opcode("pushProgram", r), t.hash ? this.accept(t.hash) : this.opcode("emptyHash", s), i;
                },
                blockParamIndex: function (t) {
                    for (var e = 0, r = this.options.blockParams.length; r > e; e++) {
                        var s = this.options.blockParams[e],
                            i = s && u.indexOf(s, t);
                        if (s && i >= 0) return [e, i];
                    }
                },
            };
        },
        function (t, e, r) {
            "use strict";
            function s(t) {
                this.value = t;
            }
            function i() {}
            function n(t, e, r, s) {
                var i = e.popStack(),
                    n = 0,
                    a = r.length;
                for (t && a--; a > n; n++) i = e.nameLookup(i, r[n], s);
                return t ? [e.aliasable("container.strict"), "(", i, ", ", e.quotedString(r[n]), ")"] : i;
            }
            var a = r(1)["default"];
            e.__esModule = !0;
            var o = r(4),
                c = r(6),
                l = a(c),
                h = r(5),
                u = r(43),
                p = a(u);
            (i.prototype = {
                nameLookup: function (t, e) {
                    return i.isValidJavaScriptVariableName(e) ? [t, ".", e] : [t, "[", JSON.stringify(e), "]"];
                },
                depthedLookup: function (t) {
                    return [this.aliasable("container.lookup"), '(depths, "', t, '")'];
                },
                compilerInfo: function () {
                    var t = o.COMPILER_REVISION,
                        e = o.REVISION_CHANGES[t];
                    return [t, e];
                },
                appendToBuffer: function (t, e, r) {
                    return h.isArray(t) || (t = [t]), (t = this.source.wrap(t, e)), this.environment.isSimple ? ["return ", t, ";"] : r ? ["buffer += ", t, ";"] : ((t.appendToBuffer = !0), t);
                },
                initializeBuffer: function () {
                    return this.quotedString("");
                },
                compile: function (t, e, r, s) {
                    (this.environment = t),
                        (this.options = e),
                        (this.stringParams = this.options.stringParams),
                        (this.trackIds = this.options.trackIds),
                        (this.precompile = !s),
                        (this.name = this.environment.name),
                        (this.isChild = !!r),
                        (this.context = r || { decorators: [], programs: [], environments: [] }),
                        this.preamble(),
                        (this.stackSlot = 0),
                        (this.stackVars = []),
                        (this.aliases = {}),
                        (this.registers = { list: [] }),
                        (this.hashes = []),
                        (this.compileStack = []),
                        (this.inlineStack = []),
                        (this.blockParams = []),
                        this.compileChildren(t, e),
                        (this.useDepths = this.useDepths || t.useDepths || t.useDecorators || this.options.compat),
                        (this.useBlockParams = this.useBlockParams || t.useBlockParams);
                    var i = t.opcodes,
                        n = void 0,
                        a = void 0,
                        o = void 0,
                        c = void 0;
                    for (o = 0, c = i.length; c > o; o++) (n = i[o]), (this.source.currentLocation = n.loc), (a = a || n.loc), this[n.opcode].apply(this, n.args);
                    if (((this.source.currentLocation = a), this.pushSource(""), this.stackSlot || this.inlineStack.length || this.compileStack.length)) throw new l["default"]("Compile completed with content left on stack");
                    this.decorators.isEmpty()
                        ? (this.decorators = void 0)
                        : ((this.useDecorators = !0),
                          this.decorators.prepend("var decorators = container.decorators;\n"),
                          this.decorators.push("return fn;"),
                          s
                              ? (this.decorators = Function.apply(this, ["fn", "props", "container", "depth0", "data", "blockParams", "depths", this.decorators.merge()]))
                              : (this.decorators.prepend("function(fn, props, container, depth0, data, blockParams, depths) {\n"), this.decorators.push("}\n"), (this.decorators = this.decorators.merge())));
                    var h = this.createFunctionContext(s);
                    if (this.isChild) return h;
                    var u = { compiler: this.compilerInfo(), main: h };
                    this.decorators && ((u.main_d = this.decorators), (u.useDecorators = !0));
                    var p = this.context,
                        f = p.programs,
                        d = p.decorators;
                    for (o = 0, c = f.length; c > o; o++) f[o] && ((u[o] = f[o]), d[o] && ((u[o + "_d"] = d[o]), (u.useDecorators = !0)));
                    return (
                        this.environment.usePartial && (u.usePartial = !0),
                        this.options.data && (u.useData = !0),
                        this.useDepths && (u.useDepths = !0),
                        this.useBlockParams && (u.useBlockParams = !0),
                        this.options.compat && (u.compat = !0),
                        s
                            ? (u.compilerOptions = this.options)
                            : ((u.compiler = JSON.stringify(u.compiler)),
                              (this.source.currentLocation = { start: { line: 1, column: 0 } }),
                              (u = this.objectLiteral(u)),
                              e.srcName ? ((u = u.toStringWithSourceMap({ file: e.destName })), (u.map = u.map && u.map.toString())) : (u = u.toString())),
                        u
                    );
                },
                preamble: function () {
                    (this.lastContext = 0), (this.source = new p["default"](this.options.srcName)), (this.decorators = new p["default"](this.options.srcName));
                },
                createFunctionContext: function (t) {
                    var e = "",
                        r = this.stackVars.concat(this.registers.list);
                    r.length > 0 && (e += ", " + r.join(", "));
                    var s = 0;
                    for (var i in this.aliases) {
                        var n = this.aliases[i];
                        this.aliases.hasOwnProperty(i) && n.children && n.referenceCount > 1 && ((e += ", alias" + ++s + "=" + i), (n.children[0] = "alias" + s));
                    }
                    var a = ["container", "depth0", "helpers", "partials", "data"];
                    (this.useBlockParams || this.useDepths) && a.push("blockParams"), this.useDepths && a.push("depths");
                    var o = this.mergeSource(e);
                    return t ? (a.push(o), Function.apply(this, a)) : this.source.wrap(["function(", a.join(","), ") {\n  ", o, "}"]);
                },
                mergeSource: function (t) {
                    var e = this.environment.isSimple,
                        r = !this.forceBuffer,
                        s = void 0,
                        i = void 0,
                        n = void 0,
                        a = void 0;
                    return (
                        this.source.each(function (t) {
                            t.appendToBuffer ? (n ? t.prepend("  + ") : (n = t), (a = t)) : (n && (i ? n.prepend("buffer += ") : (s = !0), a.add(";"), (n = a = void 0)), (i = !0), e || (r = !1));
                        }),
                        r
                            ? n
                                ? (n.prepend("return "), a.add(";"))
                                : i || this.source.push('return "";')
                            : ((t += ", buffer = " + (s ? "" : this.initializeBuffer())), n ? (n.prepend("return buffer + "), a.add(";")) : this.source.push("return buffer;")),
                        t && this.source.prepend("var " + t.substring(2) + (s ? "" : ";\n")),
                        this.source.merge()
                    );
                },
                blockValue: function (t) {
                    var e = this.aliasable("helpers.blockHelperMissing"),
                        r = [this.contextName(0)];
                    this.setupHelperArgs(t, 0, r);
                    var s = this.popStack();
                    r.splice(1, 0, s), this.push(this.source.functionCall(e, "call", r));
                },
                ambiguousBlockValue: function () {
                    var t = this.aliasable("helpers.blockHelperMissing"),
                        e = [this.contextName(0)];
                    this.setupHelperArgs("", 0, e, !0), this.flushInline();
                    var r = this.topStack();
                    e.splice(1, 0, r), this.pushSource(["if (!", this.lastHelper, ") { ", r, " = ", this.source.functionCall(t, "call", e), "}"]);
                },
                appendContent: function (t) {
                    this.pendingContent ? (t = this.pendingContent + t) : (this.pendingLocation = this.source.currentLocation), (this.pendingContent = t);
                },
                append: function () {
                    if (this.isInline())
                        this.replaceStack(function (t) {
                            return [" != null ? ", t, ' : ""'];
                        }),
                            this.pushSource(this.appendToBuffer(this.popStack()));
                    else {
                        var t = this.popStack();
                        this.pushSource(["if (", t, " != null) { ", this.appendToBuffer(t, void 0, !0), " }"]), this.environment.isSimple && this.pushSource(["else { ", this.appendToBuffer("''", void 0, !0), " }"]);
                    }
                },
                appendEscaped: function () {
                    this.pushSource(this.appendToBuffer([this.aliasable("container.escapeExpression"), "(", this.popStack(), ")"]));
                },
                getContext: function (t) {
                    this.lastContext = t;
                },
                pushContext: function () {
                    this.pushStackLiteral(this.contextName(this.lastContext));
                },
                lookupOnContext: function (t, e, r, s) {
                    var i = 0;
                    s || !this.options.compat || this.lastContext ? this.pushContext() : this.push(this.depthedLookup(t[i++])), this.resolvePath("context", t, i, e, r);
                },
                lookupBlockParam: function (t, e) {
                    (this.useBlockParams = !0), this.push(["blockParams[", t[0], "][", t[1], "]"]), this.resolvePath("context", e, 1);
                },
                lookupData: function (t, e, r) {
                    t ? this.pushStackLiteral("container.data(data, " + t + ")") : this.pushStackLiteral("data"), this.resolvePath("data", e, 0, !0, r);
                },
                resolvePath: function (t, e, r, s, i) {
                    var a = this;
                    if (this.options.strict || this.options.assumeObjects) return void this.push(n(this.options.strict && i, this, e, t));
                    for (var o = e.length; o > r; r++)
                        this.replaceStack(function (i) {
                            var n = a.nameLookup(i, e[r], t);
                            return s ? [" && ", n] : [" != null ? ", n, " : ", i];
                        });
                },
                resolvePossibleLambda: function () {
                    this.push([this.aliasable("container.lambda"), "(", this.popStack(), ", ", this.contextName(0), ")"]);
                },
                pushStringParam: function (t, e) {
                    this.pushContext(), this.pushString(e), "SubExpression" !== e && ("string" == typeof t ? this.pushString(t) : this.pushStackLiteral(t));
                },
                emptyHash: function (t) {
                    this.trackIds && this.push("{}"), this.stringParams && (this.push("{}"), this.push("{}")), this.pushStackLiteral(t ? "undefined" : "{}");
                },
                pushHash: function () {
                    this.hash && this.hashes.push(this.hash), (this.hash = { values: [], types: [], contexts: [], ids: [] });
                },
                popHash: function () {
                    var t = this.hash;
                    (this.hash = this.hashes.pop()),
                        this.trackIds && this.push(this.objectLiteral(t.ids)),
                        this.stringParams && (this.push(this.objectLiteral(t.contexts)), this.push(this.objectLiteral(t.types))),
                        this.push(this.objectLiteral(t.values));
                },
                pushString: function (t) {
                    this.pushStackLiteral(this.quotedString(t));
                },
                pushLiteral: function (t) {
                    this.pushStackLiteral(t);
                },
                pushProgram: function (t) {
                    null != t ? this.pushStackLiteral(this.programExpression(t)) : this.pushStackLiteral(null);
                },
                registerDecorator: function (t, e) {
                    var r = this.nameLookup("decorators", e, "decorator"),
                        s = this.setupHelperArgs(e, t);
                    this.decorators.push(["fn = ", this.decorators.functionCall(r, "", ["fn", "props", "container", s]), " || fn;"]);
                },
                invokeHelper: function (t, e, r) {
                    var s = this.popStack(),
                        i = this.setupHelper(t, e),
                        n = r ? [i.name, " || "] : "",
                        a = ["("].concat(n, s);
                    this.options.strict || a.push(" || ", this.aliasable("helpers.helperMissing")), a.push(")"), this.push(this.source.functionCall(a, "call", i.callParams));
                },
                invokeKnownHelper: function (t, e) {
                    var r = this.setupHelper(t, e);
                    this.push(this.source.functionCall(r.name, "call", r.callParams));
                },
                invokeAmbiguous: function (t, e) {
                    this.useRegister("helper");
                    var r = this.popStack();
                    this.emptyHash();
                    var s = this.setupHelper(0, t, e),
                        i = (this.lastHelper = this.nameLookup("helpers", t, "helper")),
                        n = ["(", "(helper = ", i, " || ", r, ")"];
                    this.options.strict || ((n[0] = "(helper = "), n.push(" != null ? helper : ", this.aliasable("helpers.helperMissing"))),
                        this.push(["(", n, s.paramsInit ? ["),(", s.paramsInit] : [], "),", "(typeof helper === ", this.aliasable('"function"'), " ? ", this.source.functionCall("helper", "call", s.callParams), " : helper))"]);
                },
                invokePartial: function (t, e, r) {
                    var s = [],
                        i = this.setupParams(e, 1, s);
                    t && ((e = this.popStack()), delete i.name),
                        r && (i.indent = JSON.stringify(r)),
                        (i.helpers = "helpers"),
                        (i.partials = "partials"),
                        (i.decorators = "container.decorators"),
                        t ? s.unshift(e) : s.unshift(this.nameLookup("partials", e, "partial")),
                        this.options.compat && (i.depths = "depths"),
                        (i = this.objectLiteral(i)),
                        s.push(i),
                        this.push(this.source.functionCall("container.invokePartial", "", s));
                },
                assignToHash: function (t) {
                    var e = this.popStack(),
                        r = void 0,
                        s = void 0,
                        i = void 0;
                    this.trackIds && (i = this.popStack()), this.stringParams && ((s = this.popStack()), (r = this.popStack()));
                    var n = this.hash;
                    r && (n.contexts[t] = r), s && (n.types[t] = s), i && (n.ids[t] = i), (n.values[t] = e);
                },
                pushId: function (t, e, r) {
                    "BlockParam" === t
                        ? this.pushStackLiteral("blockParams[" + e[0] + "].path[" + e[1] + "]" + (r ? " + " + JSON.stringify("." + r) : ""))
                        : "PathExpression" === t
                        ? this.pushString(e)
                        : "SubExpression" === t
                        ? this.pushStackLiteral("true")
                        : this.pushStackLiteral("null");
                },
                compiler: i,
                compileChildren: function (t, e) {
                    for (var r = t.children, s = void 0, i = void 0, n = 0, a = r.length; a > n; n++) {
                        (s = r[n]), (i = new this.compiler());
                        var o = this.matchExistingProgram(s);
                        if (null == o) {
                            this.context.programs.push("");
                            var c = this.context.programs.length;
                            (s.index = c),
                                (s.name = "program" + c),
                                (this.context.programs[c] = i.compile(s, e, this.context, !this.precompile)),
                                (this.context.decorators[c] = i.decorators),
                                (this.context.environments[c] = s),
                                (this.useDepths = this.useDepths || i.useDepths),
                                (this.useBlockParams = this.useBlockParams || i.useBlockParams),
                                (s.useDepths = this.useDepths),
                                (s.useBlockParams = this.useBlockParams);
                        } else (s.index = o.index), (s.name = "program" + o.index), (this.useDepths = this.useDepths || o.useDepths), (this.useBlockParams = this.useBlockParams || o.useBlockParams);
                    }
                },
                matchExistingProgram: function (t) {
                    for (var e = 0, r = this.context.environments.length; r > e; e++) {
                        var s = this.context.environments[e];
                        if (s && s.equals(t)) return s;
                    }
                },
                programExpression: function (t) {
                    var e = this.environment.children[t],
                        r = [e.index, "data", e.blockParams];
                    return (this.useBlockParams || this.useDepths) && r.push("blockParams"), this.useDepths && r.push("depths"), "container.program(" + r.join(", ") + ")";
                },
                useRegister: function (t) {
                    this.registers[t] || ((this.registers[t] = !0), this.registers.list.push(t));
                },
                push: function (t) {
                    return t instanceof s || (t = this.source.wrap(t)), this.inlineStack.push(t), t;
                },
                pushStackLiteral: function (t) {
                    this.push(new s(t));
                },
                pushSource: function (t) {
                    this.pendingContent && (this.source.push(this.appendToBuffer(this.source.quotedString(this.pendingContent), this.pendingLocation)), (this.pendingContent = void 0)), t && this.source.push(t);
                },
                replaceStack: function (t) {
                    var e = ["("],
                        r = void 0,
                        i = void 0,
                        n = void 0;
                    if (!this.isInline()) throw new l["default"]("replaceStack on non-inline");
                    var a = this.popStack(!0);
                    if (a instanceof s) (r = [a.value]), (e = ["(", r]), (n = !0);
                    else {
                        i = !0;
                        var o = this.incrStack();
                        (e = ["((", this.push(o), " = ", a, ")"]), (r = this.topStack());
                    }
                    var c = t.call(this, r);
                    n || this.popStack(), i && this.stackSlot--, this.push(e.concat(c, ")"));
                },
                incrStack: function () {
                    return this.stackSlot++, this.stackSlot > this.stackVars.length && this.stackVars.push("stack" + this.stackSlot), this.topStackName();
                },
                topStackName: function () {
                    return "stack" + this.stackSlot;
                },
                flushInline: function () {
                    var t = this.inlineStack;
                    this.inlineStack = [];
                    for (var e = 0, r = t.length; r > e; e++) {
                        var i = t[e];
                        if (i instanceof s) this.compileStack.push(i);
                        else {
                            var n = this.incrStack();
                            this.pushSource([n, " = ", i, ";"]), this.compileStack.push(n);
                        }
                    }
                },
                isInline: function () {
                    return this.inlineStack.length;
                },
                popStack: function (t) {
                    var e = this.isInline(),
                        r = (e ? this.inlineStack : this.compileStack).pop();
                    if (!t && r instanceof s) return r.value;
                    if (!e) {
                        if (!this.stackSlot) throw new l["default"]("Invalid stack pop");
                        this.stackSlot--;
                    }
                    return r;
                },
                topStack: function () {
                    var t = this.isInline() ? this.inlineStack : this.compileStack,
                        e = t[t.length - 1];
                    return e instanceof s ? e.value : e;
                },
                contextName: function (t) {
                    return this.useDepths && t ? "depths[" + t + "]" : "depth" + t;
                },
                quotedString: function (t) {
                    return this.source.quotedString(t);
                },
                objectLiteral: function (t) {
                    return this.source.objectLiteral(t);
                },
                aliasable: function (t) {
                    var e = this.aliases[t];
                    return e ? (e.referenceCount++, e) : ((e = this.aliases[t] = this.source.wrap(t)), (e.aliasable = !0), (e.referenceCount = 1), e);
                },
                setupHelper: function (t, e, r) {
                    var s = [],
                        i = this.setupHelperArgs(e, t, s, r),
                        n = this.nameLookup("helpers", e, "helper"),
                        a = this.aliasable(this.contextName(0) + " != null ? " + this.contextName(0) + " : (container.nullContext || {})");
                    return { params: s, paramsInit: i, name: n, callParams: [a].concat(s) };
                },
                setupParams: function (t, e, r) {
                    var s = {},
                        i = [],
                        n = [],
                        a = [],
                        o = !r,
                        c = void 0;
                    o && (r = []), (s.name = this.quotedString(t)), (s.hash = this.popStack()), this.trackIds && (s.hashIds = this.popStack()), this.stringParams && ((s.hashTypes = this.popStack()), (s.hashContexts = this.popStack()));
                    var l = this.popStack(),
                        h = this.popStack();
                    (h || l) && ((s.fn = h || "container.noop"), (s.inverse = l || "container.noop"));
                    for (var u = e; u--; ) (c = this.popStack()), (r[u] = c), this.trackIds && (a[u] = this.popStack()), this.stringParams && ((n[u] = this.popStack()), (i[u] = this.popStack()));
                    return (
                        o && (s.args = this.source.generateArray(r)),
                        this.trackIds && (s.ids = this.source.generateArray(a)),
                        this.stringParams && ((s.types = this.source.generateArray(n)), (s.contexts = this.source.generateArray(i))),
                        this.options.data && (s.data = "data"),
                        this.useBlockParams && (s.blockParams = "blockParams"),
                        s
                    );
                },
                setupHelperArgs: function (t, e, r, s) {
                    var i = this.setupParams(t, e, r);
                    return (i = this.objectLiteral(i)), s ? (this.useRegister("options"), r.push("options"), ["options=", i]) : r ? (r.push(i), "") : i;
                },
            }),
                (function () {
                    for (
                        var t = "break else new var case finally return void catch for switch while continue function this with default if throw delete in try do instanceof typeof abstract enum int short boolean export interface static byte extends long super char final native synchronized class float package throws const goto private transient debugger implements protected volatile double import public let yield await null true false".split(
                                " "
                            ),
                            e = (i.RESERVED_WORDS = {}),
                            r = 0,
                            s = t.length;
                        s > r;
                        r++
                    )
                        e[t[r]] = !0;
                })(),
                (i.isValidJavaScriptVariableName = function (t) {
                    return !i.RESERVED_WORDS[t] && /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(t);
                }),
                (e["default"] = i),
                (t.exports = e["default"]);
        },
        function (t, e, r) {
            "use strict";
            function s(t, e, r) {
                if (n.isArray(t)) {
                    for (var s = [], i = 0, a = t.length; a > i; i++) s.push(e.wrap(t[i], r));
                    return s;
                }
                return "boolean" == typeof t || "number" == typeof t ? t + "" : t;
            }
            function i(t) {
                (this.srcFile = t), (this.source = []);
            }
            e.__esModule = !0;
            var n = r(5),
                a = void 0;
            try {
            } catch (o) {}
            a ||
                ((a = function (t, e, r, s) {
                    (this.src = ""), s && this.add(s);
                }),
                (a.prototype = {
                    add: function (t) {
                        n.isArray(t) && (t = t.join("")), (this.src += t);
                    },
                    prepend: function (t) {
                        n.isArray(t) && (t = t.join("")), (this.src = t + this.src);
                    },
                    toStringWithSourceMap: function () {
                        return { code: this.toString() };
                    },
                    toString: function () {
                        return this.src;
                    },
                })),
                (i.prototype = {
                    isEmpty: function () {
                        return !this.source.length;
                    },
                    prepend: function (t, e) {
                        this.source.unshift(this.wrap(t, e));
                    },
                    push: function (t, e) {
                        this.source.push(this.wrap(t, e));
                    },
                    merge: function () {
                        var t = this.empty();
                        return (
                            this.each(function (e) {
                                t.add(["  ", e, "\n"]);
                            }),
                            t
                        );
                    },
                    each: function (t) {
                        for (var e = 0, r = this.source.length; r > e; e++) t(this.source[e]);
                    },
                    empty: function () {
                        var t = this.currentLocation || { start: {} };
                        return new a(t.start.line, t.start.column, this.srcFile);
                    },
                    wrap: function (t) {
                        var e = arguments.length <= 1 || void 0 === arguments[1] ? this.currentLocation || { start: {} } : arguments[1];
                        return t instanceof a ? t : ((t = s(t, this, e)), new a(e.start.line, e.start.column, this.srcFile, t));
                    },
                    functionCall: function (t, e, r) {
                        return (r = this.generateList(r)), this.wrap([t, e ? "." + e + "(" : "(", r, ")"]);
                    },
                    quotedString: function (t) {
                        return (
                            '"' +
                            (t + "")
                                .replace(/\\/g, "\\\\")
                                .replace(/"/g, '\\"')
                                .replace(/\n/g, "\\n")
                                .replace(/\r/g, "\\r")
                                .replace(/\u2028/g, "\\u2028")
                                .replace(/\u2029/g, "\\u2029") +
                            '"'
                        );
                    },
                    objectLiteral: function (t) {
                        var e = [];
                        for (var r in t)
                            if (t.hasOwnProperty(r)) {
                                var i = s(t[r], this);
                                "undefined" !== i && e.push([this.quotedString(r), ":", i]);
                            }
                        var n = this.generateList(e);
                        return n.prepend("{"), n.add("}"), n;
                    },
                    generateList: function (t) {
                        for (var e = this.empty(), r = 0, i = t.length; i > r; r++) r && e.add(","), e.add(s(t[r], this));
                        return e;
                    },
                    generateArray: function (t) {
                        var e = this.generateList(t);
                        return e.prepend("["), e.add("]"), e;
                    },
                }),
                (e["default"] = i),
                (t.exports = e["default"]);
        },
    ]);
});
var get_120 = 0;
var pop_show = 0;
var myVar;
$(document).ready(function () {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        isMobile = true;
    }
    if (pageName == "things_2_see") {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            isMobile = true;
        }
        $("input").keypress(function (event) {
            if (event.which == 13) {
                if (isMobile == true) {
                    starRatingM();
                } else {
                    starRating();
                }
            }
        });
    }
});
function validateForm1(formid) {
    if (document.getElementById("phone" + formid).value == "") {
        document.getElementById("phone" + formid).focus();
        alert("Please Enter Your mobile no");
        return false;
    }
    if (document.getElementById("f_country" + formid).value.toLowerCase() === "India".toLowerCase()) {
        var mobile = document.getElementById("phone" + formid).value;
        var len = document.getElementById("phone" + formid).value.length;
        if (len < 10 || len > 10) {
            alert("Please enter a valid 10 digit mobile no");
            document.getElementById("phone" + formid).focus();
            return false;
        }
        if (!(mobile.charAt(0) == "9" || mobile.charAt(0) == "8" || mobile.charAt(0) == "7" || mobile.charAt(0) == "6")) {
            alert("Please enter a valid mobile no starting with 6, 7, 8 or 9");
            document.getElementById("phone" + formid).focus();
            return false;
        }
    }
    if (document.getElementById("f_country" + formid).value == "") {
        document.getElementById("f_country" + formid).focus();
        alert("Please Enter Country");
        return false;
    }
    if (document.getElementById("dest" + formid).value == "") {
        document.getElementById("dest" + formid).focus();
        alert("Please Enter Your Going to city");
        return false;
    } else {
        var now = new Date();
        var time = now.getTime();
        time += 3600 * 1e3;
        now.setTime(time);
        var expires = "; expires=" + now.toUTCString() + "; path=/";
        document.cookie = "pytd=" + document.getElementById("dest" + formid).value + expires;
        document.cookie = "pytd=" + document.getElementById("dest" + formid).value;
    }
    if (document.getElementById("dest" + formid).value === "") {
        document.getElementById("dest" + formid).focus();
        return false;
    } else {
        var now = new Date();
        var time = now.getTime();
        time += 3600 * 1e3;
        now.setTime(time);
        var expires = "; expires=" + now.toUTCString() + "; path=/";
        document.cookie = "pytd=" + document.getElementById("dest" + formid).value + expires;
        document.cookie = "pytd=" + document.getElementById("dest" + formid).value;
    }
    if (typeof customform == "undefined" || customform != "1") {
        if (document.getElementById("adults" + formid).options[document.getElementById("adults" + formid).selectedIndex].value == "") {
            document.getElementById("adults" + formid).focus();
            alert("Please Enter No. Of People");
            return false;
        }
    }
    if (document.getElementById("travel_date" + formid).value == "") {
        document.getElementById("travel_date" + formid).focus();
        alert("Please Enter Your Travel Date");
        return false;
    }
    if (typeof customform == "undefined" || customform != "1") {
        if (document.getElementById("du_of_st" + formid).options[document.getElementById("du_of_st" + formid).selectedIndex].value == "") {
            document.getElementById("du_of_st" + formid).focus();
            alert("Please Enter Your Duration of Stay");
            return false;
        }
    }
    if (document.getElementById("depar_city" + formid).value == "") {
        document.getElementById("depar_city").focus();
        alert("Please Enter Your Departure city");
        return false;
    }
    if (document.getElementById("depar_city" + formid).value == "") {
        document.getElementById("depar_city" + formid).focus();
        return false;
    }
    if (typeof customform == "undefined" || customform != "1") {
        if (document.getElementById("c_name" + formid).value == "") {
            document.getElementById("c_name" + formid).focus();
            alert("Please Enter Your Name");
            return false;
        } else {
            var now = new Date();
            var time = now.getTime();
            time += 3600 * 1e3;
            now.setTime(time);
            var expires = "; expires=" + now.toUTCString() + "; path=/";
            document.cookie = "pytn=" + document.getElementById("c_name" + formid).value + expires;
            document.cookie = "pytn=" + document.getElementById("c_name" + formid).value;
        }
    }
    if (document.getElementById("e_mail" + formid).value == "") {
        document.getElementById("e_mail" + formid).focus();
        alert("Please Enter Your Email id");
        return false;
    } else {
        var now = new Date();
        var time = now.getTime();
        time += 3600 * 1e3;
        now.setTime(time);
        var expires = "; expires=" + now.toUTCString() + "; path=/";
        document.cookie = "pytml=" + document.getElementById("e_mail" + formid).value + expires;
        document.cookie = "pytml=" + document.getElementById("e_mail" + formid).value;
    }
    if (document.getElementById("e_mail" + formid).value != "" && !document.getElementById("e_mail" + formid).value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
        document.getElementById("e_mail" + formid).focus();
        alert("Please correct your email");
        return false;
    } else {
        var now = new Date();
        var time = now.getTime();
        time += 3600 * 1e3;
        now.setTime(time);
        var expires = "; expires=" + now.toUTCString() + "; path=/";
        document.cookie = "pytml=" + document.getElementById("e_mail" + formid).value + expires;
        document.cookie = "pytml=" + document.getElementById("e_mail" + formid).value;
    }
    if (typeof customform == "undefined" || customform != "1") {
        if (document.getElementById("c_name" + formid).value != "" && !document.getElementById("c_name" + formid).value.match(/^[a-zA-z ]+(,[a-zA-z ]+){0,11}$/)) {
            document.getElementById("c_name" + formid).focus();
            return false;
        } else {
            var now = new Date();
            var time = now.getTime();
            time += 3600 * 1e3;
            now.setTime(time);
            var expires = "; expires=" + now.toUTCString() + "; path=/";
            document.cookie = "pytn=" + document.getElementById("c_name" + formid).value + expires;
            document.cookie = "pytn=" + document.getElementById("c_name" + formid).value;
        }
    }
    if (typeof customform == "undefined" || customform != "1") {
        if (document.getElementById("budget_f" + formid).options[document.getElementById("budget_f" + formid).selectedIndex].value == "") {
            document.getElementById("budget_f" + formid).focus();
            alert("Please Enter Your Budget");
            return false;
        }
    }
    if (document.getElementById("privacycheck" + formid) != null && document.getElementById("privacycheck" + formid) != "undefined") {
        if (!document.getElementById("privacycheck" + formid).checked) {
            alert("Please indicate that you agree to our privacy policy & terms of service");
            document.getElementById("privacycheck" + formid).focus();
            return false;
        }
    }
    var frm = document.getElementsByName("enqfrom" + formid)[0];
    var thanksid = document.getElementById("thanks");
    ga("send", "event", "leads", "enquiry-form", "enquiry-form");
    frm.submit(frm);
    frm.reset();
    return false;
}
function o(id) {
    window.open("../thanks.php?lid=" + id, "_blank");
}
function isNumberKey1(evt) {
    var charCode = evt.which ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;
    return true;
}
function onlyAlphabets1(evt) {
    var charCode1 = evt.which ? evt.which : event.keyCode;
    if (charCode1 < 31 || (charCode1 > 64 && charCode1 < 91) || (charCode1 > 96 && charCode1 < 123) || charCode1 == 32) return true;
    return false;
}
function getuser(id) {
    var mobileno = document.getElementById("phone" + id).value;
    if (mobileno.length == 10) {
        $.ajax({
            url: "../chat/checklogin.php",
            type: "POST",
            data: { mobile: mobileno, type: "mobile" },
            cache: false,
            success: function (data) {
                var main = JSON.parse(data);
                if (main.status) {
                    var leademail = main.lead_email;
                    var leadname = main.lead_name;
                    var leadcity = main.lead_city;
                    var leadcountryiso = main.lead_country_iso;
                    var leadcountryname = main.lead_country_name;
                    if (leademail != "") {
                        document.getElementById("e_mail" + id).value = leademail;
                        document.getElementById("e_mail" + id).style.display = "none";
                    }
                    if (leadname != "") {
                        document.getElementById("c_name" + id).value = leadname;
                        document.getElementById("c_name" + id).style.display = "none";
                    }
                    if (leadcity != "") {
                        document.getElementById("depar_city" + id).value = leadcity;
                        document.getElementById("depar_city" + id).style.display = "none";
                    }
                    if (leadcountryiso != "") document.getElementById("frm_country" + id).value = leadcountryiso;
                    if (leadcountryname != "") document.getElementById("f_country" + id).value = leadcountryname;
                    if (leadcountryname != "") document.getElementById("countryfrm_full" + id).value = leadcountryname;
                } else {
                    document.getElementById("e_mail" + id).value = "";
                    document.getElementById("c_name" + id).value = "";
                    document.getElementById("depar_city" + id).value = "";
                    document.getElementById("spandep" + id).style.display = "block";
                    document.getElementById("spanname" + id).style.display = "block";
                    document.getElementById("spanemail" + id).style.display = "block";
                    document.getElementById("e_mail" + id).style.display = "block";
                    document.getElementById("c_name" + id).style.display = "block";
                    document.getElementById("depar_city" + id).style.display = "block";
                }
            },
        });
    }
}
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return "";
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
$(function () {
    (function () {
        var autoComplete = (function () {
            function e(e) {
                function t(e, t) {
                    return e.classList ? e.classList.contains(t) : new RegExp("\\b" + t + "\\b").test(e.className);
                }
                function o(e, t, o) {
                    e.attachEvent ? e.attachEvent("on" + t, o) : e.addEventListener(t, o);
                }
                function s(e, t, o) {
                    e.detachEvent ? e.detachEvent("on" + t, o) : e.removeEventListener(t, o);
                }
                function n(e, s, n, l) {
                    o(l || document, s, function (o) {
                        for (var s, l = o.target || o.srcElement; l && !(s = t(l, e)); ) l = l.parentElement;
                        s && n.call(l, o);
                    });
                }
                if (document.querySelector) {
                    var l = {
                        selector: 0,
                        source: 0,
                        minChars: 3,
                        delay: 150,
                        offsetLeft: 0,
                        offsetTop: 1,
                        cache: 1,
                        menuClass: "",
                        renderItem: function (e, t) {
                            t = t.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                            var o = new RegExp("(" + t.split(" ").join("|") + ")", "gi");
                            return '<div class="autocomplete-suggestion" data-val="' + e + '">' + e.replace(o, "<b>$1</b>") + "</div>";
                        },
                        onSelect: function () {},
                    };
                    for (var c in e) e.hasOwnProperty(c) && (l[c] = e[c]);
                    for (var a = "object" == typeof l.selector ? [l.selector] : document.querySelectorAll(l.selector), u = 0; u < a.length; u++) {
                        var i = a[u];
                        (i.sc = document.createElement("div")),
                            (i.sc.className = "autocomplete-suggestions " + l.menuClass),
                            (i.autocompleteAttr = i.getAttribute("autocomplete")),
                            i.setAttribute("autocomplete", "off"),
                            (i.cache = {}),
                            (i.last_val = ""),
                            (i.updateSC = function (e, t) {
                                var o = i.getBoundingClientRect();
                                if (i.id == "chattextboxsear") {
                                    if (
                                        ((i.sc.style.left = Math.round(o.left + (window.pageXOffset || document.documentElement.scrollLeft) + l.offsetLeft) + "px"),
                                        (i.sc.style.bottom = "50px"),
                                        (i.sc.style.height = "auto"),
                                        (i.sc.style.width = Math.round(o.right - o.left) + "px"),
                                        !e &&
                                            ((i.sc.style.display = "block"),
                                            i.sc.maxHeight || (i.sc.maxHeight = parseInt((window.getComputedStyle ? getComputedStyle(i.sc, null) : i.sc.currentStyle).maxHeight)),
                                            i.sc.suggestionHeight || (i.sc.suggestionHeight = i.sc.querySelector(".autocomplete-suggestion").offsetHeight),
                                            i.sc.suggestionHeight))
                                    )
                                        if (t) {
                                            var s = i.sc.scrollTop,
                                                n = t.getBoundingClientRect().top - i.sc.getBoundingClientRect().top;
                                            n + i.sc.suggestionHeight - i.sc.maxHeight > 0 ? (i.sc.scrollTop = n + i.sc.suggestionHeight + s - i.sc.maxHeight) : 0 > n && (i.sc.scrollTop = n + s);
                                        } else i.sc.scrollTop = 0;
                                } else {
                                    if (
                                        ((i.sc.style.left = Math.round(o.left + (window.pageXOffset || document.documentElement.scrollLeft) + l.offsetLeft) + "px"),
                                        (i.sc.style.top = Math.round(o.bottom + (window.pageYOffset || document.documentElement.scrollTop) + l.offsetTop) + "px"),
                                        (i.sc.style.width = Math.round(o.right - o.left) + "px"),
                                        !e &&
                                            ((i.sc.style.display = "block"),
                                            i.sc.maxHeight || (i.sc.maxHeight = parseInt((window.getComputedStyle ? getComputedStyle(i.sc, null) : i.sc.currentStyle).maxHeight)),
                                            i.sc.suggestionHeight || (i.sc.suggestionHeight = i.sc.querySelector(".autocomplete-suggestion").offsetHeight),
                                            i.sc.suggestionHeight))
                                    )
                                        if (t) {
                                            var s = i.sc.scrollTop,
                                                n = t.getBoundingClientRect().top - i.sc.getBoundingClientRect().top;
                                            n + i.sc.suggestionHeight - i.sc.maxHeight > 0 ? (i.sc.scrollTop = n + i.sc.suggestionHeight + s - i.sc.maxHeight) : 0 > n && (i.sc.scrollTop = n + s);
                                        } else i.sc.scrollTop = 0;
                                }
                            }),
                            o(window, "resize", i.updateSC),
                            document.body.appendChild(i.sc),
                            n(
                                "autocomplete-suggestion",
                                "mouseleave",
                                function () {
                                    var e = i.sc.querySelector(".autocomplete-suggestion.selected");
                                    e &&
                                        setTimeout(function () {
                                            e.className = e.className.replace("selected", "");
                                        }, 20);
                                },
                                i.sc
                            ),
                            n(
                                "autocomplete-suggestion",
                                "mouseover",
                                function () {
                                    var e = i.sc.querySelector(".autocomplete-suggestion.selected");
                                    e && (e.className = e.className.replace("selected", "")), (this.className += " selected");
                                },
                                i.sc
                            ),
                            n(
                                "autocomplete-suggestion",
                                "mousedown",
                                function (e) {
                                    if (t(this, "autocomplete-suggestion")) {
                                        var o = this.getAttribute("data-val");
                                        (i.value = o), l.onSelect(e, o, this), (i.sc.style.display = "none");
                                    }
                                },
                                i.sc
                            ),
                            (i.blurHandler = function () {
                                try {
                                    var e = document.querySelector(".autocomplete-suggestions:hover");
                                } catch (t) {
                                    var e = 0;
                                }
                                e
                                    ? i !== document.activeElement &&
                                      setTimeout(function () {
                                          i.focus();
                                      }, 20)
                                    : ((i.last_val = i.value),
                                      (i.sc.style.display = "none"),
                                      setTimeout(function () {
                                          i.sc.style.display = "none";
                                      }, 350));
                            }),
                            o(i, "blur", i.blurHandler);
                        var r = function (e) {
                            var t = i.value;
                            if (((i.cache[t] = e), e.length && t.length >= l.minChars)) {
                                for (var o = "", s = 0; s < e.length; s++) o += l.renderItem(e[s], t);
                                (i.sc.innerHTML = o), i.updateSC(0);
                            } else i.sc.style.display = "none";
                        };
                        (i.keydownHandler = function (e) {
                            var t = window.event ? e.keyCode : e.which;
                            if ((40 == t || 38 == t) && i.sc.innerHTML) {
                                var o,
                                    s = i.sc.querySelector(".autocomplete-suggestion.selected");
                                return (
                                    s
                                        ? ((o = 40 == t ? s.nextSibling : s.previousSibling),
                                          o
                                              ? ((s.className = s.className.replace("selected", "")), (o.className += " selected"), (i.value = o.getAttribute("data-val")))
                                              : ((s.className = s.className.replace("selected", "")), (i.value = i.last_val), (o = 0)))
                                        : ((o = 40 == t ? i.sc.querySelector(".autocomplete-suggestion") : i.sc.childNodes[i.sc.childNodes.length - 1]), (o.className += " selected"), (i.value = o.getAttribute("data-val"))),
                                    i.updateSC(0, o),
                                    !1
                                );
                            }
                            if (27 == t) (i.value = i.last_val), (i.sc.style.display = "none");
                            else if (13 == t || 9 == t) {
                                var s = i.sc.querySelector(".autocomplete-suggestion.selected");
                                s &&
                                    "none" != i.sc.style.display &&
                                    (l.onSelect(e, s.getAttribute("data-val"), s),
                                    setTimeout(function () {
                                        i.sc.style.display = "none";
                                    }, 20));
                            }
                        }),
                            o(i, "keydown", i.keydownHandler),
                            (i.keyupHandler = function (e) {
                                var t = window.event ? e.keyCode : e.which;
                                if (!t || ((35 > t || t > 40) && 13 != t && 27 != t)) {
                                    var o = i.value;
                                    if (o.length >= l.minChars) {
                                        if (o != i.last_val) {
                                            if (((i.last_val = o), clearTimeout(i.timer), l.cache)) {
                                                if (o in i.cache) return void r(i.cache[o]);
                                                for (var s = 1; s < o.length - l.minChars; s++) {
                                                    var n = o.slice(0, o.length - s);
                                                    if (n in i.cache && !i.cache[n].length) return void r([]);
                                                }
                                            }
                                            i.timer = setTimeout(function () {
                                                l.source(o, r);
                                            }, l.delay);
                                        }
                                    } else (i.last_val = o), (i.sc.style.display = "none");
                                }
                            }),
                            o(i, "keyup", i.keyupHandler),
                            (i.focusHandler = function (e) {
                                (i.last_val = "\n"), i.keyupHandler(e);
                            }),
                            l.minChars || o(i, "focus", i.focusHandler);
                    }
                    this.destroy = function () {
                        for (var e = 0; e < a.length; e++) {
                            var t = a[e];
                            s(window, "resize", t.updateSC),
                                s(t, "blur", t.blurHandler),
                                s(t, "focus", t.focusHandler),
                                s(t, "keydown", t.keydownHandler),
                                s(t, "keyup", t.keyupHandler),
                                t.autocompleteAttr ? t.setAttribute("autocomplete", t.autocompleteAttr) : t.removeAttribute("autocomplete"),
                                document.body.removeChild(t.sc),
                                (t = null);
                        }
                    };
                }
            }
            return e;
        })();
        !(function () {
            "function" == typeof define && define.amd
                ? define("autoComplete", function () {
                      return autoComplete;
                  })
                : "undefined" != typeof module && module.exports
                ? (module.exports = autoComplete)
                : (window.autoComplete = autoComplete);
        })();
        var formtemplate =
            '<div class="container"  style="max-width:1100px; margin:0 auto">' +
            '<div class="jn_main_frm" align="center" style="position:relative">' +
            '<div class="jn_fr_hed1">' +
            '<h1 class="mainh">{{headdsc}}</h1>' +
            "</div>" +
            '<form action="../hellotravel/blank.php" target="_blank"   method="POST" name="enqfrom{{formid}}" id="enqfrom{{formid}}" class="enqfrom" >' +
            '<div class="jn_frmd1">' +
            '<span {{#if userlogincontact}}style="display:none"{{/if}}><input type="number" required name="phone" placeholder="Mobile no." id="phone{{formid}}" class=""  value="{{userlogincontact}}" onKeyPress="return isNumberKey1(event)" pattern="[0-9]*" inputmode="numeric" min="0" onkeyup="getuser({{formid}});"/></span>' +
            '<input type="hidden" id="f_country{{formid}}"  name="f_country"   value="India" />' +
            '<span {{#if going_to}}style="display:none"{{/if}}><input type="text" required name="going_to" data-formid="{{formid}}" id="dest{{formid}}" placeholder="Going to" class="autoplace" value="{{going_to}}" /></span>' +
            '<span><select title="Number of People" id="adults{{formid}}" required name="adults" style="width:99%" ' +
            'oninvalid="setCustomValidity(\'Please select no. of travelers\')" onChange="">' +
            '<option value="">Adults</option>' +
            '<option value="Group">Group</option>' +
            '<option value="6">6 people</option>' +
            '<option value="5">5 people</option>' +
            '<option value="4">4 people</option>' +
            '<option value="3">3 people</option>' +
            '<option value="2" selected="selected">2 people</option>' +
            '<option value="1">1 person</option>' +
            "</select></span>" +
            '<span {{#if description}}style="display:none"{{/if}}><select title="Duration of stay" id="du_of_st{{formid}}" required name="du_of_st" style="width:99%">' +
            '<option value="">Duration</option>' +
            '<option value="1 Night/2 Days"  >1 Night/2 Days</option>' +
            '<option value="2 Nights/3 Days" >2 Nights/3 Days</option>' +
            '<option value="3 Nights/4 Days"  >3 Nights/4 Days</option>' +
            '<option value="4 Nights/5 Days"  >4 Nights/5 Days</option>' +
            '<option value="5 Nights/6 Days"  >5 Nights/6 Days</option>' +
            '<option value="6 Nights/7 Days"  >6 Nights/7 Days</option>' +
            '<option value="7 Nights/8 Days"  >7 Nights/8 Days</option>' +
            '<option value="8 Nights/9 Days"  >8 Nights/9 Days</option>' +
            '<option value="9 Nights/10 Days"  >9 Nights/10 Days</option>' +
            '<option value="10 Nights/11 Days"  >10 Nights/11 Days</option>' +
            '<option value="11 Nights/12 Days"  >11 Nights/12 Days</option>' +
            '<option value="12 Nights/13 Days"  >12 Nights/13 Days</option>' +
            '<option value="13 Nights/14 Days"  >13 Nights/14 Days</option>' +
            '<option value="14 Nights/15 Days"  >14 Nights/15 Days</option>' +
            '<option value="More than 15 Days"  >More than 15 Days</option>' +
            "</select></span>" +
            '<span><input type="text" id="travel_date{{formid}}" required name="travel_date" placeholder="Travel Date" value="" class="datepicker-here calen_ico" data-language="en"   pattern="" onKeyPress="return isNumberKey1(event)" title="Please enter tentative travel date(e.g. 21.03.1999)" readonly/></span>' +
            '<span id="spandep{{formid}}" {{#if userlogincontact}}style="display:none"{{/if}}><input type="text" data-formid="{{formid}}" id="depar_city{{formid}}" required name="depar_city" value="{{userlogincity}}" placeholder="Departure City" class="autoplace"></span>' +
            '<span id="spanemail{{formid}}" {{#if userloginemail}}style="display:none"{{/if}}><input type="email" required name="e_mail" placeholder="Email Id" id="e_mail{{formid}}"   value="{{userloginemail}}" /></span>' +
            '<span  id="spanname{{formid}}" {{#if username}}style="display:none"{{/if}}><input type="text" required name="c_name" placeholder="Your Name" id="c_name{{formid}}" class="formname"  value="{{username}}" /></span>' +
            '<span style ="display:none;">' +
            '<select title="Budget" id="budget_f{{formid}}" required name="budget"  style="width:99%">' +
            '<option value="" selected="SELECTED">Budget</option>' +
            '<option value="Economy">Economy (0 - 2 star)</option>' +
            '<option value="Standard" selected="selected">Standard (3 - 4 star)</option>' +
            '<option value="Luxury">Luxury (5 star &amp; above)</option>' +
            "</select>" +
            "</span>" +
            '<input type="hidden" id="country{{formid}}" name="going_country_code"></input>' +
            '<input type="hidden" id="country_full{{formid}}" name="going_country"></input>' +
            '<input type="hidden" id="full_address{{formid}}" name="full_address"></input>' +
            '<input type="hidden" id="state{{formid}}" name="going_state"></input>' +
            '<input type="hidden" id="district{{formid}}" name="going_district"></input>' +
            '<input type="hidden" id="frm_country{{formid}}" name="frm_country_code"></input>' +
            '<input type="hidden" id="countryfrm_full{{formid}}" name="frm_country_full"></input>' +
            '<input type="hidden" id="full1_address{{formid}}" name="full1_address"></input>' +
            '<input type="hidden" id="from_state{{formid}}" name="from_state"></input>' +
            '<input type="hidden" id="from_district{{formid}}" name="from_district"></input>' +
            '<input type="hidden" value="{{form_pvt_id}}" name="form_pvt_id" >' +
            '<input type="hidden" value="{{typetour}}" name="type_tour" >' +
            '<input type="hidden" value="{{pagesource}}" name="pagesource" >' +
            '<input type="hidden" value="{{description}}" name="description" >' +
            '<input type="hidden" value="{{aff_id}}" name="aff_id" >' +
            '<input type="hidden" name="self_url" value="{{selfurl}}" >' +
            '<input type="hidden" name="refer_url" value="{{reffrer}}" >' +
            '<div class="cl"></div>' +
            "<button type=\"submit\" onclick=\"return validateForm1('{{formid}}');ga('send', 'event', 'leads', 'enquiry-form','enquiry-form');\">Submit Enquiry</button>" +
            "{{#if privacy}}" +
            "{{#if userlogincontact}}" +
            '<div style="margin-top:5px; font-size:12px">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled="">' +
            "<i>I agree to get Email/SMS from you.</i>" +
            "</div>" +
            "{{else}}" +
            '<div style="margin-top:5px; font-size:12px; ">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;"  id="privacycheck{{formid}}" >' +
            '<i>I agree to <a href="../privacy-policy" target="_blank">privacy policy</a> & <a href="../terms-conditions" target="_blank">terms of service</a></i>' +
            "</div>" +
            "{{/if}}" +
            "{{else}}" +
            '<div style="margin-top:5px; font-size:12px">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled="">' +
            "<i>I agree to get Email/SMS from you.</i>" +
            "</div>" +
            "{{/if}}" +
            '<div style="clear:both"></div>' +
            "</div>" +
            "</form>" +
            "</div>" +
            "</div>";
        var newformtemplate =
            '<div class="f16 c3" align="center">{{headdsc}}' +
            "</div>" +
            '<form action="https://www.hellotravel.com/hellotravel/blank1.php" target="_blank"   method="POST" name="enqfrom{{formid}}" id="enqfrom{{formid}}">' +
            '<div class="formN mt1">' +
            '<span {{#if headdest}}style="display:none"{{/if}} style="width:100%" class="fl w33 p2"><input type="text" required name="going_to" data-formid="{{formid}}" id="dest{{formid}}" placeholder="Destination" class="autoplace" value="{{headdest}}" style="width:100%"/></span></div><div class="formN mt1">' +
            '<span {{#if userlogincontact}} style="display:none;"{{/if}} style="width:100%;"  class="fl w33 p2">' +
            '<input type="text" value="+91" name="sasad" style="width:20%; border-right:none; border-radius:2px 0 0 2px" class="fl"/>' +
            '<input type="text" style="width:80%;" required name="phone" placeholder="Mobile no." id="phone{{formid}}" class="fl"  value="{{userlogincontact}}" onKeyPress="return isNumberKey1(event)" pattern="[0-9]*" inputmode="numeric" min="0" onkeyup="getuser(\'{{formid}}\');"/></span>' +
            '<span class="fl w33 p2" id="spanemail{{formid}}" {{#if userloginemail}}style="display:none;width:100%;"{{/if}} style="width:100%;"><input type="text" required name="e_mail" placeholder="Email Id" id="e_mail{{formid}}"   value="{{userloginemail}}" style="width:100%"/></span>' +
            '<input type="hidden" id="f_country{{formid}}"  name="f_country"   value="India" />' +
            '<input type="hidden" id="travel_date{{formid}}" required name="travel_date" value="{{traveldate}}"></input>' +
            '<input type="hidden"  id="depar_city{{formid}}" name="depar_city" value="{{userlogincity}}">' +
            '<input type="hidden" id="country{{formid}}" name="going_country_code"></input>' +
            '<input type="hidden" id="c_name{{formid}}" name="c_name"></input>' +
            '<input type="hidden" id="country_full{{formid}}" name="going_country"></input>' +
            '<input type="hidden" id="full_address{{formid}}" name="full_address"></input>' +
            '<input type="hidden" id="state{{formid}}" name="going_state"></input>' +
            '<input type="hidden" id="district{{formid}}" name="going_district"></input>' +
            '<input type="hidden" id="frm_country{{formid}}" name="frm_country_code"></input>' +
            '<input type="hidden" id="countryfrm_full{{formid}}" name="frm_country_full"></input>' +
            '<input type="hidden" id="full1_address{{formid}}" name="full1_address"></input>' +
            '<input type="hidden" id="from_state{{formid}}" name="from_state"></input>' +
            '<input type="hidden" id="from_district{{formid}}" name="from_district"></input>' +
            '<input type="hidden" value="{{form_pvt_id}}" name="form_pvt_id" >' +
            '<input type="hidden" value="{{typetour}}" name="type_tour" >' +
            '<input type="hidden" value="{{pagesource}}" name="pagesource" >' +
            '<input type="hidden" value="{{description}}" name="description" >' +
            '<input type="hidden" value="{{aff_id}}" name="aff_id" ></input>' +
            '<input type="hidden" name="self_url" value="{{selfurl}}" ></input>' +
            '<input type="hidden" name="refer_url" value="{{reffrer}}" ></input>' +
            '<div class="cl"></div>' +
            "</div>" +
            '<div class="f17 c3 mt1 p2" align="center">' +
            "<button type=\"submit\" onclick=\"return validateForm1('{{formid}}');ga('send', 'event', 'leads', 'enquiry-form','enquiry-form');\" class=\"p5 f17 lh18 btn_Ne\">SUBMIT<br/>" +
            '<span class="f11 c1">I agree to get email & sms</span></button>' +
            "{{#if privacy}}" +
            "{{#if userlogincontact}}" +
            '<div style="margin-top:5px; font-size:12px">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled="">' +
            "</div>" +
            "{{else}}" +
            '<div style="margin-top:5px; font-size:12px; ">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;"  id="privacycheck{{formid}}" >' +
            '<i>I agree to <a href="../privacy-policy" target="_blank">privacy policy</a> & <a href="../terms-conditions" target="_blank">terms of service</a></i>' +
            "</div>" +
            "{{/if}}" +
            "{{else}}" +
            '<div style="margin-top:5px; font-size:12px;display:none;">' +
            '<input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled="">' +
            "</div>" +
            "{{/if}}" +
            "</form>" +
            "</div>" +
            "</div>";
        var forminit = function (n) {
            var ids = $("div[id^=" + n + "]");
            var scriptbody = document.createElement("script");
            scriptbody.id = "enqtemp";
            scriptbody.type = "text/x-handlebars-template";
            scriptbody.innerHTML = formtemplate;
            document.body.appendChild(scriptbody);
            var htmldata = $("#enqtemp").html();
            var theTemplate = Handlebars.compile(htmldata);
            var selfurl = window.top.location.href;
            var refer_url = document.referrer;
            var aff_id = getParameterByName("aff_id");
            var form_pvt_id = "";
            var description = "";
            var going_to = "";
            var privacyval = "";
            var pagesource = "";
            var typetour = "1";
            if (typeof type_tour != "undefined" && type_tour != "" && type_tour != 0 && type_tour != "1") typetour = type_tour;
            if (typeof pageval != "undefined" && pageval != "" && pageval != 0) pagesource = pageval;
            if (typeof privacy != "undefined" && privacy != "" && privacy != 0) privacyval = privacy;
            if (typeof pvtid != "undefined" && pvtid != "") form_pvt_id = pvtid;
            else form_pvt_id = getParameterByName("prvt_id");
            if (typeof desc != "undefined" && desc != "") description = desc;
            if (typeof goingto != "undefined" && goingto != "") going_to = goingto;
            if (description != "") var headdsc = "Enquire here for this package";
            else var headdsc = "Plan your trip now";
            ids.each(function () {
                var formid = this.id.substring(this.id.lastIndexOf("-") + 1);
                var someDate = new Date();
                var numberOfDaysToAdd = 10;
                someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
                var dd = someDate.getDate();
                var mm = someDate.getMonth() + 1;
                var y = someDate.getFullYear();
                var someFormattedDate = y + "-" + mm + "-" + dd;
                var traveldate = someFormattedDate;
                var context = {
                    formid: formid,
                    username: username,
                    userloginemail: userloginemail,
                    userlogincity: userlogincity,
                    userlogincontact: userlogincontact,
                    selfurl: selfurl,
                    reffrer: refer_url,
                    aff_id: aff_id,
                    form_pvt_id: form_pvt_id,
                    description: description,
                    going_to: going_to,
                    headdsc: headdsc,
                    privacy: privacyval,
                    pagesource: pagesource,
                    typetour: typetour,
                    traveldate: traveldate,
                };
                var html = theTemplate(context);
                $("#" + this.id).html(html);
                if (typeof new_duration != "undefined" && new_duration != "") $("select#du_of_st" + formid + " option[value='" + new_duration + "']").attr("selected", "selected");
                else $("select#du_of_st" + formid + " option[value='3 Nights/4 Days']").attr("selected", "selected");
            });
            var date = new Date();
            var currentMonth = date.getMonth() + 5;
            var currentDate = date.getDate();
            var currentYear = date.getFullYear();
            var sevendaydate = new Date();
            sevendaydate.setDate(date.getDate() + 14);
            $(".datepicker-here")
                .datepicker({ language: "en", showAnim: "show", dateFormat: "dd/mm/yy", defaultDate: new Date(), minDate: new Date(), maxDate: new Date(currentYear, currentMonth, currentDate), autoClose: true })
                .datepicker("setDate", sevendaydate);
        };
        var newforminit = function (n) {
            var ids = $("div[id^=" + n + "]");
            var scriptbody = document.createElement("script");
            scriptbody.innerHTML = newformtemplate;
            scriptbody.id = "newenqtemp";
            scriptbody.type = "text/x-handlebars-template";
            document.body.appendChild(scriptbody);
            var htmldata = $("#newenqtemp").html();
            var theTemplate = Handlebars.compile(htmldata);
            var selfurl = window.top.location.href;
            var refer_url = document.referrer;
            var aff_id = getParameterByName("aff_id");
            var form_pvt_id = "";
            var description = "";
            var going_to = "";
            var privacyval = "";
            var pagesource = "";
            var typetour = "1";
            if (typeof type_tour != "undefined" && type_tour != "" && type_tour != 0 && type_tour != "1") typetour = type_tour;
            if (typeof pageval != "undefined" && pageval != "" && pageval != 0) pagesource = pageval;
            if (typeof privacy != "undefined" && privacy != "" && privacy != 0) privacyval = privacy;
            if (typeof pvtid != "undefined" && pvtid != "") form_pvt_id = pvtid;
            else form_pvt_id = getParameterByName("prvt_id");
            if (typeof desc != "undefined" && desc != "") description = desc;
            if (typeof goingto != "undefined" && goingto != "") going_to = goingto;
            if (description != "") var headdsc = "Enquire here for this package";
            else var headdsc = "Plan your trip now";
            var head_arr = head;
            var index_counter = 0;
            ids.each(function () {
                var formid = this.id.substring(this.id.lastIndexOf("-") + 1);
                var headdest = head[index_counter];
                if (page == "story" || pageName == "story" || (typeof customform != "undefined" && customform == "1" && pageName != "deal")) {
                    headdsc = "Plan Your " + head[index_counter] + " Tour";
                } else {
                    headdsc = "Enquire For This Package";
                    headdest = going_to;
                }
                index_counter++;
                var someDate = new Date();
                var numberOfDaysToAdd = 10;
                someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
                var dd = someDate.getDate();
                var mm = someDate.getMonth() + 1;
                var y = someDate.getFullYear();
                var someFormattedDate = y + "-" + mm + "-" + dd;
                var traveldate = someFormattedDate;
                var context = {
                    headdest: headdest,
                    formid: formid,
                    username: username,
                    userloginemail: userloginemail,
                    userlogincity: userlogincity,
                    userlogincontact: userlogincontact,
                    selfurl: selfurl,
                    reffrer: refer_url,
                    aff_id: aff_id,
                    form_pvt_id: form_pvt_id,
                    description: description,
                    going_to: going_to,
                    headdsc: headdsc,
                    privacy: privacyval,
                    pagesource: pagesource,
                    typetour: typetour,
                    traveldate: traveldate,
                };
                var html = theTemplate(context);
                $("#" + this.id).html(html);
                if (typeof new_duration != "undefined" && new_duration != "") $("select#du_of_st" + formid + " option[value='" + new_duration + "']").attr("selected", "selected");
                else $("select#du_of_st" + formid + " option[value='3 Nights/4 Days']").attr("selected", "selected");
            });
            var date = new Date();
            var currentMonth = date.getMonth() + 5;
            var currentDate = date.getDate();
            var currentYear = date.getFullYear();
            var sevendaydate = new Date();
            sevendaydate.setDate(date.getDate() + 14);
            $(".datepicker-here")
                .datepicker({ language: "en", showAnim: "show", dateFormat: "dd/mm/yy", defaultDate: new Date(), minDate: new Date(), maxDate: new Date(currentYear, currentMonth, currentDate), autoClose: true })
                .datepicker("setDate", sevendaydate);
        };
        if (page == "story" || pageName == "deal" || (1 == 1 && typeof customform != "undefined" && customform == "1")) {
            newforminit("enq-from-story");
        } else {
            forminit("enq-from");
        }
    })(window.jQuery, window, document);
});
var questionNo = 1;
var page = "";
var questemp = "";
var anstemp = "";
var datetemp = "";
var slidertemp = "";
var trevtemp = "";
var durationmanual = "";
var isreposne = false;
var durtemp = "";
var packageid = "";
var loginid = "";
var pkgduration = "";
var pkgcountryto = "";
var pkgprice = "";
var storyslidertemp = "";
var pkgdatatitle = "";
var pkgdataloginid = "";
var pkgdatduration = "";
var pkgdataprice = "";
var pkgdatadest = "";
var loginname = "";
var loginemail = "";
var logincontact = "";
var logincity = "";
var pkgdatacountryto = "";
var pkgdest = "";
var pkgdataid = "";
var temp_lead = "";
var temp_leadid = "";
var quearray = [
    "Hey! Looking for a trip?",
    "I have great deals for you! Where would you like to visit?",
    "Choosing best packages for you. Please select below",
    "Great! When would you like to travel?",
    "From which city would you like to start your trip?",
    "Great! To contact you, please enter your email id",
    "Please enter your mobile number",
    "How many travelers?",
    "May I know your name please?",
    "Thank You! tell us more so that we can personalize it for you",
];
var ansarray = [];
function getCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) {
                c_end = document.cookie.length;
            }
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}
function getnamefrmemail(str) {
    var namepart = str.substr(0, str.indexOf("@"));
    namepart = namepart.replace(/[0-9]/g, " ");
    namepart = namepart.replace(/[._]/g, " ");
    namepart = namepart.replace(/\s\s+/g, " ");
    return namepart.trim();
}
function hidebuble() {
    $(".bubble").hide();
}
function showchat() {
    if (typeof siachat != "undefined" && siachat == "siachat") {
        landonmytrips(sianid, siaagentid);
    } else if (1 == 1) {
        var boxwidth = "";
        if ($(window).width() < 639) {
            $(".m_chat").toggleClass("ch_dis");
        }
        $("#chat-main").toggleClass("chat-hide");
        if (!$("#chat-main").hasClass("chat-hide")) {
            if (typeof pagest != "undefined" && pagest == "pagest") {
                showChatdiv();
            }
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                $(".m_chat").addClass("with3200");
            } else {
                $(".m_chat").addClass("with320");
            }
        } else {
            if (typeof pagest != "undefined" && pagest == "pagest") {
                hideChatdiv();
            }
            $(".m_chat").removeClass("with320");
        }
        if (questionNo != 3) $("#ansinp").focus();
    }
}
function hideChatdiv() {
    $(".m_chat").attr("style", "display: none !important;");
}
function showChatdiv() {
    $(".m_chat").attr("style", "display: block !important;");
}
function landonmytrips(sianid, siaagentid) {
    document.getElementById("siadealnid").value = sianid;
    document.getElementById("siadealagentid").value = siaagentid;
    document.getElementById("siachatform").submit();
}
function myChatMobile() {
    if (typeof siachat != "undefined" && siachat == "siachat") {
        landonmytrips(sianid, siaagentid);
    } else if (typeof pagest != "undefined" && pagest == "pagest") {
        showchat();
    } else {
        if (questionNo != 3 && questionNo != 1) $("#ansinp").focus();
    }
}
function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? "pm" : "am";
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    var strTime = hours + ":" + minutes + " " + ampm;
    return strTime;
}
function dateDropdownFormat() {
    var date = new Date();
    date.setDate(date.getDate() + 7);
    var currentMonth = date.getMonth();
    var currentDate = date.getDate();
    var currentYear = date.getFullYear();
    var data = [];
    var dd = [];
    var mm = [];
    var year = [];
    var montharray = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    var md = 0;
    for (var da = 1; da <= 31; da++) {
        if (da == currentDate) {
            if (da < 10) {
                da = "0" + da;
            }
            dd.push({ day: da.toString(), val: da, selected: "selected" });
        } else {
            if (da < 10) {
                da = "0" + da;
            }
            dd.push({ day: da.toString(), val: da });
        }
    }
    for (var ma = 0; ma < 12; ma++) {
        var mon = montharray[ma];
        var md = md + 1;
        if (ma == currentMonth) {
            if (md < 10) {
                var gd = "0" + md;
            } else {
                var gd = md;
            }
            mm.push({ month: mon, val: gd, selected: "selected" });
        } else {
            if (md < 10) {
                var gd = "0" + md;
            } else {
                var gd = md;
            }
            mm.push({ month: mon, val: gd });
        }
    }
    for (var ys = currentYear; ys < currentYear + 2; ys++) {
        if (ys == currentYear) {
            year.push({ year: ys, val: ys, selected: "selected" });
        } else {
            year.push({ year: ys, val: ys });
        }
    }
    data.push({ dd: dd, mm: mm, yy: year });
    return data;
}
function getpak(id) {
    var date = new Date();
    var datestring = formatAMPM(date);
    packageid = id;
    var title = $("#id" + packageid)
        .find("img")
        .attr("alt");
    var ans = title;
    loginid = $("#login" + packageid).val();
    pkgduration = $("#dur" + packageid).html();
    pkgprice = $("#price" + packageid).val();
    pkgdest = $("#dest" + packageid).html();
    pkgcountryto = $("#pkgcountryto" + packageid).val();
    ansarray.push(ans);
    $("#content-slider2").find("a").attr("onclick", "");
    var context = { ans: ans, datetext: datestring };
    var html = anstemp(context);
    $("#chatmessages").append(html);
    $(".ch_du").fadeIn("slow");
    questionNo++;
    var context = { ques: quearray[questionNo], datetext: datestring };
    var html = questemp(context);
    $("#chatmessages").append(html);
    $(".ch_du1").fadeIn("slow");
    scrolltobottom("chatmessages");
    $("#inputdiv").hide();
    $("#submit").hide();
    var sampletext = getplaceholder(questionNo);
    var data = dateDropdownFormat();
    var context = { data: data };
    var html = datetemp(context);
    $("#inputdiv").html(html);
    $("#inputdiv").show();
    $("#submit").show();
    if (questionNo != 3) {
        $("#ansinp").focus();
    }
    return false;
}
function getplaceholder(qno) {
    var sampletext = "Field required";
    switch (questionNo) {
        case 1:
            sampletext = "Where do you want to go?";
            break;
        case 3:
            sampletext = "dd/mm/yyyy";
            break;
        case 4:
            sampletext = "Your departure city";
            break;
        case 5:
            sampletext = "Your email id";
            break;
        case 6:
            sampletext = "Your mobile number";
            break;
        case 7:
            sampletext = "Number of travelers";
            break;
        case 8:
            sampletext = "Your name";
            break;
        default:
            break;
    }
    return sampletext;
}
function isNumber(evt) {
    evt = evt ? evt : window.event;
    var charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function validatephone(mobile) {
    var len = mobile.length;
    if (len < 10 || len > 10) {
        return "Please enter a valid 10 digit mobile no";
    }
    if (!(mobile.charAt(0) == "9" || mobile.charAt(0) == "8" || mobile.charAt(0) == "7" || mobile.charAt(0) == "6")) {
        return "Please enter a valid mobile no starting with 6, 7, 8 or 9";
    }
}
function onlyAlphabets(e) {
    try {
        if (window.event) {
            var charCode = window.event.keyCode;
        } else if (e) {
            var charCode = e.which;
        } else {
            return true;
        }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 13 || charCode == 32 || charCode == 8 || e.target.id == "submit") return true;
        else return false;
    } catch (err) {
        alert(err.Description);
    }
}
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function submitplace(place) {
    var date = new Date();
    var datestring = formatAMPM(date);
    var ans = place.trim();
    ansarray.push(ans);
    var context = { ans: ans, datetext: datestring };
    var html = anstemp(context);
    $("#chatmessages").append(html);
    $(".ch_du").fadeIn("slow");
    if (questionNo == 4) {
        $.ajax({
            url: "../chat/checklogin.php",
            type: "POST",
            data: { place_start: ans },
            success: function (data) {
                country_code = data.trim();
            },
        });
    }
    questionNo++;
    var context = { ques: quearray[questionNo], datetext: datestring };
    var html = questemp(context);
    $("#chatmessages").append(html);
    if (questionNo == 1) {
        $("#toplacesdiv").show("slow");
    } else if (questionNo == 4) {
        $("#frmplacesdiv").show("slow");
    } else {
        var height = $(window).height();
        var dh = $(".m_chat_hed").outerHeight(true);
        dh = dh + 100;
        height = height - dh;
        $("#chatbox").css("height", height);
        $("#chatmessages").css("max-height", height);
        scrolltobottom("chatmessages");
        $("#toplacesdiv").hide("slow");
        $("#frmplacesdiv").hide("slow");
    }
    if (questionNo == 2) {
        $("#inputdiv").hide();
        $("#submit").hide();
        $("#loader").show();
        packageSlider(ans);
    }
    if (questionNo != 0 && questionNo != 2 && questionNo != 9) {
        var sampletext = getplaceholder(questionNo);
        var placevalue = "";
        if (questionNo == 4) {
            placevalue = logincity;
        }
        if (questionNo == 5) {
            placevalue = loginemail;
        }
        if (questionNo == 6) {
            placevalue = logincontact;
        }
        if (questionNo == 8) {
            placevalue = loginname;
        }
        if (questionNo == 6) {
            var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="number" />';
        } else if (questionNo == 7) {
            var input = trevtemp;
        } else {
            var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="text" />';
        }
        $("#inputdiv").html(input);
        $("#ansinp").focus();
    }
    $(".ch_du1").fadeIn("slow");
    scrolltobottom("chatmessages");
    return false;
}
function submitans(e) {
    var date = new Date();
    var datestring = formatAMPM(date);
    if (questionNo == 1 || questionNo == 4 || questionNo == 8) {
        if (!onlyAlphabets(e)) {
            return false;
        }
    }
    if (questionNo == 6 || questionNo == 7) {
        if (!isNumber(e)) {
            alert("Please enter valid mobile no");
            return false;
        }
    }
    if (e.keyCode == 13 || e.target.id == "submit") {
        if (questionNo == 3) {
            var dd = $("#ansinpdd").val();
            var mm = $("#ansinpmm").val();
            var yy = $("#ansinpyy").val();
            var ansdate = new Date(yy + "-" + mm + "-" + dd);
            var threemonthsdate = new Date();
            threemonthsdate = threemonthsdate.setMonth(threemonthsdate.getMonth() + 3);
            var currentDate = new Date();
            if (ansdate < currentDate) {
                alert("Please select a later date");
                return false;
            }
            if (ansdate > threemonthsdate) {
                alert("Please select an earlier date");
                return false;
            }
            var ans = dd + "/" + mm + "/" + yy;
        } else {
            var ans = questionNo == 0 ? $("#ansinp option:selected").text() : $("#ansinp").val();
            ans = ans.trim();
            if (!isreposne && questionNo == 2) durationmanual = ans;
        }
        if (questionNo == 4) {
            $.ajax({
                url: "../chat/checklogin.php",
                type: "POST",
                data: { place_start: ans },
                success: function (data) {
                    country_code = data.trim();
                },
            });
        }
        if (questionNo == 6) {
            if (country_code != "" && country_code != null && country_code != "undefined" && country_code == "IN") {
                if (validatephone(ans)) {
                    alert(validatephone(ans));
                    return false;
                }
            }
        }
        if (questionNo == 0 && ans == "No") {
            var context = { ans: ans, datetext: datestring };
            var html = anstemp(context);
            $("#chatmessages").append(html);
            $(".ch_du").fadeIn("slow");
            var context = { ques: "Here are some stories for you", datetext: datestring };
            var html = questemp(context);
            $("#chatmessages").append(html);
            $(".ch_du1").fadeIn("slow");
            $("#inputdiv").hide();
            $("#submit").hide();
            storyslider();
            return false;
        }
        if (ans.trim() == "") {
            return false;
        }
        if (questionNo == 5) {
            if (!validateEmail(ans)) {
                alert("You have entered an invalid email address!");
                return false;
            } else {
                $("#inputdiv").hide();
                $("#submit").hide();
                $("#loader").show();
                $.ajax({
                    url: "../chat/checklogin.php",
                    type: "POST",
                    data: { email: ans },
                    success: function (data) {
                        try {
                            var leaddata = JSON.parse(data);
                            var placevalue = "";
                            if (leaddata.status) {
                                logincontact = leaddata.lead_phone;
                                loginname = leaddata.lead_name;
                                ansarray.push(ans);
                                var context = { ans: ans, datetext: datestring };
                                var html = anstemp(context);
                                $("#chatmessages").append(html);
                                $(".ch_du").fadeIn("slow");
                                var flag = 0;
                                questionNo++;
                                ifLoggedin(questionNo);
                                var context = { ques: quearray[questionNo], datetext: datestring };
                                var html = questemp(context);
                                $("#chatmessages").append(html);
                                $(".ch_du1").fadeIn("slow");
                                var sampletext = getplaceholder(questionNo);
                                if (questionNo == 6) {
                                    var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="number" />';
                                } else if (questionNo == 7) {
                                    var input = trevtemp;
                                } else {
                                    var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="text" />';
                                }
                            } else {
                                ansarray.push(ans);
                                var context = { ans: ans, datetext: datestring };
                                var html = anstemp(context);
                                $("#chatmessages").append(html);
                                $(".ch_du").fadeIn("slow");
                                var flag = 0;
                                questionNo++;
                                ifLoggedin(questionNo);
                                var context = { ques: quearray[questionNo], datetext: datestring };
                                var html = questemp(context);
                                $("#chatmessages").append(html);
                                $(".ch_du1").fadeIn("slow");
                                var sampletext = getplaceholder(questionNo);
                                if (questionNo == 6) {
                                    var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="number" />';
                                } else if (questionNo == 7) {
                                    var input = trevtemp;
                                } else {
                                    var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="text" />';
                                }
                                if (questionNo == 6) {
                                    placevalue = logincontact;
                                }
                            }
                            $("#loader").hide();
                            $("#inputdiv").html(input);
                            $("#inputdiv").show();
                            $("#submit").show();
                            scrolltobottom("chatmessages");
                        } catch (e) {
                            console.log(e);
                        }
                    },
                    error: function (error) {
                        console.log(error);
                    },
                });
                return false;
            }
        }
        ansarray.push(ans);
        var context = { ans: ans, datetext: datestring };
        var html = anstemp(context);
        $("#chatmessages").append(html);
        $(".ch_du").fadeIn("slow");
        var flag = 0;
        questionNo++;
        ifLoggedin(questionNo);
        var context = { ques: quearray[questionNo], datetext: datestring };
        var html = questemp(context);
        $("#chatmessages").append(html);
        if (questionNo == 1) {
            $("#toplacesdiv").show("slow");
        } else if (questionNo == 4) {
            $("#frmplacesdiv").show("slow");
        } else {
            var height = $(window).height();
            var dh = $(".m_chat_hed").outerHeight(true);
            dh = dh + 100;
            height = height - dh;
            $("#chatbox").css("height", height);
            $("#chatmessages").css("max-height", height);
            scrolltobottom("chatmessages");
            $("#toplacesdiv").hide("slow");
            $("#frmplacesdiv").hide("slow");
        }
        if (questionNo == 9) {
            $("#inputdiv").hide();
            $("#submit").hide();
            $("#loader").show();
            page = $("#hellotravelchat").attr("data-page");
            if (pkgdatatitle != "" && typeof pkgdatatitle != "undefined") {
                var data = {
                    choice: "YES",
                    tocity: pkgdatadest,
                    pkgtitle: pkgdatatitle,
                    dealid: pkgdataid,
                    loginid: pkgdataloginid,
                    pkgduration: pkgdatduration,
                    pkgprice: pkgdataprice,
                    pkgdest: pkgdatadest,
                    page: page,
                    traveldate: ansarray[3],
                    pkgcountryto: pkgdatacountryto,
                    fromcity: ansarray[4],
                    emailid: ansarray[5],
                    phoneno: ansarray[6],
                    groupsize: ansarray[7],
                    name: ansarray[8],
                    temp_leadid: temp_leadid,
                };
            } else {
                if (isreposne) {
                    var data = {
                        choice: ansarray[0],
                        tocity: ansarray[1],
                        pkgtitle: ansarray[2],
                        dealid: packageid,
                        loginid: loginid,
                        pkgduration: pkgduration,
                        pkgprice: pkgprice,
                        pkgdest: pkgdest,
                        page: page,
                        traveldate: ansarray[3],
                        pkgcountryto: pkgcountryto,
                        fromcity: ansarray[4],
                        emailid: ansarray[5],
                        phoneno: ansarray[6],
                        groupsize: ansarray[7],
                        name: ansarray[8],
                        temp_leadid: temp_leadid,
                    };
                } else {
                    var data = {
                        choice: ansarray[0],
                        tocity: ansarray[1],
                        pkgtitle: "",
                        dealid: "",
                        loginid: "",
                        pkgduration: durationmanual,
                        pkgprice: "",
                        pkgdest: "",
                        page: page,
                        traveldate: ansarray[3],
                        pkgcountryto: pkgcountryto,
                        fromcity: ansarray[4],
                        emailid: ansarray[5],
                        phoneno: ansarray[6],
                        groupsize: ansarray[7],
                        name: ansarray[8],
                        temp_leadid: temp_leadid,
                    };
                }
            }
            submitlead(data);
        }
        $(".ch_du1").fadeIn("slow");
        scrolltobottom("chatmessages");
        if (questionNo == 2) {
            $("#inputdiv").hide();
            $("#submit").hide();
            $("#loader").show();
            packageSlider(ans);
        }
        if (questionNo == 3) {
            var data = dateDropdownFormat();
            var context = { data: data };
            var html = datetemp(context);
            $("#loader").hide();
            $("#inputdiv").html(html);
            $("#inputdiv").show();
            $("#submit").show();
        }
        if (questionNo != 0 && questionNo != 2 && questionNo != 3 && questionNo != 9) {
            var sampletext = getplaceholder(questionNo);
            var placevalue = "";
            if (questionNo == 4) {
                placevalue = logincity;
            }
            if (questionNo == 5) {
                placevalue = loginemail;
            }
            if (questionNo == 6) {
                placevalue = logincontact;
            }
            if (questionNo == 7) {
                var page = $("#hellotravelchat").attr("data-page");
                if (pkgdatatitle != "" && typeof pkgdatatitle != "undefined") {
                    var data = {
                        choice: "YES",
                        tocity: pkgdatadest,
                        pkgtitle: pkgdatatitle,
                        dealid: pkgdataid,
                        loginid: pkgdataloginid,
                        pkgduration: pkgdatduration,
                        pkgprice: pkgdataprice,
                        pkgdest: pkgdatadest,
                        page: page,
                        traveldate: ansarray[3],
                        pkgcountryto: pkgdatacountryto,
                        fromcity: ansarray[4],
                        emailid: ansarray[5],
                        phoneno: ansarray[6],
                        temp_lead: "temp_lead",
                    };
                } else {
                    if (isreposne) {
                        var data = {
                            choice: ansarray[0],
                            tocity: ansarray[1],
                            pkgtitle: ansarray[2],
                            dealid: packageid,
                            loginid: loginid,
                            pkgduration: pkgduration,
                            pkgprice: pkgprice,
                            pkgdest: pkgdest,
                            page: page,
                            traveldate: ansarray[3],
                            pkgcountryto: pkgcountryto,
                            fromcity: ansarray[4],
                            emailid: ansarray[5],
                            phoneno: ansarray[6],
                            temp_lead: "temp_lead",
                        };
                    } else {
                        var data = {
                            choice: ansarray[0],
                            tocity: ansarray[1],
                            pkgtitle: "",
                            dealid: "",
                            loginid: "",
                            pkgduration: durationmanual,
                            pkgprice: "",
                            pkgdest: "",
                            page: page,
                            traveldate: ansarray[3],
                            pkgcountryto: pkgcountryto,
                            fromcity: ansarray[4],
                            emailid: ansarray[5],
                            phoneno: ansarray[6],
                            temp_lead: "temp_lead",
                        };
                    }
                }
                submittemplead(data);
            }
            if (questionNo == 8) {
                if (loginname != "") placevalue = loginname;
                else placevalue = getnamefrmemail(ansarray[5]);
            }
            if (questionNo == 6) {
                var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="number" />';
            } else if (questionNo == 7) {
                var input = trevtemp;
            } else {
                var input = '<input id="ansinp" placeholder="' + sampletext + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + placevalue + '" type="text" />';
            }
            $("#loader").hide();
            $("#inputdiv").html(input);
            $("#inputdiv").show();
            $("#submit").show();
        }
        $("#ansinp").focus();
        return false;
    }
}
function ifLoggedin(ques) {
    if (logincity.trim() != "" && typeof logincity != "undefined" && ques == 4) {
        ansarray.push(logincity);
        questionNo++;
        ques++;
    }
    if (loginemail.trim() != "" && typeof loginemail != "undefined" && ques == 5) {
        ansarray.push(loginemail);
        questionNo++;
        ques++;
    }
    if (logincontact.trim() != "" && typeof logincontact != "undefined" && ques == 6) {
        ansarray.push(logincontact);
        questionNo++;
        ques++;
    }
    if (loginname.trim() != "" && typeof loginname != "undefined" && ques == 8) {
        ansarray.push(loginname);
        questionNo++;
        ques++;
    }
}
function submitlead(data) {
    $.ajax({
        url: "../chat/chatlead.php",
        data: data,
        cache: false,
        type: "POST",
        success: function (data) {
            try {
                var data = JSON.parse(data);
                window.location = data["url"];
            } catch (err) {
                alert(data);
            }
        },
        error: function (error) {
            alert("Some error please try again");
            submitlead(data);
        },
    });
}
function submittemplead(data) {
    $.ajax({
        url: "../chat/chatlead.php",
        data: data,
        cache: false,
        type: "POST",
        success: function (data) {
            temp_leadid = data;
        },
    });
}
function storyslider() {
    $.ajax({
        url: "../chat/storyslider.php",
        cache: false,
        type: "GET",
        success: function (data) {
            var temp = JSON.parse(data);
            var countarray = Object.keys(temp.data).length;
            var storysliderhtml = storyslidertemp(temp);
            $("#chatmessages").append(storysliderhtml);
            $(".ch_du").fadeIn("slow");
            $("#content-slider2").lightSlider({ loop: true, keyPress: true, item: 1.2, pager: false, auto: false });
            scrolltobottom("chatmessages");
        },
        error: function (error) {
            alert("error; " + eval(error));
        },
    });
}
function packageSlider(ans) {
    $.ajax({
        url: "../chat/slider.php",
        data: { place: ans },
        type: "GET",
        cache: false,
        timeout: 5e3,
        success: function (data) {
            var temp = JSON.parse(data);
            if (temp.status === "true") {
                isreposne = true;
                var countarray = Object.keys(temp.data).length;
                if (countarray == 1) {
                    var itemsize = 1;
                } else {
                    var itemsize = 1.2;
                }
                var sliderhtml = slidertemp(temp);
                $("#chatmessages").append(sliderhtml);
                $("#content-slider2").lightSlider({ loop: true, keyPress: true, item: itemsize, pager: false, auto: false });
                scrolltobottom("chatmessages");
                $("#loader").hide();
            } else {
                $("#loader").hide();
                var html = durtemp;
                $("#inputdiv").html(html);
                $("#inputdiv").show();
                $("#submit").show();
            }
        },
        error: function (error) {
            $("#loader").hide();
            var html = durtemp;
            $("#inputdiv").html(html);
            $("#inputdiv").show();
            $("#submit").show();
        },
    });
}
function scrolltobottom(id) {
    var objDiv = document.getElementById(id);
    objDiv.scrollTop = objDiv.scrollHeight;
}
$(function () {
    (function ($, undefined) {
        "use strict";
        var defaults = {
            item: 3,
            autoWidth: false,
            slideMove: 1,
            slideMargin: 10,
            addClass: "",
            mode: "slide",
            useCSS: true,
            cssEasing: "ease",
            easing: "linear",
            speed: 400,
            auto: true,
            pauseOnHover: false,
            loop: false,
            slideEndAnimation: true,
            pause: 2e3,
            keyPress: false,
            controls: true,
            prevHtml: "",
            nextHtml: "",
            rtl: false,
            adaptiveHeight: false,
            vertical: false,
            verticalHeight: 500,
            vThumbWidth: 100,
            thumbItem: 10,
            pager: true,
            gallery: false,
            galleryMargin: 5,
            thumbMargin: 5,
            currentPagerPosition: "middle",
            enableTouch: true,
            enableDrag: true,
            freeMove: true,
            swipeThreshold: 40,
            responsive: [],
            onBeforeStart: function ($el) {},
            onSliderLoad: function ($el) {},
            onBeforeSlide: function ($el, scene) {},
            onAfterSlide: function ($el, scene) {},
            onBeforeNextSlide: function ($el, scene) {},
            onBeforePrevSlide: function ($el, scene) {},
        };
        $.fn.lightSlider = function (options) {
            if (this.length === 0) {
                return this;
            }
            if (this.length > 1) {
                this.each(function () {
                    $(this).lightSlider(options);
                });
                return this;
            }
            var plugin = {},
                settings = $.extend(true, {}, defaults, options),
                settingsTemp = {},
                $el = this;
            plugin.$el = this;
            if (settings.mode === "fade") {
                settings.vertical = false;
            }
            var $children = $el.children(),
                windowW = $(window).width(),
                breakpoint = null,
                resposiveObj = null,
                length = 0,
                w = 0,
                on = false,
                elSize = 0,
                $slide = "",
                scene = 0,
                property = settings.vertical === true ? "height" : "width",
                gutter = settings.vertical === true ? "margin-bottom" : "margin-right",
                slideValue = 0,
                pagerWidth = 0,
                slideWidth = 0,
                thumbWidth = 0,
                interval = null,
                isTouch = "ontouchstart" in document.documentElement;
            var refresh = {};
            refresh.chbreakpoint = function () {
                windowW = $(window).width();
                if (settings.responsive.length) {
                    var item;
                    if (settings.autoWidth === false) {
                        item = settings.item;
                    }
                    if (windowW < settings.responsive[0].breakpoint) {
                        for (var i = 0; i < settings.responsive.length; i++) {
                            if (windowW < settings.responsive[i].breakpoint) {
                                breakpoint = settings.responsive[i].breakpoint;
                                resposiveObj = settings.responsive[i];
                            }
                        }
                    }
                    if (typeof resposiveObj !== "undefined" && resposiveObj !== null) {
                        for (var j in resposiveObj.settings) {
                            if (resposiveObj.settings.hasOwnProperty(j)) {
                                if (typeof settingsTemp[j] === "undefined" || settingsTemp[j] === null) {
                                    settingsTemp[j] = settings[j];
                                }
                                settings[j] = resposiveObj.settings[j];
                            }
                        }
                    }
                    if (!$.isEmptyObject(settingsTemp) && windowW > settings.responsive[0].breakpoint) {
                        for (var k in settingsTemp) {
                            if (settingsTemp.hasOwnProperty(k)) {
                                settings[k] = settingsTemp[k];
                            }
                        }
                    }
                    if (settings.autoWidth === false) {
                        if (slideValue > 0 && slideWidth > 0) {
                            if (item !== settings.item) {
                                scene = Math.round(slideValue / ((slideWidth + settings.slideMargin) * settings.slideMove));
                            }
                        }
                    }
                }
            };
            refresh.calSW = function () {
                if (settings.autoWidth === false) {
                    slideWidth = (elSize - (settings.item * settings.slideMargin - settings.slideMargin)) / settings.item;
                }
            };
            refresh.calWidth = function (cln) {
                var ln = cln === true ? $slide.find(".lslide").length : $children.length;
                if (settings.autoWidth === false) {
                    w = ln * (slideWidth + settings.slideMargin);
                } else {
                    w = 0;
                    for (var i = 0; i < ln; i++) {
                        w += parseInt($children.eq(i).width()) + settings.slideMargin;
                    }
                }
                return w;
            };
            plugin = {
                doCss: function () {
                    var support = function () {
                        var transition = ["transition", "MozTransition", "WebkitTransition", "OTransition", "msTransition", "KhtmlTransition"];
                        var root = document.documentElement;
                        for (var i = 0; i < transition.length; i++) {
                            if (transition[i] in root.style) {
                                return true;
                            }
                        }
                    };
                    if (settings.useCSS && support()) {
                        return true;
                    }
                    return false;
                },
                keyPress: function () {
                    if (settings.keyPress) {
                        $(document).on("keyup.lightslider", function (e) {
                            if (!$(":focus").is("input, textarea")) {
                                if (e.preventDefault) {
                                    e.preventDefault();
                                } else {
                                    e.returnValue = false;
                                }
                                if (e.keyCode === 37) {
                                    $el.goToPrevSlide();
                                } else if (e.keyCode === 39) {
                                    $el.goToNextSlide();
                                }
                            }
                        });
                    }
                },
                controls: function () {
                    if (settings.controls) {
                        $el.after('<div class="lSAction"><a class="lSPrev">' + settings.prevHtml + '</a><a class="lSNext">' + settings.nextHtml + "</a></div>");
                        if (!settings.autoWidth) {
                            if (length <= settings.item) {
                                $slide.find(".lSAction").hide();
                            }
                        } else {
                            if (refresh.calWidth(false) < elSize) {
                                $slide.find(".lSAction").hide();
                            }
                        }
                        $slide.find(".lSAction a").on("click", function (e) {
                            if (e.preventDefault) {
                                e.preventDefault();
                            } else {
                                e.returnValue = false;
                            }
                            if ($(this).attr("class") === "lSPrev") {
                                $el.goToPrevSlide();
                            } else {
                                $el.goToNextSlide();
                            }
                            return false;
                        });
                    }
                },
                initialStyle: function () {
                    var $this = this;
                    if (settings.mode === "fade") {
                        settings.autoWidth = false;
                        settings.slideEndAnimation = false;
                    }
                    if (settings.auto) {
                        settings.slideEndAnimation = false;
                    }
                    if (settings.autoWidth) {
                        settings.slideMove = 1;
                        settings.item = 1;
                    }
                    if (settings.loop) {
                        settings.slideMove = 1;
                        settings.freeMove = false;
                    }
                    settings.onBeforeStart.call(this, $el);
                    refresh.chbreakpoint();
                    $el.addClass("lightSlider").wrap('<div class="lSSlideOuter ' + settings.addClass + '"><div class="lSSlideWrapper"></div></div>');
                    $slide = $el.parent(".lSSlideWrapper");
                    if (settings.rtl === true) {
                        $slide.parent().addClass("lSrtl");
                    }
                    if (settings.vertical) {
                        $slide.parent().addClass("vertical");
                        elSize = settings.verticalHeight;
                        $slide.css("height", elSize + "px");
                    } else {
                        elSize = $el.outerWidth();
                    }
                    $children.addClass("lslide");
                    if (settings.loop === true && settings.mode === "slide") {
                        refresh.calSW();
                        refresh.clone = function () {
                            if (refresh.calWidth(true) > elSize) {
                                var tWr = 0,
                                    tI = 0;
                                for (var k = 0; k < $children.length; k++) {
                                    tWr += parseInt($el.find(".lslide").eq(k).width()) + settings.slideMargin;
                                    tI++;
                                    if (tWr >= elSize + settings.slideMargin) {
                                        break;
                                    }
                                }
                                var tItem = settings.autoWidth === true ? tI : settings.item;
                                if (tItem < $el.find(".clone.left").length) {
                                    for (var i = 0; i < $el.find(".clone.left").length - tItem; i++) {
                                        $children.eq(i).remove();
                                    }
                                }
                                if (tItem < $el.find(".clone.right").length) {
                                    for (var j = $children.length - 1; j > $children.length - 1 - $el.find(".clone.right").length; j--) {
                                        scene--;
                                        $children.eq(j).remove();
                                    }
                                }
                                for (var n = $el.find(".clone.right").length; n < tItem; n++) {
                                    $el.find(".lslide").eq(n).clone().removeClass("lslide").addClass("clone right").appendTo($el);
                                    scene++;
                                }
                                for (var m = $el.find(".lslide").length - $el.find(".clone.left").length; m > $el.find(".lslide").length - tItem; m--) {
                                    $el.find(".lslide")
                                        .eq(m - 1)
                                        .clone()
                                        .removeClass("lslide")
                                        .addClass("clone left")
                                        .prependTo($el);
                                }
                                $children = $el.children();
                            } else {
                                if ($children.hasClass("clone")) {
                                    $el.find(".clone").remove();
                                    $this.move($el, 0);
                                }
                            }
                        };
                        refresh.clone();
                    }
                    refresh.sSW = function () {
                        length = $children.length;
                        if (settings.rtl === true && settings.vertical === false) {
                            gutter = "margin-left";
                        }
                        if (settings.autoWidth === false) {
                            $children.css(property, slideWidth + "px");
                        }
                        $children.css(gutter, settings.slideMargin + "px");
                        w = refresh.calWidth(false);
                        $el.css(property, w + "px");
                        if (settings.loop === true && settings.mode === "slide") {
                            if (on === false) {
                                scene = $el.find(".clone.left").length;
                            }
                        }
                    };
                    refresh.calL = function () {
                        $children = $el.children();
                        length = $children.length;
                    };
                    if (this.doCss()) {
                        $slide.addClass("usingCss");
                    }
                    refresh.calL();
                    if (settings.mode === "slide") {
                        refresh.calSW();
                        refresh.sSW();
                        if (settings.loop === true) {
                            slideValue = $this.slideValue();
                            this.move($el, slideValue);
                        }
                        if (settings.vertical === false) {
                            this.setHeight($el, false);
                        }
                    } else {
                        this.setHeight($el, true);
                        $el.addClass("lSFade");
                        if (!this.doCss()) {
                            $children.fadeOut(0);
                            $children.eq(scene).fadeIn(0);
                        }
                    }
                    if (settings.loop === true && settings.mode === "slide") {
                        $children.eq(scene).addClass("active");
                    } else {
                        $children.first().addClass("active");
                    }
                },
                pager: function () {
                    var $this = this;
                    refresh.createPager = function () {
                        thumbWidth = (elSize - (settings.thumbItem * settings.thumbMargin - settings.thumbMargin)) / settings.thumbItem;
                        var $children = $slide.find(".lslide");
                        var length = $slide.find(".lslide").length;
                        var i = 0,
                            pagers = "",
                            v = 0;
                        for (i = 0; i < length; i++) {
                            if (settings.mode === "slide") {
                                if (!settings.autoWidth) {
                                    v = i * ((slideWidth + settings.slideMargin) * settings.slideMove);
                                } else {
                                    v += (parseInt($children.eq(i).width()) + settings.slideMargin) * settings.slideMove;
                                }
                            }
                            var thumb = $children.eq(i * settings.slideMove).attr("data-thumb");
                            if (settings.gallery === true) {
                                pagers += '<li style="width:100%;' + property + ":" + thumbWidth + "px;" + gutter + ":" + settings.thumbMargin + 'px"><a href="#"><img src="' + thumb + '" /></a></li>';
                            } else {
                                pagers += '<li><a href="#">' + (i + 1) + "</a></li>";
                            }
                            if (settings.mode === "slide") {
                                if (v >= w - elSize - settings.slideMargin) {
                                    i = i + 1;
                                    var minPgr = 2;
                                    if (settings.autoWidth) {
                                        pagers += '<li><a href="#">' + (i + 1) + "</a></li>";
                                        minPgr = 1;
                                    }
                                    if (i < minPgr) {
                                        pagers = null;
                                        $slide.parent().addClass("noPager");
                                    } else {
                                        $slide.parent().removeClass("noPager");
                                    }
                                    break;
                                }
                            }
                        }
                        var $cSouter = $slide.parent();
                        $cSouter.find(".lSPager").html(pagers);
                        if (settings.gallery === true) {
                            if (settings.vertical === true) {
                                $cSouter.find(".lSPager").css("width", settings.vThumbWidth + "px");
                            }
                            pagerWidth = i * (settings.thumbMargin + thumbWidth) + 0.5;
                            $cSouter.find(".lSPager").css({ property: pagerWidth + "px", "transition-duration": settings.speed + "ms" });
                            if (settings.vertical === true) {
                                $slide.parent().css("padding-right", settings.vThumbWidth + settings.galleryMargin + "px");
                            }
                            $cSouter.find(".lSPager").css(property, pagerWidth + "px");
                        }
                        var $pager = $cSouter.find(".lSPager").find("li");
                        $pager.first().addClass("active");
                        $pager.on("click", function () {
                            if (settings.loop === true && settings.mode === "slide") {
                                scene = scene + ($pager.index(this) - $cSouter.find(".lSPager").find("li.active").index());
                            } else {
                                scene = $pager.index(this);
                            }
                            $el.mode(false);
                            if (settings.gallery === true) {
                                $this.slideThumb();
                            }
                            return false;
                        });
                    };
                    if (settings.pager) {
                        var cl = "lSpg";
                        if (settings.gallery) {
                            cl = "lSGallery";
                        }
                        $slide.after('<ul class="lSPager ' + cl + '"></ul>');
                        var gMargin = settings.vertical ? "margin-left" : "margin-top";
                        $slide
                            .parent()
                            .find(".lSPager")
                            .css(gMargin, settings.galleryMargin + "px");
                        refresh.createPager();
                    }
                    setTimeout(function () {
                        refresh.init();
                    }, 0);
                },
                setHeight: function (ob, fade) {
                    var obj = null,
                        $this = this;
                    if (settings.loop) {
                        obj = ob.children(".lslide ").first();
                    } else {
                        obj = ob.children().first();
                    }
                    var setCss = function () {
                        var tH = obj.outerHeight(),
                            tP = 0,
                            tHT = tH;
                        if (fade) {
                            tH = 0;
                            tP = (tHT * 100) / elSize;
                        }
                        ob.css({ height: tH + "px", "padding-bottom": tP + "%" });
                    };
                    setCss();
                    if (obj.find("img").length) {
                        if (obj.find("img")[0].complete) {
                            setCss();
                            if (!interval) {
                                $this.auto();
                            }
                        } else {
                            obj.find("img").on("load", function () {
                                setTimeout(function () {
                                    setCss();
                                    if (!interval) {
                                        $this.auto();
                                    }
                                }, 100);
                            });
                        }
                    } else {
                        if (!interval) {
                            $this.auto();
                        }
                    }
                },
                active: function (ob, t) {
                    if (this.doCss() && settings.mode === "fade") {
                        $slide.addClass("on");
                    }
                    var sc = 0;
                    if (scene * settings.slideMove < length) {
                        ob.removeClass("active");
                        if (!this.doCss() && settings.mode === "fade" && t === false) {
                            ob.fadeOut(settings.speed);
                        }
                        if (t === true) {
                            sc = scene;
                        } else {
                            sc = scene * settings.slideMove;
                        }
                        var l, nl;
                        if (t === true) {
                            l = ob.length;
                            nl = l - 1;
                            if (sc + 1 >= l) {
                                sc = nl;
                            }
                        }
                        if (settings.loop === true && settings.mode === "slide") {
                            if (t === true) {
                                sc = scene - $el.find(".clone.left").length;
                            } else {
                                sc = scene * settings.slideMove;
                            }
                            if (t === true) {
                                l = ob.length;
                                nl = l - 1;
                                if (sc + 1 === l) {
                                    sc = nl;
                                } else if (sc + 1 > l) {
                                    sc = 0;
                                }
                            }
                        }
                        if (!this.doCss() && settings.mode === "fade" && t === false) {
                            ob.eq(sc).fadeIn(settings.speed);
                        }
                        ob.eq(sc).addClass("active");
                    } else {
                        ob.removeClass("active");
                        ob.eq(ob.length - 1).addClass("active");
                        if (!this.doCss() && settings.mode === "fade" && t === false) {
                            ob.fadeOut(settings.speed);
                            ob.eq(sc).fadeIn(settings.speed);
                        }
                    }
                },
                move: function (ob, v) {
                    if (settings.rtl === true) {
                        v = -v;
                    }
                    if (this.doCss()) {
                        if (settings.vertical === true) {
                            ob.css({ transform: "translate3d(0px, " + -v + "px, 0px)", "-webkit-transform": "translate3d(0px, " + -v + "px, 0px)" });
                        } else {
                            ob.css({ transform: "translate3d(" + -v + "px, 0px, 0px)", "-webkit-transform": "translate3d(" + -v + "px, 0px, 0px)" });
                        }
                    } else {
                        if (settings.vertical === true) {
                            ob.css("position", "relative").animate({ top: -v + "px" }, settings.speed, settings.easing);
                        } else {
                            ob.css("position", "relative").animate({ left: -v + "px" }, settings.speed, settings.easing);
                        }
                    }
                    var $thumb = $slide.parent().find(".lSPager").find("li");
                    this.active($thumb, true);
                },
                fade: function () {
                    this.active($children, false);
                    var $thumb = $slide.parent().find(".lSPager").find("li");
                    this.active($thumb, true);
                },
                slide: function () {
                    var $this = this;
                    refresh.calSlide = function () {
                        if (w > elSize) {
                            slideValue = $this.slideValue();
                            $this.active($children, false);
                            if (slideValue > w - elSize - settings.slideMargin) {
                                slideValue = w - elSize - settings.slideMargin;
                            } else if (slideValue < 0) {
                                slideValue = 0;
                            }
                            $this.move($el, slideValue);
                            if (settings.loop === true && settings.mode === "slide") {
                                if (scene >= length - $el.find(".clone.left").length / settings.slideMove) {
                                    $this.resetSlide($el.find(".clone.left").length);
                                }
                                if (scene === 0) {
                                    $this.resetSlide($slide.find(".lslide").length);
                                }
                            }
                        }
                    };
                    refresh.calSlide();
                },
                resetSlide: function (s) {
                    var $this = this;
                    $slide.find(".lSAction a").addClass("disabled");
                    setTimeout(function () {
                        scene = s;
                        $slide.css("transition-duration", "0ms");
                        slideValue = $this.slideValue();
                        $this.active($children, false);
                        plugin.move($el, slideValue);
                        setTimeout(function () {
                            $slide.css("transition-duration", settings.speed + "ms");
                            $slide.find(".lSAction a").removeClass("disabled");
                        }, 50);
                    }, settings.speed + 100);
                },
                slideValue: function () {
                    var _sV = 0;
                    if (settings.autoWidth === false) {
                        _sV = scene * ((slideWidth + settings.slideMargin) * settings.slideMove);
                    } else {
                        _sV = 0;
                        for (var i = 0; i < scene; i++) {
                            _sV += parseInt($children.eq(i).width()) + settings.slideMargin;
                        }
                    }
                    return _sV;
                },
                slideThumb: function () {
                    var position;
                    switch (settings.currentPagerPosition) {
                        case "left":
                            position = 0;
                            break;
                        case "middle":
                            position = elSize / 2 - thumbWidth / 2;
                            break;
                        case "right":
                            position = elSize - thumbWidth;
                    }
                    var sc = scene - $el.find(".clone.left").length;
                    var $pager = $slide.parent().find(".lSPager");
                    if (settings.mode === "slide" && settings.loop === true) {
                        if (sc >= $pager.children().length) {
                            sc = 0;
                        } else if (sc < 0) {
                            sc = $pager.children().length;
                        }
                    }
                    var thumbSlide = sc * (thumbWidth + settings.thumbMargin) - position;
                    if (thumbSlide + elSize > pagerWidth) {
                        thumbSlide = pagerWidth - elSize - settings.thumbMargin;
                    }
                    if (thumbSlide < 0) {
                        thumbSlide = 0;
                    }
                    this.move($pager, thumbSlide);
                },
                auto: function () {
                    if (settings.auto) {
                        clearInterval(interval);
                        interval = setInterval(function () {
                            $el.goToNextSlide();
                        }, settings.pause);
                    }
                },
                pauseOnHover: function () {
                    var $this = this;
                    if (settings.auto && settings.pauseOnHover) {
                        $slide.on("mouseenter", function () {
                            $(this).addClass("ls-hover");
                            $el.pause();
                            settings.auto = true;
                        });
                        $slide.on("mouseleave", function () {
                            $(this).removeClass("ls-hover");
                            if (!$slide.find(".lightSlider").hasClass("lsGrabbing")) {
                                $this.auto();
                            }
                        });
                    }
                },
                touchMove: function (endCoords, startCoords) {
                    $slide.css("transition-duration", "0ms");
                    if (settings.mode === "slide") {
                        var distance = endCoords - startCoords;
                        var swipeVal = slideValue - distance;
                        if (swipeVal >= w - elSize - settings.slideMargin) {
                            if (settings.freeMove === false) {
                                swipeVal = w - elSize - settings.slideMargin;
                            } else {
                                var swipeValT = w - elSize - settings.slideMargin;
                                swipeVal = swipeValT + (swipeVal - swipeValT) / 5;
                            }
                        } else if (swipeVal < 0) {
                            if (settings.freeMove === false) {
                                swipeVal = 0;
                            } else {
                                swipeVal = swipeVal / 5;
                            }
                        }
                        this.move($el, swipeVal);
                    }
                },
                touchEnd: function (distance) {
                    $slide.css("transition-duration", settings.speed + "ms");
                    if (settings.mode === "slide") {
                        var mxVal = false;
                        var _next = true;
                        slideValue = slideValue - distance;
                        if (slideValue > w - elSize - settings.slideMargin) {
                            slideValue = w - elSize - settings.slideMargin;
                            if (settings.autoWidth === false) {
                                mxVal = true;
                            }
                        } else if (slideValue < 0) {
                            slideValue = 0;
                        }
                        var gC = function (next) {
                            var ad = 0;
                            if (!mxVal) {
                                if (next) {
                                    ad = 1;
                                }
                            }
                            if (!settings.autoWidth) {
                                var num = slideValue / ((slideWidth + settings.slideMargin) * settings.slideMove);
                                scene = parseInt(num) + ad;
                                if (slideValue >= w - elSize - settings.slideMargin) {
                                    if (num % 1 !== 0) {
                                        scene++;
                                    }
                                }
                            } else {
                                var tW = 0;
                                for (var i = 0; i < $children.length; i++) {
                                    tW += parseInt($children.eq(i).width()) + settings.slideMargin;
                                    scene = i + ad;
                                    if (tW >= slideValue) {
                                        break;
                                    }
                                }
                            }
                        };
                        if (distance >= settings.swipeThreshold) {
                            gC(false);
                            _next = false;
                        } else if (distance <= -settings.swipeThreshold) {
                            gC(true);
                            _next = false;
                        }
                        $el.mode(_next);
                        this.slideThumb();
                    } else {
                        if (distance >= settings.swipeThreshold) {
                            $el.goToPrevSlide();
                        } else if (distance <= -settings.swipeThreshold) {
                            $el.goToNextSlide();
                        }
                    }
                },
                enableDrag: function () {
                    var $this = this;
                    if (!isTouch) {
                        var startCoords = 0,
                            endCoords = 0,
                            isDraging = false;
                        $slide.find(".lightSlider").addClass("lsGrab");
                        $slide.on("mousedown", function (e) {
                            if (w < elSize) {
                                if (w !== 0) {
                                    return false;
                                }
                            }
                            if ($(e.target).attr("class") !== "lSPrev" && $(e.target).attr("class") !== "lSNext") {
                                startCoords = settings.vertical === true ? e.pageY : e.pageX;
                                isDraging = true;
                                if (e.preventDefault) {
                                    e.preventDefault();
                                } else {
                                    e.returnValue = false;
                                }
                                $slide.scrollLeft += 1;
                                $slide.scrollLeft -= 1;
                                $slide.find(".lightSlider").removeClass("lsGrab").addClass("lsGrabbing");
                                clearInterval(interval);
                            }
                        });
                        $(window).on("mousemove", function (e) {
                            if (isDraging) {
                                endCoords = settings.vertical === true ? e.pageY : e.pageX;
                                $this.touchMove(endCoords, startCoords);
                            }
                        });
                        $(window).on("mouseup", function (e) {
                            if (isDraging) {
                                $slide.find(".lightSlider").removeClass("lsGrabbing").addClass("lsGrab");
                                isDraging = false;
                                endCoords = settings.vertical === true ? e.pageY : e.pageX;
                                var distance = endCoords - startCoords;
                                if (Math.abs(distance) >= settings.swipeThreshold) {
                                    $(window).on("click.ls", function (e) {
                                        if (e.preventDefault) {
                                            e.preventDefault();
                                        } else {
                                            e.returnValue = false;
                                        }
                                        e.stopImmediatePropagation();
                                        e.stopPropagation();
                                        $(window).off("click.ls");
                                    });
                                }
                                $this.touchEnd(distance);
                            }
                        });
                    }
                },
                enableTouch: function () {
                    var $this = this;
                    if (isTouch) {
                        var startCoords = {},
                            endCoords = {};
                        $slide.on("touchstart", function (e) {
                            endCoords = e.originalEvent.targetTouches[0];
                            startCoords.pageX = e.originalEvent.targetTouches[0].pageX;
                            startCoords.pageY = e.originalEvent.targetTouches[0].pageY;
                            clearInterval(interval);
                        });
                        $slide.on("touchmove", function (e) {
                            if (w < elSize) {
                                if (w !== 0) {
                                    return false;
                                }
                            }
                            var orig = e.originalEvent;
                            endCoords = orig.targetTouches[0];
                            var xMovement = Math.abs(endCoords.pageX - startCoords.pageX);
                            var yMovement = Math.abs(endCoords.pageY - startCoords.pageY);
                            if (settings.vertical === true) {
                                if (yMovement * 3 > xMovement) {
                                    e.preventDefault();
                                }
                                $this.touchMove(endCoords.pageY, startCoords.pageY);
                            } else {
                                if (xMovement * 3 > yMovement) {
                                    e.preventDefault();
                                }
                                $this.touchMove(endCoords.pageX, startCoords.pageX);
                            }
                        });
                        $slide.on("touchend", function () {
                            if (w < elSize) {
                                if (w !== 0) {
                                    return false;
                                }
                            }
                            var distance;
                            if (settings.vertical === true) {
                                distance = endCoords.pageY - startCoords.pageY;
                            } else {
                                distance = endCoords.pageX - startCoords.pageX;
                            }
                            $this.touchEnd(distance);
                        });
                    }
                },
                build: function () {
                    var $this = this;
                    $this.initialStyle();
                    if (this.doCss()) {
                        if (settings.enableTouch === true) {
                            $this.enableTouch();
                        }
                        if (settings.enableDrag === true) {
                            $this.enableDrag();
                        }
                    }
                    $(window).on("focus", function () {
                        $this.auto();
                    });
                    $(window).on("blur", function () {
                        clearInterval(interval);
                    });
                    $this.pager();
                    $this.pauseOnHover();
                    $this.controls();
                    $this.keyPress();
                },
            };
            plugin.build();
            refresh.init = function () {
                refresh.chbreakpoint();
                if (settings.vertical === true) {
                    if (settings.item > 1) {
                        elSize = settings.verticalHeight;
                    } else {
                        elSize = $children.outerHeight();
                    }
                    $slide.css("height", elSize + "px");
                } else {
                    elSize = $slide.outerWidth();
                }
                if (settings.loop === true && settings.mode === "slide") {
                    refresh.clone();
                }
                refresh.calL();
                if (settings.mode === "slide") {
                    $el.removeClass("lSSlide");
                }
                if (settings.mode === "slide") {
                    refresh.calSW();
                    refresh.sSW();
                }
                setTimeout(function () {
                    if (settings.mode === "slide") {
                        $el.addClass("lSSlide");
                    }
                }, 1e3);
                if (settings.pager) {
                    refresh.createPager();
                }
                if (settings.adaptiveHeight === true && settings.vertical === false) {
                    $el.css("height", $children.eq(scene).outerHeight(true));
                }
                if (settings.adaptiveHeight === false) {
                    if (settings.mode === "slide") {
                        if (settings.vertical === false) {
                            plugin.setHeight($el, false);
                        } else {
                            plugin.auto();
                        }
                    } else {
                        plugin.setHeight($el, true);
                    }
                }
                if (settings.gallery === true) {
                    plugin.slideThumb();
                }
                if (settings.mode === "slide") {
                    plugin.slide();
                }
                if (settings.autoWidth === false) {
                    if ($children.length <= settings.item) {
                        $slide.find(".lSAction").hide();
                    } else {
                        $slide.find(".lSAction").show();
                    }
                } else {
                    if (refresh.calWidth(false) < elSize && w !== 0) {
                        $slide.find(".lSAction").hide();
                    } else {
                        $slide.find(".lSAction").show();
                    }
                }
            };
            $el.goToPrevSlide = function () {
                if (scene > 0) {
                    settings.onBeforePrevSlide.call(this, $el, scene);
                    scene--;
                    $el.mode(false);
                    if (settings.gallery === true) {
                        plugin.slideThumb();
                    }
                } else {
                    if (settings.loop === true) {
                        settings.onBeforePrevSlide.call(this, $el, scene);
                        if (settings.mode === "fade") {
                            var l = length - 1;
                            scene = parseInt(l / settings.slideMove);
                        }
                        $el.mode(false);
                        if (settings.gallery === true) {
                            plugin.slideThumb();
                        }
                    } else if (settings.slideEndAnimation === true) {
                        $el.addClass("leftEnd");
                        setTimeout(function () {
                            $el.removeClass("leftEnd");
                        }, 400);
                    }
                }
            };
            $el.goToNextSlide = function () {
                var nextI = true;
                if (settings.mode === "slide") {
                    var _slideValue = plugin.slideValue();
                    nextI = _slideValue < w - elSize - settings.slideMargin;
                }
                if (scene * settings.slideMove < length - settings.slideMove && nextI) {
                    settings.onBeforeNextSlide.call(this, $el, scene);
                    scene++;
                    $el.mode(false);
                    if (settings.gallery === true) {
                        plugin.slideThumb();
                    }
                } else {
                    if (settings.loop === true) {
                        settings.onBeforeNextSlide.call(this, $el, scene);
                        scene = 0;
                        $el.mode(false);
                        if (settings.gallery === true) {
                            plugin.slideThumb();
                        }
                    } else if (settings.slideEndAnimation === true) {
                        $el.addClass("rightEnd");
                        setTimeout(function () {
                            $el.removeClass("rightEnd");
                        }, 400);
                    }
                }
            };
            $el.mode = function (_touch) {
                if (settings.adaptiveHeight === true && settings.vertical === false) {
                    $el.css("height", $children.eq(scene).outerHeight(true));
                }
                if (on === false) {
                    if (settings.mode === "slide") {
                        if (plugin.doCss()) {
                            $el.addClass("lSSlide");
                            if (settings.speed !== "") {
                                $slide.css("transition-duration", settings.speed + "ms");
                            }
                            if (settings.cssEasing !== "") {
                                $slide.css("transition-timing-function", settings.cssEasing);
                            }
                        }
                    } else {
                        if (plugin.doCss()) {
                            if (settings.speed !== "") {
                                $el.css("transition-duration", settings.speed + "ms");
                            }
                            if (settings.cssEasing !== "") {
                                $el.css("transition-timing-function", settings.cssEasing);
                            }
                        }
                    }
                }
                if (!_touch) {
                    settings.onBeforeSlide.call(this, $el, scene);
                }
                if (settings.mode === "slide") {
                    plugin.slide();
                } else {
                    plugin.fade();
                }
                if (!$slide.hasClass("ls-hover")) {
                    plugin.auto();
                }
                setTimeout(function () {
                    if (!_touch) {
                        settings.onAfterSlide.call(this, $el, scene);
                    }
                }, settings.speed);
                on = true;
            };
            $el.play = function () {
                $el.goToNextSlide();
                settings.auto = true;
                plugin.auto();
            };
            $el.pause = function () {
                settings.auto = false;
                clearInterval(interval);
            };
            $el.refresh = function () {
                refresh.init();
            };
            $el.getCurrentSlideCount = function () {
                var sc = scene;
                if (settings.loop) {
                    var ln = $slide.find(".lslide").length,
                        cl = $el.find(".clone.left").length;
                    if (scene <= cl - 1) {
                        sc = ln + (scene - cl);
                    } else if (scene >= ln + cl) {
                        sc = scene - ln - cl;
                    } else {
                        sc = scene - cl;
                    }
                }
                return sc + 1;
            };
            $el.getTotalSlideCount = function () {
                return $slide.find(".lslide").length;
            };
            $el.goToSlide = function (s) {
                if (settings.loop) {
                    scene = s + $el.find(".clone.left").length - 1;
                } else {
                    scene = s;
                }
                $el.mode(false);
                if (settings.gallery === true) {
                    plugin.slideThumb();
                }
            };
            $el.destroy = function () {
                if ($el.lightSlider) {
                    $el.goToPrevSlide = function () {};
                    $el.goToNextSlide = function () {};
                    $el.mode = function () {};
                    $el.play = function () {};
                    $el.pause = function () {};
                    $el.refresh = function () {};
                    $el.getCurrentSlideCount = function () {};
                    $el.getTotalSlideCount = function () {};
                    $el.goToSlide = function () {};
                    $el.lightSlider = null;
                    refresh = { init: function () {} };
                    $el.parent().parent().find(".lSAction, .lSPager").remove();
                    $el.removeClass("lightSlider lSFade lSSlide lsGrab lsGrabbing leftEnd right").removeAttr("style").unwrap().unwrap();
                    $el.children().removeAttr("style");
                    $children.removeClass("lslide active");
                    $el.find(".clone").remove();
                    $children = null;
                    interval = null;
                    on = false;
                    scene = 0;
                }
            };
            setTimeout(function () {
                settings.onSliderLoad.call(this, $el);
            }, 10);
            $(window).on("resize orientationchange", function (e) {
                setTimeout(function () {
                    if (e.preventDefault) {
                        e.preventDefault();
                    } else {
                        e.returnValue = false;
                    }
                    refresh.init();
                }, 200);
            });
            return this;
        };
    })(jQuery);
});
$(function () {
    var _extends =
            Object.assign ||
            function (e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
                }
                return e;
            },
        _typeof =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                      return typeof e;
                  }
                : function (e) {
                      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                  };
    !(function (e, t) {
        "object" === ("undefined" == typeof exports ? "undefined" : _typeof(exports)) && "undefined" != typeof module ? (module.exports = t()) : "function" == typeof define && define.amd ? define(t) : (e.LazyLoad = t());
    })(this, function () {
        "use strict";
        var e = {
                elements_selector: "img",
                container: document,
                threshold: 300,
                data_src: "src",
                data_srcset: "srcset",
                class_loading: "loading",
                class_loaded: "loaded",
                class_error: "error",
                callback_load: null,
                callback_error: null,
                callback_set: null,
            },
            t = function (e, t) {
                return e.getAttribute("data-" + t);
            },
            n = function (e, t, n) {
                return e.setAttribute("data-" + t, n);
            },
            r = function (e) {
                return e.filter(function (e) {
                    return !t(e, "was-processed");
                });
            },
            s = function (e, t) {
                var n = new e(t),
                    r = new CustomEvent("LazyLoad::Initialized", { detail: { instance: n } });
                window.dispatchEvent(r);
            },
            o = function (e, n) {
                var r = n.data_srcset,
                    s = e.parentElement;
                if ("PICTURE" === s.tagName)
                    for (var o, a = 0; (o = s.children[a]); a += 1)
                        if ("SOURCE" === o.tagName) {
                            var i = t(o, r);
                            i && o.setAttribute("srcset", i);
                        }
            },
            a = function (e, n) {
                var r = n.data_src,
                    s = n.data_srcset,
                    a = e.tagName,
                    i = t(e, r);
                if ("IMG" === a) {
                    o(e, n);
                    var c = t(e, s);
                    return c && e.setAttribute("srcset", c), void (i && e.setAttribute("src", i));
                }
                "IFRAME" !== a ? i && (e.style.backgroundImage = 'url("' + i + '")') : i && e.setAttribute("src", i);
            },
            i = !!document.body.classList,
            c = function (e, t) {
                i ? e.classList.add(t) : (e.className += (e.className ? " " : "") + t);
            },
            l = function (e, t) {
                i
                    ? e.classList.remove(t)
                    : (e.className = e.className
                          .replace(new RegExp("(^|\\s+)" + t + "(\\s+|$)"), " ")
                          .replace(/^\s+/, "")
                          .replace(/\s+$/, ""));
            },
            u = function (e, t) {
                e && e(t);
            },
            f = function (e, t, n) {
                e.removeEventListener("load", t), e.removeEventListener("error", n);
            },
            d = function (e, t) {
                var n = function n(s) {
                        _(s, !0, t), f(e, n, r);
                    },
                    r = function r(s) {
                        _(s, !1, t), f(e, n, r);
                    };
                e.addEventListener("load", n), e.addEventListener("error", r);
            },
            _ = function (e, t, n) {
                var r = e.target;
                l(r, n.class_loading), c(r, t ? n.class_loaded : n.class_error), u(t ? n.callback_load : n.callback_error, r);
            },
            v = function (e, t) {
                ["IMG", "IFRAME"].indexOf(e.tagName) > -1 && (d(e, t), c(e, t.class_loading)), a(e, t), n(e, "was-processed", !0), u(t.callback_set, e);
            },
            m = function (t, n) {
                (this._settings = _extends({}, e, t)), this._setObserver(), this.update(n);
            };
        m.prototype = {
            _setObserver: function () {
                var e = this;
                if ("IntersectionObserver" in window) {
                    var t = this._settings;
                    this._observer = new IntersectionObserver(
                        function (n) {
                            n.forEach(function (n) {
                                if (n.intersectionRatio > 0) {
                                    var r = n.target;
                                    v(r, t), e._observer.unobserve(r);
                                }
                            }),
                                (e._elements = r(e._elements));
                        },
                        { root: t.container === document ? null : t.container, rootMargin: t.threshold + "px" }
                    );
                }
            },
            update: function (e) {
                var t = this,
                    n = this._settings,
                    s = e || n.container.querySelectorAll(n.elements_selector);
                (this._elements = r(Array.prototype.slice.call(s))),
                    this._observer
                        ? this._elements.forEach(function (e) {
                              t._observer.observe(e);
                          })
                        : (this._elements.forEach(function (e) {
                              v(e, n);
                          }),
                          (this._elements = r(this._elements)));
            },
            destroy: function () {
                var e = this;
                this._observer &&
                    (r(this._elements).forEach(function (t) {
                        e._observer.unobserve(t);
                    }),
                    (this._observer = null)),
                    (this._elements = null),
                    (this._settings = null);
            },
        };
        var b = window.lazyLoadOptions;
        return (
            b &&
                (function (e, t) {
                    if (t.length) for (var n, r = 0; (n = t[r]); r += 1) s(e, n);
                    else s(e, t);
                })(m, b),
            m
        );
    });
});
!(function (t) {
    "function" == typeof define && define.amd ? define(["jquery"], t) : t(jQuery);
})(function (t) {
    function e(t) {
        for (var e = t.css("visibility"); "inherit" === e; ) (t = t.parent()), (e = t.css("visibility"));
        return "hidden" !== e;
    }
    function i(t) {
        for (var e, i; t.length && t[0] !== document; ) {
            if (((e = t.css("position")), ("absolute" === e || "relative" === e || "fixed" === e) && ((i = parseInt(t.css("zIndex"), 10)), !isNaN(i) && 0 !== i))) return i;
            t = t.parent();
        }
        return 0;
    }
    function s() {
        (this._curInst = null),
            (this._keyEvent = !1),
            (this._disabledInputs = []),
            (this._datepickerShowing = !1),
            (this._inDialog = !1),
            (this._mainDivId = "ui-datepicker-div"),
            (this._inlineClass = "ui-datepicker-inline"),
            (this._appendClass = "ui-datepicker-append"),
            (this._triggerClass = "ui-datepicker-trigger"),
            (this._dialogClass = "ui-datepicker-dialog"),
            (this._disableClass = "ui-datepicker-disabled"),
            (this._unselectableClass = "ui-datepicker-unselectable"),
            (this._currentClass = "ui-datepicker-current-day"),
            (this._dayOverClass = "ui-datepicker-days-cell-over"),
            (this.regional = []),
            (this.regional[""] = {
                closeText: "Done",
                prevText: "Prev",
                nextText: "Next",
                currentText: "Today",
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                weekHeader: "Wk",
                dateFormat: "mm/dd/yy",
                firstDay: 0,
                isRTL: !1,
                showMonthAfterYear: !1,
                yearSuffix: "",
            }),
            (this._defaults = {
                showOn: "focus",
                showAnim: "fadeIn",
                showOptions: {},
                defaultDate: null,
                appendText: "",
                buttonText: "...",
                buttonImage: "",
                buttonImageOnly: !1,
                hideIfNoPrevNext: !1,
                navigationAsDateFormat: !1,
                gotoCurrent: !1,
                changeMonth: !1,
                changeYear: !1,
                yearRange: "c-10:c+10",
                showOtherMonths: !1,
                selectOtherMonths: !1,
                showWeek: !1,
                calculateWeek: this.iso8601Week,
                shortYearCutoff: "+10",
                minDate: null,
                maxDate: null,
                duration: "fast",
                beforeShowDay: null,
                beforeShow: null,
                onSelect: null,
                onChangeMonthYear: null,
                onClose: null,
                numberOfMonths: 1,
                showCurrentAtPos: 0,
                stepMonths: 1,
                stepBigMonths: 12,
                altField: "",
                altFormat: "",
                constrainInput: !0,
                showButtonPanel: !1,
                autoSize: !1,
                disabled: !1,
            }),
            t.extend(this._defaults, this.regional[""]),
            (this.regional.en = t.extend(!0, {}, this.regional[""])),
            (this.regional["en-US"] = t.extend(!0, {}, this.regional.en)),
            (this.dpDiv = n(t("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")));
    }
    function n(e) {
        var i = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
        return e
            .on("mouseout", i, function () {
                t(this).removeClass("ui-state-hover"),
                    -1 !== this.className.indexOf("ui-datepicker-prev") && t(this).removeClass("ui-datepicker-prev-hover"),
                    -1 !== this.className.indexOf("ui-datepicker-next") && t(this).removeClass("ui-datepicker-next-hover");
            })
            .on("mouseover", i, o);
    }
    function o() {
        t.datepicker._isDisabledDatepicker(m.inline ? m.dpDiv.parent()[0] : m.input[0]) ||
            (t(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"),
            t(this).addClass("ui-state-hover"),
            -1 !== this.className.indexOf("ui-datepicker-prev") && t(this).addClass("ui-datepicker-prev-hover"),
            -1 !== this.className.indexOf("ui-datepicker-next") && t(this).addClass("ui-datepicker-next-hover"));
    }
    function a(e, i) {
        t.extend(e, i);
        for (var s in i) null == i[s] && (e[s] = i[s]);
        return e;
    }
    function r(t) {
        return function () {
            var e = this.element.val();
            t.apply(this, arguments), this._refresh(), e !== this.element.val() && this._trigger("change");
        };
    }
    t.ui = t.ui || {};
    var h = ((t.ui.version = "1.12.1"), 0),
        l = Array.prototype.slice;
    (t.cleanData = (function (e) {
        return function (i) {
            var s, n, o;
            for (o = 0; null != (n = i[o]); o++)
                try {
                    (s = t._data(n, "events")), s && s.remove && t(n).triggerHandler("remove");
                } catch (a) {}
            e(i);
        };
    })(t.cleanData)),
        (t.widget = function (e, i, s) {
            var n,
                o,
                a,
                r = {},
                h = e.split(".")[0];
            e = e.split(".")[1];
            var l = h + "-" + e;
            return (
                s || ((s = i), (i = t.Widget)),
                t.isArray(s) && (s = t.extend.apply(null, [{}].concat(s))),
                (t.expr[":"][l.toLowerCase()] = function (e) {
                    return !!t.data(e, l);
                }),
                (t[h] = t[h] || {}),
                (n = t[h][e]),
                (o = t[h][e] = function (t, e) {
                    return this._createWidget ? void (arguments.length && this._createWidget(t, e)) : new o(t, e);
                }),
                t.extend(o, n, { version: s.version, _proto: t.extend({}, s), _childConstructors: [] }),
                (a = new i()),
                (a.options = t.widget.extend({}, a.options)),
                t.each(s, function (e, s) {
                    return t.isFunction(s)
                        ? void (r[e] = (function () {
                              function t() {
                                  return i.prototype[e].apply(this, arguments);
                              }
                              function n(t) {
                                  return i.prototype[e].apply(this, t);
                              }
                              return function () {
                                  var e,
                                      i = this._super,
                                      o = this._superApply;
                                  return (this._super = t), (this._superApply = n), (e = s.apply(this, arguments)), (this._super = i), (this._superApply = o), e;
                              };
                          })())
                        : void (r[e] = s);
                }),
                (o.prototype = t.widget.extend(a, { widgetEventPrefix: n ? a.widgetEventPrefix || e : e }, r, { constructor: o, namespace: h, widgetName: e, widgetFullName: l })),
                n
                    ? (t.each(n._childConstructors, function (e, i) {
                          var s = i.prototype;
                          t.widget(s.namespace + "." + s.widgetName, o, i._proto);
                      }),
                      delete n._childConstructors)
                    : i._childConstructors.push(o),
                t.widget.bridge(e, o),
                o
            );
        }),
        (t.widget.extend = function (e) {
            for (var i, s, n = l.call(arguments, 1), o = 0, a = n.length; a > o; o++)
                for (i in n[o]) (s = n[o][i]), n[o].hasOwnProperty(i) && void 0 !== s && (t.isPlainObject(s) ? (e[i] = t.isPlainObject(e[i]) ? t.widget.extend({}, e[i], s) : t.widget.extend({}, s)) : (e[i] = s));
            return e;
        }),
        (t.widget.bridge = function (e, i) {
            var s = i.prototype.widgetFullName || e;
            t.fn[e] = function (n) {
                var o = "string" == typeof n,
                    a = l.call(arguments, 1),
                    r = this;
                return (
                    o
                        ? this.length || "instance" !== n
                            ? this.each(function () {
                                  var i,
                                      o = t.data(this, s);
                                  return "instance" === n
                                      ? ((r = o), !1)
                                      : o
                                      ? t.isFunction(o[n]) && "_" !== n.charAt(0)
                                          ? ((i = o[n].apply(o, a)), i !== o && void 0 !== i ? ((r = i && i.jquery ? r.pushStack(i.get()) : i), !1) : void 0)
                                          : t.error("no such method '" + n + "' for " + e + " widget instance")
                                      : t.error("cannot call methods on " + e + " prior to initialization; attempted to call method '" + n + "'");
                              })
                            : (r = void 0)
                        : (a.length && (n = t.widget.extend.apply(null, [n].concat(a))),
                          this.each(function () {
                              var e = t.data(this, s);
                              e ? (e.option(n || {}), e._init && e._init()) : t.data(this, s, new i(n, this));
                          })),
                    r
                );
            };
        }),
        (t.Widget = function () {}),
        (t.Widget._childConstructors = []),
        (t.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: { classes: {}, disabled: !1, create: null },
            _createWidget: function (e, i) {
                (i = t(i || this.defaultElement || this)[0]),
                    (this.element = t(i)),
                    (this.uuid = h++),
                    (this.eventNamespace = "." + this.widgetName + this.uuid),
                    (this.bindings = t()),
                    (this.hoverable = t()),
                    (this.focusable = t()),
                    (this.classesElementLookup = {}),
                    i !== this &&
                        (t.data(i, this.widgetFullName, this),
                        this._on(!0, this.element, {
                            remove: function (t) {
                                t.target === i && this.destroy();
                            },
                        }),
                        (this.document = t(i.style ? i.ownerDocument : i.document || i)),
                        (this.window = t(this.document[0].defaultView || this.document[0].parentWindow))),
                    (this.options = t.widget.extend({}, this.options, this._getCreateOptions(), e)),
                    this._create(),
                    this.options.disabled && this._setOptionDisabled(this.options.disabled),
                    this._trigger("create", null, this._getCreateEventData()),
                    this._init();
            },
            _getCreateOptions: function () {
                return {};
            },
            _getCreateEventData: t.noop,
            _create: t.noop,
            _init: t.noop,
            destroy: function () {
                var e = this;
                this._destroy(),
                    t.each(this.classesElementLookup, function (t, i) {
                        e._removeClass(i, t);
                    }),
                    this.element.off(this.eventNamespace).removeData(this.widgetFullName),
                    this.widget().off(this.eventNamespace).removeAttr("aria-disabled"),
                    this.bindings.off(this.eventNamespace);
            },
            _destroy: t.noop,
            widget: function () {
                return this.element;
            },
            option: function (e, i) {
                var s,
                    n,
                    o,
                    a = e;
                if (0 === arguments.length) return t.widget.extend({}, this.options);
                if ("string" == typeof e)
                    if (((a = {}), (s = e.split(".")), (e = s.shift()), s.length)) {
                        for (n = a[e] = t.widget.extend({}, this.options[e]), o = 0; o < s.length - 1; o++) (n[s[o]] = n[s[o]] || {}), (n = n[s[o]]);
                        if (((e = s.pop()), 1 === arguments.length)) return void 0 === n[e] ? null : n[e];
                        n[e] = i;
                    } else {
                        if (1 === arguments.length) return void 0 === this.options[e] ? null : this.options[e];
                        a[e] = i;
                    }
                return this._setOptions(a), this;
            },
            _setOptions: function (t) {
                var e;
                for (e in t) this._setOption(e, t[e]);
                return this;
            },
            _setOption: function (t, e) {
                return "classes" === t && this._setOptionClasses(e), (this.options[t] = e), "disabled" === t && this._setOptionDisabled(e), this;
            },
            _setOptionClasses: function (e) {
                var i, s, n;
                for (i in e) (n = this.classesElementLookup[i]), e[i] !== this.options.classes[i] && n && n.length && ((s = t(n.get())), this._removeClass(n, i), s.addClass(this._classes({ element: s, keys: i, classes: e, add: !0 })));
            },
            _setOptionDisabled: function (t) {
                this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!t), t && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"));
            },
            enable: function () {
                return this._setOptions({ disabled: !1 });
            },
            disable: function () {
                return this._setOptions({ disabled: !0 });
            },
            _classes: function (e) {
                function i(i, o) {
                    var a, r;
                    for (r = 0; r < i.length; r++)
                        (a = n.classesElementLookup[i[r]] || t()),
                            (a = t(e.add ? t.unique(a.get().concat(e.element.get())) : a.not(e.element).get())),
                            (n.classesElementLookup[i[r]] = a),
                            s.push(i[r]),
                            o && e.classes[i[r]] && s.push(e.classes[i[r]]);
                }
                var s = [],
                    n = this;
                return (
                    (e = t.extend({ element: this.element, classes: this.options.classes || {} }, e)),
                    this._on(e.element, { remove: "_untrackClassesElement" }),
                    e.keys && i(e.keys.match(/\S+/g) || [], !0),
                    e.extra && i(e.extra.match(/\S+/g) || []),
                    s.join(" ")
                );
            },
            _untrackClassesElement: function (e) {
                var i = this;
                t.each(i.classesElementLookup, function (s, n) {
                    -1 !== t.inArray(e.target, n) && (i.classesElementLookup[s] = t(n.not(e.target).get()));
                });
            },
            _removeClass: function (t, e, i) {
                return this._toggleClass(t, e, i, !1);
            },
            _addClass: function (t, e, i) {
                return this._toggleClass(t, e, i, !0);
            },
            _toggleClass: function (t, e, i, s) {
                s = "boolean" == typeof s ? s : i;
                var n = "string" == typeof t || null === t,
                    o = { extra: n ? e : i, keys: n ? t : e, element: n ? this.element : t, add: s };
                return o.element.toggleClass(this._classes(o), s), this;
            },
            _on: function (e, i, s) {
                var n,
                    o = this;
                "boolean" != typeof e && ((s = i), (i = e), (e = !1)),
                    s ? ((i = n = t(i)), (this.bindings = this.bindings.add(i))) : ((s = i), (i = this.element), (n = this.widget())),
                    t.each(s, function (s, a) {
                        function r() {
                            return e || (o.options.disabled !== !0 && !t(this).hasClass("ui-state-disabled")) ? ("string" == typeof a ? o[a] : a).apply(o, arguments) : void 0;
                        }
                        "string" != typeof a && (r.guid = a.guid = a.guid || r.guid || t.guid++);
                        var h = s.match(/^([\w:-]*)\s*(.*)$/),
                            l = h[1] + o.eventNamespace,
                            c = h[2];
                        c ? n.on(l, c, r) : i.on(l, r);
                    });
            },
            _off: function (e, i) {
                (i = (i || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace),
                    e.off(i).off(i),
                    (this.bindings = t(this.bindings.not(e).get())),
                    (this.focusable = t(this.focusable.not(e).get())),
                    (this.hoverable = t(this.hoverable.not(e).get()));
            },
            _delay: function (t, e) {
                function i() {
                    return ("string" == typeof t ? s[t] : t).apply(s, arguments);
                }
                var s = this;
                return setTimeout(i, e || 0);
            },
            _hoverable: function (e) {
                (this.hoverable = this.hoverable.add(e)),
                    this._on(e, {
                        mouseenter: function (e) {
                            this._addClass(t(e.currentTarget), null, "ui-state-hover");
                        },
                        mouseleave: function (e) {
                            this._removeClass(t(e.currentTarget), null, "ui-state-hover");
                        },
                    });
            },
            _focusable: function (e) {
                (this.focusable = this.focusable.add(e)),
                    this._on(e, {
                        focusin: function (e) {
                            this._addClass(t(e.currentTarget), null, "ui-state-focus");
                        },
                        focusout: function (e) {
                            this._removeClass(t(e.currentTarget), null, "ui-state-focus");
                        },
                    });
            },
            _trigger: function (e, i, s) {
                var n,
                    o,
                    a = this.options[e];
                if (((s = s || {}), (i = t.Event(i)), (i.type = (e === this.widgetEventPrefix ? e : this.widgetEventPrefix + e).toLowerCase()), (i.target = this.element[0]), (o = i.originalEvent))) for (n in o) n in i || (i[n] = o[n]);
                return this.element.trigger(i, s), !((t.isFunction(a) && a.apply(this.element[0], [i].concat(s)) === !1) || i.isDefaultPrevented());
            },
        }),
        t.each({ show: "fadeIn", hide: "fadeOut" }, function (e, i) {
            t.Widget.prototype["_" + e] = function (s, n, o) {
                "string" == typeof n && (n = { effect: n });
                var a,
                    r = n ? (n === !0 || "number" == typeof n ? i : n.effect || i) : e;
                (n = n || {}),
                    "number" == typeof n && (n = { duration: n }),
                    (a = !t.isEmptyObject(n)),
                    (n.complete = o),
                    n.delay && s.delay(n.delay),
                    a && t.effects && t.effects.effect[r]
                        ? s[e](n)
                        : r !== e && s[r]
                        ? s[r](n.duration, n.easing, o)
                        : s.queue(function (i) {
                              t(this)[e](), o && o.call(s[0]), i();
                          });
            };
        });
    t.widget;
    !(function () {
        function e(t, e, i) {
            return [parseFloat(t[0]) * (u.test(t[0]) ? e / 100 : 1), parseFloat(t[1]) * (u.test(t[1]) ? i / 100 : 1)];
        }
        function i(e, i) {
            return parseInt(t.css(e, i), 10) || 0;
        }
        function s(e) {
            var i = e[0];
            return 9 === i.nodeType
                ? { width: e.width(), height: e.height(), offset: { top: 0, left: 0 } }
                : t.isWindow(i)
                ? { width: e.width(), height: e.height(), offset: { top: e.scrollTop(), left: e.scrollLeft() } }
                : i.preventDefault
                ? { width: 0, height: 0, offset: { top: i.pageY, left: i.pageX } }
                : { width: e.outerWidth(), height: e.outerHeight(), offset: e.offset() };
        }
        var n,
            o = Math.max,
            a = Math.abs,
            r = /left|center|right/,
            h = /top|center|bottom/,
            l = /[\+\-]\d+(\.[\d]+)?%?/,
            c = /^\w+/,
            u = /%$/,
            d = t.fn.position;
        (t.position = {
            scrollbarWidth: function () {
                if (void 0 !== n) return n;
                var e,
                    i,
                    s = t("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),
                    o = s.children()[0];
                return t("body").append(s), (e = o.offsetWidth), s.css("overflow", "scroll"), (i = o.offsetWidth), e === i && (i = s[0].clientWidth), s.remove(), (n = e - i);
            },
            getScrollInfo: function (e) {
                var i = e.isWindow || e.isDocument ? "" : e.element.css("overflow-x"),
                    s = e.isWindow || e.isDocument ? "" : e.element.css("overflow-y"),
                    n = "scroll" === i || ("auto" === i && e.width < e.element[0].scrollWidth),
                    o = "scroll" === s || ("auto" === s && e.height < e.element[0].scrollHeight);
                return { width: o ? t.position.scrollbarWidth() : 0, height: n ? t.position.scrollbarWidth() : 0 };
            },
            getWithinInfo: function (e) {
                var i = t(e || window),
                    s = t.isWindow(i[0]),
                    n = !!i[0] && 9 === i[0].nodeType,
                    o = !s && !n;
                return { element: i, isWindow: s, isDocument: n, offset: o ? t(e).offset() : { left: 0, top: 0 }, scrollLeft: i.scrollLeft(), scrollTop: i.scrollTop(), width: i.outerWidth(), height: i.outerHeight() };
            },
        }),
            (t.fn.position = function (n) {
                if (!n || !n.of) return d.apply(this, arguments);
                n = t.extend({}, n);
                var u,
                    p,
                    f,
                    g,
                    m,
                    _,
                    v = t(n.of),
                    b = t.position.getWithinInfo(n.within),
                    y = t.position.getScrollInfo(b),
                    w = (n.collision || "flip").split(" "),
                    k = {};
                return (
                    (_ = s(v)),
                    v[0].preventDefault && (n.at = "left top"),
                    (p = _.width),
                    (f = _.height),
                    (g = _.offset),
                    (m = t.extend({}, g)),
                    t.each(["my", "at"], function () {
                        var t,
                            e,
                            i = (n[this] || "").split(" ");
                        1 === i.length && (i = r.test(i[0]) ? i.concat(["center"]) : h.test(i[0]) ? ["center"].concat(i) : ["center", "center"]),
                            (i[0] = r.test(i[0]) ? i[0] : "center"),
                            (i[1] = h.test(i[1]) ? i[1] : "center"),
                            (t = l.exec(i[0])),
                            (e = l.exec(i[1])),
                            (k[this] = [t ? t[0] : 0, e ? e[0] : 0]),
                            (n[this] = [c.exec(i[0])[0], c.exec(i[1])[0]]);
                    }),
                    1 === w.length && (w[1] = w[0]),
                    "right" === n.at[0] ? (m.left += p) : "center" === n.at[0] && (m.left += p / 2),
                    "bottom" === n.at[1] ? (m.top += f) : "center" === n.at[1] && (m.top += f / 2),
                    (u = e(k.at, p, f)),
                    (m.left += u[0]),
                    (m.top += u[1]),
                    this.each(function () {
                        var s,
                            r,
                            h = t(this),
                            l = h.outerWidth(),
                            c = h.outerHeight(),
                            d = i(this, "marginLeft"),
                            _ = i(this, "marginTop"),
                            x = l + d + i(this, "marginRight") + y.width,
                            C = c + _ + i(this, "marginBottom") + y.height,
                            D = t.extend({}, m),
                            I = e(k.my, h.outerWidth(), h.outerHeight());
                        "right" === n.my[0] ? (D.left -= l) : "center" === n.my[0] && (D.left -= l / 2),
                            "bottom" === n.my[1] ? (D.top -= c) : "center" === n.my[1] && (D.top -= c / 2),
                            (D.left += I[0]),
                            (D.top += I[1]),
                            (s = { marginLeft: d, marginTop: _ }),
                            t.each(["left", "top"], function (e, i) {
                                t.ui.position[w[e]] &&
                                    t.ui.position[w[e]][i](D, {
                                        targetWidth: p,
                                        targetHeight: f,
                                        elemWidth: l,
                                        elemHeight: c,
                                        collisionPosition: s,
                                        collisionWidth: x,
                                        collisionHeight: C,
                                        offset: [u[0] + I[0], u[1] + I[1]],
                                        my: n.my,
                                        at: n.at,
                                        within: b,
                                        elem: h,
                                    });
                            }),
                            n.using &&
                                (r = function (t) {
                                    var e = g.left - D.left,
                                        i = e + p - l,
                                        s = g.top - D.top,
                                        r = s + f - c,
                                        u = {
                                            target: { element: v, left: g.left, top: g.top, width: p, height: f },
                                            element: { element: h, left: D.left, top: D.top, width: l, height: c },
                                            horizontal: 0 > i ? "left" : e > 0 ? "right" : "center",
                                            vertical: 0 > r ? "top" : s > 0 ? "bottom" : "middle",
                                        };
                                    l > p && a(e + i) < p && (u.horizontal = "center"),
                                        c > f && a(s + r) < f && (u.vertical = "middle"),
                                        o(a(e), a(i)) > o(a(s), a(r)) ? (u.important = "horizontal") : (u.important = "vertical"),
                                        n.using.call(this, t, u);
                                }),
                            h.offset(t.extend(D, { using: r }));
                    })
                );
            }),
            (t.ui.position = {
                fit: {
                    left: function (t, e) {
                        var i,
                            s = e.within,
                            n = s.isWindow ? s.scrollLeft : s.offset.left,
                            a = s.width,
                            r = t.left - e.collisionPosition.marginLeft,
                            h = n - r,
                            l = r + e.collisionWidth - a - n;
                        e.collisionWidth > a
                            ? h > 0 && 0 >= l
                                ? ((i = t.left + h + e.collisionWidth - a - n), (t.left += h - i))
                                : l > 0 && 0 >= h
                                ? (t.left = n)
                                : h > l
                                ? (t.left = n + a - e.collisionWidth)
                                : (t.left = n)
                            : h > 0
                            ? (t.left += h)
                            : l > 0
                            ? (t.left -= l)
                            : (t.left = o(t.left - r, t.left));
                    },
                    top: function (t, e) {
                        var i,
                            s = e.within,
                            n = s.isWindow ? s.scrollTop : s.offset.top,
                            a = e.within.height,
                            r = t.top - e.collisionPosition.marginTop,
                            h = n - r,
                            l = r + e.collisionHeight - a - n;
                        e.collisionHeight > a
                            ? h > 0 && 0 >= l
                                ? ((i = t.top + h + e.collisionHeight - a - n), (t.top += h - i))
                                : l > 0 && 0 >= h
                                ? (t.top = n)
                                : h > l
                                ? (t.top = n + a - e.collisionHeight)
                                : (t.top = n)
                            : h > 0
                            ? (t.top += h)
                            : l > 0
                            ? (t.top -= l)
                            : (t.top = o(t.top - r, t.top));
                    },
                },
                flip: {
                    left: function (t, e) {
                        var i,
                            s,
                            n = e.within,
                            o = n.offset.left + n.scrollLeft,
                            r = n.width,
                            h = n.isWindow ? n.scrollLeft : n.offset.left,
                            l = t.left - e.collisionPosition.marginLeft,
                            c = l - h,
                            u = l + e.collisionWidth - r - h,
                            d = "left" === e.my[0] ? -e.elemWidth : "right" === e.my[0] ? e.elemWidth : 0,
                            p = "left" === e.at[0] ? e.targetWidth : "right" === e.at[0] ? -e.targetWidth : 0,
                            f = -2 * e.offset[0];
                        0 > c
                            ? ((i = t.left + d + p + f + e.collisionWidth - r - o), (0 > i || i < a(c)) && (t.left += d + p + f))
                            : u > 0 && ((s = t.left - e.collisionPosition.marginLeft + d + p + f - h), (s > 0 || a(s) < u) && (t.left += d + p + f));
                    },
                    top: function (t, e) {
                        var i,
                            s,
                            n = e.within,
                            o = n.offset.top + n.scrollTop,
                            r = n.height,
                            h = n.isWindow ? n.scrollTop : n.offset.top,
                            l = t.top - e.collisionPosition.marginTop,
                            c = l - h,
                            u = l + e.collisionHeight - r - h,
                            d = "top" === e.my[1],
                            p = d ? -e.elemHeight : "bottom" === e.my[1] ? e.elemHeight : 0,
                            f = "top" === e.at[1] ? e.targetHeight : "bottom" === e.at[1] ? -e.targetHeight : 0,
                            g = -2 * e.offset[1];
                        0 > c
                            ? ((s = t.top + p + f + g + e.collisionHeight - r - o), (0 > s || s < a(c)) && (t.top += p + f + g))
                            : u > 0 && ((i = t.top - e.collisionPosition.marginTop + p + f + g - h), (i > 0 || a(i) < u) && (t.top += p + f + g));
                    },
                },
                flipfit: {
                    left: function () {
                        t.ui.position.flip.left.apply(this, arguments), t.ui.position.fit.left.apply(this, arguments);
                    },
                    top: function () {
                        t.ui.position.flip.top.apply(this, arguments), t.ui.position.fit.top.apply(this, arguments);
                    },
                },
            });
    })();
    var c =
            (t.ui.position,
            t.extend(t.expr[":"], {
                data: t.expr.createPseudo
                    ? t.expr.createPseudo(function (e) {
                          return function (i) {
                              return !!t.data(i, e);
                          };
                      })
                    : function (e, i, s) {
                          return !!t.data(e, s[3]);
                      },
            }),
            t.fn.extend({
                disableSelection: (function () {
                    var t = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown";
                    return function () {
                        return this.on(t + ".ui-disableSelection", function (t) {
                            t.preventDefault();
                        });
                    };
                })(),
                enableSelection: function () {
                    return this.off(".ui-disableSelection");
                },
            }),
            "ui-effects-"),
        u = "ui-effects-style",
        d = "ui-effects-animated",
        p = t;
    (t.effects = { effect: {} }),
        (function (t, e) {
            function i(t, e, i) {
                var s = u[e.type] || {};
                return null == t ? (i || !e.def ? null : e.def) : ((t = s.floor ? ~~t : parseFloat(t)), isNaN(t) ? e.def : s.mod ? (t + s.mod) % s.mod : 0 > t ? 0 : s.max < t ? s.max : t);
            }
            function s(e) {
                var i = l(),
                    s = (i._rgba = []);
                return (
                    (e = e.toLowerCase()),
                    f(h, function (t, n) {
                        var o,
                            a = n.re.exec(e),
                            r = a && n.parse(a),
                            h = n.space || "rgba";
                        return r ? ((o = i[h](r)), (i[c[h].cache] = o[c[h].cache]), (s = i._rgba = o._rgba), !1) : void 0;
                    }),
                    s.length ? ("0,0,0,0" === s.join() && t.extend(s, o.transparent), i) : o[e]
                );
            }
            function n(t, e, i) {
                return (i = (i + 1) % 1), 1 > 6 * i ? t + (e - t) * i * 6 : 1 > 2 * i ? e : 2 > 3 * i ? t + (e - t) * (2 / 3 - i) * 6 : t;
            }
            var o,
                a = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",
                r = /^([\-+])=\s*(\d+\.?\d*)/,
                h = [
                    {
                        re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function (t) {
                            return [t[1], t[2], t[3], t[4]];
                        },
                    },
                    {
                        re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function (t) {
                            return [2.55 * t[1], 2.55 * t[2], 2.55 * t[3], t[4]];
                        },
                    },
                    {
                        re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                        parse: function (t) {
                            return [parseInt(t[1], 16), parseInt(t[2], 16), parseInt(t[3], 16)];
                        },
                    },
                    {
                        re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                        parse: function (t) {
                            return [parseInt(t[1] + t[1], 16), parseInt(t[2] + t[2], 16), parseInt(t[3] + t[3], 16)];
                        },
                    },
                    {
                        re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        space: "hsla",
                        parse: function (t) {
                            return [t[1], t[2] / 100, t[3] / 100, t[4]];
                        },
                    },
                ],
                l = (t.Color = function (e, i, s, n) {
                    return new t.Color.fn.parse(e, i, s, n);
                }),
                c = {
                    rgba: { props: { red: { idx: 0, type: "byte" }, green: { idx: 1, type: "byte" }, blue: { idx: 2, type: "byte" } } },
                    hsla: { props: { hue: { idx: 0, type: "degrees" }, saturation: { idx: 1, type: "percent" }, lightness: { idx: 2, type: "percent" } } },
                },
                u = { byte: { floor: !0, max: 255 }, percent: { max: 1 }, degrees: { mod: 360, floor: !0 } },
                d = (l.support = {}),
                p = t("<p>")[0],
                f = t.each;
            (p.style.cssText = "background-color:rgba(1,1,1,.5)"),
                (d.rgba = p.style.backgroundColor.indexOf("rgba") > -1),
                f(c, function (t, e) {
                    (e.cache = "_" + t), (e.props.alpha = { idx: 3, type: "percent", def: 1 });
                }),
                (l.fn = t.extend(l.prototype, {
                    parse: function (n, a, r, h) {
                        if (n === e) return (this._rgba = [null, null, null, null]), this;
                        (n.jquery || n.nodeType) && ((n = t(n).css(a)), (a = e));
                        var u = this,
                            d = t.type(n),
                            p = (this._rgba = []);
                        return (
                            a !== e && ((n = [n, a, r, h]), (d = "array")),
                            "string" === d
                                ? this.parse(s(n) || o._default)
                                : "array" === d
                                ? (f(c.rgba.props, function (t, e) {
                                      p[e.idx] = i(n[e.idx], e);
                                  }),
                                  this)
                                : "object" === d
                                ? (n instanceof l
                                      ? f(c, function (t, e) {
                                            n[e.cache] && (u[e.cache] = n[e.cache].slice());
                                        })
                                      : f(c, function (e, s) {
                                            var o = s.cache;
                                            f(s.props, function (t, e) {
                                                if (!u[o] && s.to) {
                                                    if ("alpha" === t || null == n[t]) return;
                                                    u[o] = s.to(u._rgba);
                                                }
                                                u[o][e.idx] = i(n[t], e, !0);
                                            }),
                                                u[o] && t.inArray(null, u[o].slice(0, 3)) < 0 && ((u[o][3] = 1), s.from && (u._rgba = s.from(u[o])));
                                        }),
                                  this)
                                : void 0
                        );
                    },
                    is: function (t) {
                        var e = l(t),
                            i = !0,
                            s = this;
                        return (
                            f(c, function (t, n) {
                                var o,
                                    a = e[n.cache];
                                return (
                                    a &&
                                        ((o = s[n.cache] || (n.to && n.to(s._rgba)) || []),
                                        f(n.props, function (t, e) {
                                            return null != a[e.idx] ? (i = a[e.idx] === o[e.idx]) : void 0;
                                        })),
                                    i
                                );
                            }),
                            i
                        );
                    },
                    _space: function () {
                        var t = [],
                            e = this;
                        return (
                            f(c, function (i, s) {
                                e[s.cache] && t.push(i);
                            }),
                            t.pop()
                        );
                    },
                    transition: function (t, e) {
                        var s = l(t),
                            n = s._space(),
                            o = c[n],
                            a = 0 === this.alpha() ? l("transparent") : this,
                            r = a[o.cache] || o.to(a._rgba),
                            h = r.slice();
                        return (
                            (s = s[o.cache]),
                            f(o.props, function (t, n) {
                                var o = n.idx,
                                    a = r[o],
                                    l = s[o],
                                    c = u[n.type] || {};
                                null !== l && (null === a ? (h[o] = l) : (c.mod && (l - a > c.mod / 2 ? (a += c.mod) : a - l > c.mod / 2 && (a -= c.mod)), (h[o] = i((l - a) * e + a, n))));
                            }),
                            this[n](h)
                        );
                    },
                    blend: function (e) {
                        if (1 === this._rgba[3]) return this;
                        var i = this._rgba.slice(),
                            s = i.pop(),
                            n = l(e)._rgba;
                        return l(
                            t.map(i, function (t, e) {
                                return (1 - s) * n[e] + s * t;
                            })
                        );
                    },
                    toRgbaString: function () {
                        var e = "rgba(",
                            i = t.map(this._rgba, function (t, e) {
                                return null == t ? (e > 2 ? 1 : 0) : t;
                            });
                        return 1 === i[3] && (i.pop(), (e = "rgb(")), e + i.join() + ")";
                    },
                    toHslaString: function () {
                        var e = "hsla(",
                            i = t.map(this.hsla(), function (t, e) {
                                return null == t && (t = e > 2 ? 1 : 0), e && 3 > e && (t = Math.round(100 * t) + "%"), t;
                            });
                        return 1 === i[3] && (i.pop(), (e = "hsl(")), e + i.join() + ")";
                    },
                    toHexString: function (e) {
                        var i = this._rgba.slice(),
                            s = i.pop();
                        return (
                            e && i.push(~~(255 * s)),
                            "#" +
                                t
                                    .map(i, function (t) {
                                        return (t = (t || 0).toString(16)), 1 === t.length ? "0" + t : t;
                                    })
                                    .join("")
                        );
                    },
                    toString: function () {
                        return 0 === this._rgba[3] ? "transparent" : this.toRgbaString();
                    },
                })),
                (l.fn.parse.prototype = l.fn),
                (c.hsla.to = function (t) {
                    if (null == t[0] || null == t[1] || null == t[2]) return [null, null, null, t[3]];
                    var e,
                        i,
                        s = t[0] / 255,
                        n = t[1] / 255,
                        o = t[2] / 255,
                        a = t[3],
                        r = Math.max(s, n, o),
                        h = Math.min(s, n, o),
                        l = r - h,
                        c = r + h,
                        u = 0.5 * c;
                    return (
                        (e = h === r ? 0 : s === r ? (60 * (n - o)) / l + 360 : n === r ? (60 * (o - s)) / l + 120 : (60 * (s - n)) / l + 240),
                        (i = 0 === l ? 0 : 0.5 >= u ? l / c : l / (2 - c)),
                        [Math.round(e) % 360, i, u, null == a ? 1 : a]
                    );
                }),
                (c.hsla.from = function (t) {
                    if (null == t[0] || null == t[1] || null == t[2]) return [null, null, null, t[3]];
                    var e = t[0] / 360,
                        i = t[1],
                        s = t[2],
                        o = t[3],
                        a = 0.5 >= s ? s * (1 + i) : s + i - s * i,
                        r = 2 * s - a;
                    return [Math.round(255 * n(r, a, e + 1 / 3)), Math.round(255 * n(r, a, e)), Math.round(255 * n(r, a, e - 1 / 3)), o];
                }),
                f(c, function (s, n) {
                    var o = n.props,
                        a = n.cache,
                        h = n.to,
                        c = n.from;
                    (l.fn[s] = function (s) {
                        if ((h && !this[a] && (this[a] = h(this._rgba)), s === e)) return this[a].slice();
                        var n,
                            r = t.type(s),
                            u = "array" === r || "object" === r ? s : arguments,
                            d = this[a].slice();
                        return (
                            f(o, function (t, e) {
                                var s = u["object" === r ? t : e.idx];
                                null == s && (s = d[e.idx]), (d[e.idx] = i(s, e));
                            }),
                            c ? ((n = l(c(d))), (n[a] = d), n) : l(d)
                        );
                    }),
                        f(o, function (e, i) {
                            l.fn[e] ||
                                (l.fn[e] = function (n) {
                                    var o,
                                        a = t.type(n),
                                        h = "alpha" === e ? (this._hsla ? "hsla" : "rgba") : s,
                                        l = this[h](),
                                        c = l[i.idx];
                                    return "undefined" === a
                                        ? c
                                        : ("function" === a && ((n = n.call(this, c)), (a = t.type(n))),
                                          null == n && i.empty ? this : ("string" === a && ((o = r.exec(n)), o && (n = c + parseFloat(o[2]) * ("+" === o[1] ? 1 : -1))), (l[i.idx] = n), this[h](l)));
                                });
                        });
                }),
                (l.hook = function (e) {
                    var i = e.split(" ");
                    f(i, function (e, i) {
                        (t.cssHooks[i] = {
                            set: function (e, n) {
                                var o,
                                    a,
                                    r = "";
                                if ("transparent" !== n && ("string" !== t.type(n) || (o = s(n)))) {
                                    if (((n = l(o || n)), !d.rgba && 1 !== n._rgba[3])) {
                                        for (a = "backgroundColor" === i ? e.parentNode : e; ("" === r || "transparent" === r) && a && a.style; )
                                            try {
                                                (r = t.css(a, "backgroundColor")), (a = a.parentNode);
                                            } catch (h) {}
                                        n = n.blend(r && "transparent" !== r ? r : "_default");
                                    }
                                    n = n.toRgbaString();
                                }
                                try {
                                    e.style[i] = n;
                                } catch (h) {}
                            },
                        }),
                            (t.fx.step[i] = function (e) {
                                e.colorInit || ((e.start = l(e.elem, i)), (e.end = l(e.end)), (e.colorInit = !0)), t.cssHooks[i].set(e.elem, e.start.transition(e.end, e.pos));
                            });
                    });
                }),
                l.hook(a),
                (t.cssHooks.borderColor = {
                    expand: function (t) {
                        var e = {};
                        return (
                            f(["Top", "Right", "Bottom", "Left"], function (i, s) {
                                e["border" + s + "Color"] = t;
                            }),
                            e
                        );
                    },
                }),
                (o = t.Color.names = {
                    aqua: "#00ffff",
                    black: "#000000",
                    blue: "#0000ff",
                    fuchsia: "#ff00ff",
                    gray: "#808080",
                    green: "#008000",
                    lime: "#00ff00",
                    maroon: "#800000",
                    navy: "#000080",
                    olive: "#808000",
                    purple: "#800080",
                    red: "#ff0000",
                    silver: "#c0c0c0",
                    teal: "#008080",
                    white: "#ffffff",
                    yellow: "#ffff00",
                    transparent: [null, null, null, 0],
                    _default: "#ffffff",
                });
        })(p),
        (function () {
            function e(e) {
                var i,
                    s,
                    n = e.ownerDocument.defaultView ? e.ownerDocument.defaultView.getComputedStyle(e, null) : e.currentStyle,
                    o = {};
                if (n && n.length && n[0] && n[n[0]]) for (s = n.length; s--; ) (i = n[s]), "string" == typeof n[i] && (o[t.camelCase(i)] = n[i]);
                else for (i in n) "string" == typeof n[i] && (o[i] = n[i]);
                return o;
            }
            function i(e, i) {
                var s,
                    o,
                    a = {};
                for (s in i) (o = i[s]), e[s] !== o && (n[s] || ((t.fx.step[s] || !isNaN(parseFloat(o))) && (a[s] = o)));
                return a;
            }
            var s = ["add", "remove", "toggle"],
                n = { border: 1, borderBottom: 1, borderColor: 1, borderLeft: 1, borderRight: 1, borderTop: 1, borderWidth: 1, margin: 1, padding: 1 };
            t.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function (e, i) {
                t.fx.step[i] = function (t) {
                    (("none" !== t.end && !t.setAttr) || (1 === t.pos && !t.setAttr)) && (p.style(t.elem, i, t.end), (t.setAttr = !0));
                };
            }),
                t.fn.addBack ||
                    (t.fn.addBack = function (t) {
                        return this.add(null == t ? this.prevObject : this.prevObject.filter(t));
                    }),
                (t.effects.animateClass = function (n, o, a, r) {
                    var h = t.speed(o, a, r);
                    return this.queue(function () {
                        var o,
                            a = t(this),
                            r = a.attr("class") || "",
                            l = h.children ? a.find("*").addBack() : a;
                        (l = l.map(function () {
                            var i = t(this);
                            return { el: i, start: e(this) };
                        })),
                            (o = function () {
                                t.each(s, function (t, e) {
                                    n[e] && a[e + "Class"](n[e]);
                                });
                            }),
                            o(),
                            (l = l.map(function () {
                                return (this.end = e(this.el[0])), (this.diff = i(this.start, this.end)), this;
                            })),
                            a.attr("class", r),
                            (l = l.map(function () {
                                var e = this,
                                    i = t.Deferred(),
                                    s = t.extend({}, h, {
                                        queue: !1,
                                        complete: function () {
                                            i.resolve(e);
                                        },
                                    });
                                return this.el.animate(this.diff, s), i.promise();
                            })),
                            t.when.apply(t, l.get()).done(function () {
                                o(),
                                    t.each(arguments, function () {
                                        var e = this.el;
                                        t.each(this.diff, function (t) {
                                            e.css(t, "");
                                        });
                                    }),
                                    h.complete.call(a[0]);
                            });
                    });
                }),
                t.fn.extend({
                    addClass: (function (e) {
                        return function (i, s, n, o) {
                            return s ? t.effects.animateClass.call(this, { add: i }, s, n, o) : e.apply(this, arguments);
                        };
                    })(t.fn.addClass),
                    removeClass: (function (e) {
                        return function (i, s, n, o) {
                            return arguments.length > 1 ? t.effects.animateClass.call(this, { remove: i }, s, n, o) : e.apply(this, arguments);
                        };
                    })(t.fn.removeClass),
                    toggleClass: (function (e) {
                        return function (i, s, n, o, a) {
                            return "boolean" == typeof s || void 0 === s
                                ? n
                                    ? t.effects.animateClass.call(this, s ? { add: i } : { remove: i }, n, o, a)
                                    : e.apply(this, arguments)
                                : t.effects.animateClass.call(this, { toggle: i }, s, n, o);
                        };
                    })(t.fn.toggleClass),
                    switchClass: function (e, i, s, n, o) {
                        return t.effects.animateClass.call(this, { add: i, remove: e }, s, n, o);
                    },
                });
        })(),
        (function () {
            function e(e, i, s, n) {
                return (
                    t.isPlainObject(e) && ((i = e), (e = e.effect)),
                    (e = { effect: e }),
                    null == i && (i = {}),
                    t.isFunction(i) && ((n = i), (s = null), (i = {})),
                    ("number" == typeof i || t.fx.speeds[i]) && ((n = s), (s = i), (i = {})),
                    t.isFunction(s) && ((n = s), (s = null)),
                    i && t.extend(e, i),
                    (s = s || i.duration),
                    (e.duration = t.fx.off ? 0 : "number" == typeof s ? s : s in t.fx.speeds ? t.fx.speeds[s] : t.fx.speeds._default),
                    (e.complete = n || i.complete),
                    e
                );
            }
            function i(e) {
                return !e || "number" == typeof e || t.fx.speeds[e] ? !0 : "string" != typeof e || t.effects.effect[e] ? (t.isFunction(e) ? !0 : "object" != typeof e || e.effect ? !1 : !0) : !0;
            }
            function s(t, e) {
                var i = e.outerWidth(),
                    s = e.outerHeight(),
                    n = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/,
                    o = n.exec(t) || ["", 0, i, s, 0];
                return { top: parseFloat(o[1]) || 0, right: "auto" === o[2] ? i : parseFloat(o[2]), bottom: "auto" === o[3] ? s : parseFloat(o[3]), left: parseFloat(o[4]) || 0 };
            }
            t.expr &&
                t.expr.filters &&
                t.expr.filters.animated &&
                (t.expr.filters.animated = (function (e) {
                    return function (i) {
                        return !!t(i).data(d) || e(i);
                    };
                })(t.expr.filters.animated)),
                t.uiBackCompat !== !1 &&
                    t.extend(t.effects, {
                        save: function (t, e) {
                            for (var i = 0, s = e.length; s > i; i++) null !== e[i] && t.data(c + e[i], t[0].style[e[i]]);
                        },
                        restore: function (t, e) {
                            for (var i, s = 0, n = e.length; n > s; s++) null !== e[s] && ((i = t.data(c + e[s])), t.css(e[s], i));
                        },
                        setMode: function (t, e) {
                            return "toggle" === e && (e = t.is(":hidden") ? "show" : "hide"), e;
                        },
                        createWrapper: function (e) {
                            if (e.parent().is(".ui-effects-wrapper")) return e.parent();
                            var i = { width: e.outerWidth(!0), height: e.outerHeight(!0), float: e.css("float") },
                                s = t("<div></div>").addClass("ui-effects-wrapper").css({ fontSize: "100%", background: "transparent", border: "none", margin: 0, padding: 0 }),
                                n = { width: e.width(), height: e.height() },
                                o = document.activeElement;
                            try {
                                o.id;
                            } catch (a) {
                                o = document.body;
                            }
                            return (
                                e.wrap(s),
                                (e[0] === o || t.contains(e[0], o)) && t(o).trigger("focus"),
                                (s = e.parent()),
                                "static" === e.css("position")
                                    ? (s.css({ position: "relative" }), e.css({ position: "relative" }))
                                    : (t.extend(i, { position: e.css("position"), zIndex: e.css("z-index") }),
                                      t.each(["top", "left", "bottom", "right"], function (t, s) {
                                          (i[s] = e.css(s)), isNaN(parseInt(i[s], 10)) && (i[s] = "auto");
                                      }),
                                      e.css({ position: "relative", top: 0, left: 0, right: "auto", bottom: "auto" })),
                                e.css(n),
                                s.css(i).show()
                            );
                        },
                        removeWrapper: function (e) {
                            var i = document.activeElement;
                            return e.parent().is(".ui-effects-wrapper") && (e.parent().replaceWith(e), (e[0] === i || t.contains(e[0], i)) && t(i).trigger("focus")), e;
                        },
                    }),
                t.extend(t.effects, {
                    version: "1.12.1",
                    define: function (e, i, s) {
                        return s || ((s = i), (i = "effect")), (t.effects.effect[e] = s), (t.effects.effect[e].mode = i), s;
                    },
                    scaledDimensions: function (t, e, i) {
                        if (0 === e) return { height: 0, width: 0, outerHeight: 0, outerWidth: 0 };
                        var s = "horizontal" !== i ? (e || 100) / 100 : 1,
                            n = "vertical" !== i ? (e || 100) / 100 : 1;
                        return { height: t.height() * n, width: t.width() * s, outerHeight: t.outerHeight() * n, outerWidth: t.outerWidth() * s };
                    },
                    clipToBox: function (t) {
                        return { width: t.clip.right - t.clip.left, height: t.clip.bottom - t.clip.top, left: t.clip.left, top: t.clip.top };
                    },
                    unshift: function (t, e, i) {
                        var s = t.queue();
                        e > 1 && s.splice.apply(s, [1, 0].concat(s.splice(e, i))), t.dequeue();
                    },
                    saveStyle: function (t) {
                        t.data(u, t[0].style.cssText);
                    },
                    restoreStyle: function (t) {
                        (t[0].style.cssText = t.data(u) || ""), t.removeData(u);
                    },
                    mode: function (t, e) {
                        var i = t.is(":hidden");
                        return "toggle" === e && (e = i ? "show" : "hide"), (i ? "hide" === e : "show" === e) && (e = "none"), e;
                    },
                    getBaseline: function (t, e) {
                        var i, s;
                        switch (t[0]) {
                            case "top":
                                i = 0;
                                break;
                            case "middle":
                                i = 0.5;
                                break;
                            case "bottom":
                                i = 1;
                                break;
                            default:
                                i = t[0] / e.height;
                        }
                        switch (t[1]) {
                            case "left":
                                s = 0;
                                break;
                            case "center":
                                s = 0.5;
                                break;
                            case "right":
                                s = 1;
                                break;
                            default:
                                s = t[1] / e.width;
                        }
                        return { x: s, y: i };
                    },
                    createPlaceholder: function (e) {
                        var i,
                            s = e.css("position"),
                            n = e.position();
                        return (
                            e
                                .css({ marginTop: e.css("marginTop"), marginBottom: e.css("marginBottom"), marginLeft: e.css("marginLeft"), marginRight: e.css("marginRight") })
                                .outerWidth(e.outerWidth())
                                .outerHeight(e.outerHeight()),
                            /^(static|relative)/.test(s) &&
                                ((s = "absolute"),
                                (i = t("<" + e[0].nodeName + ">")
                                    .insertAfter(e)
                                    .css({
                                        display: /^(inline|ruby)/.test(e.css("display")) ? "inline-block" : "block",
                                        visibility: "hidden",
                                        marginTop: e.css("marginTop"),
                                        marginBottom: e.css("marginBottom"),
                                        marginLeft: e.css("marginLeft"),
                                        marginRight: e.css("marginRight"),
                                        float: e.css("float"),
                                    })
                                    .outerWidth(e.outerWidth())
                                    .outerHeight(e.outerHeight())
                                    .addClass("ui-effects-placeholder")),
                                e.data(c + "placeholder", i)),
                            e.css({ position: s, left: n.left, top: n.top }),
                            i
                        );
                    },
                    removePlaceholder: function (t) {
                        var e = c + "placeholder",
                            i = t.data(e);
                        i && (i.remove(), t.removeData(e));
                    },
                    cleanUp: function (e) {
                        t.effects.restoreStyle(e), t.effects.removePlaceholder(e);
                    },
                    setTransition: function (e, i, s, n) {
                        return (
                            (n = n || {}),
                            t.each(i, function (t, i) {
                                var o = e.cssUnit(i);
                                o[0] > 0 && (n[i] = o[0] * s + o[1]);
                            }),
                            n
                        );
                    },
                }),
                t.fn.extend({
                    effect: function () {
                        function i(e) {
                            function i() {
                                r.removeData(d), t.effects.cleanUp(r), "hide" === s.mode && r.hide(), a();
                            }
                            function a() {
                                t.isFunction(h) && h.call(r[0]), t.isFunction(e) && e();
                            }
                            var r = t(this);
                            (s.mode = c.shift()), t.uiBackCompat === !1 || o ? ("none" === s.mode ? (r[l](), a()) : n.call(r[0], s, i)) : (r.is(":hidden") ? "hide" === l : "show" === l) ? (r[l](), a()) : n.call(r[0], s, a);
                        }
                        var s = e.apply(this, arguments),
                            n = t.effects.effect[s.effect],
                            o = n.mode,
                            a = s.queue,
                            r = a || "fx",
                            h = s.complete,
                            l = s.mode,
                            c = [],
                            u = function (e) {
                                var i = t(this),
                                    s = t.effects.mode(i, l) || o;
                                i.data(d, !0), c.push(s), o && ("show" === s || (s === o && "hide" === s)) && i.show(), (o && "none" === s) || t.effects.saveStyle(i), t.isFunction(e) && e();
                            };
                        return t.fx.off || !n
                            ? l
                                ? this[l](s.duration, h)
                                : this.each(function () {
                                      h && h.call(this);
                                  })
                            : a === !1
                            ? this.each(u).each(i)
                            : this.queue(r, u).queue(r, i);
                    },
                    show: (function (t) {
                        return function (s) {
                            if (i(s)) return t.apply(this, arguments);
                            var n = e.apply(this, arguments);
                            return (n.mode = "show"), this.effect.call(this, n);
                        };
                    })(t.fn.show),
                    hide: (function (t) {
                        return function (s) {
                            if (i(s)) return t.apply(this, arguments);
                            var n = e.apply(this, arguments);
                            return (n.mode = "hide"), this.effect.call(this, n);
                        };
                    })(t.fn.hide),
                    toggle: (function (t) {
                        return function (s) {
                            if (i(s) || "boolean" == typeof s) return t.apply(this, arguments);
                            var n = e.apply(this, arguments);
                            return (n.mode = "toggle"), this.effect.call(this, n);
                        };
                    })(t.fn.toggle),
                    cssUnit: function (e) {
                        var i = this.css(e),
                            s = [];
                        return (
                            t.each(["em", "px", "%", "pt"], function (t, e) {
                                i.indexOf(e) > 0 && (s = [parseFloat(i), e]);
                            }),
                            s
                        );
                    },
                    cssClip: function (t) {
                        return t ? this.css("clip", "rect(" + t.top + "px " + t.right + "px " + t.bottom + "px " + t.left + "px)") : s(this.css("clip"), this);
                    },
                    transfer: function (e, i) {
                        var s = t(this),
                            n = t(e.to),
                            o = "fixed" === n.css("position"),
                            a = t("body"),
                            r = o ? a.scrollTop() : 0,
                            h = o ? a.scrollLeft() : 0,
                            l = n.offset(),
                            c = { top: l.top - r, left: l.left - h, height: n.innerHeight(), width: n.innerWidth() },
                            u = s.offset(),
                            d = t("<div class='ui-effects-transfer'></div>")
                                .appendTo("body")
                                .addClass(e.className)
                                .css({ top: u.top - r, left: u.left - h, height: s.innerHeight(), width: s.innerWidth(), position: o ? "fixed" : "absolute" })
                                .animate(c, e.duration, e.easing, function () {
                                    d.remove(), t.isFunction(i) && i();
                                });
                    },
                }),
                (t.fx.step.clip = function (e) {
                    e.clipInit || ((e.start = t(e.elem).cssClip()), "string" == typeof e.end && (e.end = s(e.end, e.elem)), (e.clipInit = !0)),
                        t(e.elem).cssClip({
                            top: e.pos * (e.end.top - e.start.top) + e.start.top,
                            right: e.pos * (e.end.right - e.start.right) + e.start.right,
                            bottom: e.pos * (e.end.bottom - e.start.bottom) + e.start.bottom,
                            left: e.pos * (e.end.left - e.start.left) + e.start.left,
                        });
                });
        })(),
        (function () {
            var e = {};
            t.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function (t, i) {
                e[i] = function (e) {
                    return Math.pow(e, t + 2);
                };
            }),
                t.extend(e, {
                    Sine: function (t) {
                        return 1 - Math.cos((t * Math.PI) / 2);
                    },
                    Circ: function (t) {
                        return 1 - Math.sqrt(1 - t * t);
                    },
                    Elastic: function (t) {
                        return 0 === t || 1 === t ? t : -Math.pow(2, 8 * (t - 1)) * Math.sin(((80 * (t - 1) - 7.5) * Math.PI) / 15);
                    },
                    Back: function (t) {
                        return t * t * (3 * t - 2);
                    },
                    Bounce: function (t) {
                        for (var e, i = 4; t < ((e = Math.pow(2, --i)) - 1) / 11; );
                        return 1 / Math.pow(4, 3 - i) - 7.5625 * Math.pow((3 * e - 2) / 22 - t, 2);
                    },
                }),
                t.each(e, function (e, i) {
                    (t.easing["easeIn" + e] = i),
                        (t.easing["easeOut" + e] = function (t) {
                            return 1 - i(1 - t);
                        }),
                        (t.easing["easeInOut" + e] = function (t) {
                            return 0.5 > t ? i(2 * t) / 2 : 1 - i(-2 * t + 2) / 2;
                        });
                });
        })();
    var f,
        f = t.effects;
    t.effects.define("blind", "hide", function (e, i) {
        var s = { up: ["bottom", "top"], vertical: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], horizontal: ["right", "left"], right: ["left", "right"] },
            n = t(this),
            o = e.direction || "up",
            a = n.cssClip(),
            r = { clip: t.extend({}, a) },
            h = t.effects.createPlaceholder(n);
        (r.clip[s[o][0]] = r.clip[s[o][1]]),
            "show" === e.mode && (n.cssClip(r.clip), h && h.css(t.effects.clipToBox(r)), (r.clip = a)),
            h && h.animate(t.effects.clipToBox(r), e.duration, e.easing),
            n.animate(r, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
    }),
        t.effects.define("bounce", function (e, i) {
            var s,
                n,
                o,
                a = t(this),
                r = e.mode,
                h = "hide" === r,
                l = "show" === r,
                c = e.direction || "up",
                u = e.distance,
                d = e.times || 5,
                p = 2 * d + (l || h ? 1 : 0),
                f = e.duration / p,
                g = e.easing,
                m = "up" === c || "down" === c ? "top" : "left",
                _ = "up" === c || "left" === c,
                v = 0,
                b = a.queue().length;
            for (
                t.effects.createPlaceholder(a),
                    o = a.css(m),
                    u || (u = a["top" === m ? "outerHeight" : "outerWidth"]() / 3),
                    l &&
                        ((n = { opacity: 1 }),
                        (n[m] = o),
                        a
                            .css("opacity", 0)
                            .css(m, _ ? 2 * -u : 2 * u)
                            .animate(n, f, g)),
                    h && (u /= Math.pow(2, d - 1)),
                    n = {},
                    n[m] = o;
                d > v;
                v++
            )
                (s = {}), (s[m] = (_ ? "-=" : "+=") + u), a.animate(s, f, g).animate(n, f, g), (u = h ? 2 * u : u / 2);
            h && ((s = { opacity: 0 }), (s[m] = (_ ? "-=" : "+=") + u), a.animate(s, f, g)), a.queue(i), t.effects.unshift(a, b, p + 1);
        }),
        t.effects.define("clip", "hide", function (e, i) {
            var s,
                n = {},
                o = t(this),
                a = e.direction || "vertical",
                r = "both" === a,
                h = r || "horizontal" === a,
                l = r || "vertical" === a;
            (s = o.cssClip()),
                (n.clip = { top: l ? (s.bottom - s.top) / 2 : s.top, right: h ? (s.right - s.left) / 2 : s.right, bottom: l ? (s.bottom - s.top) / 2 : s.bottom, left: h ? (s.right - s.left) / 2 : s.left }),
                t.effects.createPlaceholder(o),
                "show" === e.mode && (o.cssClip(n.clip), (n.clip = s)),
                o.animate(n, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
        }),
        t.effects.define("drop", "hide", function (e, i) {
            var s,
                n = t(this),
                o = e.mode,
                a = "show" === o,
                r = e.direction || "left",
                h = "up" === r || "down" === r ? "top" : "left",
                l = "up" === r || "left" === r ? "-=" : "+=",
                c = "+=" === l ? "-=" : "+=",
                u = { opacity: 0 };
            t.effects.createPlaceholder(n),
                (s = e.distance || n["top" === h ? "outerHeight" : "outerWidth"](!0) / 2),
                (u[h] = l + s),
                a && (n.css(u), (u[h] = c + s), (u.opacity = 1)),
                n.animate(u, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
        }),
        t.effects.define("explode", "hide", function (e, i) {
            function s() {
                b.push(this), b.length === u * d && n();
            }
            function n() {
                p.css({ visibility: "visible" }), t(b).remove(), i();
            }
            var o,
                a,
                r,
                h,
                l,
                c,
                u = e.pieces ? Math.round(Math.sqrt(e.pieces)) : 3,
                d = u,
                p = t(this),
                f = e.mode,
                g = "show" === f,
                m = p.show().css("visibility", "hidden").offset(),
                _ = Math.ceil(p.outerWidth() / d),
                v = Math.ceil(p.outerHeight() / u),
                b = [];
            for (o = 0; u > o; o++)
                for (h = m.top + o * v, c = o - (u - 1) / 2, a = 0; d > a; a++)
                    (r = m.left + a * _),
                        (l = a - (d - 1) / 2),
                        p
                            .clone()
                            .appendTo("body")
                            .wrap("<div></div>")
                            .css({ position: "absolute", visibility: "visible", left: -a * _, top: -o * v })
                            .parent()
                            .addClass("ui-effects-explode")
                            .css({ position: "absolute", overflow: "hidden", width: _, height: v, left: r + (g ? l * _ : 0), top: h + (g ? c * v : 0), opacity: g ? 0 : 1 })
                            .animate({ left: r + (g ? 0 : l * _), top: h + (g ? 0 : c * v), opacity: g ? 1 : 0 }, e.duration || 500, e.easing, s);
        }),
        t.effects.define("fade", "toggle", function (e, i) {
            var s = "show" === e.mode;
            t(this)
                .css("opacity", s ? 0 : 1)
                .animate({ opacity: s ? 1 : 0 }, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
        }),
        t.effects.define("fold", "hide", function (e, i) {
            var s = t(this),
                n = e.mode,
                o = "show" === n,
                a = "hide" === n,
                r = e.size || 15,
                h = /([0-9]+)%/.exec(r),
                l = !!e.horizFirst,
                c = l ? ["right", "bottom"] : ["bottom", "right"],
                u = e.duration / 2,
                d = t.effects.createPlaceholder(s),
                p = s.cssClip(),
                f = { clip: t.extend({}, p) },
                g = { clip: t.extend({}, p) },
                m = [p[c[0]], p[c[1]]],
                _ = s.queue().length;
            h && (r = (parseInt(h[1], 10) / 100) * m[a ? 0 : 1]),
                (f.clip[c[0]] = r),
                (g.clip[c[0]] = r),
                (g.clip[c[1]] = 0),
                o && (s.cssClip(g.clip), d && d.css(t.effects.clipToBox(g)), (g.clip = p)),
                s
                    .queue(function (i) {
                        d && d.animate(t.effects.clipToBox(f), u, e.easing).animate(t.effects.clipToBox(g), u, e.easing), i();
                    })
                    .animate(f, u, e.easing)
                    .animate(g, u, e.easing)
                    .queue(i),
                t.effects.unshift(s, _, 4);
        }),
        t.effects.define("highlight", "show", function (e, i) {
            var s = t(this),
                n = { backgroundColor: s.css("backgroundColor") };
            "hide" === e.mode && (n.opacity = 0), t.effects.saveStyle(s), s.css({ backgroundImage: "none", backgroundColor: e.color || "#ffff99" }).animate(n, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
        }),
        t.effects.define("size", function (e, i) {
            var s,
                n,
                o,
                a = t(this),
                r = ["fontSize"],
                h = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
                l = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
                c = e.mode,
                u = "effect" !== c,
                d = e.scale || "both",
                p = e.origin || ["middle", "center"],
                f = a.css("position"),
                g = a.position(),
                m = t.effects.scaledDimensions(a),
                _ = e.from || m,
                v = e.to || t.effects.scaledDimensions(a, 0);
            t.effects.createPlaceholder(a),
                "show" === c && ((o = _), (_ = v), (v = o)),
                (n = { from: { y: _.height / m.height, x: _.width / m.width }, to: { y: v.height / m.height, x: v.width / m.width } }),
                ("box" === d || "both" === d) &&
                    (n.from.y !== n.to.y && ((_ = t.effects.setTransition(a, h, n.from.y, _)), (v = t.effects.setTransition(a, h, n.to.y, v))),
                    n.from.x !== n.to.x && ((_ = t.effects.setTransition(a, l, n.from.x, _)), (v = t.effects.setTransition(a, l, n.to.x, v)))),
                ("content" === d || "both" === d) && n.from.y !== n.to.y && ((_ = t.effects.setTransition(a, r, n.from.y, _)), (v = t.effects.setTransition(a, r, n.to.y, v))),
                p &&
                    ((s = t.effects.getBaseline(p, m)),
                    (_.top = (m.outerHeight - _.outerHeight) * s.y + g.top),
                    (_.left = (m.outerWidth - _.outerWidth) * s.x + g.left),
                    (v.top = (m.outerHeight - v.outerHeight) * s.y + g.top),
                    (v.left = (m.outerWidth - v.outerWidth) * s.x + g.left)),
                a.css(_),
                ("content" === d || "both" === d) &&
                    ((h = h.concat(["marginTop", "marginBottom"]).concat(r)),
                    (l = l.concat(["marginLeft", "marginRight"])),
                    a.find("*[width]").each(function () {
                        var i = t(this),
                            s = t.effects.scaledDimensions(i),
                            o = { height: s.height * n.from.y, width: s.width * n.from.x, outerHeight: s.outerHeight * n.from.y, outerWidth: s.outerWidth * n.from.x },
                            a = { height: s.height * n.to.y, width: s.width * n.to.x, outerHeight: s.height * n.to.y, outerWidth: s.width * n.to.x };
                        n.from.y !== n.to.y && ((o = t.effects.setTransition(i, h, n.from.y, o)), (a = t.effects.setTransition(i, h, n.to.y, a))),
                            n.from.x !== n.to.x && ((o = t.effects.setTransition(i, l, n.from.x, o)), (a = t.effects.setTransition(i, l, n.to.x, a))),
                            u && t.effects.saveStyle(i),
                            i.css(o),
                            i.animate(a, e.duration, e.easing, function () {
                                u && t.effects.restoreStyle(i);
                            });
                    })),
                a.animate(v, {
                    queue: !1,
                    duration: e.duration,
                    easing: e.easing,
                    complete: function () {
                        var e = a.offset();
                        0 === v.opacity && a.css("opacity", _.opacity), u || (a.css("position", "static" === f ? "relative" : f).offset(e), t.effects.saveStyle(a)), i();
                    },
                });
        }),
        t.effects.define("scale", function (e, i) {
            var s = t(this),
                n = e.mode,
                o = parseInt(e.percent, 10) || (0 === parseInt(e.percent, 10) ? 0 : "effect" !== n ? 0 : 100),
                a = t.extend(!0, { from: t.effects.scaledDimensions(s), to: t.effects.scaledDimensions(s, o, e.direction || "both"), origin: e.origin || ["middle", "center"] }, e);
            e.fade && ((a.from.opacity = 1), (a.to.opacity = 0)), t.effects.effect.size.call(this, a, i);
        }),
        t.effects.define("puff", "hide", function (e, i) {
            var s = t.extend(!0, {}, e, { fade: !0, percent: parseInt(e.percent, 10) || 150 });
            t.effects.effect.scale.call(this, s, i);
        }),
        t.effects.define("pulsate", "show", function (e, i) {
            var s = t(this),
                n = e.mode,
                o = "show" === n,
                a = "hide" === n,
                r = o || a,
                h = 2 * (e.times || 5) + (r ? 1 : 0),
                l = e.duration / h,
                c = 0,
                u = 1,
                d = s.queue().length;
            for ((o || !s.is(":visible")) && (s.css("opacity", 0).show(), (c = 1)); h > u; u++) s.animate({ opacity: c }, l, e.easing), (c = 1 - c);
            s.animate({ opacity: c }, l, e.easing), s.queue(i), t.effects.unshift(s, d, h + 1);
        }),
        t.effects.define("shake", function (e, i) {
            var s = 1,
                n = t(this),
                o = e.direction || "left",
                a = e.distance || 20,
                r = e.times || 3,
                h = 2 * r + 1,
                l = Math.round(e.duration / h),
                c = "up" === o || "down" === o ? "top" : "left",
                u = "up" === o || "left" === o,
                d = {},
                p = {},
                f = {},
                g = n.queue().length;
            for (t.effects.createPlaceholder(n), d[c] = (u ? "-=" : "+=") + a, p[c] = (u ? "+=" : "-=") + 2 * a, f[c] = (u ? "-=" : "+=") + 2 * a, n.animate(d, l, e.easing); r > s; s++) n.animate(p, l, e.easing).animate(f, l, e.easing);
            n
                .animate(p, l, e.easing)
                .animate(d, l / 2, e.easing)
                .queue(i),
                t.effects.unshift(n, g, h + 1);
        }),
        t.effects.define("slide", "show", function (e, i) {
            var s,
                n,
                o = t(this),
                a = { up: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], right: ["left", "right"] },
                r = e.mode,
                h = e.direction || "left",
                l = "up" === h || "down" === h ? "top" : "left",
                c = "up" === h || "left" === h,
                u = e.distance || o["top" === l ? "outerHeight" : "outerWidth"](!0),
                d = {};
            t.effects.createPlaceholder(o),
                (s = o.cssClip()),
                (n = o.position()[l]),
                (d[l] = (c ? -1 : 1) * u + n),
                (d.clip = o.cssClip()),
                (d.clip[a[h][1]] = d.clip[a[h][0]]),
                "show" === r && (o.cssClip(d.clip), o.css(l, d[l]), (d.clip = s), (d[l] = n)),
                o.animate(d, { queue: !1, duration: e.duration, easing: e.easing, complete: i });
        });
    t.uiBackCompat !== !1 &&
        (f = t.effects.define("transfer", function (e, i) {
            t(this).transfer(e, i);
        }));
    (t.ui.focusable = function (i, s) {
        var n,
            o,
            a,
            r,
            h,
            l = i.nodeName.toLowerCase();
        return "area" === l
            ? ((n = i.parentNode), (o = n.name), i.href && o && "map" === n.nodeName.toLowerCase() ? ((a = t("img[usemap='#" + o + "']")), a.length > 0 && a.is(":visible")) : !1)
            : (/^(input|select|textarea|button|object)$/.test(l) ? ((r = !i.disabled), r && ((h = t(i).closest("fieldset")[0]), h && (r = !h.disabled))) : (r = "a" === l ? i.href || s : s), r && t(i).is(":visible") && e(t(i)));
    }),
        t.extend(t.expr[":"], {
            focusable: function (e) {
                return t.ui.focusable(e, null != t.attr(e, "tabindex"));
            },
        });
    t.ui.focusable,
        (t.fn.form = function () {
            return "string" == typeof this[0].form ? this.closest("form") : t(this[0].form);
        }),
        (t.ui.formResetMixin = {
            _formResetHandler: function () {
                var e = t(this);
                setTimeout(function () {
                    var i = e.data("ui-form-reset-instances");
                    t.each(i, function () {
                        this.refresh();
                    });
                });
            },
            _bindFormResetHandler: function () {
                if (((this.form = this.element.form()), this.form.length)) {
                    var t = this.form.data("ui-form-reset-instances") || [];
                    t.length || this.form.on("reset.ui-form-reset", this._formResetHandler), t.push(this), this.form.data("ui-form-reset-instances", t);
                }
            },
            _unbindFormResetHandler: function () {
                if (this.form.length) {
                    var e = this.form.data("ui-form-reset-instances");
                    e.splice(t.inArray(this, e), 1), e.length ? this.form.data("ui-form-reset-instances", e) : this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset");
                }
            },
        });
    "1.7" === t.fn.jquery.substring(0, 3) &&
        (t.each(["Width", "Height"], function (e, i) {
            function s(e, i, s, o) {
                return (
                    t.each(n, function () {
                        (i -= parseFloat(t.css(e, "padding" + this)) || 0), s && (i -= parseFloat(t.css(e, "border" + this + "Width")) || 0), o && (i -= parseFloat(t.css(e, "margin" + this)) || 0);
                    }),
                    i
                );
            }
            var n = "Width" === i ? ["Left", "Right"] : ["Top", "Bottom"],
                o = i.toLowerCase(),
                a = { innerWidth: t.fn.innerWidth, innerHeight: t.fn.innerHeight, outerWidth: t.fn.outerWidth, outerHeight: t.fn.outerHeight };
            (t.fn["inner" + i] = function (e) {
                return void 0 === e
                    ? a["inner" + i].call(this)
                    : this.each(function () {
                          t(this).css(o, s(this, e) + "px");
                      });
            }),
                (t.fn["outer" + i] = function (e, n) {
                    return "number" != typeof e
                        ? a["outer" + i].call(this, e)
                        : this.each(function () {
                              t(this).css(o, s(this, e, !0, n) + "px");
                          });
                });
        }),
        (t.fn.addBack = function (t) {
            return this.add(null == t ? this.prevObject : this.prevObject.filter(t));
        }));
    (t.ui.keyCode = { BACKSPACE: 8, COMMA: 188, DELETE: 46, DOWN: 40, END: 35, ENTER: 13, ESCAPE: 27, HOME: 36, LEFT: 37, PAGE_DOWN: 34, PAGE_UP: 33, PERIOD: 190, RIGHT: 39, SPACE: 32, TAB: 9, UP: 38 }),
        (t.ui.escapeSelector = (function () {
            var t = /([!"#$%&'()*+,.\/:;<=>?@[\]^`{|}~])/g;
            return function (e) {
                return e.replace(t, "\\$1");
            };
        })()),
        (t.fn.labels = function () {
            var e, i, s, n, o;
            return this[0].labels && this[0].labels.length
                ? this.pushStack(this[0].labels)
                : ((n = this.eq(0).parents("label")),
                  (s = this.attr("id")),
                  s && ((e = this.eq(0).parents().last()), (o = e.add(e.length ? e.siblings() : this.siblings())), (i = "label[for='" + t.ui.escapeSelector(s) + "']"), (n = n.add(o.find(i).addBack(i)))),
                  this.pushStack(n));
        }),
        (t.fn.scrollParent = function (e) {
            var i = this.css("position"),
                s = "absolute" === i,
                n = e ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                o = this.parents()
                    .filter(function () {
                        var e = t(this);
                        return s && "static" === e.css("position") ? !1 : n.test(e.css("overflow") + e.css("overflow-y") + e.css("overflow-x"));
                    })
                    .eq(0);
            return "fixed" !== i && o.length ? o : t(this[0].ownerDocument || document);
        }),
        t.extend(t.expr[":"], {
            tabbable: function (e) {
                var i = t.attr(e, "tabindex"),
                    s = null != i;
                return (!s || i >= 0) && t.ui.focusable(e, s);
            },
        }),
        t.fn.extend({
            uniqueId: (function () {
                var t = 0;
                return function () {
                    return this.each(function () {
                        this.id || (this.id = "ui-id-" + ++t);
                    });
                };
            })(),
            removeUniqueId: function () {
                return this.each(function () {
                    /^ui-id-\d+$/.test(this.id) && t(this).removeAttr("id");
                });
            },
        }),
        t.widget("ui.accordion", {
            version: "1.12.1",
            options: {
                active: 0,
                animate: {},
                classes: { "ui-accordion-header": "ui-corner-top", "ui-accordion-header-collapsed": "ui-corner-all", "ui-accordion-content": "ui-corner-bottom" },
                collapsible: !1,
                event: "click",
                header: "> li > :first-child, > :not(li):even",
                heightStyle: "auto",
                icons: { activeHeader: "ui-icon-triangle-1-s", header: "ui-icon-triangle-1-e" },
                activate: null,
                beforeActivate: null,
            },
            hideProps: { borderTopWidth: "hide", borderBottomWidth: "hide", paddingTop: "hide", paddingBottom: "hide", height: "hide" },
            showProps: { borderTopWidth: "show", borderBottomWidth: "show", paddingTop: "show", paddingBottom: "show", height: "show" },
            _create: function () {
                var e = this.options;
                (this.prevShow = this.prevHide = t()),
                    this._addClass("ui-accordion", "ui-widget ui-helper-reset"),
                    this.element.attr("role", "tablist"),
                    e.collapsible || (e.active !== !1 && null != e.active) || (e.active = 0),
                    this._processPanels(),
                    e.active < 0 && (e.active += this.headers.length),
                    this._refresh();
            },
            _getCreateEventData: function () {
                return { header: this.active, panel: this.active.length ? this.active.next() : t() };
            },
            _createIcons: function () {
                var e,
                    i,
                    s = this.options.icons;
                s &&
                    ((e = t("<span>")),
                    this._addClass(e, "ui-accordion-header-icon", "ui-icon " + s.header),
                    e.prependTo(this.headers),
                    (i = this.active.children(".ui-accordion-header-icon")),
                    this._removeClass(i, s.header)._addClass(i, null, s.activeHeader)._addClass(this.headers, "ui-accordion-icons"));
            },
            _destroyIcons: function () {
                this._removeClass(this.headers, "ui-accordion-icons"), this.headers.children(".ui-accordion-header-icon").remove();
            },
            _destroy: function () {
                var t;
                this.element.removeAttr("role"),
                    this.headers.removeAttr("role aria-expanded aria-selected aria-controls tabIndex").removeUniqueId(),
                    this._destroyIcons(),
                    (t = this.headers.next().css("display", "").removeAttr("role aria-hidden aria-labelledby").removeUniqueId()),
                    "content" !== this.options.heightStyle && t.css("height", "");
            },
            _setOption: function (t, e) {
                return "active" === t
                    ? void this._activate(e)
                    : ("event" === t && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(e)),
                      this._super(t, e),
                      "collapsible" !== t || e || this.options.active !== !1 || this._activate(0),
                      void ("icons" === t && (this._destroyIcons(), e && this._createIcons())));
            },
            _setOptionDisabled: function (t) {
                this._super(t), this.element.attr("aria-disabled", t), this._toggleClass(null, "ui-state-disabled", !!t), this._toggleClass(this.headers.add(this.headers.next()), null, "ui-state-disabled", !!t);
            },
            _keydown: function (e) {
                if (!e.altKey && !e.ctrlKey) {
                    var i = t.ui.keyCode,
                        s = this.headers.length,
                        n = this.headers.index(e.target),
                        o = !1;
                    switch (e.keyCode) {
                        case i.RIGHT:
                        case i.DOWN:
                            o = this.headers[(n + 1) % s];
                            break;
                        case i.LEFT:
                        case i.UP:
                            o = this.headers[(n - 1 + s) % s];
                            break;
                        case i.SPACE:
                        case i.ENTER:
                            this._eventHandler(e);
                            break;
                        case i.HOME:
                            o = this.headers[0];
                            break;
                        case i.END:
                            o = this.headers[s - 1];
                    }
                    o && (t(e.target).attr("tabIndex", -1), t(o).attr("tabIndex", 0), t(o).trigger("focus"), e.preventDefault());
                }
            },
            _panelKeyDown: function (e) {
                e.keyCode === t.ui.keyCode.UP && e.ctrlKey && t(e.currentTarget).prev().trigger("focus");
            },
            refresh: function () {
                var e = this.options;
                this._processPanels(),
                    (e.active === !1 && e.collapsible === !0) || !this.headers.length
                        ? ((e.active = !1), (this.active = t()))
                        : e.active === !1
                        ? this._activate(0)
                        : this.active.length && !t.contains(this.element[0], this.active[0])
                        ? this.headers.length === this.headers.find(".ui-state-disabled").length
                            ? ((e.active = !1), (this.active = t()))
                            : this._activate(Math.max(0, e.active - 1))
                        : (e.active = this.headers.index(this.active)),
                    this._destroyIcons(),
                    this._refresh();
            },
            _processPanels: function () {
                var t = this.headers,
                    e = this.panels;
                (this.headers = this.element.find(this.options.header)),
                    this._addClass(this.headers, "ui-accordion-header ui-accordion-header-collapsed", "ui-state-default"),
                    (this.panels = this.headers.next().filter(":not(.ui-accordion-content-active)").hide()),
                    this._addClass(this.panels, "ui-accordion-content", "ui-helper-reset ui-widget-content"),
                    e && (this._off(t.not(this.headers)), this._off(e.not(this.panels)));
            },
            _refresh: function () {
                var e,
                    i = this.options,
                    s = i.heightStyle,
                    n = this.element.parent();
                (this.active = this._findActive(i.active)),
                    this._addClass(this.active, "ui-accordion-header-active", "ui-state-active")._removeClass(this.active, "ui-accordion-header-collapsed"),
                    this._addClass(this.active.next(), "ui-accordion-content-active"),
                    this.active.next().show(),
                    this.headers
                        .attr("role", "tab")
                        .each(function () {
                            var e = t(this),
                                i = e.uniqueId().attr("id"),
                                s = e.next(),
                                n = s.uniqueId().attr("id");
                            e.attr("aria-controls", n), s.attr("aria-labelledby", i);
                        })
                        .next()
                        .attr("role", "tabpanel"),
                    this.headers.not(this.active).attr({ "aria-selected": "false", "aria-expanded": "false", tabIndex: -1 }).next().attr({ "aria-hidden": "true" }).hide(),
                    this.active.length ? this.active.attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 }).next().attr({ "aria-hidden": "false" }) : this.headers.eq(0).attr("tabIndex", 0),
                    this._createIcons(),
                    this._setupEvents(i.event),
                    "fill" === s
                        ? ((e = n.height()),
                          this.element.siblings(":visible").each(function () {
                              var i = t(this),
                                  s = i.css("position");
                              "absolute" !== s && "fixed" !== s && (e -= i.outerHeight(!0));
                          }),
                          this.headers.each(function () {
                              e -= t(this).outerHeight(!0);
                          }),
                          this.headers
                              .next()
                              .each(function () {
                                  t(this).height(Math.max(0, e - t(this).innerHeight() + t(this).height()));
                              })
                              .css("overflow", "auto"))
                        : "auto" === s &&
                          ((e = 0),
                          this.headers
                              .next()
                              .each(function () {
                                  var i = t(this).is(":visible");
                                  i || t(this).show(), (e = Math.max(e, t(this).css("height", "").height())), i || t(this).hide();
                              })
                              .height(e));
            },
            _activate: function (e) {
                var i = this._findActive(e)[0];
                i !== this.active[0] && ((i = i || this.active[0]), this._eventHandler({ target: i, currentTarget: i, preventDefault: t.noop }));
            },
            _findActive: function (e) {
                return "number" == typeof e ? this.headers.eq(e) : t();
            },
            _setupEvents: function (e) {
                var i = { keydown: "_keydown" };
                e &&
                    t.each(e.split(" "), function (t, e) {
                        i[e] = "_eventHandler";
                    }),
                    this._off(this.headers.add(this.headers.next())),
                    this._on(this.headers, i),
                    this._on(this.headers.next(), { keydown: "_panelKeyDown" }),
                    this._hoverable(this.headers),
                    this._focusable(this.headers);
            },
            _eventHandler: function (e) {
                var i,
                    s,
                    n = this.options,
                    o = this.active,
                    a = t(e.currentTarget),
                    r = a[0] === o[0],
                    h = r && n.collapsible,
                    l = h ? t() : a.next(),
                    c = o.next(),
                    u = { oldHeader: o, oldPanel: c, newHeader: h ? t() : a, newPanel: l };
                e.preventDefault(),
                    (r && !n.collapsible) ||
                        this._trigger("beforeActivate", e, u) === !1 ||
                        ((n.active = h ? !1 : this.headers.index(a)),
                        (this.active = r ? t() : a),
                        this._toggle(u),
                        this._removeClass(o, "ui-accordion-header-active", "ui-state-active"),
                        n.icons && ((i = o.children(".ui-accordion-header-icon")), this._removeClass(i, null, n.icons.activeHeader)._addClass(i, null, n.icons.header)),
                        r ||
                            (this._removeClass(a, "ui-accordion-header-collapsed")._addClass(a, "ui-accordion-header-active", "ui-state-active"),
                            n.icons && ((s = a.children(".ui-accordion-header-icon")), this._removeClass(s, null, n.icons.header)._addClass(s, null, n.icons.activeHeader)),
                            this._addClass(a.next(), "ui-accordion-content-active")));
            },
            _toggle: function (e) {
                var i = e.newPanel,
                    s = this.prevShow.length ? this.prevShow : e.oldPanel;
                this.prevShow.add(this.prevHide).stop(!0, !0),
                    (this.prevShow = i),
                    (this.prevHide = s),
                    this.options.animate ? this._animate(i, s, e) : (s.hide(), i.show(), this._toggleComplete(e)),
                    s.attr({ "aria-hidden": "true" }),
                    s.prev().attr({ "aria-selected": "false", "aria-expanded": "false" }),
                    i.length && s.length
                        ? s.prev().attr({ tabIndex: -1, "aria-expanded": "false" })
                        : i.length &&
                          this.headers
                              .filter(function () {
                                  return 0 === parseInt(t(this).attr("tabIndex"), 10);
                              })
                              .attr("tabIndex", -1),
                    i.attr("aria-hidden", "false").prev().attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 });
            },
            _animate: function (t, e, i) {
                var s,
                    n,
                    o,
                    a = this,
                    r = 0,
                    h = t.css("box-sizing"),
                    l = t.length && (!e.length || t.index() < e.index()),
                    c = this.options.animate || {},
                    u = (l && c.down) || c,
                    d = function () {
                        a._toggleComplete(i);
                    };
                return (
                    "number" == typeof u && (o = u),
                    "string" == typeof u && (n = u),
                    (n = n || u.easing || c.easing),
                    (o = o || u.duration || c.duration),
                    e.length
                        ? t.length
                            ? ((s = t.show().outerHeight()),
                              e.animate(this.hideProps, {
                                  duration: o,
                                  easing: n,
                                  step: function (t, e) {
                                      e.now = Math.round(t);
                                  },
                              }),
                              void t.hide().animate(this.showProps, {
                                  duration: o,
                                  easing: n,
                                  complete: d,
                                  step: function (t, i) {
                                      (i.now = Math.round(t)), "height" !== i.prop ? "content-box" === h && (r += i.now) : "content" !== a.options.heightStyle && ((i.now = Math.round(s - e.outerHeight() - r)), (r = 0));
                                  },
                              }))
                            : e.animate(this.hideProps, o, n, d)
                        : t.animate(this.showProps, o, n, d)
                );
            },
            _toggleComplete: function (t) {
                var e = t.oldPanel,
                    i = e.prev();
                this._removeClass(e, "ui-accordion-content-active"),
                    this._removeClass(i, "ui-accordion-header-active")._addClass(i, "ui-accordion-header-collapsed"),
                    e.length && (e.parent()[0].className = e.parent()[0].className),
                    this._trigger("activate", null, t);
            },
        }),
        (t.ui.safeActiveElement = function (t) {
            var e;
            try {
                e = t.activeElement;
            } catch (i) {
                e = t.body;
            }
            return e || (e = t.body), e.nodeName || (e = t.body), e;
        }),
        t.widget("ui.menu", {
            version: "1.12.1",
            defaultElement: "<ul>",
            delay: 300,
            options: { icons: { submenu: "ui-icon-caret-1-e" }, items: "> *", menus: "ul", position: { my: "left top", at: "right top" }, role: "menu", blur: null, focus: null, select: null },
            _create: function () {
                (this.activeMenu = this.element),
                    (this.mouseHandled = !1),
                    this.element.uniqueId().attr({ role: this.options.role, tabIndex: 0 }),
                    this._addClass("ui-menu", "ui-widget ui-widget-content"),
                    this._on({
                        "mousedown .ui-menu-item": function (t) {
                            t.preventDefault();
                        },
                        "click .ui-menu-item": function (e) {
                            var i = t(e.target),
                                s = t(t.ui.safeActiveElement(this.document[0]));
                            !this.mouseHandled &&
                                i.not(".ui-state-disabled").length &&
                                (this.select(e),
                                e.isPropagationStopped() || (this.mouseHandled = !0),
                                i.has(".ui-menu").length
                                    ? this.expand(e)
                                    : !this.element.is(":focus") && s.closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer)));
                        },
                        "mouseenter .ui-menu-item": function (e) {
                            if (!this.previousFilter) {
                                var i = t(e.target).closest(".ui-menu-item"),
                                    s = t(e.currentTarget);
                                i[0] === s[0] && (this._removeClass(s.siblings().children(".ui-state-active"), null, "ui-state-active"), this.focus(e, s));
                            }
                        },
                        mouseleave: "collapseAll",
                        "mouseleave .ui-menu": "collapseAll",
                        focus: function (t, e) {
                            var i = this.active || this.element.find(this.options.items).eq(0);
                            e || this.focus(t, i);
                        },
                        blur: function (e) {
                            this._delay(function () {
                                var i = !t.contains(this.element[0], t.ui.safeActiveElement(this.document[0]));
                                i && this.collapseAll(e);
                            });
                        },
                        keydown: "_keydown",
                    }),
                    this.refresh(),
                    this._on(this.document, {
                        click: function (t) {
                            this._closeOnDocumentClick(t) && this.collapseAll(t), (this.mouseHandled = !1);
                        },
                    });
            },
            _destroy: function () {
                var e = this.element.find(".ui-menu-item").removeAttr("role aria-disabled"),
                    i = e.children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup");
                this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(),
                    i.children().each(function () {
                        var e = t(this);
                        e.data("ui-menu-submenu-caret") && e.remove();
                    });
            },
            _keydown: function (e) {
                var i,
                    s,
                    n,
                    o,
                    a = !0;
                switch (e.keyCode) {
                    case t.ui.keyCode.PAGE_UP:
                        this.previousPage(e);
                        break;
                    case t.ui.keyCode.PAGE_DOWN:
                        this.nextPage(e);
                        break;
                    case t.ui.keyCode.HOME:
                        this._move("first", "first", e);
                        break;
                    case t.ui.keyCode.END:
                        this._move("last", "last", e);
                        break;
                    case t.ui.keyCode.UP:
                        this.previous(e);
                        break;
                    case t.ui.keyCode.DOWN:
                        this.next(e);
                        break;
                    case t.ui.keyCode.LEFT:
                        this.collapse(e);
                        break;
                    case t.ui.keyCode.RIGHT:
                        this.active && !this.active.is(".ui-state-disabled") && this.expand(e);
                        break;
                    case t.ui.keyCode.ENTER:
                    case t.ui.keyCode.SPACE:
                        this._activate(e);
                        break;
                    case t.ui.keyCode.ESCAPE:
                        this.collapse(e);
                        break;
                    default:
                        (a = !1),
                            (s = this.previousFilter || ""),
                            (o = !1),
                            (n = e.keyCode >= 96 && e.keyCode <= 105 ? (e.keyCode - 96).toString() : String.fromCharCode(e.keyCode)),
                            clearTimeout(this.filterTimer),
                            n === s ? (o = !0) : (n = s + n),
                            (i = this._filterMenuItems(n)),
                            (i = o && -1 !== i.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : i),
                            i.length || ((n = String.fromCharCode(e.keyCode)), (i = this._filterMenuItems(n))),
                            i.length
                                ? (this.focus(e, i),
                                  (this.previousFilter = n),
                                  (this.filterTimer = this._delay(function () {
                                      delete this.previousFilter;
                                  }, 1e3)))
                                : delete this.previousFilter;
                }
                a && e.preventDefault();
            },
            _activate: function (t) {
                this.active && !this.active.is(".ui-state-disabled") && (this.active.children("[aria-haspopup='true']").length ? this.expand(t) : this.select(t));
            },
            refresh: function () {
                var e,
                    i,
                    s,
                    n,
                    o,
                    a = this,
                    r = this.options.icons.submenu,
                    h = this.element.find(this.options.menus);
                this._toggleClass("ui-menu-icons", null, !!this.element.find(".ui-icon").length),
                    (s = h
                        .filter(":not(.ui-menu)")
                        .hide()
                        .attr({ role: this.options.role, "aria-hidden": "true", "aria-expanded": "false" })
                        .each(function () {
                            var e = t(this),
                                i = e.prev(),
                                s = t("<span>").data("ui-menu-submenu-caret", !0);
                            a._addClass(s, "ui-menu-icon", "ui-icon " + r), i.attr("aria-haspopup", "true").prepend(s), e.attr("aria-labelledby", i.attr("id"));
                        })),
                    this._addClass(s, "ui-menu", "ui-widget ui-widget-content ui-front"),
                    (e = h.add(this.element)),
                    (i = e.find(this.options.items)),
                    i.not(".ui-menu-item").each(function () {
                        var e = t(this);
                        a._isDivider(e) && a._addClass(e, "ui-menu-divider", "ui-widget-content");
                    }),
                    (n = i.not(".ui-menu-item, .ui-menu-divider")),
                    (o = n.children().not(".ui-menu").uniqueId().attr({ tabIndex: -1, role: this._itemRole() })),
                    this._addClass(n, "ui-menu-item")._addClass(o, "ui-menu-item-wrapper"),
                    i.filter(".ui-state-disabled").attr("aria-disabled", "true"),
                    this.active && !t.contains(this.element[0], this.active[0]) && this.blur();
            },
            _itemRole: function () {
                return { menu: "menuitem", listbox: "option" }[this.options.role];
            },
            _setOption: function (t, e) {
                if ("icons" === t) {
                    var i = this.element.find(".ui-menu-icon");
                    this._removeClass(i, null, this.options.icons.submenu)._addClass(i, null, e.submenu);
                }
                this._super(t, e);
            },
            _setOptionDisabled: function (t) {
                this._super(t), this.element.attr("aria-disabled", String(t)), this._toggleClass(null, "ui-state-disabled", !!t);
            },
            focus: function (t, e) {
                var i, s, n;
                this.blur(t, t && "focus" === t.type),
                    this._scrollIntoView(e),
                    (this.active = e.first()),
                    (s = this.active.children(".ui-menu-item-wrapper")),
                    this._addClass(s, null, "ui-state-active"),
                    this.options.role && this.element.attr("aria-activedescendant", s.attr("id")),
                    (n = this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper")),
                    this._addClass(n, null, "ui-state-active"),
                    t && "keydown" === t.type
                        ? this._close()
                        : (this.timer = this._delay(function () {
                              this._close();
                          }, this.delay)),
                    (i = e.children(".ui-menu")),
                    i.length && t && /^mouse/.test(t.type) && this._startOpening(i),
                    (this.activeMenu = e.parent()),
                    this._trigger("focus", t, { item: e });
            },
            _scrollIntoView: function (e) {
                var i, s, n, o, a, r;
                this._hasScroll() &&
                    ((i = parseFloat(t.css(this.activeMenu[0], "borderTopWidth")) || 0),
                    (s = parseFloat(t.css(this.activeMenu[0], "paddingTop")) || 0),
                    (n = e.offset().top - this.activeMenu.offset().top - i - s),
                    (o = this.activeMenu.scrollTop()),
                    (a = this.activeMenu.height()),
                    (r = e.outerHeight()),
                    0 > n ? this.activeMenu.scrollTop(o + n) : n + r > a && this.activeMenu.scrollTop(o + n - a + r));
            },
            blur: function (t, e) {
                e || clearTimeout(this.timer), this.active && (this._removeClass(this.active.children(".ui-menu-item-wrapper"), null, "ui-state-active"), this._trigger("blur", t, { item: this.active }), (this.active = null));
            },
            _startOpening: function (t) {
                clearTimeout(this.timer),
                    "true" === t.attr("aria-hidden") &&
                        (this.timer = this._delay(function () {
                            this._close(), this._open(t);
                        }, this.delay));
            },
            _open: function (e) {
                var i = t.extend({ of: this.active }, this.options.position);
                clearTimeout(this.timer), this.element.find(".ui-menu").not(e.parents(".ui-menu")).hide().attr("aria-hidden", "true"), e.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(i);
            },
            collapseAll: function (e, i) {
                clearTimeout(this.timer),
                    (this.timer = this._delay(function () {
                        var s = i ? this.element : t(e && e.target).closest(this.element.find(".ui-menu"));
                        s.length || (s = this.element), this._close(s), this.blur(e), this._removeClass(s.find(".ui-state-active"), null, "ui-state-active"), (this.activeMenu = s);
                    }, this.delay));
            },
            _close: function (t) {
                t || (t = this.active ? this.active.parent() : this.element), t.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false");
            },
            _closeOnDocumentClick: function (e) {
                return !t(e.target).closest(".ui-menu").length;
            },
            _isDivider: function (t) {
                return !/[^\-\u2014\u2013\s]/.test(t.text());
            },
            collapse: function (t) {
                var e = this.active && this.active.parent().closest(".ui-menu-item", this.element);
                e && e.length && (this._close(), this.focus(t, e));
            },
            expand: function (t) {
                var e = this.active && this.active.children(".ui-menu ").find(this.options.items).first();
                e &&
                    e.length &&
                    (this._open(e.parent()),
                    this._delay(function () {
                        this.focus(t, e);
                    }));
            },
            next: function (t) {
                this._move("next", "first", t);
            },
            previous: function (t) {
                this._move("prev", "last", t);
            },
            isFirstItem: function () {
                return this.active && !this.active.prevAll(".ui-menu-item").length;
            },
            isLastItem: function () {
                return this.active && !this.active.nextAll(".ui-menu-item").length;
            },
            _move: function (t, e, i) {
                var s;
                this.active && (s = "first" === t || "last" === t ? this.active["first" === t ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : this.active[t + "All"](".ui-menu-item").eq(0)),
                    (s && s.length && this.active) || (s = this.activeMenu.find(this.options.items)[e]()),
                    this.focus(i, s);
            },
            nextPage: function (e) {
                var i, s, n;
                return this.active
                    ? void (
                          this.isLastItem() ||
                          (this._hasScroll()
                              ? ((s = this.active.offset().top),
                                (n = this.element.height()),
                                this.active.nextAll(".ui-menu-item").each(function () {
                                    return (i = t(this)), i.offset().top - s - n < 0;
                                }),
                                this.focus(e, i))
                              : this.focus(e, this.activeMenu.find(this.options.items)[this.active ? "last" : "first"]()))
                      )
                    : void this.next(e);
            },
            previousPage: function (e) {
                var i, s, n;
                return this.active
                    ? void (
                          this.isFirstItem() ||
                          (this._hasScroll()
                              ? ((s = this.active.offset().top),
                                (n = this.element.height()),
                                this.active.prevAll(".ui-menu-item").each(function () {
                                    return (i = t(this)), i.offset().top - s + n > 0;
                                }),
                                this.focus(e, i))
                              : this.focus(e, this.activeMenu.find(this.options.items).first()))
                      )
                    : void this.next(e);
            },
            _hasScroll: function () {
                return this.element.outerHeight() < this.element.prop("scrollHeight");
            },
            select: function (e) {
                this.active = this.active || t(e.target).closest(".ui-menu-item");
                var i = { item: this.active };
                this.active.has(".ui-menu").length || this.collapseAll(e, !0), this._trigger("select", e, i);
            },
            _filterMenuItems: function (e) {
                var i = e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"),
                    s = new RegExp("^" + i, "i");
                return this.activeMenu
                    .find(this.options.items)
                    .filter(".ui-menu-item")
                    .filter(function () {
                        return s.test(t.trim(t(this).children(".ui-menu-item-wrapper").text()));
                    });
            },
        });
    t.extend(t.ui, { datepicker: { version: "1.12.1" } });
    var m;
    t.extend(s.prototype, {
        markerClassName: "hasDatepicker",
        maxRows: 4,
        _widgetDatepicker: function () {
            return this.dpDiv;
        },
        setDefaults: function (t) {
            return a(this._defaults, t || {}), this;
        },
        _attachDatepicker: function (e, i) {
            var s, n, o;
            (s = e.nodeName.toLowerCase()),
                (n = "div" === s || "span" === s),
                e.id || ((this.uuid += 1), (e.id = "dp" + this.uuid)),
                (o = this._newInst(t(e), n)),
                (o.settings = t.extend({}, i || {})),
                "input" === s ? this._connectDatepicker(e, o) : n && this._inlineDatepicker(e, o);
        },
        _newInst: function (e, i) {
            var s = e[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1");
            return {
                id: s,
                input: e,
                selectedDay: 0,
                selectedMonth: 0,
                selectedYear: 0,
                drawMonth: 0,
                drawYear: 0,
                inline: i,
                dpDiv: i ? n(t("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv,
            };
        },
        _connectDatepicker: function (e, i) {
            var s = t(e);
            (i.append = t([])),
                (i.trigger = t([])),
                s.hasClass(this.markerClassName) ||
                    (this._attachments(s, i),
                    s.addClass(this.markerClassName).on("keydown", this._doKeyDown).on("keypress", this._doKeyPress).on("keyup", this._doKeyUp),
                    this._autoSize(i),
                    t.data(e, "datepicker", i),
                    i.settings.disabled && this._disableDatepicker(e));
        },
        _attachments: function (e, i) {
            var s,
                n,
                o,
                a = this._get(i, "appendText"),
                r = this._get(i, "isRTL");
            i.append && i.append.remove(),
                a && ((i.append = t("<span class='" + this._appendClass + "'>" + a + "</span>")), e[r ? "before" : "after"](i.append)),
                e.off("focus", this._showDatepicker),
                i.trigger && i.trigger.remove(),
                (s = this._get(i, "showOn")),
                ("focus" === s || "both" === s) && e.on("focus", this._showDatepicker),
                ("button" === s || "both" === s) &&
                    ((n = this._get(i, "buttonText")),
                    (o = this._get(i, "buttonImage")),
                    (i.trigger = t(
                        this._get(i, "buttonImageOnly")
                            ? t("<img/>").addClass(this._triggerClass).attr({ src: o, alt: n, title: n })
                            : t("<button type='button'></button>")
                                  .addClass(this._triggerClass)
                                  .html(o ? t("<img/>").attr({ src: o, alt: n, title: n }) : n)
                    )),
                    e[r ? "before" : "after"](i.trigger),
                    i.trigger.on("click", function () {
                        return (
                            t.datepicker._datepickerShowing && t.datepicker._lastInput === e[0]
                                ? t.datepicker._hideDatepicker()
                                : t.datepicker._datepickerShowing && t.datepicker._lastInput !== e[0]
                                ? (t.datepicker._hideDatepicker(), t.datepicker._showDatepicker(e[0]))
                                : t.datepicker._showDatepicker(e[0]),
                            !1
                        );
                    }));
        },
        _autoSize: function (t) {
            if (this._get(t, "autoSize") && !t.inline) {
                var e,
                    i,
                    s,
                    n,
                    o = new Date(2009, 11, 20),
                    a = this._get(t, "dateFormat");
                a.match(/[DM]/) &&
                    ((e = function (t) {
                        for (i = 0, s = 0, n = 0; n < t.length; n++) t[n].length > i && ((i = t[n].length), (s = n));
                        return s;
                    }),
                    o.setMonth(e(this._get(t, a.match(/MM/) ? "monthNames" : "monthNamesShort"))),
                    o.setDate(e(this._get(t, a.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - o.getDay())),
                    t.input.attr("size", this._formatDate(t, o).length);
            }
        },
        _inlineDatepicker: function (e, i) {
            var s = t(e);
            s.hasClass(this.markerClassName) ||
                (s.addClass(this.markerClassName).append(i.dpDiv),
                t.data(e, "datepicker", i),
                this._setDate(i, this._getDefaultDate(i), !0),
                this._updateDatepicker(i),
                this._updateAlternate(i),
                i.settings.disabled && this._disableDatepicker(e),
                i.dpDiv.css("display", "block"));
        },
        _dialogDatepicker: function (e, i, s, n, o) {
            var r,
                h,
                l,
                c,
                u,
                d = this._dialogInst;
            return (
                d ||
                    ((this.uuid += 1),
                    (r = "dp" + this.uuid),
                    (this._dialogInput = t("<input type='text' id='" + r + "' style='position: absolute; top: -100px; width: 0px;'/>")),
                    this._dialogInput.on("keydown", this._doKeyDown),
                    t("body").append(this._dialogInput),
                    (d = this._dialogInst = this._newInst(this._dialogInput, !1)),
                    (d.settings = {}),
                    t.data(this._dialogInput[0], "datepicker", d)),
                a(d.settings, n || {}),
                (i = i && i.constructor === Date ? this._formatDate(d, i) : i),
                this._dialogInput.val(i),
                (this._pos = o ? (o.length ? o : [o.pageX, o.pageY]) : null),
                this._pos ||
                    ((h = document.documentElement.clientWidth),
                    (l = document.documentElement.clientHeight),
                    (c = document.documentElement.scrollLeft || document.body.scrollLeft),
                    (u = document.documentElement.scrollTop || document.body.scrollTop),
                    (this._pos = [h / 2 - 100 + c, l / 2 - 150 + u])),
                this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"),
                (d.settings.onSelect = s),
                (this._inDialog = !0),
                this.dpDiv.addClass(this._dialogClass),
                this._showDatepicker(this._dialogInput[0]),
                t.blockUI && t.blockUI(this.dpDiv),
                t.data(this._dialogInput[0], "datepicker", d),
                this
            );
        },
        _destroyDatepicker: function (e) {
            var i,
                s = t(e),
                n = t.data(e, "datepicker");
            s.hasClass(this.markerClassName) &&
                ((i = e.nodeName.toLowerCase()),
                t.removeData(e, "datepicker"),
                "input" === i
                    ? (n.append.remove(), n.trigger.remove(), s.removeClass(this.markerClassName).off("focus", this._showDatepicker).off("keydown", this._doKeyDown).off("keypress", this._doKeyPress).off("keyup", this._doKeyUp))
                    : ("div" === i || "span" === i) && s.removeClass(this.markerClassName).empty(),
                m === n && (m = null));
        },
        _enableDatepicker: function (e) {
            var i,
                s,
                n = t(e),
                o = t.data(e, "datepicker");
            n.hasClass(this.markerClassName) &&
                ((i = e.nodeName.toLowerCase()),
                "input" === i
                    ? ((e.disabled = !1),
                      o.trigger
                          .filter("button")
                          .each(function () {
                              this.disabled = !1;
                          })
                          .end()
                          .filter("img")
                          .css({ opacity: "1.0", cursor: "" }))
                    : ("div" === i || "span" === i) && ((s = n.children("." + this._inlineClass)), s.children().removeClass("ui-state-disabled"), s.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)),
                (this._disabledInputs = t.map(this._disabledInputs, function (t) {
                    return t === e ? null : t;
                })));
        },
        _disableDatepicker: function (e) {
            var i,
                s,
                n = t(e),
                o = t.data(e, "datepicker");
            n.hasClass(this.markerClassName) &&
                ((i = e.nodeName.toLowerCase()),
                "input" === i
                    ? ((e.disabled = !0),
                      o.trigger
                          .filter("button")
                          .each(function () {
                              this.disabled = !0;
                          })
                          .end()
                          .filter("img")
                          .css({ opacity: "0.5", cursor: "default" }))
                    : ("div" === i || "span" === i) && ((s = n.children("." + this._inlineClass)), s.children().addClass("ui-state-disabled"), s.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)),
                (this._disabledInputs = t.map(this._disabledInputs, function (t) {
                    return t === e ? null : t;
                })),
                (this._disabledInputs[this._disabledInputs.length] = e));
        },
        _isDisabledDatepicker: function (t) {
            if (!t) return !1;
            for (var e = 0; e < this._disabledInputs.length; e++) if (this._disabledInputs[e] === t) return !0;
            return !1;
        },
        _getInst: function (e) {
            try {
                return t.data(e, "datepicker");
            } catch (i) {
                throw "Missing instance data for this datepicker";
            }
        },
        _optionDatepicker: function (e, i, s) {
            var n,
                o,
                r,
                h,
                l = this._getInst(e);
            return 2 === arguments.length && "string" == typeof i
                ? "defaults" === i
                    ? t.extend({}, t.datepicker._defaults)
                    : l
                    ? "all" === i
                        ? t.extend({}, l.settings)
                        : this._get(l, i)
                    : null
                : ((n = i || {}),
                  "string" == typeof i && ((n = {}), (n[i] = s)),
                  void (
                      l &&
                      (this._curInst === l && this._hideDatepicker(),
                      (o = this._getDateDatepicker(e, !0)),
                      (r = this._getMinMaxDate(l, "min")),
                      (h = this._getMinMaxDate(l, "max")),
                      a(l.settings, n),
                      null !== r && void 0 !== n.dateFormat && void 0 === n.minDate && (l.settings.minDate = this._formatDate(l, r)),
                      null !== h && void 0 !== n.dateFormat && void 0 === n.maxDate && (l.settings.maxDate = this._formatDate(l, h)),
                      "disabled" in n && (n.disabled ? this._disableDatepicker(e) : this._enableDatepicker(e)),
                      this._attachments(t(e), l),
                      this._autoSize(l),
                      this._setDate(l, o),
                      this._updateAlternate(l),
                      this._updateDatepicker(l))
                  ));
        },
        _changeDatepicker: function (t, e, i) {
            this._optionDatepicker(t, e, i);
        },
        _refreshDatepicker: function (t) {
            var e = this._getInst(t);
            e && this._updateDatepicker(e);
        },
        _setDateDatepicker: function (t, e) {
            var i = this._getInst(t);
            i && (this._setDate(i, e), this._updateDatepicker(i), this._updateAlternate(i));
        },
        _getDateDatepicker: function (t, e) {
            var i = this._getInst(t);
            return i && !i.inline && this._setDateFromField(i, e), i ? this._getDate(i) : null;
        },
        _doKeyDown: function (e) {
            var i,
                s,
                n,
                o = t.datepicker._getInst(e.target),
                a = !0,
                r = o.dpDiv.is(".ui-datepicker-rtl");
            if (((o._keyEvent = !0), t.datepicker._datepickerShowing))
                switch (e.keyCode) {
                    case 9:
                        t.datepicker._hideDatepicker(), (a = !1);
                        break;
                    case 13:
                        return (
                            (n = t("td." + t.datepicker._dayOverClass + ":not(." + t.datepicker._currentClass + ")", o.dpDiv)),
                            n[0] && t.datepicker._selectDay(e.target, o.selectedMonth, o.selectedYear, n[0]),
                            (i = t.datepicker._get(o, "onSelect")),
                            i ? ((s = t.datepicker._formatDate(o)), i.apply(o.input ? o.input[0] : null, [s, o])) : t.datepicker._hideDatepicker(),
                            !1
                        );
                    case 27:
                        t.datepicker._hideDatepicker();
                        break;
                    case 33:
                        t.datepicker._adjustDate(e.target, e.ctrlKey ? -t.datepicker._get(o, "stepBigMonths") : -t.datepicker._get(o, "stepMonths"), "M");
                        break;
                    case 34:
                        t.datepicker._adjustDate(e.target, e.ctrlKey ? +t.datepicker._get(o, "stepBigMonths") : +t.datepicker._get(o, "stepMonths"), "M");
                        break;
                    case 35:
                        (e.ctrlKey || e.metaKey) && t.datepicker._clearDate(e.target), (a = e.ctrlKey || e.metaKey);
                        break;
                    case 36:
                        (e.ctrlKey || e.metaKey) && t.datepicker._gotoToday(e.target), (a = e.ctrlKey || e.metaKey);
                        break;
                    case 37:
                        (e.ctrlKey || e.metaKey) && t.datepicker._adjustDate(e.target, r ? 1 : -1, "D"),
                            (a = e.ctrlKey || e.metaKey),
                            e.originalEvent.altKey && t.datepicker._adjustDate(e.target, e.ctrlKey ? -t.datepicker._get(o, "stepBigMonths") : -t.datepicker._get(o, "stepMonths"), "M");
                        break;
                    case 38:
                        (e.ctrlKey || e.metaKey) && t.datepicker._adjustDate(e.target, -7, "D"), (a = e.ctrlKey || e.metaKey);
                        break;
                    case 39:
                        (e.ctrlKey || e.metaKey) && t.datepicker._adjustDate(e.target, r ? -1 : 1, "D"),
                            (a = e.ctrlKey || e.metaKey),
                            e.originalEvent.altKey && t.datepicker._adjustDate(e.target, e.ctrlKey ? +t.datepicker._get(o, "stepBigMonths") : +t.datepicker._get(o, "stepMonths"), "M");
                        break;
                    case 40:
                        (e.ctrlKey || e.metaKey) && t.datepicker._adjustDate(e.target, 7, "D"), (a = e.ctrlKey || e.metaKey);
                        break;
                    default:
                        a = !1;
                }
            else 36 === e.keyCode && e.ctrlKey ? t.datepicker._showDatepicker(this) : (a = !1);
            a && (e.preventDefault(), e.stopPropagation());
        },
        _doKeyPress: function (e) {
            var i,
                s,
                n = t.datepicker._getInst(e.target);
            return t.datepicker._get(n, "constrainInput")
                ? ((i = t.datepicker._possibleChars(t.datepicker._get(n, "dateFormat"))), (s = String.fromCharCode(null == e.charCode ? e.keyCode : e.charCode)), e.ctrlKey || e.metaKey || " " > s || !i || i.indexOf(s) > -1)
                : void 0;
        },
        _doKeyUp: function (e) {
            var i,
                s = t.datepicker._getInst(e.target);
            if (s.input.val() !== s.lastVal)
                try {
                    (i = t.datepicker.parseDate(t.datepicker._get(s, "dateFormat"), s.input ? s.input.val() : null, t.datepicker._getFormatConfig(s))),
                        i && (t.datepicker._setDateFromField(s), t.datepicker._updateAlternate(s), t.datepicker._updateDatepicker(s));
                } catch (n) {}
            return !0;
        },
        _showDatepicker: function (e) {
            if (((e = e.target || e), "input" !== e.nodeName.toLowerCase() && (e = t("input", e.parentNode)[0]), !t.datepicker._isDisabledDatepicker(e) && t.datepicker._lastInput !== e)) {
                var s, n, o, r, h, l, c;
                (s = t.datepicker._getInst(e)),
                    t.datepicker._curInst && t.datepicker._curInst !== s && (t.datepicker._curInst.dpDiv.stop(!0, !0), s && t.datepicker._datepickerShowing && t.datepicker._hideDatepicker(t.datepicker._curInst.input[0])),
                    (n = t.datepicker._get(s, "beforeShow")),
                    (o = n ? n.apply(e, [e, s]) : {}),
                    o !== !1 &&
                        (a(s.settings, o),
                        (s.lastVal = null),
                        (t.datepicker._lastInput = e),
                        t.datepicker._setDateFromField(s),
                        t.datepicker._inDialog && (e.value = ""),
                        t.datepicker._pos || ((t.datepicker._pos = t.datepicker._findPos(e)), (t.datepicker._pos[1] += e.offsetHeight)),
                        (r = !1),
                        t(e)
                            .parents()
                            .each(function () {
                                return (r |= "fixed" === t(this).css("position")), !r;
                            }),
                        (h = { left: t.datepicker._pos[0], top: t.datepicker._pos[1] }),
                        (t.datepicker._pos = null),
                        s.dpDiv.empty(),
                        s.dpDiv.css({ position: "absolute", display: "block", top: "-1000px" }),
                        t.datepicker._updateDatepicker(s),
                        (h = t.datepicker._checkOffset(s, h, r)),
                        s.dpDiv.css({ position: t.datepicker._inDialog && t.blockUI ? "static" : r ? "fixed" : "absolute", display: "none", left: h.left + "px", top: h.top + "px" }),
                        s.inline ||
                            ((l = t.datepicker._get(s, "showAnim")),
                            (c = t.datepicker._get(s, "duration")),
                            s.dpDiv.css("z-index", i(t(e)) + 1),
                            (t.datepicker._datepickerShowing = !0),
                            t.effects && t.effects.effect[l] ? s.dpDiv.show(l, t.datepicker._get(s, "showOptions"), c) : s.dpDiv[l || "show"](l ? c : null),
                            t.datepicker._shouldFocusInput(s) && s.input.trigger("focus"),
                            (t.datepicker._curInst = s)));
            }
        },
        _updateDatepicker: function (e) {
            (this.maxRows = 4), (m = e), e.dpDiv.empty().append(this._generateHTML(e)), this._attachHandlers(e);
            var i,
                s = this._getNumberOfMonths(e),
                n = s[1],
                a = 17,
                r = e.dpDiv.find("." + this._dayOverClass + " a");
            r.length > 0 && o.apply(r.get(0)),
                e.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""),
                n > 1 && e.dpDiv.addClass("ui-datepicker-multi-" + n).css("width", a * n + "em"),
                e.dpDiv[(1 !== s[0] || 1 !== s[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"),
                e.dpDiv[(this._get(e, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"),
                e === t.datepicker._curInst && t.datepicker._datepickerShowing && t.datepicker._shouldFocusInput(e) && e.input.trigger("focus"),
                e.yearshtml &&
                    ((i = e.yearshtml),
                    setTimeout(function () {
                        i === e.yearshtml && e.yearshtml && e.dpDiv.find("select.ui-datepicker-year:first").replaceWith(e.yearshtml), (i = e.yearshtml = null);
                    }, 0));
        },
        _shouldFocusInput: function (t) {
            return t.input && t.input.is(":visible") && !t.input.is(":disabled") && !t.input.is(":focus");
        },
        _checkOffset: function (e, i, s) {
            var n = e.dpDiv.outerWidth(),
                o = e.dpDiv.outerHeight(),
                a = e.input ? e.input.outerWidth() : 0,
                r = e.input ? e.input.outerHeight() : 0,
                h = document.documentElement.clientWidth + (s ? 0 : t(document).scrollLeft()),
                l = document.documentElement.clientHeight + (s ? 0 : t(document).scrollTop());
            return (
                (i.left -= this._get(e, "isRTL") ? n - a : 0),
                (i.left -= s && i.left === e.input.offset().left ? t(document).scrollLeft() : 0),
                (i.top -= s && i.top === e.input.offset().top + r ? t(document).scrollTop() : 0),
                (i.left -= Math.min(i.left, i.left + n > h && h > n ? Math.abs(i.left + n - h) : 0)),
                (i.top -= Math.min(i.top, i.top + o > l && l > o ? Math.abs(o + r) : 0)),
                i
            );
        },
        _findPos: function (e) {
            for (var i, s = this._getInst(e), n = this._get(s, "isRTL"); e && ("hidden" === e.type || 1 !== e.nodeType || t.expr.filters.hidden(e)); ) e = e[n ? "previousSibling" : "nextSibling"];
            return (i = t(e).offset()), [i.left, i.top];
        },
        _hideDatepicker: function (e) {
            var i,
                s,
                n,
                o,
                a = this._curInst;
            !a ||
                (e && a !== t.data(e, "datepicker")) ||
                (this._datepickerShowing &&
                    ((i = this._get(a, "showAnim")),
                    (s = this._get(a, "duration")),
                    (n = function () {
                        t.datepicker._tidyDialog(a);
                    }),
                    t.effects && (t.effects.effect[i] || t.effects[i]) ? a.dpDiv.hide(i, t.datepicker._get(a, "showOptions"), s, n) : a.dpDiv["slideDown" === i ? "slideUp" : "fadeIn" === i ? "fadeOut" : "hide"](i ? s : null, n),
                    i || n(),
                    (this._datepickerShowing = !1),
                    (o = this._get(a, "onClose")),
                    o && o.apply(a.input ? a.input[0] : null, [a.input ? a.input.val() : "", a]),
                    (this._lastInput = null),
                    this._inDialog && (this._dialogInput.css({ position: "absolute", left: "0", top: "-100px" }), t.blockUI && (t.unblockUI(), t("body").append(this.dpDiv))),
                    (this._inDialog = !1)));
        },
        _tidyDialog: function (t) {
            t.dpDiv.removeClass(this._dialogClass).off(".ui-datepicker-calendar");
        },
        _checkExternalClick: function (e) {
            if (t.datepicker._curInst) {
                var i = t(e.target),
                    s = t.datepicker._getInst(i[0]);
                ((i[0].id !== t.datepicker._mainDivId &&
                    0 === i.parents("#" + t.datepicker._mainDivId).length &&
                    !i.hasClass(t.datepicker.markerClassName) &&
                    !i.closest("." + t.datepicker._triggerClass).length &&
                    t.datepicker._datepickerShowing &&
                    (!t.datepicker._inDialog || !t.blockUI)) ||
                    (i.hasClass(t.datepicker.markerClassName) && t.datepicker._curInst !== s)) &&
                    t.datepicker._hideDatepicker();
            }
        },
        _adjustDate: function (e, i, s) {
            var n = t(e),
                o = this._getInst(n[0]);
            this._isDisabledDatepicker(n[0]) || (this._adjustInstDate(o, i + ("M" === s ? this._get(o, "showCurrentAtPos") : 0), s), this._updateDatepicker(o));
        },
        _gotoToday: function (e) {
            var i,
                s = t(e),
                n = this._getInst(s[0]);
            this._get(n, "gotoCurrent") && n.currentDay
                ? ((n.selectedDay = n.currentDay), (n.drawMonth = n.selectedMonth = n.currentMonth), (n.drawYear = n.selectedYear = n.currentYear))
                : ((i = new Date()), (n.selectedDay = i.getDate()), (n.drawMonth = n.selectedMonth = i.getMonth()), (n.drawYear = n.selectedYear = i.getFullYear())),
                this._notifyChange(n),
                this._adjustDate(s);
        },
        _selectMonthYear: function (e, i, s) {
            var n = t(e),
                o = this._getInst(n[0]);
            (o["selected" + ("M" === s ? "Month" : "Year")] = o["draw" + ("M" === s ? "Month" : "Year")] = parseInt(i.options[i.selectedIndex].value, 10)), this._notifyChange(o), this._adjustDate(n);
        },
        _selectDay: function (e, i, s, n) {
            var o,
                a = t(e);
            t(n).hasClass(this._unselectableClass) ||
                this._isDisabledDatepicker(a[0]) ||
                ((o = this._getInst(a[0])),
                (o.selectedDay = o.currentDay = t("a", n).html()),
                (o.selectedMonth = o.currentMonth = i),
                (o.selectedYear = o.currentYear = s),
                this._selectDate(e, this._formatDate(o, o.currentDay, o.currentMonth, o.currentYear)));
        },
        _clearDate: function (e) {
            var i = t(e);
            this._selectDate(i, "");
        },
        _selectDate: function (e, i) {
            var s,
                n = t(e),
                o = this._getInst(n[0]);
            (i = null != i ? i : this._formatDate(o)),
                o.input && o.input.val(i),
                this._updateAlternate(o),
                (s = this._get(o, "onSelect")),
                s ? s.apply(o.input ? o.input[0] : null, [i, o]) : o.input && o.input.trigger("change"),
                o.inline ? this._updateDatepicker(o) : (this._hideDatepicker(), (this._lastInput = o.input[0]), "object" != typeof o.input[0] && o.input.trigger("focus"), (this._lastInput = null));
        },
        _updateAlternate: function (e) {
            var i,
                s,
                n,
                o = this._get(e, "altField");
            o && ((i = this._get(e, "altFormat") || this._get(e, "dateFormat")), (s = this._getDate(e)), (n = this.formatDate(i, s, this._getFormatConfig(e))), t(o).val(n));
        },
        noWeekends: function (t) {
            var e = t.getDay();
            return [e > 0 && 6 > e, ""];
        },
        iso8601Week: function (t) {
            var e,
                i = new Date(t.getTime());
            return i.setDate(i.getDate() + 4 - (i.getDay() || 7)), (e = i.getTime()), i.setMonth(0), i.setDate(1), Math.floor(Math.round((e - i) / 864e5) / 7) + 1;
        },
        parseDate: function (e, i, s) {
            if (null == e || null == i) throw "Invalid arguments";
            if (((i = "object" == typeof i ? i.toString() : i + ""), "" === i)) return null;
            var n,
                o,
                a,
                r,
                h = 0,
                l = (s ? s.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                c = "string" != typeof l ? l : (new Date().getFullYear() % 100) + parseInt(l, 10),
                u = (s ? s.dayNamesShort : null) || this._defaults.dayNamesShort,
                d = (s ? s.dayNames : null) || this._defaults.dayNames,
                p = (s ? s.monthNamesShort : null) || this._defaults.monthNamesShort,
                f = (s ? s.monthNames : null) || this._defaults.monthNames,
                g = -1,
                m = -1,
                _ = -1,
                v = -1,
                b = !1,
                y = function (t) {
                    var i = n + 1 < e.length && e.charAt(n + 1) === t;
                    return i && n++, i;
                },
                w = function (t) {
                    var e = y(t),
                        s = "@" === t ? 14 : "!" === t ? 20 : "y" === t && e ? 4 : "o" === t ? 3 : 2,
                        n = "y" === t ? s : 1,
                        o = new RegExp("^\\d{" + n + "," + s + "}"),
                        a = i.substring(h).match(o);
                    if (!a) throw "Missing number at position " + h;
                    return (h += a[0].length), parseInt(a[0], 10);
                },
                k = function (e, s, n) {
                    var o = -1,
                        a = t
                            .map(y(e) ? n : s, function (t, e) {
                                return [[e, t]];
                            })
                            .sort(function (t, e) {
                                return -(t[1].length - e[1].length);
                            });
                    if (
                        (t.each(a, function (t, e) {
                            var s = e[1];
                            return i.substr(h, s.length).toLowerCase() === s.toLowerCase() ? ((o = e[0]), (h += s.length), !1) : void 0;
                        }),
                        -1 !== o)
                    )
                        return o + 1;
                    throw "Unknown name at position " + h;
                },
                x = function () {
                    if (i.charAt(h) !== e.charAt(n)) throw "Unexpected literal at position " + h;
                    h++;
                };
            for (n = 0; n < e.length; n++)
                if (b) "'" !== e.charAt(n) || y("'") ? x() : (b = !1);
                else
                    switch (e.charAt(n)) {
                        case "d":
                            _ = w("d");
                            break;
                        case "D":
                            k("D", u, d);
                            break;
                        case "o":
                            v = w("o");
                            break;
                        case "m":
                            m = w("m");
                            break;
                        case "M":
                            m = k("M", p, f);
                            break;
                        case "y":
                            g = w("y");
                            break;
                        case "@":
                            (r = new Date(w("@"))), (g = r.getFullYear()), (m = r.getMonth() + 1), (_ = r.getDate());
                            break;
                        case "!":
                            (r = new Date((w("!") - this._ticksTo1970) / 1e4)), (g = r.getFullYear()), (m = r.getMonth() + 1), (_ = r.getDate());
                            break;
                        case "'":
                            y("'") ? x() : (b = !0);
                            break;
                        default:
                            x();
                    }
            if (h < i.length && ((a = i.substr(h)), !/^\s+/.test(a))) throw "Extra/unparsed characters found in date: " + a;
            if ((-1 === g ? (g = new Date().getFullYear()) : 100 > g && (g += new Date().getFullYear() - (new Date().getFullYear() % 100) + (c >= g ? 0 : -100)), v > -1))
                for (m = 1, _ = v; ; ) {
                    if (((o = this._getDaysInMonth(g, m - 1)), o >= _)) break;
                    m++, (_ -= o);
                }
            if (((r = this._daylightSavingAdjust(new Date(g, m - 1, _))), r.getFullYear() !== g || r.getMonth() + 1 !== m || r.getDate() !== _)) throw "Invalid date";
            return r;
        },
        ATOM: "yy-mm-dd",
        COOKIE: "D, dd M yy",
        ISO_8601: "yy-mm-dd",
        RFC_822: "D, d M y",
        RFC_850: "DD, dd-M-y",
        RFC_1036: "D, d M y",
        RFC_1123: "D, d M yy",
        RFC_2822: "D, d M yy",
        RSS: "D, d M y",
        TICKS: "!",
        TIMESTAMP: "@",
        W3C: "yy-mm-dd",
        _ticksTo1970: 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) * 60 * 60 * 1e7,
        formatDate: function (t, e, i) {
            if (!e) return "";
            var s,
                n = (i ? i.dayNamesShort : null) || this._defaults.dayNamesShort,
                o = (i ? i.dayNames : null) || this._defaults.dayNames,
                a = (i ? i.monthNamesShort : null) || this._defaults.monthNamesShort,
                r = (i ? i.monthNames : null) || this._defaults.monthNames,
                h = function (e) {
                    var i = s + 1 < t.length && t.charAt(s + 1) === e;
                    return i && s++, i;
                },
                l = function (t, e, i) {
                    var s = "" + e;
                    if (h(t)) for (; s.length < i; ) s = "0" + s;
                    return s;
                },
                c = function (t, e, i, s) {
                    return h(t) ? s[e] : i[e];
                },
                u = "",
                d = !1;
            if (e)
                for (s = 0; s < t.length; s++)
                    if (d) "'" !== t.charAt(s) || h("'") ? (u += t.charAt(s)) : (d = !1);
                    else
                        switch (t.charAt(s)) {
                            case "d":
                                u += l("d", e.getDate(), 2);
                                break;
                            case "D":
                                u += c("D", e.getDay(), n, o);
                                break;
                            case "o":
                                u += l("o", Math.round((new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime() - new Date(e.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                                break;
                            case "m":
                                u += l("m", e.getMonth() + 1, 2);
                                break;
                            case "M":
                                u += c("M", e.getMonth(), a, r);
                                break;
                            case "y":
                                u += h("y") ? e.getFullYear() : (e.getFullYear() % 100 < 10 ? "0" : "") + (e.getFullYear() % 100);
                                break;
                            case "@":
                                u += e.getTime();
                                break;
                            case "!":
                                u += 1e4 * e.getTime() + this._ticksTo1970;
                                break;
                            case "'":
                                h("'") ? (u += "'") : (d = !0);
                                break;
                            default:
                                u += t.charAt(s);
                        }
            return u;
        },
        _possibleChars: function (t) {
            var e,
                i = "",
                s = !1,
                n = function (i) {
                    var s = e + 1 < t.length && t.charAt(e + 1) === i;
                    return s && e++, s;
                };
            for (e = 0; e < t.length; e++)
                if (s) "'" !== t.charAt(e) || n("'") ? (i += t.charAt(e)) : (s = !1);
                else
                    switch (t.charAt(e)) {
                        case "d":
                        case "m":
                        case "y":
                        case "@":
                            i += "0123456789";
                            break;
                        case "D":
                        case "M":
                            return null;
                        case "'":
                            n("'") ? (i += "'") : (s = !0);
                            break;
                        default:
                            i += t.charAt(e);
                    }
            return i;
        },
        _get: function (t, e) {
            return void 0 !== t.settings[e] ? t.settings[e] : this._defaults[e];
        },
        _setDateFromField: function (t, e) {
            if (t.input.val() !== t.lastVal) {
                var i = this._get(t, "dateFormat"),
                    s = (t.lastVal = t.input ? t.input.val() : null),
                    n = this._getDefaultDate(t),
                    o = n,
                    a = this._getFormatConfig(t);
                try {
                    o = this.parseDate(i, s, a) || n;
                } catch (r) {
                    s = e ? "" : s;
                }
                (t.selectedDay = o.getDate()),
                    (t.drawMonth = t.selectedMonth = o.getMonth()),
                    (t.drawYear = t.selectedYear = o.getFullYear()),
                    (t.currentDay = s ? o.getDate() : 0),
                    (t.currentMonth = s ? o.getMonth() : 0),
                    (t.currentYear = s ? o.getFullYear() : 0),
                    this._adjustInstDate(t);
            }
        },
        _getDefaultDate: function (t) {
            return this._restrictMinMax(t, this._determineDate(t, this._get(t, "defaultDate"), new Date()));
        },
        _determineDate: function (e, i, s) {
            var n = function (t) {
                    var e = new Date();
                    return e.setDate(e.getDate() + t), e;
                },
                o = function (i) {
                    try {
                        return t.datepicker.parseDate(t.datepicker._get(e, "dateFormat"), i, t.datepicker._getFormatConfig(e));
                    } catch (s) {}
                    for (var n = (i.toLowerCase().match(/^c/) ? t.datepicker._getDate(e) : null) || new Date(), o = n.getFullYear(), a = n.getMonth(), r = n.getDate(), h = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, l = h.exec(i); l; ) {
                        switch (l[2] || "d") {
                            case "d":
                            case "D":
                                r += parseInt(l[1], 10);
                                break;
                            case "w":
                            case "W":
                                r += 7 * parseInt(l[1], 10);
                                break;
                            case "m":
                            case "M":
                                (a += parseInt(l[1], 10)), (r = Math.min(r, t.datepicker._getDaysInMonth(o, a)));
                                break;
                            case "y":
                            case "Y":
                                (o += parseInt(l[1], 10)), (r = Math.min(r, t.datepicker._getDaysInMonth(o, a)));
                        }
                        l = h.exec(i);
                    }
                    return new Date(o, a, r);
                },
                a = null == i || "" === i ? s : "string" == typeof i ? o(i) : "number" == typeof i ? (isNaN(i) ? s : n(i)) : new Date(i.getTime());
            return (a = a && "Invalid Date" === a.toString() ? s : a), a && (a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0)), this._daylightSavingAdjust(a);
        },
        _daylightSavingAdjust: function (t) {
            return t ? (t.setHours(t.getHours() > 12 ? t.getHours() + 2 : 0), t) : null;
        },
        _setDate: function (t, e, i) {
            var s = !e,
                n = t.selectedMonth,
                o = t.selectedYear,
                a = this._restrictMinMax(t, this._determineDate(t, e, new Date()));
            (t.selectedDay = t.currentDay = a.getDate()),
                (t.drawMonth = t.selectedMonth = t.currentMonth = a.getMonth()),
                (t.drawYear = t.selectedYear = t.currentYear = a.getFullYear()),
                (n === t.selectedMonth && o === t.selectedYear) || i || this._notifyChange(t),
                this._adjustInstDate(t),
                t.input && t.input.val(s ? "" : this._formatDate(t));
        },
        _getDate: function (t) {
            var e = !t.currentYear || (t.input && "" === t.input.val()) ? null : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay));
            return e;
        },
        _attachHandlers: function (e) {
            var i = this._get(e, "stepMonths"),
                s = "#" + e.id.replace(/\\\\/g, "\\");
            e.dpDiv.find("[data-handler]").map(function () {
                var e = {
                    prev: function () {
                        t.datepicker._adjustDate(s, -i, "M");
                    },
                    next: function () {
                        t.datepicker._adjustDate(s, +i, "M");
                    },
                    hide: function () {
                        t.datepicker._hideDatepicker();
                    },
                    today: function () {
                        t.datepicker._gotoToday(s);
                    },
                    selectDay: function () {
                        return t.datepicker._selectDay(s, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1;
                    },
                    selectMonth: function () {
                        return t.datepicker._selectMonthYear(s, this, "M"), !1;
                    },
                    selectYear: function () {
                        return t.datepicker._selectMonthYear(s, this, "Y"), !1;
                    },
                };
                t(this).on(this.getAttribute("data-event"), e[this.getAttribute("data-handler")]);
            });
        },
        _generateHTML: function (t) {
            var e,
                i,
                s,
                n,
                o,
                a,
                r,
                h,
                l,
                c,
                u,
                d,
                p,
                f,
                g,
                m,
                _,
                v,
                b,
                y,
                w,
                k,
                x,
                C,
                D,
                I,
                T,
                P,
                M,
                S,
                H,
                z,
                O,
                A,
                N,
                W,
                E,
                F,
                L,
                R = new Date(),
                B = this._daylightSavingAdjust(new Date(R.getFullYear(), R.getMonth(), R.getDate())),
                Y = this._get(t, "isRTL"),
                j = this._get(t, "showButtonPanel"),
                q = this._get(t, "hideIfNoPrevNext"),
                K = this._get(t, "navigationAsDateFormat"),
                U = this._getNumberOfMonths(t),
                V = this._get(t, "showCurrentAtPos"),
                $ = this._get(t, "stepMonths"),
                X = 1 !== U[0] || 1 !== U[1],
                G = this._daylightSavingAdjust(t.currentDay ? new Date(t.currentYear, t.currentMonth, t.currentDay) : new Date(9999, 9, 9)),
                Q = this._getMinMaxDate(t, "min"),
                J = this._getMinMaxDate(t, "max"),
                Z = t.drawMonth - V,
                tt = t.drawYear;
            if ((0 > Z && ((Z += 12), tt--), J))
                for (e = this._daylightSavingAdjust(new Date(J.getFullYear(), J.getMonth() - U[0] * U[1] + 1, J.getDate())), e = Q && Q > e ? Q : e; this._daylightSavingAdjust(new Date(tt, Z, 1)) > e; ) Z--, 0 > Z && ((Z = 11), tt--);
            for (
                t.drawMonth = Z,
                    t.drawYear = tt,
                    i = this._get(t, "prevText"),
                    i = K ? this.formatDate(i, this._daylightSavingAdjust(new Date(tt, Z - $, 1)), this._getFormatConfig(t)) : i,
                    s = this._canAdjustMonth(t, -1, tt, Z)
                        ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "e" : "w") + "'>" + i + "</span></a>"
                        : q
                        ? ""
                        : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "e" : "w") + "'>" + i + "</span></a>",
                    n = this._get(t, "nextText"),
                    n = K ? this.formatDate(n, this._daylightSavingAdjust(new Date(tt, Z + $, 1)), this._getFormatConfig(t)) : n,
                    o = this._canAdjustMonth(t, 1, tt, Z)
                        ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "w" : "e") + "'>" + n + "</span></a>"
                        : q
                        ? ""
                        : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "w" : "e") + "'>" + n + "</span></a>",
                    a = this._get(t, "currentText"),
                    r = this._get(t, "gotoCurrent") && t.currentDay ? G : B,
                    a = K ? this.formatDate(a, r, this._getFormatConfig(t)) : a,
                    h = t.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(t, "closeText") + "</button>",
                    l = j
                        ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" +
                          (Y ? h : "") +
                          (this._isInRange(t, r) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + a + "</button>" : "") +
                          (Y ? "" : h) +
                          "</div>"
                        : "",
                    c = parseInt(this._get(t, "firstDay"), 10),
                    c = isNaN(c) ? 0 : c,
                    u = this._get(t, "showWeek"),
                    d = this._get(t, "dayNames"),
                    p = this._get(t, "dayNamesMin"),
                    f = this._get(t, "monthNames"),
                    g = this._get(t, "monthNamesShort"),
                    m = this._get(t, "beforeShowDay"),
                    _ = this._get(t, "showOtherMonths"),
                    v = this._get(t, "selectOtherMonths"),
                    b = this._getDefaultDate(t),
                    y = "",
                    k = 0;
                k < U[0];
                k++
            ) {
                for (x = "", this.maxRows = 4, C = 0; C < U[1]; C++) {
                    if (((D = this._daylightSavingAdjust(new Date(tt, Z, t.selectedDay))), (I = " ui-corner-all"), (T = ""), X)) {
                        if (((T += "<div class='ui-datepicker-group"), U[1] > 1))
                            switch (C) {
                                case 0:
                                    (T += " ui-datepicker-group-first"), (I = " ui-corner-" + (Y ? "right" : "left"));
                                    break;
                                case U[1] - 1:
                                    (T += " ui-datepicker-group-last"), (I = " ui-corner-" + (Y ? "left" : "right"));
                                    break;
                                default:
                                    (T += " ui-datepicker-group-middle"), (I = "");
                            }
                        T += "'>";
                    }
                    for (
                        T +=
                            "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" +
                            I +
                            "'>" +
                            (/all|left/.test(I) && 0 === k ? (Y ? o : s) : "") +
                            (/all|right/.test(I) && 0 === k ? (Y ? s : o) : "") +
                            this._generateMonthYearHeader(t, Z, tt, Q, J, k > 0 || C > 0, f, g) +
                            "</div><table class='ui-datepicker-calendar'><thead><tr>",
                            P = u ? "<th class='ui-datepicker-week-col'>" + this._get(t, "weekHeader") + "</th>" : "",
                            w = 0;
                        7 > w;
                        w++
                    )
                        (M = (w + c) % 7), (P += "<th scope='col'" + ((w + c + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + d[M] + "'>" + p[M] + "</span></th>");
                    for (
                        T += P + "</tr></thead><tbody>",
                            S = this._getDaysInMonth(tt, Z),
                            tt === t.selectedYear && Z === t.selectedMonth && (t.selectedDay = Math.min(t.selectedDay, S)),
                            H = (this._getFirstDayOfMonth(tt, Z) - c + 7) % 7,
                            z = Math.ceil((H + S) / 7),
                            O = X && this.maxRows > z ? this.maxRows : z,
                            this.maxRows = O,
                            A = this._daylightSavingAdjust(new Date(tt, Z, 1 - H)),
                            N = 0;
                        O > N;
                        N++
                    ) {
                        for (T += "<tr>", W = u ? "<td class='ui-datepicker-week-col'>" + this._get(t, "calculateWeek")(A) + "</td>" : "", w = 0; 7 > w; w++)
                            (E = m ? m.apply(t.input ? t.input[0] : null, [A]) : [!0, ""]),
                                (F = A.getMonth() !== Z),
                                (L = (F && !v) || !E[0] || (Q && Q > A) || (J && A > J)),
                                (W +=
                                    "<td class='" +
                                    ((w + c + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") +
                                    (F ? " ui-datepicker-other-month" : "") +
                                    ((A.getTime() === D.getTime() && Z === t.selectedMonth && t._keyEvent) || (b.getTime() === A.getTime() && b.getTime() === D.getTime()) ? " " + this._dayOverClass : "") +
                                    (L ? " " + this._unselectableClass + " ui-state-disabled" : "") +
                                    (F && !_ ? "" : " " + E[1] + (A.getTime() === G.getTime() ? " " + this._currentClass : "") + (A.getTime() === B.getTime() ? " ui-datepicker-today" : "")) +
                                    "'" +
                                    ((F && !_) || !E[2] ? "" : " title='" + E[2].replace(/'/g, "&#39;") + "'") +
                                    (L ? "" : " data-handler='selectDay' data-event='click' data-month='" + A.getMonth() + "' data-year='" + A.getFullYear() + "'") +
                                    ">" +
                                    (F && !_
                                        ? "&#xa0;"
                                        : L
                                        ? "<span class='ui-state-default'>" + A.getDate() + "</span>"
                                        : "<a class='ui-state-default" +
                                          (A.getTime() === B.getTime() ? " ui-state-highlight" : "") +
                                          (A.getTime() === G.getTime() ? " ui-state-active" : "") +
                                          (F ? " ui-priority-secondary" : "") +
                                          "' href='#'>" +
                                          A.getDate() +
                                          "</a>") +
                                    "</td>"),
                                A.setDate(A.getDate() + 1),
                                (A = this._daylightSavingAdjust(A));
                        T += W + "</tr>";
                    }
                    Z++, Z > 11 && ((Z = 0), tt++), (T += "</tbody></table>" + (X ? "</div>" + (U[0] > 0 && C === U[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : "")), (x += T);
                }
                y += x;
            }
            return (y += l), (t._keyEvent = !1), y;
        },
        _generateMonthYearHeader: function (t, e, i, s, n, o, a, r) {
            var h,
                l,
                c,
                u,
                d,
                p,
                f,
                g,
                m = this._get(t, "changeMonth"),
                _ = this._get(t, "changeYear"),
                v = this._get(t, "showMonthAfterYear"),
                b = "<div class='ui-datepicker-title'>",
                y = "";
            if (o || !m) y += "<span class='ui-datepicker-month'>" + a[e] + "</span>";
            else {
                for (h = s && s.getFullYear() === i, l = n && n.getFullYear() === i, y += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", c = 0; 12 > c; c++)
                    (!h || c >= s.getMonth()) && (!l || c <= n.getMonth()) && (y += "<option value='" + c + "'" + (c === e ? " selected='selected'" : "") + ">" + r[c] + "</option>");
                y += "</select>";
            }
            if ((v || (b += y + (!o && m && _ ? "" : "&#xa0;")), !t.yearshtml))
                if (((t.yearshtml = ""), o || !_)) b += "<span class='ui-datepicker-year'>" + i + "</span>";
                else {
                    for (
                        u = this._get(t, "yearRange").split(":"),
                            d = new Date().getFullYear(),
                            p = function (t) {
                                var e = t.match(/c[+\-].*/) ? i + parseInt(t.substring(1), 10) : t.match(/[+\-].*/) ? d + parseInt(t, 10) : parseInt(t, 10);
                                return isNaN(e) ? d : e;
                            },
                            f = p(u[0]),
                            g = Math.max(f, p(u[1] || "")),
                            f = s ? Math.max(f, s.getFullYear()) : f,
                            g = n ? Math.min(g, n.getFullYear()) : g,
                            t.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>";
                        g >= f;
                        f++
                    )
                        t.yearshtml += "<option value='" + f + "'" + (f === i ? " selected='selected'" : "") + ">" + f + "</option>";
                    (t.yearshtml += "</select>"), (b += t.yearshtml), (t.yearshtml = null);
                }
            return (b += this._get(t, "yearSuffix")), v && (b += (!o && m && _ ? "" : "&#xa0;") + y), (b += "</div>");
        },
        _adjustInstDate: function (t, e, i) {
            var s = t.selectedYear + ("Y" === i ? e : 0),
                n = t.selectedMonth + ("M" === i ? e : 0),
                o = Math.min(t.selectedDay, this._getDaysInMonth(s, n)) + ("D" === i ? e : 0),
                a = this._restrictMinMax(t, this._daylightSavingAdjust(new Date(s, n, o)));
            (t.selectedDay = a.getDate()), (t.drawMonth = t.selectedMonth = a.getMonth()), (t.drawYear = t.selectedYear = a.getFullYear()), ("M" === i || "Y" === i) && this._notifyChange(t);
        },
        _restrictMinMax: function (t, e) {
            var i = this._getMinMaxDate(t, "min"),
                s = this._getMinMaxDate(t, "max"),
                n = i && i > e ? i : e;
            return s && n > s ? s : n;
        },
        _notifyChange: function (t) {
            var e = this._get(t, "onChangeMonthYear");
            e && e.apply(t.input ? t.input[0] : null, [t.selectedYear, t.selectedMonth + 1, t]);
        },
        _getNumberOfMonths: function (t) {
            var e = this._get(t, "numberOfMonths");
            return null == e ? [1, 1] : "number" == typeof e ? [1, e] : e;
        },
        _getMinMaxDate: function (t, e) {
            return this._determineDate(t, this._get(t, e + "Date"), null);
        },
        _getDaysInMonth: function (t, e) {
            return 32 - this._daylightSavingAdjust(new Date(t, e, 32)).getDate();
        },
        _getFirstDayOfMonth: function (t, e) {
            return new Date(t, e, 1).getDay();
        },
        _canAdjustMonth: function (t, e, i, s) {
            var n = this._getNumberOfMonths(t),
                o = this._daylightSavingAdjust(new Date(i, s + (0 > e ? e : n[0] * n[1]), 1));
            return 0 > e && o.setDate(this._getDaysInMonth(o.getFullYear(), o.getMonth())), this._isInRange(t, o);
        },
        _isInRange: function (t, e) {
            var i,
                s,
                n = this._getMinMaxDate(t, "min"),
                o = this._getMinMaxDate(t, "max"),
                a = null,
                r = null,
                h = this._get(t, "yearRange");
            return (
                h && ((i = h.split(":")), (s = new Date().getFullYear()), (a = parseInt(i[0], 10)), (r = parseInt(i[1], 10)), i[0].match(/[+\-].*/) && (a += s), i[1].match(/[+\-].*/) && (r += s)),
                (!n || e.getTime() >= n.getTime()) && (!o || e.getTime() <= o.getTime()) && (!a || e.getFullYear() >= a) && (!r || e.getFullYear() <= r)
            );
        },
        _getFormatConfig: function (t) {
            var e = this._get(t, "shortYearCutoff");
            return (
                (e = "string" != typeof e ? e : (new Date().getFullYear() % 100) + parseInt(e, 10)),
                { shortYearCutoff: e, dayNamesShort: this._get(t, "dayNamesShort"), dayNames: this._get(t, "dayNames"), monthNamesShort: this._get(t, "monthNamesShort"), monthNames: this._get(t, "monthNames") }
            );
        },
        _formatDate: function (t, e, i, s) {
            e || ((t.currentDay = t.selectedDay), (t.currentMonth = t.selectedMonth), (t.currentYear = t.selectedYear));
            var n = e ? ("object" == typeof e ? e : this._daylightSavingAdjust(new Date(s, i, e))) : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay));
            return this.formatDate(this._get(t, "dateFormat"), n, this._getFormatConfig(t));
        },
    }),
        (t.fn.datepicker = function (e) {
            if (!this.length) return this;
            t.datepicker.initialized || (t(document).on("mousedown", t.datepicker._checkExternalClick), (t.datepicker.initialized = !0)), 0 === t("#" + t.datepicker._mainDivId).length && t("body").append(t.datepicker.dpDiv);
            var i = Array.prototype.slice.call(arguments, 1);
            return "string" != typeof e || ("isDisabled" !== e && "getDate" !== e && "widget" !== e)
                ? "option" === e && 2 === arguments.length && "string" == typeof arguments[1]
                    ? t.datepicker["_" + e + "Datepicker"].apply(t.datepicker, [this[0]].concat(i))
                    : this.each(function () {
                          "string" == typeof e ? t.datepicker["_" + e + "Datepicker"].apply(t.datepicker, [this].concat(i)) : t.datepicker._attachDatepicker(this, e);
                      })
                : t.datepicker["_" + e + "Datepicker"].apply(t.datepicker, [this[0]].concat(i));
        }),
        (t.datepicker = new s()),
        (t.datepicker.initialized = !1),
        (t.datepicker.uuid = new Date().getTime()),
        (t.datepicker.version = "1.12.1");
    var _ = (t.datepicker, (t.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())), !1);
});
$(document).ready(function () {
    $(".autoplace").each(function () {
        var el = document.getElementById(this.id);
        new autoComplete({
            selector: el,
            minChars: 1,
            source: function (term, suggest) {
                term = term.toLowerCase();
                var choices = [
                    ["Destination", "iso", "Destination"],
                    ["Manali", "IN", "India"],
                    ["Shimla", "IN", "India"],
                    ["Kerala", "IN", "India"],
                    ["Goa", "IN", "India"],
                    ["Munnar", "IN", "India"],
                    ["Kufri", "IN", "India"],
                    ["Thekkady", "IN", "India"],
                    ["Darjeeling", "IN", "India"],
                    ["Ooty", "IN", "India"],
                    ["Cochin", "IN", "India"],
                    ["Alleppey", "IN", "India"],
                    ["Gangtok", "IN", "India"],
                    ["Kullu", "IN", "India"],
                    ["Delhi", "IN", "India"],
                    ["Chandigarh", "IN", "India"],
                    ["Port Blair", "IN", "India"],
                    ["Coonoor", "IN", "India"],
                    ["Nainital", "IN", "India"],
                    ["Mumbai", "IN", "India"],
                    ["Manikaran", "IN", "India"],
                    ["Coorg", "IN", "India"],
                    ["Srinagar", "IN", "India"],
                    ["Sikkim", "IN", "India"],
                    ["Haridwar", "IN", "India"],
                    ["Rishikesh", "IN", "India"],
                    ["Agra", "IN", "India"],
                    ["Jaipur", "IN", "India"],
                    ["Shillong", "IN", "India"],
                    ["Panchgani", "IN", "India"],
                    ["Mysore", "IN", "India"],
                    ["Mahabaleshwar", "IN", "India"],
                    ["Gulmarg", "IN", "India"],
                    ["Katra", "IN", "India"],
                    ["Bangalore", "IN", "India"],
                    ["Guwahati", "IN", "India"],
                    ["Jammu", "IN", "India"],
                    ["Dharamshala", "IN", "India"],
                    ["Kedarnath", "IN", "India"],
                    ["Kasol", "IN", "India"],
                    ["Lonavala", "IN", "India"],
                    ["Pahalgam", "IN", "India"],
                    ["Kolkata", "IN", "India"],
                    ["Dalhousie", "IN", "India"],
                    ["Himachal Pradesh", "IN", "India"],
                    ["Ranikhet", "IN", "India"],
                    ["Hyderabad", "IN", "India"],
                    ["Kodaikanal", "IN", "India"],
                    ["Badrinath", "IN", "India"],
                    ["Udaipur", "IN", "India"],
                    ["Chennai", "IN", "India"],
                    ["Uttarakhand", "IN", "India"],
                    ["Dehradun", "IN", "India"],
                    ["Shirdi", "IN", "India"],
                    ["Rajasthan", "IN", "India"],
                    ["Lansdowne", "IN", "India"],
                    ["Kanyakumari", "IN", "India"],
                    ["Pune", "IN", "India"],
                    ["Lakshadweep", "IN", "India"],
                    ["Amritsar", "IN", "India"],
                    ["Ahmedabad", "IN", "India"],
                    ["Tawang", "IN", "India"],
                    ["Kochi", "IN", "India"],
                    ["Kasauli", "IN", "India"],
                    ["Bengaluru", "IN", "India"],
                    ["Mount Abu", "IN", "India"],
                    ["Kalimpong", "IN", "India"],
                    ["Mcleodganj", "IN", "India"],
                    ["Lakshadweep Islands", "IN", "India"],
                    ["Pelling", "IN", "India"],
                    ["Tirupati", "IN", "India"],
                    ["Matheran", "IN", "India"],
                    ["Varanasi", "IN", "India"],
                    ["Auli", "IN", "India"],
                    ["Madurai", "IN", "India"],
                    ["Kausani", "IN", "India"],
                    ["Ajmer", "IN", "India"],
                    ["Wayanad", "IN", "India"],
                    ["Kaziranga", "IN", "India"],
                    ["Coimbatore", "IN", "India"],
                    ["Pondicherry", "IN", "India"],
                    ["Madikeri", "IN", "India"],
                    ["Visakhapatnam", "IN", "India"],
                    ["Gangotri", "IN", "India"],
                    ["Puri", "IN", "India"],
                    ["Jodhpur", "IN", "India"],
                    ["Puducherry", "IN", "India"],
                    ["Somnath", "IN", "India"],
                    ["Trivandrum", "IN", "India"],
                    ["Lachung", "IN", "India"],
                    ["Khajjiar", "IN", "India"],
                    ["Dwarka", "IN", "India"],
                    ["Aurangabad", "IN", "India"],
                    ["Mathura", "IN", "India"],
                    ["Zuluk", "IN", "India"],
                    ["Nashik", "IN", "India"],
                    ["Kumarakom", "IN", "India"],
                    ["Saputara", "IN", "India"],
                    ["Rameshwaram", "IN", "India"],
                    ["Patnitop", "IN", "India"],
                    ["Gujarat", "IN", "India"],
                    ["Vrindavan", "IN", "India"],
                    ["Srisailam", "IN", "India"],
                    ["Jaisalmer", "IN", "India"],
                    ["Meghalaya", "IN", "India"],
                    ["Yercaud", "IN", "India"],
                    ["Lachen", "IN", "India"],
                    ["Solang Valley", "IN", "India"],
                    ["Bhubaneswar", "IN", "India"],
                    ["Ujjain", "IN", "India"],
                    ["Sangla", "IN", "India"],
                    ["Rameswaram", "IN", "India"],
                    ["Namchi", "IN", "India"],
                    ["Almora", "IN", "India"],
                    ["Nagpur", "IN", "India"],
                    ["Mahabalipuram", "IN", "India"],
                    ["Ratnagiri", "IN", "India"],
                    ["Pushkar", "IN", "India"],
                    ["Nandi Hills", "IN", "India"],
                    ["Shiv Khori", "IN", "India"],
                    ["Assam", "IN", "India"],
                    ["Chopta", "IN", "India"],
                    ["Hampi", "IN", "India"],
                    ["Lavasa", "IN", "India"],
                    ["Gokarna", "IN", "India"],
                    ["Alappuzha", "IN", "India"],
                    ["Arunachal Pradesh", "IN", "India"],
                    ["Dhanaulti", "IN", "India"],
                    ["Bikaner", "IN", "India"],
                    ["Kovalam", "IN", "India"],
                    ["Leh", "IN", "India"],
                    ["Bagdogra", "IN", "India"],
                    ["Ladakh", "IN", "India"],
                    ["Havelock Island", "IN", "India"],
                    ["Corbett", "IN", "India"],
                    ["Andaman And Nicobar Islands", "IN", "India"],
                    ["Kathgodam", "IN", "India"],
                    ["Sonmarg", "IN", "India"],
                    ["Bomdila", "IN", "India"],
                    ["Cherrapunjee", "IN", "India"],
                    ["Cherrapunji", "IN", "India"],
                    ["Rohtang", "IN", "India"],
                    ["Bhalukpong", "IN", "India"],
                    ["Karnataka", "IN", "India"],
                    ["Jammu And Kashmir", "IN", "India"],
                    ["Pachmarhi", "IN", "India"],
                    ["Agatti Island", "IN", "India"],
                    ["Dirang", "IN", "India"],
                    ["Triund", "IN", "India"],
                    ["Lucknow", "IN", "India"],
                    ["Baratang", "IN", "India"],
                    ["Panjim", "IN", "India"],
                    ["Palampur", "IN", "India"],
                    ["Chail", "IN", "India"],
                    ["Yamunotri", "IN", "India"],
                    ["Sillery Gaon", "IN", "India"],
                    ["Naggar", "IN", "India"],
                    ["Tosh", "IN", "India"],
                    ["Maharashtra", "IN", "India"],
                    ["Tamil Nadu", "IN", "India"],
                    ["Aritar", "IN", "India"],
                    ["Reshikhola", "IN", "India"],
                    ["Kalpa", "IN", "India"],
                    ["Dawki", "IN", "India"],
                    ["Sarahan", "IN", "India"],
                    ["Nathang Valley", "IN", "India"],
                    ["Rudraprayag", "IN", "India"],
                    ["Rajkot", "IN", "India"],
                    ["Bhagsunag", "IN", "India"],
                    ["Mawlynnong", "IN", "India"],
                    ["Diu", "IN", "India"],
                    ["Kheerganga", "IN", "India"],
                    ["Rampur", "IN", "India"],
                    ["Kalpeni Island", "IN", "India"],
                    ["Goa Velha", "IN", "India"],
                    ["Patna", "IN", "India"],
                    ["Indore", "IN", "India"],
                    ["Mashobra", "IN", "India"],
                    ["Kavarathi", "IN", "India"],
                    ["Chikmagalur", "IN", "India"],
                    ["North Bay Island", "IN", "India"],
                    ["Joshimath", "IN", "India"],
                    ["Nasik", "IN", "India"],
                    ["Taacharu", "IN", "India"],
                    ["West Bengal", "IN", "India"],
                    ["Vizag", "IN", "India"],
                    ["Varca", "IN", "India"],
                    ["Chamba", "IN", "India"],
                    ["Malvan", "IN", "India"],
                    ["Ramnagar", "IN", "India"],
                    ["Gopalpur", "IN", "India"],
                    ["Binsar", "IN", "India"],
                    ["Sarchu", "IN", "India"],
                    ["Bhopal", "IN", "India"],
                    ["Barkot", "IN", "India"],
                    ["Malana", "IN", "India"],
                    ["Bangaram Island", "IN", "India"],
                    ["Gurgaon", "IN", "India"],
                    ["Bhavnagar", "IN", "India"],
                    ["Mirik", "IN", "India"],
                    ["Calangute", "IN", "India"],
                    ["North Goa", "IN", "India"],
                    ["Brahampur", "IN", "India"],
                    ["Daringbadi", "IN", "India"],
                    ["Jamnagar", "IN", "India"],
                    ["Kangra Valley", "IN", "India"],
                    ["Mysuru", "IN", "India"],
                    ["Kaza", "IN", "India"],
                    ["Udupi", "IN", "India"],
                    ["Siliguri", "IN", "India"],
                    ["Tamabil", "IN", "India"],
                    ["Sandakphu", "IN", "India"],
                    ["Surat", "IN", "India"],
                    ["South Goa", "IN", "India"],
                    ["Devprayag", "IN", "India"],
                    ["Neil Island", "IN", "India"],
                    ["Thane", "IN", "India"],
                    ["Pratapgarh", "IN", "India"],
                    ["Keylong", "IN", "India"],
                    ["Trichy", "IN", "India"],
                    ["Allahabad", "IN", "India"],
                    ["Vadodara", "IN", "India"],
                    ["Nicobar", "IN", "India"],
                    ["Rajgir", "IN", "India"],
                    ["Anjuna", "IN", "India"],
                    ["Baga", "IN", "India"],
                    ["Jabalpur", "IN", "India"],
                    ["Khandala", "IN", "India"],
                    ["Nako", "IN", "India"],
                    ["Phalut", "IN", "India"],
                    ["Uttarkashi", "IN", "India"],
                    ["Amarnath", "IN", "India"],
                    ["Araku Valley", "IN", "India"],
                    ["Alibag", "IN", "India"],
                    ["Noida", "IN", "India"],
                    ["Mangalore", "IN", "India"],
                    ["Bangkok", "TH", "Thailand"],
                    ["Koh Samui", "TH", "Thailand"],
                    ["Thiruvananthapuram", "IN", "India"],
                    ["Imphal", "IN", "India"],
                    ["Dapoli", "IN", "India"],
                    ["Kibber", "IN", "India"],
                    ["Ganpatipule", "IN", "India"],
                    ["Pratapgad", "IN", "India"],
                    ["Pathankot", "IN", "India"],
                    ["Tuljapur", "IN", "India"],
                    ["Konark", "IN", "India"],
                    ["Tehri", "IN", "India"],
                    ["Akkalkot", "IN", "India"],
                    ["Rackcham", "IN", "India"],
                    ["Daman", "IN", "India"],
                    ["Pandharpur", "IN", "India"],
                    ["Chamoli", "IN", "India"],
                    ["Ranakpur", "IN", "India"],
                    ["Nubra", "IN", "India"],
                    ["Yumthang", "IN", "India"],
                    ["Digha", "IN", "India"],
                    ["Bhimtal", "IN", "India"],
                    ["Munsiyari", "IN", "India"],
                    ["Chittorgarh", "IN", "India"],
                    ["Yelagiri", "IN", "India"],
                    ["Karjat", "IN", "India"],
                    ["Khajuraho", "IN", "India"],
                    ["Nahan", "IN", "India"],
                    ["Pipariya", "IN", "India"],
                    ["Mangaluru", "IN", "India"],
                    ["Ghaziabad", "IN", "India"],
                    ["Naldehra", "IN", "India"],
                    ["Vengurla", "IN", "India"],
                    ["Kanchipuram", "IN", "India"],
                    ["Santhanpara", "IN", "India"],
                    ["Andhra Pradesh", "IN", "India"],
                    ["Kanpur", "IN", "India"],
                    ["Bharatpur", "IN", "India"],
                    ["Dharmasthala", "IN", "India"],
                    ["Ravangla", "IN", "India"],
                    ["Kumbhalgarh", "IN", "India"],
                    ["Trimbakeshwar", "IN", "India"],
                    ["Kotdwara", "IN", "India"],
                    ["Badami", "IN", "India"],
                    ["Kollur", "IN", "India"],
                    ["Gurugram", "IN", "India"],
                    ["Guptkashi", "IN", "India"],
                    ["Kargil", "IN", "India"],
                    ["Kumbakonam", "IN", "India"],
                    ["Raipur", "IN", "India"],
                    ["Bir", "IN", "India"],
                    ["Pedong", "IN", "India"],
                    ["Jhansi", "IN", "India"],
                    ["Bodhgaya", "IN", "India"],
                    ["Omkareshwar", "IN", "India"],
                    ["Ranthambore", "IN", "India"],
                    ["Bandipur", "IN", "India"],
                    ["Kohima", "IN", "India"],
                    ["Ludhiana", "IN", "India"],
                    ["Nalanda", "IN", "India"],
                    ["Island", "IN", "India"],
                    ["Lataguri", "IN", "India"],
                    ["Mussoorie", "IN", "India"],
                    ["Dabolim", "IN", "India"],
                    ["Barsaini", "IN", "India"],
                    ["Fatehpur Sikri", "IN", "India"],
                    ["Kanatal", "IN", "India"],
                    ["Ranchi", "IN", "India"],
                    ["Sundarban", "IN", "India"],
                    ["Kanha National Park", "IN", "India"],
                    ["Mandarmani", "IN", "India"],
                    ["Faridabad", "IN", "India"],
                    ["Poovar", "IN", "India"],
                    ["Kundalpur", "IN", "India"],
                    ["Gunawaji", "IN", "India"],
                    ["Pawapuri", "IN", "India"],
                    ["Parasnath", "IN", "India"],
                    ["Madhya Pradesh", "IN", "India"],
                    ["Navi Mumbai", "IN", "India"],
                    ["Kabini", "IN", "India"],
                    ["Gwalior", "IN", "India"],
                    ["Aamby Valley", "IN", "India"],
                    ["Mandi", "IN", "India"],
                    ["Calicut", "IN", "India"],
                    ["Rishikhola", "IN", "India"],
                    ["Rishop", "IN", "India"],
                    ["Khardungla", "IN", "India"],
                    ["Junagadh", "IN", "India"],
                    ["Mauritius", "IN", "India"],
                    ["Gaya", "IN", "India"],
                    ["Dharamkot", "IN", "India"],
                    ["Horanadu", "IN", "India"],
                    ["Moreh", "IN", "India"],
                    ["Dimapur", "IN", "India"],
                    ["Loktak", "IN", "India"],
                    ["Secunderabad", "IN", "India"],
                    ["Igatpuri", "IN", "India"],
                    ["Lepchajagat Village", "IN", "India"],
                    ["Bangaram", "IN", "India"],
                    ["Odisha", "IN", "India"],
                    ["Palani", "IN", "India"],
                    ["Sar Pass", "IN", "India"],
                    ["Kota", "IN", "India"],
                    ["Mukteshwar", "IN", "India"],
                    ["Kangra", "IN", "India"],
                    ["Periyar", "IN", "India"],
                    ["Howrah", "IN", "India"],
                    ["Tanjore", "IN", "India"],
                    ["Anegundi", "IN", "India"],
                    ["Kolhapur", "IN", "India"],
                    ["Hansi", "IN", "India"],
                    ["Guruvayoor", "IN", "India"],
                    ["Ambaji", "IN", "India"],
                    ["Palakkad", "IN", "India"],
                    ["Sringeri", "IN", "India"],
                    ["Srirangam", "IN", "India"],
                    ["Horsley Hills", "IN", "India"],
                    ["Rohtak", "IN", "India"],
                    ["Tezpur", "IN", "India"],
                    ["Gadiara", "IN", "India"],
                    ["Anjarle", "IN", "India"],
                    ["Chalal", "IN", "India"],
                    ["Bhuj", "IN", "India"],
                    ["Vijayawada", "IN", "India"],
                    ["Rasol", "IN", "India"],
                    ["Manirarn", "IN", "India"],
                    ["Fagu", "IN", "India"],
                    ["Thanjavur", "IN", "India"],
                    ["Bodh Gaya", "IN", "India"],
                    ["Punjab", "IN", "India"],
                    ["Kushalnagar", "IN", "India"],
                    ["Chopta Valley", "IN", "India"],
                    ["Gurudongmar", "IN", "India"],
                    ["Tumling", "IN", "India"],
                    ["Andaman And Nicobar", "IN", "India"],
                    ["Gandhinagar", "IN", "India"],
                    ["Paro", "BT", "Bhutan"],
                    ["Genting Highlands", "MY", "Malaysia"],
                    ["Male", "MV", "Maldives"],
                    ["Joshinath", "IN", "India"],
                    ["Gir", "IN", "India"],
                    ["Kushinagar", "IN", "India"],
                    ["Raichur", "IN", "India"],
                    ["Gangasagar", "IN", "India"],
                    ["Ramanagaram", "IN", "India"],
                    ["Gorakhpur", "IN", "India"],
                    ["Ayodhya", "IN", "India"],
                    ["Lumbini", "IN", "India"],
                    ["Agartala", "IN", "India"],
                    ["Uttar Pradesh", "IN", "India"],
                    ["Kelshi", "IN", "India"],
                    ["Jamshedpur", "IN", "India"],
                    ["Panvel", "IN", "India"],
                    ["Pithapuram", "IN", "India"],
                    ["Samalkot", "IN", "India"],
                    ["Karwar", "IN", "India"],
                    ["Vellore", "IN", "India"],
                    ["Chitrakoot", "IN", "India"],
                    ["Raichak", "IN", "India"],
                    ["Jalandhar", "IN", "India"],
                    ["Dibrugarh", "IN", "India"],
                    ["Shivpuri", "IN", "India"],
                    ["Orchha", "IN", "India"],
                    ["Chittoor", "IN", "India"],
                    ["Warangal", "IN", "India"],
                    ["Chakrata", "IN", "India"],
                    ["Bijapur", "IN", "India"],
                    ["Chikkamagaluru", "IN", "India"],
                    ["Delwara", "IN", "India"],
                    ["Porbandar", "IN", "India"],
                    ["Dervan", "IN", "India"],
                    ["Shivamogga", "IN", "India"],
                    ["Tarakeswar", "IN", "India"],
                    ["Silvassa", "IN", "India"],
                    ["Vaishali", "IN", "India"],
                    ["Hadimba", "IN", "India"],
                    ["Sadhupul", "IN", "India"],
                    ["Shrivardhan", "IN", "India"],
                    ["Durshet", "IN", "India"],
                    ["Lolegaon", "IN", "India"],
                    ["Solan", "IN", "India"],
                    ["Nameri", "IN", "India"],
                    ["Orissa", "IN", "India"],
                    ["Kozhikode", "IN", "India"],
                    ["Neemrana", "IN", "India"],
                    ["Sabarimala", "IN", "India"],
                    ["Himalayas", "IN", "India"],
                    ["Haryana", "IN", "India"],
                    ["Nanded", "IN", "India"],
                    ["Sasan", "IN", "India"],
                    ["Courtallam", "IN", "India"],
                    ["Ernakulam", "IN", "India"],
                    ["Amboli", "IN", "India"],
                    ["Jispa", "IN", "India"],
                    ["Yumthang Valley", "IN", "India"],
                    ["Hemalkasa", "IN", "India"],
                    ["Bareilly", "IN", "India"],
                    ["New Jalpaiguri", "IN", "India"],
                    ["Maheshwar", "IN", "India"],
                    ["Bhangarh", "IN", "India"],
                    ["Tarkarli", "IN", "India"],
                    ["Tabo", "IN", "India"],
                    ["Roychak", "IN", "India"],
                    ["Velankanni", "IN", "India"],
                    ["Santiniketan", "IN", "India"],
                    ["Kinnaur", "IN", "India"],
                    ["Varkala", "IN", "India"],
                    ["Chilka", "IN", "India"],
                    ["Harihareshwar", "IN", "India"],
                    ["Ramoji", "IN", "India"],
                    ["Parambikulam", "IN", "India"],
                    ["Thirunallur", "IN", "India"],
                    ["Kanchanoor", "IN", "India"],
                    ["Keezhperumpallam", "IN", "India"],
                    ["Nathula", "IN", "India"],
                    ["Chungthang", "IN", "India"],
                    ["Bheemeshwari", "IN", "India"],
                    ["Tiruvannamalai", "IN", "India"],
                    ["Mangan", "IN", "India"],
                    ["Thimphu", "BT", "Bhutan"],
                    ["Wayyand", "IN", "India"],
                    ["Andro", "IN", "India"],
                    ["Panaji", "IN", "India"],
                    ["Murdeshwar", "IN", "India"],
                    ["Nagarhole", "IN", "India"],
                    ["Dooars", "IN", "India"],
                    ["Chidambaram", "IN", "India"],
                    ["Jagdalpur", "IN", "India"],
                    ["Bilaspur", "IN", "India"],
                    ["Sawai Madhopur", "IN", "India"],
                    ["Gondal", "IN", "India"],
                    ["Meerut", "IN", "India"],
                    ["Giridih", "IN", "India"],
                    ["Dandeli", "IN", "India"],
                    ["Mandu", "IN", "India"],
                    ["Minicoy Island", "IN", "India"],
                    ["Anandvan", "IN", "India"],
                    ["Hassan", "IN", "India"],
                    ["Manebhanjyang", "IN", "India"],
                    ["Kalapokhri", "IN", "India"],
                    ["Sasan Gir", "IN", "India"],
                    ["Sillerygaon", "IN", "India"],
                    ["Alwar", "IN", "India"],
                    ["Kavaratti Island", "IN", "India"],
                    ["Loleygaon", "IN", "India"],
                    ["Murudeshwar", "IN", "India"],
                    ["Kamshet", "IN", "India"],
                    ["Deoghar", "IN", "India"],
                    ["Bihar", "IN", "India"],
                    ["Silerygaon", "IN", "India"],
                    ["Govindghat", "IN", "India"],
                    ["Ganeshgudi", "IN", "India"],
                    ["Bhandardara", "IN", "India"],
                    ["Sham Valley", "IN", "India"],
                    ["Jaldapara", "IN", "India"],
                    ["Patiala", "IN", "India"],
                    ["Subramanya", "IN", "India"],
                    ["Kalyan", "IN", "India"],
                    ["Murud Harnai", "IN", "India"],
                    ["Solangnala", "IN", "India"],
                    ["Sawantvadi", "IN", "India"],
                    ["Tiruchendur", "IN", "India"],
                    ["Virpur", "IN", "India"],
                    ["Langkawi", "IN", "India"],
                    ["Phuentsholing", "IN", "India"],
                    ["Baltal", "IN", "India"],
                    ["Moradabad", "IN", "India"],
                    ["Hazur Sahib", "IN", "India"],
                    ["Sasangir", "IN", "India"],
                    ["Sagar", "IN", "India"],
                    ["Nainadevi", "IN", "India"],
                    ["Barsheni", "IN", "India"],
                    ["Patliputra", "IN", "India"],
                    ["Thrissur", "IN", "India"],
                    ["Haldwani", "IN", "India"],
                    ["Jhandi", "IN", "India"],
                    ["Pasighat", "IN", "India"],
                    ["Ziro", "IN", "India"],
                    ["Chhindwara", "IN", "India"],
                    ["Pangot", "IN", "India"],
                    ["Tirunelveli", "IN", "India"],
                    ["Ajanta", "IN", "India"],
                    ["Chintpurni", "IN", "India"],
                    ["Tsomgolake", "IN", "India"],
                    ["Murshidabad", "IN", "India"],
                    ["Mayapur", "IN", "India"],
                    ["Kutch", "IN", "India"],
                    ["Neelkanth", "IN", "India"],
                    ["Ghangaria", "IN", "India"],
                    ["Hisar", "IN", "India"],
                    ["Tiruttani", "IN", "India"],
                    ["Dabhol Bandar", "IN", "India"],
                    ["Chiplun", "IN", "India"],
                    ["Tirupathi", "IN", "India"],
                    ["Ambala", "IN", "India"],
                    ["Mandvi", "IN", "India"],
                    ["Rajahmundry", "IN", "India"],
                    ["Cuttack", "IN", "India"],
                    ["Amravati", "IN", "India"],
                    ["Changu", "IN", "India"],
                    ["Dhanolti", "IN", "India"],
                    ["Shivthar Ghal", "IN", "India"],
                    ["Narkanda", "IN", "India"],
                    ["Belgaum", "IN", "India"],
                    ["Daporijo", "IN", "India"],
                    ["Mlenyadri", "IN", "India"],
                    ["Tadoba", "IN", "India"],
                    ["Mandawa", "IN", "India"],
                    ["Parwanoo", "IN", "India"],
                    ["Vagamon", "IN", "India"],
                    ["Kottayam", "IN", "India"],
                    ["Palitana", "IN", "India"],
                    ["Dantewada", "IN", "India"],
                    ["Viper Island", "IN", "India"],
                    ["Kadmat", "IN", "India"],
                    ["Roorkee", "IN", "India"],
                    ["Pokhara", "IN", "India"],
                    ["Bhubaneshwar", "IN", "India"],
                    ["Rameshewaram", "IN", "India"],
                    ["Jharkhand", "IN", "India"],
                    ["Nathang", "IN", "India"],
                    ["Manipal", "IN", "India"],
                    ["Kalpetta", "IN", "India"],
                    ["Salem", "IN", "India"],
                    ["Jayanti", "IN", "India"],
                    ["Mawsynram", "IN", "India"],
                    ["Guntur", "IN", "India"],
                    ["Bhaderwah", "IN", "India"],
                    ["Gulbarga", "IN", "India"],
                    ["Silchar", "IN", "India"],
                    ["Nagaland", "IN", "India"],
                    ["Kannur", "IN", "India"],
                    ["Agumbe", "IN", "India"],
                    ["Konkan", "IN", "India"],
                    ["Solapur", "IN", "India"],
                    ["Lepchajagat", "IN", "India"],
                    ["Karnal", "IN", "India"],
                    ["Baratang Island", "IN", "India"],
                    ["Timber Trail", "IN", "India"],
                    ["Tsomgo", "IN", "India"],
                    ["Nagar", "IN", "India"],
                    ["Bhuntar", "IN", "India"],
                    ["Nanpara", "IN", "India"],
                    ["Bhilwara", "IN", "India"],
                    ["Aligarh", "IN", "India"],
                    ["Harsil", "IN", "India"],
                    ["Srikhola", "IN", "India"],
                    ["Tonglu", "IN", "India"],
                    ["Nathdwara", "IN", "India"],
                    ["Asansol", "IN", "India"],
                    ["Manipur", "IN", "India"],
                    ["Sanchi", "IN", "India"],
                    ["Manebhanjan", "IN", "India"],
                    ["Bandhavgarh", "IN", "India"],
                    ["Tirathgarh", "IN", "India"],
                    ["Tsomoriri", "IN", "India"],
                    ["Bhedaghat", "IN", "India"],
                    ["Pithoragarh", "IN", "India"],
                    ["Kurukshetra", "IN", "India"],
                    ["Bhitarkanika", "IN", "India"],
                    ["Hubli", "IN", "India"],
                    ["Abbey Falls", "IN", "India"],
                    ["Chitwan", "IN", "India"],
                    ["Suryanelli", "IN", "India"],
                    ["Hospet", "IN", "India"],
                    ["Vapi", "IN", "India"],
                    ["Banaras", "IN", "India"],
                    ["Khopoli", "IN", "India"],
                    ["Biling", "IN", "India"],
                    ["Sonprayag", "IN", "India"],
                    ["Kalka", "IN", "India"],
                    ["Kollam", "IN", "India"],
                    ["Chandrapur", "IN", "India"],
                    ["Athirapally", "IN", "India"],
                    ["Bhojbasa", "IN", "India"],
                    ["Mohali", "IN", "India"],
                    ["Ankola", "IN", "India"],
                    ["Parvati", "IN", "India"],
                    ["Dhanbad", "IN", "India"],
                    ["Govind Ghat", "IN", "India"],
                    ["Thinnakara", "IN", "India"],
                    ["Muzaffarnagar", "IN", "India"],
                    ["Bhadrachalam", "IN", "India"],
                    ["Udipi", "IN", "India"],
                    ["Spiti Valley", "IN", "India"],
                    ["Shimoga", "IN", "India"],
                    ["Jalpaiguri", "IN", "India"],
                    ["Rudrapur", "IN", "India"],
                    ["Bhowali", "IN", "India"],
                    ["Diveagar", "IN", "India"],
                    ["Hogenakkal", "IN", "India"],
                    ["Pattadakal", "IN", "India"],
                    ["Bidar", "IN", "India"],
                    ["Chikhaldara", "IN", "India"],
                    ["Akshardham", "IN", "India"],
                    ["Durg", "IN", "India"],
                    ["Bhilai", "IN", "India"],
                    ["Guruvayur", "IN", "India"],
                    ["Aihole", "IN", "India"],
                    ["Tiruchirappalli", "IN", "India"],
                    ["Yusmarg", "IN", "India"],
                    ["Jorhat", "IN", "India"],
                    ["Unakoti", "IN", "India"],
                    ["Rourkela", "IN", "India"],
                    ["Rishyap", "IN", "India"],
                    ["Ramgarh", "IN", "India"],
                    ["Punakha", "IN", "India"],
                    ["Tripura", "IN", "India"],
                    ["Greater Noida", "IN", "India"],
                    ["Skandagiri Hills", "IN", "India"],
                    ["Kailash Mansarovar", "IN", "India"],
                    ["Kukke Subramanya", "IN", "India"],
                    ["Kolad", "IN", "India"],
                    ["Raigad", "IN", "India"],
                    ["Radhanagar", "IN", "India"],
                    ["North Bay", "IN", "India"],
                    ["Margao", "IN", "India"],
                    ["Gomukh", "IN", "India"],
                    ["Madras", "IN", "India"],
                    ["Nilambur", "IN", "India"],
                    ["Padong", "IN", "India"],
                    ["Satara", "IN", "India"],
                    ["Itanagar", "IN", "India"],
                    ["Indrahar Pass", "IN", "India"],
                    ["Chilika", "IN", "India"],
                    ["Gokul", "IN", "India"],
                    ["Deoria Tal", "IN", "India"],
                    ["Kodungallur", "IN", "India"],
                    ["Pahal", "IN", "India"],
                    ["Khonoma", "IN", "India"],
                    ["Muzaffarpur", "IN", "India"],
                    ["Patan", "IN", "India"],
                    ["Alipura", "IN", "India"],
                    ["Muthathi", "IN", "India"],
                    ["Wagha Border", "IN", "India"],
                    ["Chandannagar", "IN", "India"],
                    ["Gaurikund", "IN", "India"],
                    ["Munsyari", "IN", "India"],
                    ["Sattal", "IN", "India"],
                    ["Alchi", "IN", "India"],
                    ["Karla", "IN", "India"],
                    ["Jalgaon", "IN", "India"],
                    ["Chitkul", "IN", "India"],
                    ["Vasundhara", "IN", "India"],
                    ["Shivkhori", "IN", "India"],
                    ["Balasore", "IN", "India"],
                    ["Faizabad", "IN", "India"],
                    ["Govardhan", "IN", "India"],
                    ["Gao", "IN", "India"],
                    ["Kodagu", "IN", "India"],
                    ["Rose Island", "IN", "India"],
                    ["Nellore", "IN", "India"],
                    ["Thenmala", "IN", "India"],
                    ["Ankleshwar", "IN", "India"],
                    ["Jhalong", "IN", "India"],
                    ["Diskit", "IN", "India"],
                    ["Abu Road", "IN", "India"],
                    ["Spitalyi", "IN", "India"],
                    ["Kazerbaijana", "IN", "India"],
                    ["Mawphu", "IN", "India"],
                    ["Guptakashi", "IN", "India"],
                    ["Valsad", "IN", "India"],
                    ["Sirsi", "IN", "India"],
                    ["Bhimashankar", "IN", "India"],
                    ["Khardungla Top", "IN", "India"],
                    ["Wandoor", "IN", "India"],
                    ["Rewari", "IN", "India"],
                    ["Bathinda", "IN", "India"],
                    ["Nagercoil", "IN", "India"],
                    ["Ratlam", "IN", "India"],
                    ["Fatehpur", "IN", "India"],
                    ["Ahmadabad", "IN", "India"],
                    ["Akola", "IN", "India"],
                    ["Sariska", "IN", "India"],
                    ["Bolpur", "IN", "India"],
                    ["Neermahal", "IN", "India"],
                    ["Madhopur", "IN", "India"],
                    ["Malana Dam", "IN", "India"],
                    ["Dhauli", "IN", "India"],
                    ["Vythiri", "IN", "India"],
                    ["Calcutta", "IN", "India"],
                    ["Vagator", "IN", "India"],
                    ["Charkhole", "IN", "India"],
                    ["Kanya Kumari", "IN", "India"],
                    ["Rado Valley", "IN", "India"],
                    ["Ellappatti Camp", "IN", "India"],
                    ["Jind", "IN", "India"],
                    ["Panipat", "IN", "India"],
                    ["Sarnath", "IN", "India"],
                    ["Kakinada", "IN", "India"],
                    ["Yuksom", "IN", "India"],
                    ["Malda", "IN", "India"],
                    ["Ganapatipule", "IN", "India"],
                    ["Thiksey", "IN", "India"],
                    ["Pykara", "IN", "India"],
                    ["Jharsuguda", "IN", "India"],
                    ["Aizawl", "IN", "India"],
                    ["Bakkhali", "IN", "India"],
                    ["Ellora", "IN", "India"],
                    ["Thirunallar", "IN", "India"],
                    ["Kanjanur", "IN", "India"],
                    ["Alangudi", "IN", "India"],
                    ["Thiruvenkadu", "IN", "India"],
                    ["Vaitheeswaran Koil", "IN", "India"],
                    ["Suriyanar Koil", "IN", "India"],
                    ["Tungnath", "IN", "India"],
                    ["Sonipat", "IN", "India"],
                    ["Jageshwar", "IN", "India"],
                    ["Hikkim", "IN", "India"],
                    ["Chottanikkara", "IN", "India"],
                    ["Hubballi", "IN", "India"],
                    ["Anantapur", "IN", "India"],
                    ["Bharuch", "IN", "India"],
                    ["Kosi", "IN", "India"],
                    ["Cuddalore", "IN", "India"],
                    ["Mizoram", "IN", "India"],
                    ["Karimnagar", "IN", "India"],
                    ["Malshej Ghat", "IN", "India"],
                    ["Dombivli", "IN", "India"],
                    ["Chokhi Dhani", "IN", "India"],
                    ["Tanakpur", "IN", "India"],
                    ["Baroda", "IN", "India"],
                    ["Pench", "IN", "India"],
                    ["Ganagapur", "IN", "India"],
                    ["Pandharpuur", "IN", "India"],
                    ["Athirappally", "IN", "India"],
                    ["Thirunageswaram", "IN", "India"],
                    ["Durgapur", "IN", "India"],
                    ["Ghum", "IN", "India"],
                    ["Lingtam", "IN", "India"],
                    ["Satkosia", "IN", "India"],
                    ["Baralacha", "IN", "India"],
                    ["Bhagsu", "IN", "India"],
                    ["Naddi", "IN", "India"],
                    ["Pong", "IN", "India"],
                    ["Agara", "IN", "India"],
                    ["Khir Ganga", "IN", "India"],
                    ["Kharagpur", "IN", "India"],
                    ["Scandal Point", "IN", "India"],
                    ["Lakkar Bazaar", "IN", "India"],
                    ["Suntalekhola", "IN", "India"],
                    ["Connor", "IN", "India"],
                    ["Sultanpur", "IN", "India"],
                    ["Lapchakha", "IN", "India"],
                    ["Santrabarie", "IN", "India"],
                    ["Vantawang", "IN", "India"],
                    ["Champai", "IN", "India"],
                    ["Telangana", "IN", "India"],
                    ["Kurnool", "IN", "India"],
                    ["Skandagiri Trek", "IN", "India"],
                    ["Konaseema", "IN", "India"],
                    ["Nagarjunasagar", "IN", "India"],
                    ["Ramanagara", "IN", "India"],
                    ["Shegaon", "IN", "India"],
                    ["Chaukori", "IN", "India"],
                    ["Sitapur", "IN", "India"],
                    ["Kunzum", "IN", "India"],
                    ["Sikar", "IN", "India"],
                    ["Veraval", "IN", "India"],
                    ["Auroville", "IN", "India"],
                    ["Azamgarh", "IN", "India"],
                    ["Kashi", "IN", "India"],
                    ["Jagannath Puri", "IN", "India"],
                    ["Baharampur", "IN", "India"],
                    ["Someshwar", "IN", "India"],
                    ["Kanchi", "IN", "India"],
                    ["Chaubatia", "IN", "India"],
                    ["Gavi", "IN", "India"],
                    ["Sawantwad", "IN", "India"],
                    ["Jaigadh", "IN", "India"],
                    ["Berhampur", "IN", "India"],
                    ["Pashupati", "IN", "India"],
                    ["Korba", "IN", "India"],
                    ["Latur", "IN", "India"],
                    ["Masinagudi", "IN", "India"],
                    ["Jaunpur", "IN", "India"],
                    ["Darbhanga", "IN", "India"],
                    ["Batal", "IN", "India"],
                    ["Alipurduar", "IN", "India"],
                    ["Ramdhura", "IN", "India"],
                    ["Begusarai", "IN", "India"],
                    ["Kankhal", "IN", "India"],
                    ["Bhandara", "IN", "India"],
                    ["Bageshwar", "IN", "India"],
                    ["Idukki", "IN", "India"],
                    ["Pali", "IN", "India"],
                    ["Aluva", "IN", "India"],
                    ["Kamarpukur", "IN", "India"],
                    ["Naukuchiatal", "IN", "India"],
                    ["Sawantwadi", "IN", "India"],
                    ["Tarkeshwar", "IN", "India"],
                    ["Borong", "IN", "India"],
                    ["Manesar", "IN", "India"],
                    ["Naldhara", "IN", "India"],
                    ["Chail Palace", "IN", "India"],
                    ["Kokernag", "IN", "India"],
                    ["Vashi", "IN", "India"],
                    ["Bhiwadi", "IN", "India"],
                    ["Sangli", "IN", "India"],
                    ["Bharmour", "IN", "India"],
                    ["Unnao", "IN", "India"],
                    ["Minakshi Puram", "IN", "India"],
                    ["Malappuram", "IN", "India"],
                    ["Pipli", "IN", "India"],
                    ["Hirapur", "IN", "India"],
                    ["Angul", "IN", "India"],
                    ["Japan", "IN", "India"],
                    ["Virar", "IN", "India"],
                    ["Bundi", "IN", "India"],
                    ["Sangrur", "IN", "India"],
                    ["Valera Falls", "IN", "India"],
                    ["Mandwa", "IN", "India"],
                    ["Gandhidham", "IN", "India"],
                    ["Yamuna Nagar", "IN", "India"],
                    ["Kaudiyala", "IN", "India"],
                    ["Srikakulam", "IN", "India"],
                    ["Dhordo", "IN", "India"],
                    ["Sambalpur", "IN", "India"],
                    ["Uttarey", "IN", "India"],
                    ["Mana", "IN", "India"],
                    ["Kausan", "IN", "India"],
                    ["Morbi", "IN", "India"],
                    ["Kopargaon", "IN", "India"],
                    ["Kirti Nagar", "IN", "India"],
                    ["Kalaburagi", "IN", "India"],
                    ["Saharanpur", "IN", "India"],
                    ["Narayan Sarovar", "IN", "India"],
                    ["Ganga Sagar", "IN", "India"],
                    ["Dasada", "IN", "India"],
                    ["Abhayapuri", "IN", "India"],
                    ["Pin Valley", "IN", "India"],
                    ["Bhiwandi", "IN", "India"],
                    ["Rewalsar", "IN", "India"],
                    ["Mirzapur", "IN", "India"],
                    ["Chandratal", "IN", "India"],
                    ["Vishakhapatnam", "IN", "India"],
                    ["Herur", "IN", "India"],
                    ["Kadapa", "IN", "India"],
                    ["Nagarkot", "IN", "India"],
                    ["Rumtek", "IN", "India"],
                    ["Simikot", "IN", "India"],
                    ["Mehsana", "IN", "India"],
                    ["Hoshiarpur", "IN", "India"],
                    ["Kashid", "IN", "India"],
                    ["Pipalkoti", "IN", "India"],
                    ["Pemayangtse", "IN", "India"],
                    ["Balotra", "IN", "India"],
                    ["Erode", "IN", "India"],
                    ["Ahmednagar", "IN", "India"],
                    ["Kashmandu", "NP", "Nepal"],
                    ["Malaysia", "MY", "Malaysia"],
                    ["Aalborg", "DK", "Denmark"],
                    ["Abakan", "RU", "Russia"],
                    ["Aberdare", "KE", "Kenya"],
                    ["Accra", "GH", "Ghana"],
                    ["Acropolis", "GR", "Greece"],
                    ["Addis", "ET", "Ethiopia"],
                    ["Adelaide", "AU", "Australia"],
                    ["Afghanistan", "AF", "Afghanistan"],
                    ["Africa", "RAF", "Africa"],
                    ["Alabama", "US", "United States Of America"],
                    ["Alaska", "US", "United States Of America"],
                    ["Albania", "CO", "Colombia"],
                    ["Alexandria", "PS", "Palestine"],
                    ["Alicante", "ES", "Spain"],
                    ["Allentown", "US", "United States Of America"],
                    ["Allestree", "AU", "Australia"],
                    ["Almaty", "KG", "Kazakhstan"],
                    ["Alpine", "IT", "Italy"],
                    ["Alta", "REU", "Europe"],
                    ["Amalfi", "GR", "Greece"],
                    ["Amarapura", "MM", "Myanmar"],
                    ["Amarillo", "US", "United States Of America"],
                    ["Ambla", "EE", "Estonia"],
                    ["Amboseli", "KE", "Kenya"],
                    ["Amerstdam", "UK", "United Kingdom"],
                    ["Amman", "JO", "Jordan"],
                    ["Amsterdam", "NL", "Netherlands"],
                    ["Anaheim", "US", "United States Of America"],
                    ["Anchorage", "US", "United States Of America"],
                    ["Andorra", "REU", "Europe"],
                    ["Angkor Wat", "KH", "Cambodia"],
                    ["Angor", "RME", "MiddleEast"],
                    ["Ankara", "TR", "Turkey"],
                    ["Annemasse", "REU", "Europe"],
                    ["Anruadhapura", "LK", "Sri Lanka"],
                    ["Antaliya", "TR", "Turkey"],
                    ["Antalya", "TR", "Turkey"],
                    ["Antananarivo", "MG", "Madagascar"],
                    ["Antarctica", "AQ", "Antarctica"],
                    ["Antipolo", "PH", "Philippines"],
                    ["Antwerp", "BE", "Belgium"],
                    ["Anuradhapura", "LK", "Sri Lanka"],
                    ["Aomori", "JP", "Japan"],
                    ["Aphrodisias", "TR", "Turkey"],
                    ["Aquarium", "SG", "Singapore"],
                    ["Arab", "US", "United States Of America"],
                    ["Arbaeen", "RME", "MiddleEast"],
                    ["Ardebil", "IR", "Iran"],
                    ["Arenal", "CR", "Costa Rica"],
                    ["Arizona", "US", "United States Of America"],
                    ["Arkhangelsk", "RU", "Russia"],
                    ["Armenia", "REU", "Europe"],
                    ["Arusha", "TZ", "Tanzania"],
                    ["Asturias", "ES", "Spain"],
                    ["Aswan", "EG", "Egypt"],
                    ["Athens", "GR", "Greece"],
                    ["Athina", "GR", "Greece"],
                    ["Atlanta", "US", "United States Of America"],
                    ["Atlantic", "US", "United States Of America"],
                    ["Auckland", "NZ", "New Zealand"],
                    ["Audincourt", "FR", "France"],
                    ["Nice", "FR", "France"],
                    ["Aukana", "LK", "Sri Lanka"],
                    ["Austin", "US", "United States Of America"],
                    ["Australia", "AU", "Australia"],
                    ["Australian", "AU", "Australia"],
                    ["Austrelia", "NZ", "New Zealand"],
                    ["Austria", "FR", "France"],
                    ["Ayutthaya", "TH", "Thailand"],
                    ["Azad", "PK", "Pakistan"],
                    ["Azerbaijan", "AZ", "Azerbaijan"],
                    ["Bacolod", "PH", "Philippines"],
                    ["Bagan", "MM", "Myanmar"],
                    ["Baghdad", "RME", "MiddleEast"],
                    ["Baguio", "PH", "Philippines"],
                    ["Bahamas", "BS", "Bahamas"],
                    ["Bahrain", "BH", "Bahrain"],
                    ["Baitul", "RME", "MiddleEast"],
                    ["Baja", "MX", "Mexico"],
                    ["Baku", "AZ", "Azerbaijan"],
                    ["Balakong", "MY", "Malaysia"],
                    ["Balestrand", "REU", "Europe"],
                    ["Balibago", "PH", "Philippines"],
                    ["Ballina", "IE", "Ireland"],
                    ["Balore", "US", "United States Of America"],
                    ["Baltimore", "US", "United States Of America"],
                    ["Baltra", "EC", "Ecuador"],
                    ["Bandar", "BN", "Brunei"],
                    ["Bandarawela", "LK", "Sri Lanka"],
                    ["Bandelierkop", "ZA", "South Africa"],
                    ["Bandos", "MV", "Maldives"],
                    ["Bandung", "ID", "Indonesia"],
                    ["Bangladesh", "BD", "Bangladesh"],
                    ["Barcelona", "ES", "Spain"],
                    ["Barisal", "BD", "Bangladesh"],
                    ["Barong", "ID", "Indonesia"],
                    ["Batan Island", "PH", "Philippines"],
                    ["Baton", "US", "United States Of America"],
                    ["Batticaloa", "LK", "Sri Lanka"],
                    ["Batu", "SG", "Singapore"],
                    ["Batucaves", "MY", "Malaysia"],
                    ["Batumi", "GE", "Georgia"],
                    ["Bedford", "GB", "Great Britain"],
                    ["Bedugul", "ID", "Indonesia"],
                    ["Behrensdorf", "DE", "Germany"],
                    ["Beijing", "CN", "China"],
                    ["Beira", "MZ", "Mozambique"],
                    ["Beirut", "LB", "Lebanon"],
                    ["Belgium", "MC", "Monaco"],
                    ["Belgorod", "RU", "Russia"],
                    ["Belize", "RSA", "South America"],
                    ["Bengkong", "ID", "Indonesia"],
                    ["Benin", "BJ", "Benin"],
                    ["Benoa", "ID", "Indonesia"],
                    ["Bergen", "REU", "Europe"],
                    ["Berlin", "DE", "Germany"],
                    ["Bermingham", "UK", "United Kingdom"],
                    ["Bermuda", "BM", "Bermuda"],
                    ["Bern", "REU", "Europe"],
                    ["Bethlehem", "IL", "Israel"],
                    ["Bhagdad", "RME", "MiddleEast"],
                    ["Bhaktapur", "NP", "Nepal"],
                    ["Bhurj", "AE", "United Arab Emirates"],
                    ["Bhutan", "BT", "Bhutan"],
                    ["Biarritz", "FR", "France"],
                    ["Bicol", "PH", "Philippines"],
                    ["Bicton", "AU", "Australia"],
                    ["Bidart", "FR", "France"],
                    ["Birmingham", "GB", "Great Britain"],
                    ["Bishkek", "KG", "Kyrgyzstan"],
                    ["Blanquilla", "RCA", "Caribbean"],
                    ["Blasket", "IE", "Ireland"],
                    ["Bogor", "ID", "Indonesia"],
                    ["Bogota", "CO", "Colombia"],
                    ["Bogra", "BD", "Bangladesh"],
                    ["Bolivar", "CO", "Colombia"],
                    ["Bolivia", "BO", "Bolivia"],
                    ["Bolwarra", "AU", "Australia"],
                    ["Bora", "PF", "French Polynesia"],
                    ["Borabora", "FR", "France"],
                    ["Bosnai", "REU", "Europe"],
                    ["Bosnia", "MY", "Malaysia"],
                    ["Boston", "US", "United States Of America"],
                    ["Botswana", "ZA", "South Africa"],
                    ["Bratislava", "AT", "Austria"],
                    ["Brazil", "BR", "Brazil"],
                    ["Brentwood", "UK", "United Kingdom"],
                    ["Brisbane", "AU", "Australia"],
                    ["British", "CA", "Canada"],
                    ["Brno", "CZ", "Czech Republic"],
                    ["Brooklyn", "US", "United States Of America"],
                    ["Bruges", "BE", "Belgium"],
                    ["Brussels", "BE", "Belgium"],
                    ["Bucaramanga", "CO", "Colombia"],
                    ["Bucharest", "RO", "Romania"],
                    ["Budapest", "HU", "Hungary"],
                    ["Buena", "US", "United States Of America"],
                    ["Buffalo", "US", "United States Of America"],
                    ["Bullet", "JP", "Japan"],
                    ["Bumthang", "BT", "Bhutan"],
                    ["Bunaken", "ID", "Indonesia"],
                    ["Burkina", "RAF", "Africa"],
                    ["Burlington", "CA", "Canada"],
                    ["Burundi", "BI", "Burundi"],
                    ["Buyan", "ID", "Indonesia"],
                    ["Cairns", "AU", "Australia"],
                    ["Cairo", "EG", "Egypt"],
                    ["Calgary", "CA", "Canada"],
                    ["California", "US", "United States Of America"],
                    ["Cambodia", "KH", "Cambodia"],
                    ["Cameroon", "CM", "Cameroon"],
                    ["Camperdown", "AU", "Australia"],
                    ["Campleakey", "ID", "Indonesia"],
                    ["Canada", "CA", "Canada"],
                    ["Canadaperu", "ZA", "South Africa"],
                    ["Cancun", "US", "United States Of America"],
                    ["Cannes", "FR", "France"],
                    ["Canning", "CA", "Canada"],
                    ["Canton", "US", "United States Of America"],
                    ["Cao", "RFE", "Far East"],
                    ["Capetown", "KE", "Kenya"],
                    ["Cape_Town", "ZA", "South Africa"],
                    ["Capitol", "US", "United States Of America"],
                    ["Capo", "REU", "Europe"],
                    ["Cappadocia", "TR", "Turkey"],
                    ["Caribbean", "RCA", "Caribbean"],
                    ["Carnegie", "AU", "Australia"],
                    ["Carpathians", "RO", "Romania"],
                    ["Cary", "US", "United States Of America"],
                    ["Casablanca", "MA", "Morocco"],
                    ["Cayman", "KY", "Cayman Islands"],
                    ["Celuk", "ID", "Indonesia"],
                    ["Central", "SG", "Singapore"],
                    ["Cerfs", "MU", "Mauritius"],
                    ["Cesky", "CZ", "Czech Republic"],
                    ["Changmai", "TH", "Thailand"],
                    ["Changunarayan", "NP", "Nepal"],
                    ["Chania", "GR", "Greece"],
                    ["Charvak", "UZ", "Uzbekistan"],
                    ["Chau", "VN", "Vietnam"],
                    ["Chefchaoun", "MA", "Morocco"],
                    ["Chegaga", "MA", "Morocco"],
                    ["Chelela", "BT", "Bhutan"],
                    ["Chengde", "CN", "China"],
                    ["Chengdu", "CN", "China"],
                    ["Cheras", "MY", "Malaysia"],
                    ["Chiang", "TH", "Thailand"],
                    ["Chiapas", "MX", "Mexico"],
                    ["Chicago", "US", "United States Of America"],
                    ["Chickamaugalur", "US", "United States Of America"],
                    ["Chilaw", "LK", "Sri Lanka"],
                    ["Chile", "CL", "Chile"],
                    ["Chimgan", "UZ", "Uzbekistan"],
                    ["China", "CN", "China"],
                    ["Chinagreatwall", "CN", "China"],
                    ["Chinatown", "MY", "Malaysia"],
                    ["Chino", "US", "United States Of America"],
                    ["Chisinau", "MD", "Moldova"],
                    ["Chitran", "NP", "Nepal"],
                    ["Chittagong", "BD", "Bangladesh"],
                    ["Chongqing", "CN", "China"],
                    ["Christchurch", "NZ", "New Zealand"],
                    ["Cimahi", "ID", "Indonesia"],
                    ["Ciudad", "US", "United States Of America"],
                    ["Claremont", "US", "United States Of America"],
                    ["Cleveland", "US", "United States Of America"],
                    ["Clonmacnoise", "IE", "Ireland"],
                    ["Codrington", "AU", "Australia"],
                    ["Cognac", "FR", "France"],
                    ["Cologne", "CH", "Switzerland"],
                    ["Colombia", "CO", "Colombia"],
                    ["Colombo", "LK", "Sri Lanka"],
                    ["Combo", "AU", "Australia"],
                    ["Comillas", "ES", "Spain"],
                    ["Comoros", "KM", "Comoros"],
                    ["Conakry", "GN", "Guinea"],
                    ["Connemara", "IE", "Ireland"],
                    ["Copenhagen", "DK", "Denmark"],
                    ["Corfu", "US", "United States Of America"],
                    ["Coria", "ES", "Spain"],
                    ["Cork", "IE", "Ireland"],
                    ["Coron", "PH", "Philippines"],
                    ["Corsica", "FR", "France"],
                    ["Costa", "CR", "Costa Rica"],
                    ["Cranbrook", "CA", "Canada"],
                    ["Crest", "US", "United States Of America"],
                    ["Croatia", "IT", "Italy"],
                    ["Crook", "US", "United States Of America"],
                    ["Crouse", "UK", "United Kingdom"],
                    ["Cuba", "CU", "Cuba"],
                    ["Curacao", "CH", "Switzerland"],
                    ["Curepipe", "MU", "Mauritius"],
                    ["Cuzco", "PE", "Peru"],
                    ["Cyprus", "CY", "Cyprus"],
                    ["Dades", "MA", "Morocco"],
                    ["Daegu", "KR", "South Korea"],
                    ["Dakar", "SN", "Senegal"],
                    ["Dalat", "VN", "Vietnam"],
                    ["Dallas", "US", "United States Of America"],
                    ["Dambulla", "LK", "Sri Lanka"],
                    ["Dammam", "SA", "Saudi Arabia"],
                    ["Denmark", "REU", "Europe"],
                    ["Dargi", "RFE", "Far East"],
                    ["Darlinghurst", "AU", "Australia"],
                    ["Dartmouth", "CA", "Canada"],
                    ["Davao", "PH", "Philippines"],
                    ["Deira", "AE", "United Arab Emirates"],
                    ["Delray", "US", "United States Of America"],
                    ["Denarau", "FJ", "Fiji"],
                    ["Denpasar", "ID", "Indonesia"],
                    ["Denver", "US", "United States Of America"],
                    ["Detroit", "US", "United States Of America"],
                    ["Dexter", "SG", "Singapore"],
                    ["Dhaka", "BD", "Bangladesh"],
                    ["Dhow", "AE", "United Arab Emirates"],
                    ["Dhudh", "NP", "Nepal"],
                    ["Dhulikhel", "NP", "Nepal"],
                    ["Diani", "KE", "Kenya"],
                    ["Dinajpur", "BD", "Bangladesh"],
                    ["Dingboche", "NP", "Nepal"],
                    ["Dirapuk", "NP", "Nepal"],
                    ["Disneyland", "CN", "China"],
                    ["Division", "BD", "Bangladesh"],
                    ["Djibouti", "DJ", "Djibouti"],
                    ["Dlingo", "ID", "Indonesia"],
                    ["Dochula", "BT", "Bhutan"],
                    ["Doha", "QA", "Qatar"],
                    ["Dominica", "DM", "Dominica"],
                    ["Dominican", "DO", "Dominican Republic"],
                    ["Dongguan", "RFE", "Far East"],
                    ["Dorset", "UK", "United Kingdom"],
                    ["Drakensberg", "ZA", "South Africa"],
                    ["Drukgyel", "BT", "Bhutan"],
                    ["Drukgyeldzong", "BT", "Bhutan"],
                    ["Dubai", "AE", "United Arab Emirates"],
                    ["Dublin", "IE", "Ireland"],
                    ["Dubrovnik", "REU", "Europe"],
                    ["Dumaguete", "PH", "Philippines"],
                    ["Dunes", "MA", "Morocco"],
                    ["Ecuador", "EC", "Ecuador"],
                    ["Edinburgh", "UK", "United Kingdom"],
                    ["Egypt", "IL", "Israel"],
                    ["Elsalvador", "US", "United States Of America"],
                    ["Engelberg", "CH", "Switzerland"],
                    ["Epcot", "US", "United States Of America"],
                    ["Ephesus", "TR", "Turkey"],
                    ["Equador", "RSA", "South America"],
                    ["Eritrea", "ER", "Eritrea"],
                    ["Estonia", "FI", "Finland"],
                    ["Etali", "RSA", "South America"],
                    ["Ethiopia", "ET", "Ethiopia"],
                    ["Eureka", "US", "United States Of America"],
                    ["Everest", "NP", "Nepal"],
                    ["Faridpur", "BD", "Bangladesh"],
                    ["Faro", "PT", "Portugal"],
                    ["Fethiye", "TR", "Turkey"],
                    ["Fihalhohi", "MV", "Maldives"],
                    ["Fiji", "AU", "Australia"],
                    ["Finland", "FI", "Finland"],
                    ["Floreana", "EC", "Ecuador"],
                    ["Florence", "IT", "Italy"],
                    ["Florida", "US", "United States Of America"],
                    ["Fortune", "CA", "Canada"],
                    ["France", "FR", "France"],
                    ["Frankfurt", "DE", "Germany"],
                    ["Freiburg", "DE", "Germany"],
                    ["Fuji", "JP", "Japan"],
                    ["Galle", "LK", "Sri Lanka"],
                    ["Gangtey", "BT", "Bhutan"],
                    ["Garden", "SG", "Singapore"],
                    ["Gardenroute", "KE", "Kenya"],
                    ["Garelt", "CA", "Canada"],
                    ["Gaul", "RME", "MiddleEast"],
                    ["Gawagala", "LK", "Sri Lanka"],
                    ["Geilo", "REU", "Europe"],
                    ["Gelang", "MY", "Malaysia"],
                    ["Gemini", "SG", "Singapore"],
                    ["George", "ZA", "South Africa"],
                    ["Georgetown", "US", "United States Of America"],
                    ["Georgia", "GE", "Georgia"],
                    ["Georgiaritreamoroccony", "REU", "Europe"],
                    ["Gerik", "MY", "Malaysia"],
                    ["Ghana", "GH", "Ghana"],
                    ["Ghent", "BE", "Belgium"],
                    ["Ghorepani", "NP", "Nepal"],
                    ["Giza", "EG", "Egypt"],
                    ["Glacier", "NZ", "New Zealand"],
                    ["Glasgow", "GB", "Great Britain"],
                    ["Glattbrugg", "CH", "Switzerland"],
                    ["Glendale", "US", "United States Of America"],
                    ["Godagari", "BD", "Bangladesh"],
                    ["Goias", "RSA", "South America"],
                    ["Gokyo", "NP", "Nepal"],
                    ["Gold", "AE", "United Arab Emirates"],
                    ["Gold Coast", "AU", "Australia"],
                    ["Golden", "US", "United States Of America"],
                    ["Gorakshep", "NP", "Nepal"],
                    ["Gorey", "REU", "Europe"],
                    ["Gorkha", "NP", "Nepal"],
                    ["Gorky", "KZ", "Kazakhstan"],
                    ["Gornergrat", "CH", "Switzerland"],
                    ["Granada", "ES", "Spain"],
                    ["Grandcanyon", "RNA", "North America"],
                    ["Greece", "GR", "Greece"],
                    ["Greenland", "US", "United States Of America"],
                    ["Grindelwald", "CH", "Switzerland"],
                    ["Gruyeres", "CH", "Switzerland"],
                    ["Guam", "GU", "Guam"],
                    ["Guanabara", "BR", "Brazil"],
                    ["Guanabarabay", "RSA", "South America"],
                    ["Guangzhou", "CN", "China"],
                    ["Gumpa", "DM", "Dominica"],
                    ["Gwadar", "PK", "Pakistan"],
                    ["Haifa", "IL", "Israel"],
                    ["Hajj", "SA", "Saudi Arabia"],
                    ["Halong", "KH", "Cambodia"],
                    ["Halongbay", "KH", "Cambodia"],
                    ["Hambantota", "LK", "Sri Lanka"],
                    ["Hamburg", "DE", "Germany"],
                    ["Hamilton", "NZ", "New Zealand"],
                    ["Hammerfest", "REU", "Europe"],
                    ["Hangzhou", "CN", "China"],
                    ["Hanoi", "VN", "Vietnam"],
                    ["Hardangerfjord", "REU", "Europe"],
                    ["Harrisburg", "US", "United States Of America"],
                    ["Hatshpsut", "EG", "Egypt"],
                    ["Haugesund", "NO", "Norway"],
                    ["Havana", "CU", "Cuba"],
                    ["Havant", "GB", "Great Britain"],
                    ["Hawaiian", "US", "United States Of America"],
                    ["Hawally", "KW", "Kuwait"],
                    ["Heckenberg", "AU", "Australia"],
                    ["Heidelberg", "FR", "France"],
                    ["Helsinki", "FL", "Finland"],
                    ["Hemel", "GB", "Great Britain"],
                    ["Heraklion", "REU", "Europe"],
                    ["Heroica", "MX", "Mexico"],
                    ["Hikkaduwa", "LK", "Sri Lanka"],
                    ["Hiroshima", "JP", "Japan"],
                    ["Hochiminhcity", "VN", "Vietnam"],
                    ["Hokkaido", "JP", "Japan"],
                    ["Holland", "AT", "Austria"],
                    ["Holyland", "RME", "MiddleEast"],
                    ["Homestead", "US", "United States Of America"],
                    ["Honduras", "HN", "Honduras"],
                    ["Hongkong", "HK", "Hong Kong"],
                    ["Honningsvag", "REU", "Europe"],
                    ["Honolulu", "US", "United States Of America"],
                    ["Hooghly", "BD", "Bangladesh"],
                    ["Houston", "US", "United States Of America"],
                    ["Hujand", "RME", "MiddleEast"],
                    ["Humble", "UK", "United Kingdom"],
                    ["Hungary", "HU", "Hungary"],
                    ["Hurghada", "EG", "Egypt"],
                    ["Ibiza", "ES", "Spain"],
                    ["Ice", "CA", "Canada"],
                    ["Iguassu", "BR", "Brazil"],
                    ["Ile", "RAF", "Africa"],
                    ["Ileauxcerfs", "RAF", "Africa"],
                    ["Imilchil", "MA", "Morocco"],
                    ["Incheon", "KR", "South Korea"],
                    ["Indiana", "US", "United States Of America"],
                    ["Indianapolis", "US", "United States Of America"],
                    ["Indonasia", "ID", "Indonesia"],
                    ["Indus", "DM", "Dominica"],
                    ["Inglewood", "US", "United States Of America"],
                    ["Inle", "MM", "Myanmar"],
                    ["Bern", "CH", "Switzerland"],
                    ["Geneva", "CH", "Switzerland"],
                    ["Innersbruck", "UK", "United Kingdom"],
                    ["Innsbruck", "AT", "Austria"],
                    ["Vienna", "AT", "Austria"],
                    ["Interlaken", "CH", "Switzerland"],
                    ["Ipoh", "MY", "Malaysia"],
                    ["Iraklio", "GR", "Greece"],
                    ["Iran", "ES", "Spain"],
                    ["Iraq", "RME", "MiddleEast"],
                    ["Ireland", "UK", "United Kingdom"],
                    ["Israel", "IL", "Israel"],
                    ["Issykkul", "KG", "Kyrgyzstan"],
                    ["Istanbul", "TR", "Turkey"],
                    ["Italy", "FR", "France"],
                    ["Itlay", "IT", "Italy"],
                    ["Izmir", "TR", "Turkey"],
                    ["Jacksonville", "US", "United States Of America"],
                    ["Jaffna", "LK", "Sri Lanka"],
                    ["Jakar", "BT", "Bhutan"],
                    ["Jakarta", "ID", "Indonesia"],
                    ["Jamaica", "JM", "Jamaica"],
                    ["Jamalpur", "BD", "Bangladesh"],
                    ["Jasper", "CA", "Canada"],
                    ["Jeddah", "SA", "Saudi Arabia"],
                    ["Jerash", "JO", "Jordan"],
                    ["Jerusalem", "IL", "Israel"],
                    ["Jessore", "BD", "Bangladesh"],
                    ["Jizan", "SA", "Saudi Arabia"],
                    ["Johannesburg", "ZA", "South Africa"],
                    ["Johor", "MY", "Malaysia"],
                    ["Johorbahru", "MY", "Malaysia"],
                    ["Jomsom", "NP", "Nepal"],
                    ["Jonesborough", "US", "United States Of America"],
                    ["Jordan", "JO", "Jordan"],
                    ["Jim Corbett", "IN", "India"],
                    ["Jumeirah", "AE", "United Arab Emirates"],
                    ["Junrog", "SG", "Singapore"],
                    ["Jurong", "SG", "Singapore"],
                    ["Kagbeni", "NP", "Nepal"],
                    ["Kaghan", "PK", "Pakistan"],
                    ["Kaikoura", "NZ", "New Zealand"],
                    ["Kailash", "NP", "Nepal"],
                    ["Kajang", "MY", "Malaysia"],
                    ["Kalba", "AE", "United Arab Emirates"],
                    ["Kaley", "MM", "Myanmar"],
                    ["Kalipokhri", "NP", "Nepal"],
                    ["Kamchatka", "RU", "Russia"],
                    ["Kamloops", "CA", "Canada"],
                    ["Kampala", "UG", "Uganda"],
                    ["Kanazawa", "JP", "Japan"],
                    ["Kandy", "LK", "Sri Lanka"],
                    ["Kansas", "US", "United States Of America"],
                    ["Kanthmandu", "NP", "Nepal"],
                    ["Kapilavastu", "NP", "Nepal"],
                    ["Karachi", "PK", "Pakistan"],
                    ["Karak", "JO", "Jordan"],
                    ["Karank", "EG", "Egypt"],
                    ["Karbi", "TH", "Thailand"],
                    ["Karlaplan", "SE", "Sweden"],
                    ["Karnak", "EG", "Egypt"],
                    ["Karnaktemple", "EG", "Egypt"],
                    ["Katakombs", "EG", "Egypt"],
                    ["Katar", "AE", "United Arab Emirates"],
                    ["Kataragama", "LK", "Sri Lanka"],
                    ["Katarakama", "LK", "Sri Lanka"],
                    ["Kathmandu", "NP", "Nepal"],
                    ["Katy", "US", "United States Of America"],
                    ["Kauai", "US", "United States Of America"],
                    ["Kawaguchiko", "JP", "Japan"],
                    ["Kazan", "RU", "Russia"],
                    ["Kedah", "MY", "Malaysia"],
                    ["Kef", "IS", "Iceland"],
                    ["Kelala", "ET", "Ethiopia"],
                    ["Kemerovo", "RU", "Russia"],
                    ["Kendal", "UK", "United Kingdom"],
                    ["Kentucky", "US", "United States Of America"],
                    ["Kenya", "KE", "Kenya"],
                    ["Kerry", "IE", "Ireland"],
                    ["Key", "US", "United States Of America"],
                    ["Khardong", "LK", "Sri Lanka"],
                    ["Kharkiv", "UA", "Ukraine"],
                    ["Khuan", "TH", "Thailand"],
                    ["Khulna", "BD", "Bangladesh"],
                    ["Kiev", "REU", "Europe"],
                    ["Killarney", "IE", "Ireland"],
                    ["Kingston", "CA", "Canada"],
                    ["Kintamani", "ID", "Indonesia"],
                    ["Kitulgala", "LK", "Sri Lanka"],
                    ["Kleine", "IT", "Italy"],
                    ["Kloten", "CH", "Switzerland"],
                    ["Knysna", "ZA", "South Africa"],
                    ["Kohsamui", "TH", "Thailand"],
                    ["Koneswaram", "LK", "Sri Lanka"],
                    ["Konigsberg", "RU", "Russia"],
                    ["Konya", "TR", "Turkey"],
                    ["Kophangan", "TH", "Thailand"],
                    ["Kotiyal", "RFE", "Far East"],
                    ["Krabhi", "TH", "Thailand"],
                    ["Krabi", "TH", "Thailand"],
                    ["Krakow", "DE", "Germany"],
                    ["Krong", "KH", "Cambodia"],
                    ["Kruger", "ZA", "South Africa"],
                    ["Krugerregion", "ZA", "South Africa"],
                    ["Kuala", "SG", "Singapore"],
                    ["Kuala Lumpur", "MY", "Malaysia"],
                    ["Kuching", "MY", "Malaysia"],
                    ["Kudacan", "GB", "Great Britain"],
                    ["Kuden", "REU", "Europe"],
                    ["Kufa", "RME", "MiddleEast"],
                    ["Kumai", "ID", "Indonesia"],
                    ["Kunming", "CN", "China"],
                    ["Kusadasi", "TR", "Turkey"],
                    ["Kuta", "ID", "Indonesia"],
                    ["Kuzuko", "ZA", "South Africa"],
                    ["Kwantu", "ZA", "South Africa"],
                    ["Kynsna", "ZA", "South Africa"],
                    ["Kyoto", "JP", "Japan"],
                    ["Kyrgyzstan", "KG", "Kyrgyzstan"],
                    ["Lahijan", "IR", "Iran"],
                    ["Lahore", "PK", "Pakistan"],
                    ["Lakenaivasha", "KE", "Kenya"],
                    ["Lakenakuru", "KE", "Kenya"],
                    ["Lanarkshire", "UK", "United Kingdom"],
                    ["Landan", "UK", "United Kingdom"],
                    ["Landon", "UK", "United Kingdom"],
                    ["Lankanfinolhu", "MV", "Maldives"],
                    ["Laohekou", "REU", "Europe"],
                    ["Laos", "LA", "Laos"],
                    ["Larkana", "PK", "Pakistan"],
                    ["Larnaca", "CY", "Cyprus"],
                    ["Las", "ES", "Spain"],
                    ["Las Vegas", "US", "United States Of America"],
                    ["Latvia", "LV", "Latvia"],
                    ["Lausanne", "CH", "Switzerland"],
                    ["Lawrenceville", "US", "United States Of America"],
                    ["Lea", "GB", "Great Britain"],
                    ["Lebanon", "RME", "MiddleEast"],
                    ["Lehi", "US", "United States Of America"],
                    ["Lehigh", "US", "United States Of America"],
                    ["Leicester", "GB", "Great Britain"],
                    ["Leuven", "BE", "Belgium"],
                    ["Lexington", "US", "United States Of America"],
                    ["Liberia", "RAF", "Africa"],
                    ["Libreville", "GA", "Gabon"],
                    ["Liechtenstein", "FR", "France"],
                    ["Lima", "PE", "Peru"],
                    ["Limerick", "IE", "Ireland"],
                    ["Linggi", "MY", "Malaysia"],
                    ["Lisbon", "PT", "Portugal"],
                    ["Lithuania", "LT", "Lithuania"],
                    ["Lo-Manthang", "NP", "Nepal"],
                    ["Lobuche", "NP", "Nepal"],
                    ["Lomani", "IS", "Iceland"],
                    ["London", "UK", "United Kingdom"],
                    ["Long", "US", "United States Of America"],
                    ["Longford", "GB", "Great Britain"],
                    ["Longyearbyen", "SJ", "Svalbard &amp"],
                    ["Los Angeles", "US", "United States Of America"],
                    ["Lost", "AE", "United Arab Emirates"],
                    ["Lucern", "UK", "United Kingdom"],
                    ["Lucerne", "CH", "Switzerland"],
                    ["Lugano", "CH", "Switzerland"],
                    ["Lukla", "NP", "Nepal"],
                    ["Lumbadzi", "MW", "Malawi"],
                    ["Lumpur", "SG", "Singapore"],
                    ["Luxembourg", "REU", "Europe"],
                    ["Luxor", "EG", "Egypt"],
                    ["Luzern", "CH", "Switzerland"],
                    ["Lyon", "FR", "France"],
                    ["Maasai", "KE", "Kenya"],
                    ["Macau", "HK", "Hong Kong"],
                    ["Macca", "SA", "Saudi Arabia"],
                    ["Maccau", "HK", "Hong Kong"],
                    ["Macedonia", "REU", "Europe"],
                    ["Machu", "PE", "Peru"],
                    ["Macquarie", "AU", "Australia"],
                    ["Madaba", "JO", "Jordan"],
                    ["Madagascar", "RAF", "Africa"],
                    ["Madame", "CH", "Switzerland"],
                    ["Madarihat", "BT", "Bhutan"],
                    ["Madina", "SA", "Saudi Arabia"],
                    ["Madrid", "ES", "Spain"],
                    ["Mainland", "UK", "United Kingdom"],
                    ["Makati", "RFE", "Far East"],
                    ["Makka", "SA", "Saudi Arabia"],
                    ["Makkah", "SA", "Saudi Arabia"],
                    ["Malaca", "TH", "Thailand"],
                    ["Malacca", "MY", "Malaysia"],
                    ["Malas", "SG", "Singapore"],
                    ["Malawi", "MW", "Malawi"],
                    ["Maldives", "MV", "Maldives"],
                    ["Malta", "MT", "Malta"],
                    ["Manado", "ID", "Indonesia"],
                    ["Manaiceland", "FJ", "Fiji"],
                    ["Manakamana", "NP", "Nepal"],
                    ["Manama", "BH", "Bahrain"],
                    ["Manaus", "BR", "Brazil"],
                    ["Manchester", "GB", "Great Britain"],
                    ["Mandalay", "MM", "Myanmar"],
                    ["Mandao", "PH", "Philippines"],
                    ["Mangolia", "RU", "Russia"],
                    ["Manila", "PH", "Philippines"],
                    ["Manile", "PH", "Philippines"],
                    ["Mansarovar", "NP", "Nepal"],
                    ["Manyara", "KE", "Kenya"],
                    ["Marble", "ZA", "South Africa"],
                    ["Marikina", "ROC", "Pacific/Oceania"],
                    ["Marina", "US", "United States Of America"],
                    ["Marine", "ID", "Indonesia"],
                    ["Market", "DM", "Dominica"],
                    ["Marrakech", "MA", "Morocco"],
                    ["Masai", "KE", "Kenya"],
                    ["Masaimara", "KE", "Kenya"],
                    ["Mascow", "RU", "Russia"],
                    ["Mashhad", "IR", "Iran"],
                    ["Masouleh", "IR", "Iran"],
                    ["Masouri", "GR", "Greece"],
                    ["Massachusetts", "US", "United States Of America"],
                    ["Matale", "LK", "Sri Lanka"],
                    ["Maui", "US", "United States Of America"],
                    ["Maurices", "IE", "Ireland"],
                    ["Mauritania", "RAF", "Africa"],
                    ["Maurtius", "MU", "Mauritius"],
                    ["Mecca", "RME", "MiddleEast"],
                    ["Meccah", "SA", "Saudi Arabia"],
                    ["Medan", "ID", "Indonesia"],
                    ["Medina", "SA", "Saudi Arabia"],
                    ["Mekong", "VN", "Vietnam"],
                    ["Melaka", "MY", "Malaysia"],
                    ["Melbourne", "AU", "Australia"],
                    ["Memphis", "EG", "Egypt"],
                    ["Mergouga", "MA", "Morocco"],
                    ["Merlion", "SG", "Singapore"],
                    ["Mexico", "US", "United States Of America"],
                    ["Miami", "US", "United States Of America"],
                    ["Michigan", "US", "United States Of America"],
                    ["Mihintale", "LK", "Sri Lanka"],
                    ["Milan", "FR", "France"],
                    ["Millicent", "AU", "Australia"],
                    ["Milpitas", "US", "United States Of America"],
                    ["Minneapolis", "US", "United States Of America"],
                    ["Minneriya", "LK", "Sri Lanka"],
                    ["Minorca", "ES", "Spain"],
                    ["Minsk", "BY", "Belarus"],
                    ["Minuwangoda", "LK", "Sri Lanka"],
                    ["Moheshpur", "BD", "Bangladesh"],
                    ["Moka", "RAF", "Africa"],
                    ["Moldova", "MD", "Moldova"],
                    ["Mombasa", "KE", "Kenya"],
                    ["Monaco", "MC", "Monaco"],
                    ["Monestries", "DM", "Dominica"],
                    ["Montenegro", "ME", "Montenegro"],
                    ["Monteriggioni", "IT", "Italy"],
                    ["Montevideo", "US", "United States Of America"],
                    ["Montreal", "CA", "Canada"],
                    ["Montreux", "CH", "Switzerland"],
                    ["Moratuwa", "LK", "Sri Lanka"],
                    ["Moreshes", "TH", "Thailand"],
                    ["Morocco", "MA", "Morocco"],
                    ["Morosis", "ID", "Indonesia"],
                    ["Moscow", "RU", "Russia"],
                    ["Moskow", "RFE", "Far East"],
                    ["Muktinath", "NP", "Nepal"],
                    ["Munich", "DE", "Germany"],
                    ["Muscat", "OM", "Oman"],
                    ["Musikot", "NP", "Nepal"],
                    ["Myconos", "GR", "Greece"],
                    ["Mykonos", "GR", "Greece"],
                    ["Myrtle", "US", "United States Of America"],
                    ["Nadi", "FJ", "Fiji"],
                    ["Nagoya", "JP", "Japan"],
                    ["Naiobi", "KE", "Kenya"],
                    ["Nairobi", "KE", "Kenya"],
                    ["Najaf", "RME", "MiddleEast"],
                    ["Nakuru", "KE", "Kenya"],
                    ["Namche", "NP", "Nepal"],
                    ["Nanaimo", "CA", "Canada"],
                    ["Naples", "IT", "Italy"],
                    ["Nara", "JP", "Japan"],
                    ["Narail", "BD", "Bangladesh"],
                    ["Narita", "JP", "Japan"],
                    ["Natal", "BR", "Brazil"],
                    ["Natore", "BD", "Bangladesh"],
                    ["Nauru", "NR", "Nauru"],
                    ["Nazareth", "IL", "Israel"],
                    ["Ncr", "RFE", "Far East"],
                    ["Negombo", "LK", "Sri Lanka"],
                    ["Nellaidhoo", "MV", "Maldives"],
                    ["Nepal", "NP", "Nepal"],
                    ["Nepalgunj", "NP", "Nepal"],
                    ["Netherlands", "NL", "Netherlands"],
                    ["Nevada", "US", "United States Of America"],
                    ["Newark", "US", "United States Of America"],
                    ["Newport", "US", "United States Of America"],
                    ["Newyork", "US", "United States Of America"],
                    ["Ngurah", "ID", "Indonesia"],
                    ["Niagara Falls", "US", "United States Of America"],
                    ["Nigerisrael", "RCA", "Caribbean"],
                    ["Nile", "EG", "Egypt"],
                    ["Nilecruise", "EG", "Egypt"],
                    ["Niue", "NU", "Niue"],
                    ["Nomads", "MA", "Morocco"],
                    ["Nong", "TH", "Thailand"],
                    ["Norfolk", "US", "United States Of America"],
                    ["Northtour", "RAF", "Africa"],
                    ["Norway", "US", "United States Of America"],
                    ["Nottingham", "GB", "Great Britain"],
                    ["Nusa", "ID", "Indonesia"],
                    ["Nuwara", "LK", "Sri Lanka"],
                    ["Nuwara-Eliya", "LK", "Sri Lanka"],
                    ["Nuwaraeliya", "LK", "Sri Lanka"],
                    ["Nyalam", "NP", "Nepal"],
                    ["Oklahoma", "RFE", "Far East"],
                    ["Omaha", "US", "United States Of America"],
                    ["Ontario", "CA", "Canada"],
                    ["Oosterhout", "NL", "Netherlands"],
                    ["Orange", "US", "United States Of America"],
                    ["Orchard", "SG", "Singapore"],
                    ["Oregon", "US", "United States Of America"],
                    ["Orkney", "GB", "Great Britain"],
                    ["Orlando", "US", "United States Of America"],
                    ["Osaka", "JP", "Japan"],
                    ["Oslo", "NO", "Norway"],
                    ["Ottawa", "CA", "Canada"],
                    ["Ouarzazate", "MA", "Morocco"],
                    ["Oudtshoorn", "ZA", "South Africa"],
                    ["Pabna", "BD", "Bangladesh"],
                    ["Pacific", "IS", "Iceland"],
                    ["Padang", "ID", "Indonesia"],
                    ["Pahang", "MY", "Malaysia"],
                    ["Pakistan", "PK", "Pakistan"],
                    ["Palastine", "IL", "Israel"],
                    ["Palau", "IT", "Italy"],
                    ["Palma", "ES", "Spain"],
                    ["Pamplemousse", "MU", "Mauritius"],
                    ["Pamukkale", "TR", "Turkey"],
                    ["Panama", "RSA", "South America"],
                    ["Pangboche", "NP", "Nepal"],
                    ["Pangkalanbun", "ID", "Indonesia"],
                    ["Papeete", "FR", "France"],
                    ["Papua", "PG", "Papua New Guinea"],
                    ["Paradise", "US", "United States Of America"],
                    ["Paraguay", "PY", "Paraguay"],
                    ["Paris", "FR", "France"],
                    ["Parish", "US", "United States Of America"],
                    ["Pasay", "PH", "Philippines"],
                    ["Pashupatinath", "NP", "Nepal"],
                    ["Pattaya", "TH", "Thailand"],
                    ["Pattivasal", "RIS", "Indian Subcontinent"],
                    ["Penang", "MY", "Malaysia"],
                    ["Pennington", "US", "United States Of America"],
                    ["Pennsylvania", "US", "United States Of America"],
                    ["Perdana", "SG", "Singapore"],
                    ["Perhentian", "MY", "Malaysia"],
                    ["Perth", "AU", "Australia"],
                    ["Peru", "PE", "Peru"],
                    ["Peshawar", "PK", "Pakistan"],
                    ["St. Petersburg", "RU", "Russia"],
                    ["Petra", "JO", "Jordan"],
                    ["Phakding", "NP", "Nepal"],
                    ["Phang", "TH", "Thailand"],
                    ["Pheuntsholing", "BT", "Bhutan"],
                    ["Phi Phi Islands", "TH", "Thailand"],
                    ["Philadelphia", "US", "United States Of America"],
                    ["Philippines", "ROC", "Pacific/Oceania"],
                    ["Phnompenh", "KH", "Cambodia"],
                    ["Phuket", "TH", "Thailand"],
                    ["Phulshillong", "BT", "Bhutan"],
                    ["Phunakha", "BT", "Bhutan"],
                    ["Phunchulling", "BT", "Bhutan"],
                    ["Phuntsholing", "BT", "Bhutan"],
                    ["Pilgrims", "UK", "United Kingdom"],
                    ["Pillipens", "RFE", "Far East"],
                    ["Pinnawala", "LK", "Sri Lanka"],
                    ["Pisa", "CH", "Switzerland"],
                    ["Plan", "ES", "Spain"],
                    ["Plymouth", "US", "United States Of America"],
                    ["Poblet", "ES", "Spain"],
                    ["Pointe", "MU", "Mauritius"],
                    ["Poland", "PL", "Poland"],
                    ["Polannaruwa", "LK", "Sri Lanka"],
                    ["Polonnaruwa", "LK", "Sri Lanka"],
                    ["Polynesia", "WS", "Samoa"],
                    ["Pondoktangguy", "ID", "Indonesia"],
                    ["Pontianak", "ID", "Indonesia"],
                    ["Poon", "NP", "Nepal"],
                    ["Portland", "US", "United States Of America"],
                    ["Porto", "ES", "Spain"],
                    ["Portugal", "REU", "Europe"],
                    ["Prague", "CZ", "Czech Republic"],
                    ["Prasilin", "SC", "Seychelles"],
                    ["Praslin", "SC", "Seychelles"],
                    ["Princes", "AU", "Australia"],
                    ["Puebla", "MX", "Mexico"],
                    ["Puerto", "ES", "Spain"],
                    ["Puket", "TH", "Thailand"],
                    ["Pullman", "US", "United States Of America"],
                    ["Purang", "NP", "Nepal"],
                    ["Putra", "SG", "Singapore"],
                    ["Putrajaya", "MY", "Malaysia"],
                    ["Queensland", "AU", "Australia"],
                    ["Queenstown", "NZ", "New Zealand"],
                    ["Quezon", "PH", "Philippines"],
                    ["Quito", "EC", "Ecuador"],
                    ["Qutar", "RME", "MiddleEast"],
                    ["Kuwait", "SA", "Saudi Arabia"],
                    ["Raba", "MA", "Morocco"],
                    ["Rangpur", "BD", "Bangladesh"],
                    ["Ranipauwa", "NP", "Nepal"],
                    ["Ravanusa", "IT", "Italy"],
                    ["Red", "AE", "United Arab Emirates"],
                    ["Redwood", "US", "United States Of America"],
                    ["Rennes", "FR", "France"],
                    ["Reston", "US", "United States Of America"],
                    ["Rhine", "UK", "United Kingdom"],
                    ["Richmond", "US", "United States Of America"],
                    ["Rio De Janeiro", "BR", "Brazil"],
                    ["Riska", "REU", "Europe"],
                    ["Ritigala", "LK", "Sri Lanka"],
                    ["River", "GB", "Great Britain"],
                    ["Riyadh", "SA", "Saudi Arabia"],
                    ["Road", "VG", "Virgin Islands"],
                    ["Rocca", "IT", "Italy"],
                    ["Romania", "RO", "Romania"],
                    ["Rome", "IT", "Italy"],
                    ["Rotorua", "NZ", "New Zealand"],
                    ["Roudkhan", "IR", "Iran"],
                    ["Sagam", "DM", "Dominica"],
                    ["Sagarmatha", "NP", "Nepal"],
                    ["Saint", "RCA", "Caribbean"],
                    ["Saitama", "JP", "Japan"],
                    ["Sakkra", "EG", "Egypt"],
                    ["Salalah", "OM", "Oman"],
                    ["Salvador", "BR", "Brazil"],
                    ["Salzburg", "CZ", "Czech Republic"],
                    ["Samarkand", "UZ", "Uzbekistan"],
                    ["Samburu", "KE", "Kenya"],
                    ["San Diego", "US", "United States Of America"],
                    ["San Francisco", "US", "United States Of America"],
                    ["Sangir", "ID", "Indonesia"],
                    ["Sanluisobipspo", "US", "United States Of America"],
                    ["Santa", "BO", "Bolivia"],
                    ["Santacruze", "EC", "Ecuador"],
                    ["Santiago", "RSA", "South America"],
                    ["Santo", "DO", "Dominican Republic"],
                    ["Santorini", "GR", "Greece"],
                    ["Sarangkot", "NP", "Nepal"],
                    ["Saratoga", "ES", "Spain"],
                    ["Scandinavia", "REU", "Europe"],
                    ["Schaffhausen", "REU", "Europe"],
                    ["Schiphol", "NL", "Netherlands"],
                    ["Scotland", "REU", "Europe"],
                    ["Sea", "SG", "Singapore"],
                    ["Seattle", "US", "United States Of America"],
                    ["Semarang", "ID", "Indonesia"],
                    ["Senegal", "SN", "Senegal"],
                    ["Sentosa", "ID", "Indonesia"],
                    ["Sentosa Island", "SG", "Singapore"],
                    ["Seorak", "KR", "South Korea"],
                    ["Seoul", "KR", "South Korea"],
                    ["Sepang", "MY", "Malaysia"],
                    ["Serengeti", "TZ", "Tanzania"],
                    ["Seri", "RIS", "Indian Subcontinent"],
                    ["Serua", "ROC", "Pacific/Oceania"],
                    ["Sevilla", "ES", "Spain"],
                    ["Shanghai", "CN", "China"],
                    ["Shanti", "DM", "Dominica"],
                    ["Sharjah", "AE", "United Arab Emirates"],
                    ["Shenzhen", "CN", "China"],
                    ["Shinjuku", "JP", "Japan"],
                    ["Shinkansen", "JP", "Japan"],
                    ["Shiraz", "IR", "Iran"],
                    ["Siberia", "RU", "Russia"],
                    ["Sierranegravocano", "EC", "Ecuador"],
                    ["Sigiriya", "LK", "Sri Lanka"],
                    ["Siingapore", "RFE", "Far East"],
                    ["Silang", "PH", "Philippines"],
                    ["Simalla", "ET", "Ethiopia"],
                    ["Simmikot", "NP", "Nepal"],
                    ["Simsbury", "US", "United States Of America"],
                    ["Sinagapore", "SG", "Singapore"],
                    ["Skopje", "MK", "Macedonia"],
                    ["Skoura", "MA", "Morocco"],
                    ["Slovakia", "DE", "Germany"],
                    ["Slovenia", "IT", "Italy"],
                    ["Smila", "UA", "Ukraine"],
                    ["Smithsonian", "US", "United States Of America"],
                    ["Snow", "AE", "United Arab Emirates"],
                    ["Sochi", "RU", "Russia"],
                    ["Soekarno", "ID", "Indonesia"],
                    ["Sofia", "REU", "Europe"],
                    ["Solomon", "SB", "Solomon Islands"],
                    ["Soule", "KR", "South Korea"],
                    ["Southampton", "UK", "United Kingdom"],
                    ["Spain", "ES", "Spain"],
                    ["Sparta", "US", "United States Of America"],
                    ["Sphinx", "EG", "Egypt"],
                    ["Srilanka", "LK", "Sri Lanka"],
                    ["Stanfordville", "US", "United States Of America"],
                    ["Stockholm", "SE", "Sweden"],
                    ["Storm", "AU", "Australia"],
                    ["Strasbourg", "FR", "France"],
                    ["Stumpa", "DM", "Dominica"],
                    ["Stuttgart", "DE", "Germany"],
                    ["Sucre", "VE", "Venezuela"],
                    ["Summerkhand", "UZ", "Uzbekistan"],
                    ["Superstargeminicruise", "MY", "Malaysia"],
                    ["Surabaya", "ID", "Indonesia"],
                    ["Surry", "AU", "Australia"],
                    ["Swakopmund", "NA", "Namibia"],
                    ["Swarovski", "REU", "Europe"],
                    ["Switzerland", "FR", "France"],
                    ["Sydney", "AU", "Australia"],
                    ["Sylhet", "BD", "Bangladesh"],
                    ["Syria", "RME", "MiddleEast"],
                    ["Taiwang", "RFE", "Far East"],
                    ["Tanjungharapan", "ID", "Indonesia"],
                    ["Tannersville", "US", "United States Of America"],
                    ["Tanzania", "KE", "Kenya"],
                    ["Tarboche", "NP", "Nepal"],
                    ["Taringa", "AU", "Australia"],
                    ["Tashkent", "UZ", "Uzbekistan"],
                    ["Tasmania", "AU", "Australia"],
                    ["Taveuni", "FJ", "Fiji"],
                    ["Tawangmangu", "ID", "Indonesia"],
                    ["Thailand", "TH", "Thailand"],
                    ["Thakudwara", "NP", "Nepal"],
                    ["Thangnak", "NP", "Nepal"],
                    ["Thinadhoo", "MV", "Maldives"],
                    ["Thirappane", "LK", "Sri Lanka"],
                    ["Thulusdhoo", "MV", "Maldives"],
                    ["Tiananmen", "CN", "China"],
                    ["Tibet", "CN", "China"],
                    ["Timberlake", "US", "United States Of America"],
                    ["Timor", "ID", "Indonesia"],
                    ["Tioman", "MY", "Malaysia"],
                    ["Tirana", "REU", "Europe"],
                    ["Tirinadad", "RCA", "Caribbean"],
                    ["Tissa", "LK", "Sri Lanka"],
                    ["Todra", "MA", "Morocco"],
                    ["Tokyo", "JP", "Japan"],
                    ["Tongi", "BD", "Bangladesh"],
                    ["Tongsa", "BT", "Bhutan"],
                    ["Tonka", "UK", "United Kingdom"],
                    ["Tonle", "RFE", "Far East"],
                    ["Tornado", "US", "United States Of America"],
                    ["Toronto", "CA", "Canada"],
                    ["Triconomallee", "LK", "Sri Lanka"],
                    ["Trincomalee", "LK", "Sri Lanka"],
                    ["Trinidad", "TT", "Trinidad And Tobago"],
                    ["Trongsa", "BT", "Bhutan"],
                    ["Trou", "MU", "Mauritius"],
                    ["Tsavo", "KE", "Kenya"],
                    ["Tunisia", "TN", "Tunisia"],
                    ["Turkey", "TR", "Turkey"],
                    ["Turku", "FI", "Finland"],
                    ["Uganda", "UG", "Uganda"],
                    ["Ukraine", "UA", "Ukraine"],
                    ["Umarh", "SA", "Saudi Arabia"],
                    ["Unawatuna", "LK", "Sri Lanka"],
                    ["Universal", "SG", "Singapore"],
                    ["Uruguay", "UY", "Uruguay"],
                    ["USA", "US", "United States Of America"],
                    ["Uzbekistan", "UZ", "Uzbekistan"],
                    ["Vancouver", "CA", "Canada"],
                    ["Vanish", "UK", "United Kingdom"],
                    ["Vapiano", "GB", "Great Britain"],
                    ["Varani", "US", "United States Of America"],
                    ["Vatican", "REU", "Europe"],
                    ["Vaughan", "CA", "Canada"],
                    ["Venezuela", "VE", "Venezuela"],
                    ["Venice", "IT", "Italy"],
                    ["Verginia", "US", "United States Of America"],
                    ["Victoria", "MT", "Malta"],
                    ["Vietnam", "VN", "Vietnam"],
                    ["Virginia", "US", "United States Of America"],
                    ["Waitomo", "NZ", "New Zealand"],
                    ["Wanak", "NZ", "New Zealand"],
                    ["Wanaka", "NZ", "New Zealand"],
                    ["Wangdi", "BT", "Bhutan"],
                    ["Warsaw", "PO", "Poland"],
                    ["Tallinn", "EE", "Estonia"],
                    ["Washington", "US", "United States Of America"],
                    ["Wellington", "NZ", "New Zealand"],
                    ["Williamsburg", "US", "United States Of America"],
                    ["Yangon", "MM", "Myanmar"],
                    ["Yojiya", "SE", "Sweden"],
                    ["Zagreb", "IT", "Italy"],
                    ["Zambezi", "RME", "MiddleEast"],
                    ["Zamboanga", "PH", "Philippines"],
                    ["Zanasker", "DM", "Dominica"],
                    ["Zanzibar", "US", "United States Of America"],
                    ["Zaragoza", "ES", "Spain"],
                    ["Zermatt", "CH", "Switzerland"],
                    ["Zimbabwe", "ZA", "South Africa"],
                    ["Zimut", "RME", "MiddleEast"],
                    ["Zurich", "CH", "Switzerland"],
                    ["Zuthulphuk", "NP", "Nepal"],
                    ["Portblair", "IN", "India"],
                    ["Rohtang Pass", "IN", "India"],
                    ["Kashmir", "IN", "India"],
                    ["Vaishno Devi", "IN", "India"],
                    ["Tamilnadu", "IN", "India"],
                    ["Dharamsala", "IN", "India"],
                    ["Singapore", "SG", "Singapore"],
                    ["United Arab Emirates", "AE", "United Arab Emirates"],
                    ["Indonesia", "ID", "Indonesia"],
                    ["United States Of America", "US", "United States Of America"],
                    ["Europe", "REU", "Europe"],
                    ["Saudi Arabia", "SA", "Saudi Arabia"],
                    ["United Kingdom", "UK", "United Kingdom"],
                    ["Russia", "RU", "Russia"],
                    ["Seychelles", "SC", "Seychelles"],
                    ["South Africa", "ZA", "South Africa"],
                    ["Belarus", "BY", "Belarus"],
                    ["South Korea", "KR", "South Korea"],
                    ["New Zealand", "NZ", "New Zealand"],
                    ["South America", "RSA", "South America"],
                    ["Qatar", "QA", "Qatar"],
                    ["Iceland", "IS", "Iceland"],
                    ["North America", "RNA", "North America"],
                    ["Czech Republic", "CZ", "Czech Republic"],
                    ["Sweden", "SE", "Sweden"],
                    ["Kazakhstan", "KZ", "Kazakhstan"],
                    ["Oman", "OM", "Oman"],
                    ["Myanmar", "MM", "Myanmar"],
                    ["Argentina", "AR", "Argentina"],
                    ["Namibia", "NA", "Namibia"],
                    ["New Delhi", "IN", "India"],
                    ["New York", "US", "United States Of America"],
                    ["Durban", "ZA", "South Africa"],
                    ["pretoria", "ZA", "South Africa"],
                    ["Windhoek", "NA", "Namibia"],
                    ["Bali", "ID", "Indonesia"],
                    ["Bintan", "ID", "Indonesia"],
                    ["Tangier", "MA", "Morocco"],
                    ["Port Louis", "MU", "Mauritius"],
                    ["Tel Aviv", "IR", "Israel"],
                    ["Beersheba", "IR", "Israel"],
                    ["Netanya", "IR", "Israel"],
                    ["Acre", "IR", "Israel"],
                    ["Islamabad", "PK", "Pakistan"],
                    ["Aqaba", "JO", "Jordan"],
                    ["Sao Paulo", "BR", "Brazil"],
                    ["Brasilia", "BR", "Brazil"],
                    ["Buenos Aires", "AR", "Argentina"],
                ];
                var suggestions = [];
                for (i = 0; i < choices.length; i++) if (~(choices[i][0] + " " + choices[i][1]).toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                suggest(suggestions);
            },
            renderItem: function (item, search) {
                search = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                var re = new RegExp("(" + search.split(" ").join("|") + ")", "gi");
                return (
                    '<div class="autocomplete-suggestion" data-langname="' +
                    item[0] +
                    '" data-lang="' +
                    item[1] +
                    '" data-countryname="' +
                    item[2] +
                    '" data-val="' +
                    search +
                    '">' +
                    item[0].replace(re, "<b>$1</b>") +
                    "&nbsp;" +
                    item[2].replace(re, "<b>$1</b>") +
                    "</div>"
                );
            },
            onSelect: function (e, term, item) {
                var autoformid = el.getAttribute("data-formid");
                var placeid = el.id;
                document.getElementById(el.id).value = item.getAttribute("data-langname");
                if (placeid == "depar_city" + autoformid) {
                    document.getElementById("frm_country" + autoformid).value = item.getAttribute("data-lang");
                    document.getElementById("f_country" + autoformid).value = item.getAttribute("data-countryname");
                    document.getElementById("countryfrm_full" + autoformid).value = item.getAttribute("data-countryname");
                    document.getElementById("full_address" + autoformid).value = item.getAttribute("data-lang") + "," + item.getAttribute("data-countryname");
                } else if (placeid == "dest" + autoformid) {
                    document.getElementById("country" + autoformid).value = item.getAttribute("data-lang");
                    document.getElementById("country_full" + autoformid).value = item.getAttribute("data-countryname");
                }
            },
        });
    });
});
if (page != "things_2do_detail" && page != "things_2see_detail") {
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider").lightSlider({ loop: true, keyPress: true, item: 4, auto: false });
        } else {
            $("#content-slider").lightSlider({ loop: true, keyPress: true, item: 10, auto: false });
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider1").lightSlider({ loop: true, keyPress: true, item: 4, auto: false });
        } else {
            $("#content-slider1").lightSlider({ loop: true, keyPress: true, item: 6, auto: false });
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider9").lightSlider({ loop: false, keyPress: true, item: 1, auto: false });
            $("#travel-dealsilder").lightSlider({ loop: false, keyPress: true, item: 1.5, auto: false });
        } else {
            if (pageName != "deal") {
                $("#content-slider9").lightSlider({ loop: false, keyPress: true, item: 3, auto: false });
            } else {
                $("#content-slider9").lightSlider({ loop: false, keyPress: true, item: 1, auto: false });
                $("#travel-dealsilder").lightSlider({ loop: false, keyPress: true, item: 3, auto: false });
            }
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider3").lightSlider({ loop: true, keyPress: true, item: 1, auto: false });
        } else {
            $("#content-slider3").lightSlider({ loop: true, keyPress: true, item: 3, auto: false });
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider4").lightSlider({ loop: true, keyPress: true, item: 1, auto: true });
        } else {
            $("#content-slider4").lightSlider({ loop: true, keyPress: true, item: 3, auto: true });
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider5").lightSlider({ loop: true, keyPress: true, item: 1, auto: true });
        } else {
            $("#content-slider5").lightSlider({ loop: true, keyPress: true, item: 2, auto: false });
        }
    });
    $(document).ready(function () {
        if (pageName != "home") {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                $("#content-slider6").lightSlider({ loop: true, keyPress: true, item: 1.5, auto: false, pager: false, controls: true });
            } else {
                $("#content-slider6").lightSlider({ loop: true, keyPress: true, item: 3, auto: false, pager: false, controls: true });
            }
        } else {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                $("#content-slider6").lightSlider({ loop: true, keyPress: true, item: 1, auto: false, pager: false, controls: true });
            } else {
                $("#content-slider6").lightSlider({ loop: true, keyPress: true, item: 1, auto: false, pager: false, controls: true });
            }
        }
    });
    $(document).ready(function () {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $("#content-slider7").lightSlider({ loop: true, keyPress: true, item: 2, auto: false });
        } else {
            $("#content-slider7").lightSlider({ loop: true, keyPress: true, item: 6, auto: false });
        }
    });
}
function show_data() {
    var filter_selected = document.getElementById("filter").value;
    if (filter_selected == "all") {
        $("#default_disp").show();
        $("#default_disp2").show();
        $("#default_disp3").show();
        $("#on_change").hide();
        $("#on_change2").hide();
        $("#on_change3").hide();
    } else {
        $("#default_disp").hide();
        $("#on_change").show();
        $("#default_disp2").hide();
        $("#on_change2").show();
        $("#default_disp3").hide();
        $("#on_change3").show();
        $.ajax({
            url: baseurl + "utility/homeajax.php?chk_filtr=1",
            cache: true,
            data: { filter_selected: filter_selected },
            type: "post",
            success: function (data) {
                var filter = JSON.parse(data);
                $.each(filter.data, function (i, item) {
                    $("#on_change").html(item.present_mnth_array);
                    $("#on_change2").html(item.next_mnth_array);
                    $("#on_change3").html(item.last_mnth_array);
                });
            },
            error: function () {},
        });
    }
}
function shuffle(array) {
    var currentIndex = array.length,
        temporaryValue,
        randomIndex;
    while (0 !== currentIndex) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    return array;
}
function searchReq() {
    var main_clause = "";
    var place_to = "";
    countertext = "";
    if (typeof document.getElementById("to") != undefined && document.getElementById("to") != null) {
        place_to = document.getElementById("to").value;
    }
    if (typeof document.getElementById("to1") != undefined && document.getElementById("to1") != null) {
        countertext = "1";
        place_to = document.getElementById("to1").value;
    }
    if (place_to != "" && !place_to.match(/^[a-zA-z0-9\s-_.,]+$/)) {
        document.getElementById("to" + countertext).focus();
        alert("Please enter valid destination");
        return false;
    }
    place_to = place_to.toLowerCase();
    if (place_to != "" && place_to != "Where do you want to go") {
        var place_to_modified = place_to.replace(/\s*[,]+\s*/gi, "-s-");
        place_to_modified = place_to_modified.replace(/[\s]+/gi, "-");
        document.location = "https://www.hellotravel.com/deals/" + place_to_modified;
    }
    return false;
}
function searchReq2222() {
    var main_clause = "";
    var place_to = "";
    place_to = document.getElementById("to").value;
    if (document.getElementById("to").value == "") {
        place_to = document.getElementById("to1").value;
    }
    if (place_to != "" && !place_to.match(/^[a-zA-z0-9\s-_.,]+$/)) {
        document.getElementById("to").focus();
        alert("Please enter valid destination");
        return false;
    }
    place_to = place_to.toLowerCase();
    if (place_to != "" && place_to != "Where do you want to go") {
        var place_to_modified = place_to.replace(/\s*[,]+\s*/gi, "-s-");
        place_to_modified = place_to_modified.replace(/[\s]+/gi, "-");
        document.location = "https://www.hellotravel.com/deals/" + place_to_modified;
    }
}
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function BrowserBackDetection() {
    var curr_page_url;
    var response;
    if (typeof history.pushState === "function") {
        history.pushState("jibberish", null, null);
        window.onpopstate = function () {
            history.pushState("newjibberish", null, null);
            curr_page_url = window.location.href;
            RedirectToWhere(curr_page_url);
        };
    } else {
        var ignoreHashChange = true;
        window.onhashchange = function () {
            if (!ignoreHashChange) {
                ignoreHashChange = true;
                window.location.hash = Math.random();
            } else {
                ignoreHashChange = false;
            }
        };
    }
}
function RedirectToWhere(pageUrl) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            response = xmlhttp.responseText;
            if (response != "") {
                document.getElementById("ajaxdata").innerHTML = response;
                document.getElementById("datalike").style.display = "block";
                sessionStorage.removeItem("page");
            }
        }
    };
    xmlhttp.open("GET", "/hellotravel/callback-ajax.php?pageUrl=" + pageUrl, true);
    xmlhttp.send();
}
function showHide() {
    if (document.getElementById("menu").style.display == "block") {
        document.getElementById("menu").style.display = "none";
        $("#sub-cat").show();
        $("body").click(function (e) {
            if (e.target.id != "holiday_sh" && !$(event.target).hasClass("mai_f1")) $("#menu").hide();
        });
    } else {
        document.getElementById("menu").style.display = "block";
        $("#sub-cat").show();
        $("body").click(function (e) {
            if (e.target.id != "holiday_sh" && !$(event.target).hasClass("mai_f1")) $("#menu").hide();
        });
    }
}
function popupCenter(url, title, w, h) {
    var left = screen.width / 2 - w / 2;
    var top = screen.height / 2 - h / 2;
    return window.open(url, title, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=" + w + ", height=" + h + ", top=" + top + ", left=" + left);
}

$(document).ready(function () {
    if (a != "") {
        if (a.indexOf(homeurl) == -1 && a.split("/")[2].slice(a.split("/")[2].indexOf(".") + 1) != "hellotravel.com" && window.performance.navigation.type == 0 && window.location.href != homeurl) {
            history.pushState("", "", window.location.href),
                (window.onpopstate = function () {
                    if (history.state != "" && history.state != "forward" && history.state != "forward1" && location.hash == "") {
                        sessionStorage.setItem("flag", 1), window.location.replace(homeurl);
                    }
                });
        } else {
            if (
                a.indexOf(homeurl) == -1 &&
                a.split("/")[2].slice(a.split("/")[2].indexOf(".") + 1) != "hellotravel.com" &&
                (window.performance.navigation.type == 2 || window.performance.navigation.type == 1) &&
                window.location.href != homeurl
            ) {
                window.onpopstate = function () {
                    if (history.state != "" && history.state != "forward" && history.state != "forward1" && location.hash == "") {
                        sessionStorage.setItem("flag", 1), window.location.replace(homeurl);
                    }
                };
            }
        }
    } else {
        if (a.indexOf(homeurl) == -1 && window.performance.navigation.type == 0 && window.location.href != homeurl) {
            history.pushState("", "", window.location.href),
                (window.onpopstate = function () {
                    if (history.state != "" && history.state != "forward" && history.state != "forward1" && location.hash == "") {
                        sessionStorage.setItem("flag", 1), window.location.replace(homeurl);
                    }
                });
        } else {
            if (a.indexOf(homeurl) == -1 && (window.performance.navigation.type == 2 || window.performance.navigation.type == 1) && window.location.href != homeurl) {
                window.onpopstate = function () {
                    if (history.state != "" && history.state != "forward" && history.state != "forward1" && location.hash == "") {
                        sessionStorage.setItem("flag", 1), window.location.replace(homeurl);
                    }
                };
            }
        }
    }
    if (sessionStorage.getItem("flag") == 1 && (window.performance.navigation.type == 0 || window.performance.navigation.type == 255) && window.location.href == homeurl) {
        history.pushState("", "", window.location.href), sessionStorage.setItem("flag", 0);
        window.onpopstate = function () {
            if (window.performance.navigation.type == 255) {
                if (history.state != "" && location.hash == "") {
                    sessionStorage.removeItem("flag"), history.go(-2);
                }
            } else {
                if (history.state != "" && history.state != "forward" && history.state != "forward1" && location.hash == "") {
                    sessionStorage.removeItem("flag"), history.go(-1);
                }
            }
        };
    } else {
        if (sessionStorage.getItem("flag") == 0 && (window.performance.navigation.type == 2 || window.performance.navigation.type == 1) && window.location.href == homeurl) {
            window.onpopstate = function () {
                if (history.state != "" && location.hash == "") {
                    sessionStorage.removeItem("flag"), history.go(-1);
                }
            };
        }
    }
});

function getUserIP(onNewIP) {
    var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
    var pc = new myPeerConnection({ iceServers: [] }),
        noop = function () {},
        localIPs = {},
        ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
        key;
    function iterateIP(ip) {
        if (!localIPs[ip]) onNewIP(ip);
        localIPs[ip] = true;
    }
    pc.createDataChannel("");
    pc.createOffer().then(function (sdp) {
        sdp.sdp.split("\n").forEach(function (line) {
            if (line.indexOf("candidate") < 0) return;
            line.match(ipRegex).forEach(iterateIP);
        });
        pc.setLocalDescription(sdp, noop, noop);
    });
    pc.onicecandidate = function (ice) {
        if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
        ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
    };
}
function closebtn() {
    check = true;
    $(".bottomRecent").hide();
    no_history = 1;
    if (typeof Storage !== "undefined") {
        sessionStorage.setItem("closebutton", no_history);
    }
}
function sendUserdata(pageobject) {
    var http = new XMLHttpRequest();
    var url = baseurl + "utility/header_ajax.php";
    var ajxleadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var userip = "";
    if (typeof Storage !== "undefined") {
        userip = localStorage.getItem("userip");
    }
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        var device_type = "mobile";
    } else {
        var device_type = "desktop";
    }
    var params =
        "pageval=" +
        pageobject.pageval +
        "&pageurl=" +
        pageobject.pageurl +
        "&pagetitle=" +
        pageobject.pagetitle +
        "&pagestart=" +
        pageobject.pagestart +
        "&pageend=" +
        pageobject.pageend +
        "&searchterm=" +
        pageobject.searchterm +
        "&savehistorty=savehistorty&ajxleadval=" +
        ajxleadval +
        "&ajxloginvalue=" +
        ajxloginvalue +
        "&userip=" +
        userip +
        "&referrer=" +
        referrer +
        "&pageid=" +
        pageid +
        "&device_type=" +
        device_type;
    http.open("POST", url, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.onreadystatechange = function () {
        if (http.readyState == 4 && http.status == 200) {
        }
    };
    http.send(params);
}
function image_popup(lead, image_name) {
    var lead_id = lead;
    var imageName = image_name;
    var docHeight = $(document).height();
    var scrollTop = $(window).scrollTop();
    var selectedPopup = $(this).data("showpopup");
    $("#hellodiv").show().css({ height: docHeight });
    $(".popup1").show();
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        $(".overlay-content").css({ top: scrollTop + 20 + "px" });
    }
    $("#p_slide").show();
    $("#pop_review").html("");
    $("#pop_review").append('<div style="margin-top:30%;" align="center" id="pop_loading"><img src="/hellotravel/images/loader.gif" width="80"></div>');
    $.ajax({
        url: "popup_image_ajx.php",
        data: { lead_id: lead_id, image_name: imageName },
        type: "post",
        success: function (data) {
            $("#pop_review").html("");
            $("#pop_loading").hide();
            $("#pop_review").append(data);
        },
        error: function () {
            alert("Photos are not uploaded.Please try again");
        },
    });
}
function check_email() {
    var mail = document.getElementById("e_mailPop").value;
    var reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (!mail) {
        alert("Please enter email address!");
        document.getElementById("e_mailPop").focus();
        return false;
    }
    if (!reg.test(mail)) {
        alert("You have entered an invalid email address!");
        document.getElementById("e_mailPop").focus();
        return false;
    }
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        data: { e_mailPop: mail },
        type: "POST",
        cache: false,
        success: function (data) {
            location.reload();
        },
    });
}
function myTimer() {
    var curr_time = Math.round(new Date().getTime() / 1e3);
    if (curr_time >= get_120 && pop_show == 0) {
        $("#lpop").show();
        $("html,body").css({ overflow: "hidden", height: "hidden" });
        $(".close_1").click(function () {
            $("#lpop").hide();
            $("html,body").css({ overflow: "auto", height: "auto" });
        });
        document.addEventListener("keyup", function (e) {
            if (e.keyCode == 27) {
                $("#lpop").hide();
                $("html,body").css({ overflow: "auto", height: "auto" });
            }
        });
        clearInterval(myVar);
        document.cookie = "popup_shown=1; path=/";
    }
}
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
function youmaylike() {
    if (typeof Storage !== "undefined") {
        var data = localStorage.getItem("serachdata");
        data = data.replace("&amp;", "and");
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                response = JSON.parse(xmlhttp.responseText);
                if (response != "") {
                    if (response.status) {
                        var itemno = 5;
                        try {
                            if (typeof document.getElementById("datalikenew") != "undefined" && document.getElementById("datalikenew") != null) {
                                document.getElementById("datalikenew").innerHTML = "";
                                document.getElementById("datalikenew").innerHTML = response.content;
                                document.getElementById("datalikenew").style.display = "block";
                            }
                            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                                itemno = 2;
                                if (response.page == "deal") {
                                    itemno = 1;
                                } else if (response.page == "events_detail") {
                                    itemno = 1.5;
                                }
                                $("#content-slider35").lightSlider({ loop: false, keyPress: true, item: itemno, pager: false, auto: false });
                            } else {
                                itemno = 5;
                                if (response.page == "deal") {
                                    itemno = 3;
                                } else if (response.page == "events_detail") {
                                    itemno = 3;
                                }
                                $("#content-slider35").lightSlider({ loop: false, keyPress: true, item: itemno, pager: false, auto: false });
                            }
                        } catch (error) {
                            console.log(error);
                        }
                    }
                }
            }
        };
        var json_upload = "pagename=" + pageval + "&getlike=yes&data=" + data;
        xmlhttp.open("POST", baseurl + "utility/youmaylike.php");
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send(json_upload);
    }
}
function detectmob() {
    if (
        navigator.userAgent.match(/Android/i) ||
        navigator.userAgent.match(/webOS/i) ||
        navigator.userAgent.match(/iPhone/i) ||
        navigator.userAgent.match(/iPad/i) ||
        navigator.userAgent.match(/iPod/i) ||
        navigator.userAgent.match(/BlackBerry/i) ||
        navigator.userAgent.match(/Windows Phone/i)
    ) {
        return true;
    } else {
        return false;
    }
}
function getCountrycodec() {
    var e = document.getElementById("country_listpop");
    var strUser = e.options[e.selectedIndex].value;
    var dataarray = strUser.split("_");
    document.getElementById("country_codepop").value = "+" + dataarray[1];
    if (dataarray[1] == "91") {
        document.getElementById("user_emailpop").style.display = "none";
    } else {
        document.getElementById("user_emailpop").style.display = "block";
    }
}
function getcounrtyc() {
    if (typeof document.getElementById("country_listpop") != "undefined" || typeof document.getElementById("leadjrny2_country_list") != "undefined") {
        var timevar = new Date().getTime();
        var q = "get_isd_code_lits=1&" + timevar;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                response = xmlhttp.responseText;
                if (response != "") {
                    objcon = jQuery.parseJSON(response);
                    if (typeof document.getElementById("country_listpop") != "undefined") {
                        $("#country_listpop").empty();
                        $("#country_listpop").append(objcon.OPT);
                    }
                    if (typeof document.getElementById("leadjrny2_country_list") != "undefined") {
                        $("#leadjrny2_country_list").empty();
                        $("#leadjrny2_country_list").append(objcon.OPT);
                    }
                }
            }
        };
        xmlhttp.open("GET", "https://www.hellotravel.com/serveform/inc/ajax-call.php?" + q, true);
        xmlhttp.send();
    }
}
function getisdcodec() {
    if (typeof document.getElementById("country_listpop") != "undefined" || typeof document.getElementById("leadjrny2_country_list") != "undefined") {
        var timevar = new Date().getTime();
        var q = "isd_code&form_fr_country=&form_lang=en&" + timevar;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                response = xmlhttp.responseText;
                if (response != "") {
                    if (typeof document.getElementById("country_listpop") != "undefined") {
                        $("#country_codepop").val("");
                        $("#country_codepop").val(response);
                    }
                    if (typeof document.getElementById("leadjrny2_country_list") != "undefined") {
                        $("#leadjrny2_country_code").val("");
                        $("#leadjrny2_country_code").val(response);
                    }
                }
            }
        };
        xmlhttp.open("GET", "https://www.hellotravel.com/serveform/inc/ajax-call.php?" + q, true);
        xmlhttp.send();
    }
}
callonloadfn();
function callonloadfn() {
    if (pageName == "events_detail") {
        youmaylike();
        getQuestionAns(page_type, page_id);
    }
}
if (pageName == "story") {
    var contentslider15;
    $(document).ready(function () {
        $("#content-slider").lightSlider({ loop: true, keyPress: true });
        $("#image-gallery").lightSlider({
            gallery: true,
            item: 1,
            thumbItem: 9,
            slideMargin: 0,
            speed: 500,
            auto: false,
            loop: true,
            onSliderLoad: function () {
                $("#image-gallery").removeClass("cS-hidden");
            },
        });
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".slider18").lightSlider({ loop: false, keyPress: true, item: 2.2, pager: false, auto: false });
        } else {
            $(".slider18").lightSlider({ loop: false, keyPress: true, item: 5, pager: false, auto: false });
        }
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".slider19").lightSlider({ loop: false, keyPress: true, item: 1.5, pager: false, auto: false });
        } else {
            $(".slider19").lightSlider({ loop: false, keyPress: true, item: 3, pager: false, auto: false });
        }
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            contentslider15 = $("#content-slider15").lightSlider({
                loop: true,
                keyPress: true,
                item: 1,
                pager: false,
                auto: false,
                slideMove: 1,
                onAfterSlide: function () {
                    show_photo_popup("1", "");
                },
            });
        } else {
            contentslider15 = $("#content-slider15").lightSlider({
                loop: true,
                keyPress: true,
                item: 1,
                pager: false,
                auto: false,
                slideMove: 1,
                onAfterSlide: function () {
                    show_photo_popup("2", "");
                },
            });
        }
    });
}
function show_photo_popup(type, data) {
    var photo_slider = data;
    var counter = 1;
    for (var i = 0; i < photo_slider_div.length; i++) {
        id_counter = i + 2;
        if (counter <= 5) {
            if (typeof photo_slider_div[i]["image"] != "undefined" && photo_slider_div[i]["status_pop_img"] != 1) {
                if (type == "1") {
                    var imagepath = photo_slider_div[i]["image"];
                } else {
                    var imagepath = photo_slider_div[i]["image"];
                }
                var imagename = photo_slider_div[i]["image_name"];
                photo_slider_div[i]["status_pop_img"] = 1;
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                    photo_slider +=
                        "<li class='testimages'><a href='javascript:void(0)'  class='carousel'  style='text-decoration:none'><div class='box_card boxc_higt'> <div class='p_r story_img_1' ><img alt=''  src='" +
                        imagepath +
                        "' /></div></div></a></li>";
                } else {
                    photo_slider +=
                        "<li class='testimages'><a href='javascript:void(0)'  class='carousel'  style='text-decoration:none'><div class='box_card boxc_higt'> <div class='p_r story_img_1' ><img alt='' src='" +
                        imagepath +
                        "' /></div></div></a></li>";
                }
                counter++;
            }
        }
    }
    if (photo_slider != "") {
        $("#content-slider15").append(photo_slider);
        contentslider15.refresh();
    }
}
function image_pop_story(image_mb, id) {
    var nextSlide = 0;
    $("li.liactive").each(function () {
        if ($(this).hasClass("active")) {
            liId = $(this).attr("id").split("_");
            lang = $(this).attr("lang");
            if (lang == "image") {
                image_mb = $(this).attr("data-thumb");
                nextSlide = liId[1];
            } else if (lang == "video") {
                nextSlide = parseInt(liId[1]) + parseInt(1);
                image_mb = $("#slider_" + nextSlide).attr("data-thumb");
                console.log(image_mb + "======================#slider_" + nextSlide);
            }
        }
    });
}
function image_pop(image_mb, id) {
    var nextSlide = 0;
    if (image_mb == "click7" && pageName == "story") {
        $("li.liactive").each(function () {
            if ($(this).hasClass("active")) {
                liId = $(this).attr("id").split("_");
                lang = $(this).attr("lang");
                if (lang == "image") {
                    image_mb = $(this).attr("data-thumb");
                    nextSlide = liId[1];
                } else if (lang == "video") {
                    nextSlide = parseInt(liId[1]) + parseInt(1);
                    image_mb = $("#slider_" + nextSlide).attr("data-thumb");
                }
            }
        });
    }
    if (pageName != "fcp_home" && pageName != "fcp_package" && pageName != "fcpreviews" && pageName != "fcp_announcement" && pageName != "fcp_aboutus") {
        photo_slider_div = photos_slide[id];
    } else {
        photo_slider_div = photos_slide;
    }
    if (image_mb != "") {
        for (var i = 0; i < photo_slider_div.length; i++) {
            if (photo_slider_div[i]["image"] && photo_slider_div[i]["image"] == image_mb) {
                photo_slider_div[i]["status_pop_img"] = 1;
                break;
            }
        }
    }
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        contentslider15 = $("#content-slider15").lightSlider({
            loop: true,
            keyPress: true,
            item: 1,
            pager: false,
            auto: false,
            slideMove: 1,
            onAfterSlide: function () {
                show_photo_popup("1", "");
            },
        });
    } else {
        contentslider15 = $("#content-slider15").lightSlider({
            loop: true,
            keyPress: true,
            item: 1,
            pager: false,
            auto: false,
            slideMove: 1,
            onAfterSlide: function () {
                show_photo_popup("2", "");
            },
        });
    }
    $("#content-slider15").html("");
    contentslider15.refresh();
    var docHeight = $(document).height();
    var scrollTop = $(window).scrollTop();
    $("#hellodiv").show().css({ height: docHeight });
    $(".popup1").show();
    var photo_slider = "";
    if (image_mb != "") {
        for (var i = 0; i < photo_slider_div.length; i++) {
            if (photo_slider_div[i]["image"] && photo_slider_div[i]["image"] == image_mb) {
                photo_slider_div[i]["status_pop_img"] = 1;
            }
        }
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            if (pageName == "story") {
                $(".overlay-content").css({ top: 50 + "px" });
            } else {
                $(".overlay-content").css({ top: scrollTop + 20 + "px" });
            }
            photo_slider =
                "<li class='testimages'><a href='javascript:void(0)'  class='carousel'  style='text-decoration:none'><div class='box_card boxc_higt'> <div class='p_r story_img_1' ><img alt='' src='" + image_mb + "'/></div></div></a></li>";
            show_photo_popup("1", photo_slider);
        } else {
            photo_slider =
                "<li class='testimages'><a href='javascript:void(0)'  class='carousel'  style='text-decoration:none'><div class='box_card boxc_higt'> <div class='p_r story_img_1' ><img alt='' src='" + image_mb + "' /></div></div></a></li>";
            show_photo_popup("2", photo_slider);
        }
    } else {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            show_photo_popup("1", "");
        } else {
            show_photo_popup("2", "");
        }
    }
}
$(document).ready(function () {
    $(".rand_img").each(function () {
        $(this).css("background-color", getRandomColor());
    });
});
function getRandomColor() {
    var letters = "0123456789ABCDEF";
    var color = "#";
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
function sidebar(readid) {
    $("#subread_" + readid + "_show").removeClass("sidebar-box");
    $("#subread_" + readid + "_hide").hide();
}
$(document).ready(function () {
    var $el, $ps, $up, totalHeight;
});
$(document).ready(function () {
    $(".close-btn1").click(function () {
        $("#content-slider15").html("");
        $("#content-slider15").empty();
        contentslider15.refresh();
        if (pageName != "story") {
            $(".lSPager").remove();
        }
        $(".overlay-bg, .overlay-content").hide();
        for (var i = 0; i < photo_slider_div.length; i++) {
            photo_slider_div[i]["status_pop_img"] = 0;
        }
    });
    $(".overlay-bg").click(function () {
        if (typeof customform != "undefined" && customform == "1") {
            $(".overlay-bg, .overlay-content").hide();
        } else {
            $("#content-slider15").html("");
            $("#content-slider15").empty();
            contentslider15.refresh();
            $(".lSPager").remove();
            for (var i = 0; i < photo_slider_div.length; i++) {
                photo_slider_div[i]["status_pop_img"] = 0;
            }
            $(".overlay-bg, .overlay-content").hide();
        }
    });
    $(document).keyup(function (e) {
        if (e.which == 27) {
            $("#content-slider15").html("");
            $("#content-slider15").empty();
            contentslider15.refresh();
            $(".lSPager").remove();
            $("#hellodiv").hide();
            for (var i = 0; i < photo_slider_div.length; i++) {
                photo_slider_div[i]["status_pop_img"] = 0;
            }
            $(".overlay-bg, .overlay-content").hide();
        }
    });
    $(".overlay-content").click(function () {
        return false;
    });
});
function getQuestionAns(page_type, page_id) {
    if (page_type && page_id) {
        $.ajax({
            url: baseurl + "utility/quesandans.php",
            cache: false,
            data: { page_type: page_type, page_id: page_id },
            type: "post",
            success: function (data) {
                var response = JSON.parse(data);
                if (response.status) {
                    var html = "";
                    var z = "";
                    for (var i = 0; i < response.data.length; i++) {
                        if (i < 1) {
                            var arrowclass = "fa-angle-up";
                            var anshide = "";
                            if (ansid == response.data[i]["question_id"]) {
                                var z = "autofocus";
                            }
                        } else if (ansid == response.data[i]["question_id"]) {
                            var arrowclass = "fa-angle-up";
                            var anshide = "";
                            var z = "autofocus";
                        } else {
                            var arrowclass = "";
                            var anshide = "dnone";
                        }
                        var fristans = "";
                        var seemore = "";
                        var moreans = "";
                        if (response.data[i]["first_ans"] != "") {
                            fristans = "<div>" + response.data[i]["first_ans"] + "" + "<br/>" + '<span class="f12 c9">By ' + response.data[i]["traveler_name1"] + " on " + response.data[i]["time1"] + " </span>" + "</div>";
                        }
                        if (response.data[i]["ans_array"].length > 0) {
                            moreans += '<div class="mt1 sh" id="sh' + response.data[i]["question_id"] + '" style="display:none" >';
                            for (var j = 0; j < response.data[i]["ans_array"].length; j++) {
                                moreans +=
                                    response.data[i]["ans_array"][j]["ans"] + "" + "<br/>" + '<span class="f12 c9">By ' + response.data[i]["ans_array"][j]["traveler_name"] + " on " + response.data[i]["ans_array"][j]["time"] + " </span>";
                            }
                            moreans += "</div>";
                        }
                        if (response.data[i]["ans_array"].length > 0) {
                            seemore = '<div class="f12 mt1 seeM" data-id="' + response.data[i]["question_id"] + '"><a href="javascript:void(0);" id="seeM' + response.data[i]["question_id"] + '">See more answers &raquo;</a></div>';
                        }
                        html +=
                            '   <div class="mt15 bb1 pb15">  ' +
                            '       <div class="">   ' +
                            '       <div class="pnt ques">   ' +
                            '           <span class="c3 fl b w10_20">Q :</span>   ' +
                            '           <span class="c3 fl w80_70">' +
                            response.data[i]["ques"] +
                            "</span>   " +
                            '           <span class="fl c6 f22 w10 r"><i class="fa fa-angle-down upDn ' +
                            arrowclass +
                            '"></i></span>   ' +
                            '           <div class="cl"></div>   ' +
                            "           </div>   " +
                            '           <div class="mt1 ' +
                            anshide +
                            '  answ" style="">   ' +
                            '               <span class="c6 fl w10_20 f11 cn"> <a href="javascript:void(0);" class="likeq like_que" onclick="helpful(' +
                            response.data[i]["question_id"] +
                            "," +
                            response.data[i]["helpful_no"] +
                            ');"></a> <span class="c3" id="' +
                            response.data[i]["question_id"] +
                            '">' +
                            response.data[i]["helpful_no"] +
                            "</span><br> <span>Helpful</span>   " +
                            "               </span>   " +
                            '               <span class="c6 fl w90_80"> ' +
                            fristans +
                            " " +
                            moreans +
                            "" +
                            seemore +
                            " " +
                            '               <div class="mt1 place_filt">   ' +
                            '                   <input type="text" name="ans" id="ans_' +
                            response.data[i]["question_id"] +
                            '" placeholder="your answer" style="width:68%; border-radius:2px 0 0 2px" class="fl" ' +
                            z +
                            '><input type="submit" id="sbmt_ans_' +
                            response.data[i]["question_id"] +
                            '" data-qid="ans_' +
                            response.data[i]["question_id"] +
                            '" name="submit" value="Submit" style="width:32%;" onclick="submit_question(\'ans_' +
                            response.data[i]["question_id"] +
                            "','2'," +
                            page_id +
                            ",'" +
                            page_type +
                            "','" +
                            country_code +
                            "'); ga('send', 'event', 'Q&A', 'new-placestosee-detail','answer-submit-button');\"> " +
                            '<span id="load_ans_' +
                            response.data[i]["question_id"] +
                            '" style="background-color:#fff;cursor:pointer; border-radiu      s:0 2px 2px 0; color:      #fff; border:1px solid #ff8707; font-weight:bold; width:24%; text-align:center; padding:6px 8px; display:none;      " class="fl"><img src="https://www.hellotravel.com/images/ajax-loader2.gif"/></span>' +
                            '               <div class="cl"></div>  </div></span>' +
                            "           </div>   " +
                            "       </div>   " +
                            '       <div class="cl"></div>   ' +
                            "  </div>  ";
                    }
                    $("#morequestions").html(html);
                }
            },
            error: function () {},
        });
    }
}
function checkRating() {
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: false,
        data: { evt_id: page_id, tuid: uid_decoded_client, vid: vid_decoded_client, mode: "display_evt" },
        type: "post",
        success: function (data) {
            if (data.trim() != "1") {
                document.getElementById("feed_quest").style.display = "block";
            }
        },
        error: function () {},
    });
}
function getvalue_evt(place, city, quest) {
    var update_val_value = "";
    var dataid = [];
    $("#feed_quest").hide();
    $("#feed_quest input:radio").each(function (index) {
        if ($(this).prop("checked")) {
            var parentid = $(this).attr("name");
            var ques = $("#" + parentid)
                .find(".c3")
                .html();
            var ans = $(this).val();
            dataid.push({ ques: ques, ans: ans });
        }
    });
    console.log(dataid);
    $.ajax({
        url: "https://www.hellotravel.com/plc-reviews.php",
        cache: false,
        data: { update_val: JSON.stringify(dataid), tuid: uid_decoded_client, vid: vid_decoded_client, pts_id: page_id, page_type: "event_page" },
        type: "post",
        success: function (data) {},
        error: function () {},
    });
}
function helpful(id, val) {
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: true,
        data: { helpful: 1, id: id, val: val },
        type: "post",
        success: function (data) {
            $("#" + id).html(data);
        },
        error: function () {},
    });
}
function serach_logs(search_str) {
    var main_clause = "";
    var place_too = "";
    if (search_str == "mysearch") {
        place_too = document.getElementById("place_to").value;
        if (document.getElementById("place_to").value != "" && !document.getElementById("place_to").value.match(/^[a-zA-z0-9\s-_.,]+$/)) {
            return false;
        }
    } else {
        place_too = document.getElementById("to").value;
        if (document.getElementById("to").value != "" && !document.getElementById("to").value.match(/^[a-zA-z0-9\s-_.,]+$/)) {
            return false;
        }
    }
    place_too = place_too.toLowerCase();
    if (place_too != "" && place_too != "Where do you want to go") {
        $.ajax({ url: baseurl + "utility/header_ajax.php?type=search_log&search_log=" + place_too, cache: true, type: "post", success: function (data) {} });
    }
}
$("#datePick").datepicker({
    dateFormat: "dd-mm-yy",
    minDate: 0,
    maxDate: 120,
    onSelect: function (date) {
        $("#fxd1").removeClass("w98a");
        $("#fxd1").addClass("w49a");
        $("#datePick").removeClass("w98a");
        $("#datePick").addClass("w49a");
        var date_arr = date.split("-");
        if (date_arr[2] == undefined) {
        } else {
            date_str = date_arr[2] + "-" + date_arr[1] + "-" + date_arr[0];
            updateledvalue("TBL_LEAD_TRAVEL_DATE", date_str);
        }
        fixeddate = document.getElementById("datePick").style.display == "inline-block";
        if (fixeddate == true && fixeddate != "undefined") {
            fixeddateval = document.getElementById("datePick").value;
        }
    },
});
function leadproofing() {
    id = getCookie("leadproofingid");
    leadidarr = id.split(",");
    if (leadidarr.length > 10) {
        deleteCookie("leadproofingid");
        id = "";
    }
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        type: "post",
        data: { leadproofing: 1, form_version: 2, id: id },
        success: function (data) {
            data = JSON.parse(data);
            first_letter = data.first_letter;
            time = data.time;
            tbl_lead_name = data.TBL_LEAD_NAME;
            city = data.TBL_LEAD_CITY;
            destination = data.destination;
            tbl_leadid = data.tbl_lead_id;
            if (first_letter == "" || first_letter == null) {
                $("#leadproofing_fletter").html('<i class="fa fa-user"></i>');
            } else {
                $("#leadproofing_fletter").html(first_letter);
            }
            $("#leadproofingtime").html(time);
            if (tbl_lead_name == "" || tbl_lead_name == "undefined" || first_letter == null) {
                tbl_lead_name = "A Hellotraveller";
            }
            if (city == "" || city == "undefined" || city == "NA" || city == null) {
                $("#leadproofingpersoncity").html(tbl_lead_name);
            } else {
                $("#leadproofingpersoncity").html(tbl_lead_name + " from " + city);
            }
            $("#leadproofingdestination").html("planned a trip to " + destination + "!");
            $("#leadproofing").show();
            if (id != "") {
                cookieleadidvalue = id + "," + tbl_leadid;
            } else {
                cookieleadidvalue = tbl_leadid;
            }
            setCookieComb("leadproofingid", cookieleadidvalue);
            setTimeout(function () {
                $("#leadproofing").hide();
            }, 1e4);
        },
        error: function (err) {},
    });
}
$("#cl_leadproofing").click(function () {
    $("#leadproofing").hide();
});
function deleteCookie(cname) {
    var d = new Date();
    d.setTime(d.getTime() - 1e3 * 60 * 60 * 24);
    var expires = "expires=" + d.toGMTString();
    window.document.cookie = cname + "=" + "; " + expires;
}
function setCookieComb(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1e3);
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
var lead_journey_data = {};
function create_call_history(pns) {
    if (uid_client_feed != "") {
        var tuid = atob(uid_client_feed);
        if (tuid != "" && tuid != "0" && pns != "") {
            var param = "call_history=1&tuid=" + tuid + "&pns=" + pns;
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    console.log(this.responseText);
                }
            };
            var randam = new Date().getTime();
            xhttp.open("POST", baseurl + "utility/header_ajax.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send(param);
        }
    }
}
function logincheck(siachat) {
    var value = document.getElementById("usernamepop").value.trim();
    var country = document.getElementById("country_codepop").value;
    var country = $("#country_listpop").val();
    var countryiso = document.getElementById("country_isopop").value;
    var isnum = /^\d+$/.test(value);
    if (!isnum) {
        alert("Please enter valid mobile no");
        return false;
    }
    var isnumindia = /^[9,8,7,6,]+/.test(value);
    var result = country.split("!");
    if (result[1] == "IN" && !isnumindia) {
        alert("mobile no sholud be start with 9,8,7 or 6");
        return false;
    }
    if (result[1] == "IN" && value.length != 10) {
        alert("Length of mobile number should be 10.");
        return false;
    }
    if (document.getElementById("privacycheckpop") != null && document.getElementById("privacycheckpop") != "undefined" && !document.getElementById("privacycheckpop").checked) {
        alert("Please indicate that you agree to our privacy policy & terms of service");
        document.getElementById("privacycheckpop").focus();
        return false;
    } else {
        var q = "username=" + value + "&country=" + result[2] + "&newform=1&countryname=" + result[0] + "&isdcode=" + result[1];
        var xmlhttp = new XMLHttpRequest();
        $("#frm_login_pop_btn").hide();
        $("#from_login_loader1").show();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                try {
                    $("#frm_login_pop_btn").show();
                    $("#from_login_loader1").hide();
                    response = JSON.parse(xmlhttp.responseText);
                    if (response != "" && response.status == true) {
                        if (typeof tuid != "undefiend") {
                            tuid = response.datatuid;
                        }
                        $("#usernamepop_hidden").val(value);
                        $("#country_isopop_hidden").val(result[1]);
                        $("#country_codepop_hidden").val(result[2]);
                        $("#country_name_hidden").val(result[0]);
                        if (typeof loginredirect != "undefined" && loginredirect != "" && 1 == 2) {
                            location.replace(loginredirect);
                            window.location = "my_trips.php";
                        } else {
                        }
                        if (typeof siachat != "undefined" && siachat != "") {
                            var qidq = currques;
                            if (response.emailstatus) {
                                emailstatus = response.emailstatus;
                                currques = currques + 2;
                                qidq = currques - 2;
                            } else {
                                currques = currques + 1;
                                qidq = currques - 1;
                            }
                            tuid = response.datatuid;
                            showview("overviewid", url);
                            var obj = { mail_sentrec: "19", mail_content: value, tick: '<span class="cc5"><i class="fa fa-check mrl8"></i>' };
                            var dataarray = { data: obj };
                            var scrpithtml = document.getElementById("chatsingleid").innerHTML;
                            var scrpittemp = Handlebars.compile(scrpithtml);
                            var scriptmainhtml = scrpittemp(dataarray);
                            document.getElementById("chat").innerHTML += scriptmainhtml;
                            document.getElementById("message_content").value = "";
                            savechatans(value, qidq);
                            setloaderdiv();
                            setTimeout(getsiachat, 2e3);
                        } else {
                            var plan_type_for_login = $("#plan_type_for_login").val();
                            if (plan_type_for_login == 0) {
                                pass_form_ajax("force_hide", 1);
                            } else {
                                pass_form_ajax("hide_destination", 1);
                            }
                        }
                        return false;
                    }
                } catch (e) {
                    $("#frm_login_pop_btn").show();
                    $("#from_login_loader1").hide();
                }
            }
        };
        xmlhttp.open("GET", baseurl + "utility/header_ajax.php?" + q, true);
        xmlhttp.send();
    }
    return false;
}
function getCountrycode() {
    var e = document.getElementById("country_listpop");
    var strUser = e.options[e.selectedIndex].value;
    var dataarray = strUser.split("_");
    document.getElementById("country_codepop").value = "+" + dataarray[1];
    if (dataarray[1] == "91") {
        document.getElementById("user_emailpop").style.display = "none";
    } else {
        document.getElementById("user_emailpop").style.display = "block";
    }
}
function getcounrty() {
    if (typeof document.getElementById("country_listpop") != "undefined") {
        var timevar = new Date().getTime();
        var q = "get_isd_code_lits=1&" + timevar;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                response = xmlhttp.responseText;
                if (response != "") {
                    objcon = jQuery.parseJSON(response);
                    $("#country_listpop").empty();
                    $("#country_listpop").append(objcon.OPT);
                }
            }
        };
        xmlhttp.open("GET", "https://www.hellotravel.com/serveform/inc/ajax-call.php?" + q, true);
        xmlhttp.send();
    }
}
function getisdcode() {
    if (typeof document.getElementById("country_listpop") != "undefined") {
        var timevar = new Date().getTime();
        var q = "isd_code&form_fr_country=&form_lang=en&" + timevar;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                response = xmlhttp.responseText;
                if (response != "") {
                    $("#country_codepop").val("");
                    $("#country_codepop").val(response);
                }
            }
        };
        xmlhttp.open("GET", "https://www.hellotravel.com/serveform/inc/ajax-call.php?" + q, true);
        xmlhttp.send();
    }
}
function validate_otp(skyp_otp) {
    var value = document.getElementById("usernamepop_hidden").value.trim();
    var country = document.getElementById("country_isopop_hidden").value;
    var otp = document.getElementById("login_frm_otp").value;
    var nid = document.getElementById("login_nid").value;
    var agent_id = document.getElementById("login_agent_login_id").value;
    var email = document.getElementById("login_frm_emailid").value;
    var destination = document.getElementById("login_frm_destination_id").value;
    var booking = document.getElementById("booking_val").value;
    var otp_state_val = $("#otp_state_hidden").val();
    var leadval = getCookie("leadvalue");
    var cookieleadid = "";
    if (typeof leadval != "undefined" && leadval != "") {
        cookieleadid = atob(leadval);
    }
    var type = "";
    if ((nid > 0 && nid != "") || destination != "") {
        type = "plan";
    }
    var is_visible_dest = document.getElementById("login_frm_destination_id").style.display == "block";
    if (destination == "" && is_visible_dest == true) {
        alert("Please enter destination.");
        return false;
    }
    var is_visible_email = document.getElementById("login_frm_emailid").style.display == "block";
    email_status = validateEmail(email);
    if (is_visible_email == true && (email == "" || email_status == false)) {
        alert("Please enter email id.");
        return false;
    }
    var is_visible_otp = document.getElementById("login_frm_otp").style.display == "block";
    var is_visible_otp_blank = document.getElementById("login_frm_otp").style.display == "";
    if (otp == "" && (is_visible_otp == true || is_visible_otp_blank == true) && skyp_otp == 0) {
        alert("Please enter otp.");
        return false;
    }
    $("#otpsubmit").hide();
    $("#from_login_loader2").show();
    var pagesource = "";
    if (typeof pageval != "undefined" && pageval != 0) {
        pagesource = pageval;
    }
    var pageaffid = 1044;
    if (typeof assaffid != "undefined" && assaffid != 0) {
        pageaffid = assaffid;
    }
    $.ajax({
        url: baseurl + "utility/header_ajax.php?",
        cache: false,
        data: {
            otp_state: otp_state_val,
            username: value,
            country: country,
            otp: otp,
            email_id: email,
            validateotp: 1,
            destination: destination,
            nid: nid,
            agent_id: agent_id,
            type: type,
            self_url: pop_self_url,
            ref_url: pop_referer_url,
            skyp_otp: skyp_otp,
            pagesource: pagesource,
            pageaffid: pageaffid,
            leadaffid: pageaffid,
            booking: booking,
        },
        type: "post",
        success: function (data) {
            $("#otpsubmit").show();
            $("#from_login_loader2").hide();
            $("#login_frm_otp").css("display", "block");
            var filter = JSON.parse(data);
            if (filter.status == 1) {
                var redirect_type = $("#redirect_type").val();
                if (redirect_type == "feedback") {
                    var feedback_ques_id = $("#feedback_ques_id").val();
                    var questiondatas = JSON.parse(feedback_ques_id);
                    submitdata(questiondatas);
                    $("#feedback_ques_id").val("");
                    $("#redirect_type").val("");
                } else if (redirect_type == "plc_feed") {
                    var feedback_ques_id = $("#frm_redirect_url").val();
                    $("#frm_redirect_url").val("");
                    var win = window.open(feedback_ques_id);
                } else if (redirect_type == "ttd_feed") {
                    $("#brow").show();
                } else if (redirect_type == "deals_book") {
                    username = value;
                    userloginemail = filter.email_id;
                    userlogincontact = filter.contact_no;
                    uid_client_dec = filter.tuid;
                    $("#lpop").hide();
                    book_amount_submit();
                } else if (redirect_type == "pns") {
                    var feedback_ques_id = $("#frm_redirect_url").val();
                    $("#frm_redirect_url").val("");
                    window.location = "tel:" + feedback_ques_id;
                } else {
                    location.reload();
                }
            } else if (filter.status == 2) {
                $("#otp_state_hidden").val(2);
                $("#login_frm_otp").val("");
                $("#newotpdiv").css("display", "block");
                $("#login_frm_otp").css("display", "block");
                otp_data = filter.data.OTP;
                $("#mobileotpmask").html(filter.message);
            } else if (filter.status == 3) {
                var lead_data = filter.lead_data;
                lead_id = lead_data.lead_id;
                trans = lead_data.trans;
                $("#login_nid").val("");
                $("#login_frm_destination_id").val("");
                $("#login_agent_login_id").val("");
                $("#lpop").hide();
                lead_id = lead_id;
                validateleadbylogin(lead_id, trans);
                var redirect_type = $("#redirect_type").val();
                $("#redirect_type").val("");
                if (redirect_type == "pns") {
                    var feedback_ques_id = $("#frm_redirect_url").val();
                    $("#frm_redirect_url").val("");
                    $("#redirect_type").val("");
                    feedback_ques_id_class = feedback_ques_id;
                    feedback_ques_id_class = feedback_ques_id_class.replace("+", "");
                    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                        $("." + feedback_ques_id_class + "_hide").hide();
                        $("." + feedback_ques_id_class + "_show").show();
                        if (skyp_otp == 1) {
                            $("." + feedback_ques_id_class + "_show").html('* You have been connected with more agents.<br/> <a href="https://www.hellotravel.com/thanks_new.php?lid="' + lead_id + '">See details</a>');
                        } else {
                            $("." + feedback_ques_id_class + "_show").html(
                                '* You have been connected with more agents.<br/> <a href="https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid="' + lead_id + '">See details</a>'
                            );
                        }
                    } else {
                        $("." + feedback_ques_id_class + "_hide").hide();
                        $("." + feedback_ques_id_class + "_show").show();
                    }
                    window.location = "tel:" + feedback_ques_id;
                } else {
                    $("#redirect_type").val("");
                    $("#frm_redirect_url").val("");
                    if (booking == "1") {
                        username = value;
                        userloginemail = filter.email_id;
                        userlogincontact = filter.contact_no;
                        uid_client_book = filter.tuid;
                        document.getElementById("booking_leadid").value = lead_id;
                        book_amount_submit();
                    } else {
                        if (skyp_otp == 1) {
                            window.location = "https://www.hellotravel.com/thanks_new.php?lid=" + lead_id;
                        } else {
                            window.location = "https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + lead_id;
                        }
                    }
                }
            } else if (filter.status == 0) {
                $("#mobileotpmask").html(filter.message);
            } else {
                $("#mobileotpmask").html(otp_data.msg);
            }
        },
        error: function () {
            $("#otpsubmit").show();
            $("#from_login_loader2").hide();
        },
    });
}
function pass_form_ajax(destination_flag, fromlogin) {
    var q = "passformm=1";
    var nid = $("#login_nid").val();
    var xmlhttp = new XMLHttpRequest();
    $("#otp_state_hidden").val("1");
    $("#poptext").html("Last step..!");
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            try {
                response = JSON.parse(xmlhttp.responseText);
                if (response != "" && response.status == true) {
                    var object = response.user_data;
                    $("#mobileotpmask").html(response.msg);
                    var dest = $("#login_frm_destination_id").val();
                    if (dest == "!!") {
                        dest = "";
                        $("#login_frm_destination_id").val("");
                    }
                    if (
                        destination_flag == "force_hide" ||
                        nid != "" ||
                        ((pageval == "things_2see_detail" || pageval == "things_2see_detail" || pageval == "destination_detail" || pageval == "events_detail" || pageval == "events" || pageval == "things_2_see") && dest != "")
                    ) {
                        $("#login_frm_destination_id").css("display", "none");
                        $("#login_frm_destination_div").css("display", "none");
                        $("#newotpdiv").css("display", "block");
                    } else {
                        $("#login_frm_destination_id").css("display", "block");
                        $("#login_frm_destination_div").css("display", "block");
                        var destination_text = $("#login_frm_destination_id").val();
                        destination_text = destination_text.replace(/\!/g, ",");
                        destination_text = destination_text.replace(/(^,)|(,$)/g, "");
                        if (destination_text == ",") {
                            destination_text = "";
                        }
                        var destination_array = destination_text.split(",");
                        if (pageName != "home") {
                            $("#login_frm_destination_id").val(destination_array[0]);
                        } else {
                            $("#login_frm_destination_id").val(destination_text);
                        }
                        $("#newotpdiv").css("display", "block");
                    }
                    if (object.EMAIL_ID != "" && object.EMAIL_ID != null) {
                        $("#login_frm_emailid").val(object.EMAIL_ID);
                        $("#login_frm_emailid").css("display", "none");
                        $("#login_frm_email_div").css("display", "none");
                        $("#newotpdiv").css("display", "block");
                        $("#login_frm_otp").css("display", "block");
                    } else {
                        var emailid = $("#login_frm_emailid").val();
                        if (object.COUNTRYCODE != "IN") {
                            $("#newotpdiv").css("display", "none");
                            $("#login_frm_otp").css("display", "none");
                        } else {
                            $("#newotpdiv").css("display", "block");
                            $("#login_frm_otp").css("display", "block");
                        }
                        if (emailid != "") {
                            $("#login_frm_otp").css("display", "block");
                        }
                        $("#login_frm_emailid").css("display", "block");
                        $("#login_frm_email_div").css("display", "block");
                    }
                    $("#usernamepop_hidden").val(object.LOGIN_ID);
                    $("#country_isopop_hidden").val(object.COUNTRYCODE);
                    $("#country_codepop_hidden").val(object.MCOUNTRY_CODE);
                    $("#country_name_hidden").val(object.COUNTRYNAME);
                    $("#destinationsubmit").prop("disabled", true);
                    $("#destinationsubmit").css("display", "none");
                    $("#otpsubmit").prop("disabled", false);
                    $("#otpsubmit").css("display", "block");
                    $("#destinationsubmit").css("display", "none");
                    $("#otpsubmitspan").css("display", "block");
                    if (fromlogin == 1) {
                        $("#login_frm_otp").val("");
                        $("#otpfrmmob").removeClass("dnone");
                        $("#loginfrmmob").addClass("dnone");
                        $("#lpop").hide();
                        $("#lpop").show();
                        $("#resend_skip_otp").hide();
                        $("#skip").hide();
                        setTimeout(function () {
                            $("#resend_skip_otp").show();
                        }, 1e4);
                    } else {
                        $("#login_frm_otp").val("");
                        $("#resend_skip_otp").hide();
                        $("#skip").hide();
                        $("#lpop").show();
                        setTimeout(function () {
                            $("#resend_skip_otp").show();
                        }, 1e4);
                    }
                }
            } catch (e) {}
        }
    };
    xmlhttp.open("GET", baseurl + "utility/header_ajax.php?" + q, true);
    xmlhttp.send();
}
function open_login_popup(args, destination_flag) {
    redirect_page = args;
    var args = { action: "login", "redirect-type": "login", "redirect-url": args };
    open_login_popup_plan(args);
}
function clearnewleadjourney() {}
function open_login_popup_plan(args) {
    $(".closejuurneydiv").hide();
    var action = "";
    if (args.displayid != "" && args.displayid != undefined) {
        lead_journey_data.displayid = args.displayid;
    } else {
        lead_journey_data.displayid = "";
    }
    if (args.action != null && args.action != "undefined" && args.action != "") {
        action = args.action;
        lead_journey_data.actionurl = action;
        if (lead_journey_data.actionurl == "pns") {
            lead_journey_data.pnsid = args.pnsnumber;
        }
        if (action == "deals") {
            action = "nid";
        }
    } else {
        args.actionurl = "";
        action = "";
        lead_journey_data.action = action;
    }
    if (args.action == "login") {
        var ajxloginvalue = getCookie("loginvalue");
        var ajxpassvalue = getCookie("userpass");
        if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
            if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "") {
                location.reload();
            } else {
                resend_otp();
                $("#lpop").show();
                $("#stp7h").show();
                $("#stp7").show();
                $("#mobileotp0").focus();
            }
        } else {
            $("#lpop").show();
            $("#stp6h").show();
            $("#stp6").show();
            $("#usernamepop").focus();
        }
        return;
    } else if (args.action == "otp") {
        $("#lpop").show();
        $("#stp7h").show();
        $("#stp7").show();
        $("#mobileotp0").focus();
        return;
    } else if (args.agent_id != null && args.agent_id != "undefined" && args.agent_id != "") {
        lead_journey_data.agent_id = args.agent_id;
        if (args.nid != null && args.nid != "undefined" && args.nid != "") {
            lead_journey_data.nid = args.nid;
        }
    }
    $("#stp1").hide();
    $("#stp2").hide();
    $("#stp1h").hide();
    $("#stp2h").hide();
    $("#stp3").hide();
    $("#stp3h").hide();
    $("#stp2date").hide();
    $("#stp4").hide();
    $("#stp4h").hide();
    if ((lead_journey_data.action == "deals" && lead_journey_data.agent_id > 0) || 1 == 1) {
        var ajxloginvalue = getCookie("loginvalue");
        var ajxpassvalue = getCookie("userpass");
        if (args.destination == "" && lead_journey_data.action != "deals") {
            $("#lpop").show();
            $("#stp1").show();
            $("#login_frm_destination_id").val("");
            $("#stp1h").show();
        } else {
            if (args.destination != "") {
                lead_journey_data.destination = args.destination;
            }
            if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                    var postargs = {};
                    if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                        postargs.agent_id = lead_journey_data.agent_id;
                        postargs.nid = lead_journey_data.nid;
                    } else {
                        postargs.destination = lead_journey_data.destination;
                    }
                    postargs.leadaffid = 1044;
                    postargs.chatpostlead = 1;
                    lead_journey_data.action = "leadpost";
                    postargs.othersdata = JSON.stringify(lead_journey_data);
                    register_or_login_lead_journey(postargs);
                } else {
                    $("#lpop").show();
                    if (ajxpassvalue == null || ajxpassvalue == "undefined" || ajxpassvalue == "") {
                        resend_otp();
                        $("#stp7").show();
                        $("#stp7h").show();
                        $("#mobileotp0").focus();
                    } else {
                        $("#stp8").show();
                        $("#stp8h").show();
                    }
                }
            } else {
                $("#lpop").show();
                $("#stp6").show();
                $("#stp6h").show();
                $("#usernamepop").focus();
            }
        }
    } else {
        $("#stp5").show();
        $("#stp5h").show();
    }
}
function open_login_popup_other(args) {
    $(".closejuurneydiv").hide();
    var action = "";
    if (args.displayid != "" && args.displayid != undefined) {
        lead_journey_data.displayid = args.displayid;
    } else {
        lead_journey_data.displayid = "";
    }
    lead_journey_data.actionurl = args.page_type;
    var page_type = args.page_type;
    var questiondatas = args.questiondata;
    lead_journey_data.questiondata = questiondatas;
    if (args.action == "login") {
        $("#lpop").show();
        $("#stp6h").show();
        $("#stp6").show();
        $("#usernamepop").focus();
    } else if (args.action == "otp") {
        $("#lpop").show();
        $("#stp7h").show();
        $("#stp7").show();
        resend_otp();
        $("#mobileotp0").focus();
    }
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
        if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "") {
            if (page_type == "feedback") {
                submitdata(questiondatas);
            } else if (page_type == "plc_feed") {
                url = args.url;
                var win = window.open(url);
            } else if (page_type == "ttd_feed") {
                $("#brow").show();
            } else if (page_type == "fcp") {
                document.getElementById("pwht_amt1").style.display = "block";
            }
        } else {
            if (page_type == "refresh") {
                $("#lpop").show();
                $("#stp1h").show();
                $("#stp1").show();
            } else {
                $("#lpop").show();
                $("#stp7h").show();
                $("#stp7").show();
                resend_otp();
                $("#mobileotp0").focus();
            }
        }
    } else {
        if (page_type == "refresh") {
            $("#lpop").show();
            $("#stp1h").show();
            $("#stp1").show();
        } else {
            $("#lpop").show();
            $("#stp6h").show();
            $("#stp6").show();
            $("#usernamepop").focus();
        }
    }
}
function refresh_with_lead() {
    var args = { page_type: "refresh" };
    open_login_popup_other(args);
}
function resend_otp() {
    var q = "passformm=1&smstype=resend";
    var xmlhttp = new XMLHttpRequest();
    $("#resend_otp_journey").hide();
    setTimeout(function () {
        $("#resend_otp_journey").show();
    }, 1e4);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            try {
                response = JSON.parse(xmlhttp.responseText);
                if (response != "" && response.status == true) {
                    if (lead_journey_data.action == "emailnextt") {
                        $("#otpemailmessage").html(response.msg);
                    } else {
                        $("#otpmessage").html(response.msg);
                    }
                }
            } catch (e) {}
        }
    };
    xmlhttp.open("GET", baseurl + "utility/header_ajax.php?" + q, true);
    xmlhttp.send();
}
function validateleadbylogin(lead_id, trans) {
    console.log("MAX Trans " + trans);
    var http = new XMLHttpRequest();
    var ajxpassvalue = getCookie("userpass");
    var url = baseurl + "serveform/lead-publish-v3.php?lead_id=" + lead_id + "&tuidmaxtrans=" + trans;
    if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        url = baseurl + "serveform/lead-publish-_instantv3.php?by_passmobile_validation=1&lead_id=" + lead_id + "&tuidmaxtrans=" + trans;
    }
    http.open("GET", url, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.onreadystatechange = function () {
        if (http.readyState == 4 && http.status == 200) {
            if (http.responseText != "") {
                console.log(http.responseText);
                response = JSON.parse(http.responseText);
            }
        }
    };
    http.send();
}
function check_duplicate_buy(nid, login_id) {
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        leadid = atob(leadval);
        duplicate_buy(leadid, nid, login_id);
    } else {
        var args = { nid: nid, agent_id: login_id, destination_flag: "1" };
        open_login_popup_plan(args);
    }
}
function check_duplicate_buy(nid, login_id, id, hide) {
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        leadid = atob(leadval);
        duplicate_buy(leadid, nid, login_id);
    } else {
        var args = { nid: nid, agent_id: login_id, destination_flag: "1" };
        open_login_popup_plan(args);
    }
}
function dup_buy_with_lead(lead_id, nid, login_id, id, hide) {
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        document.getElementById(hide + "_" + nid).style.display = "none";
        document.getElementById(id + "_" + nid).style.display = "block";
        var lead_id = atob(leadval);
        var http = new XMLHttpRequest();
        var url = "/hellotravel/dup_buy.php";
        var params = "lead_ID=" + lead_id + "&dealid=" + nid + "&client_id=" + login_id + "&pagesource=" + pageval;
        http.open("POST", url, true);
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        http.onreadystatechange = function () {
            if (http.readyState == 4 && http.status == 200) {
            }
        };
        http.send(params);
    } else {
        var args = { nid: nid, agent_id: login_id, destination_flag: "1" };
        open_login_popup_plan(args);
    }
}
function dup_buy(nid, login_id, id, hide) {
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        document.getElementById(hide + "_" + nid).style.display = "none";
        document.getElementById(id + "_" + nid).style.display = "";
        var lead_id = atob(leadval);
        var http = new XMLHttpRequest();
        var url = "/hellotravel/dup_buy.php";
        var params = "lead_ID=" + lead_id + "&dealid=" + nid + "&client_id=" + login_id + "&pagesource=" + pageval;
        http.open("POST", url, true);
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        http.onreadystatechange = function () {
            if (http.readyState == 4 && http.status == 200) {
            }
        };
        http.send(params);
    } else {
        var args = { nid: nid, agent_id: login_id, destination_flag: "1", action: "deals" };
        open_login_popup_plan(args);
    }
}
function duplicate_buy(lead_id, nid, login_id) {
    if (pageName === "listpage") {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && newdesign != 1) {
            document.getElementById("d_" + nid).style.display = "none";
            document.getElementById("di_" + nid).style.display = "none";
            document.getElementById("m_" + nid).style.display = "block";
        } else {
            document.getElementById(nid).style.display = "none";
            document.getElementById("sent_" + nid).style.display = "block";
        }
        $.ajax({
            url: "/hellotravel/dup_buy.php",
            data: { lead_ID: lead_id, dealid: nid, client_id: login_id, pagesource: pageval },
            type: "post",
            success: function (data) {
                if (1 != 2) {
                    console.log(data);
                }
            },
            error: function () {
                alert("Try Again");
            },
        });
    } else {
        $("#" + nid).hide();
        $("#sent_" + nid).show();
        $.ajax({
            url: "/hellotravel/dup_buy.php",
            data: { lead_ID: lead_id, dealid: nid, client_id: login_id, pagesource: pageval },
            type: "post",
            success: function (data) {
                if (1 != 2) {
                    console.log(data);
                }
            },
            error: function () {
                alert("Try Again");
            },
        });
    }
}
function openInNewTab(url) {
    window.location = url;
}
$(function () {
    $("#destinationsubmit").click(function () {
        destination = $("#login_frm_destination_id").val();
        var args = {};
        if (destination == "") {
            alert("destination can not be blank");
            args.passdest = "0";
            return false;
        } else {
            args.passdest = "1";
            if (args.hasOwnProperty("display") && args.display == "none") {
                var noneid = args.displayid;
                $("#req" + noneid).hide();
                $("#sent" + noneid).show();
            }
            args.displayid = $("#displayid").val();
            args.display = $("#display").val();
            $("#display").val("");
            $("#displayid").val();
            var post_leadval = getCookie("leadvalue");
            args.thanks = 1;
            if (typeof post_leadval != "undefined" && post_leadval != "") {
                if (args.displayid == "" || args.displayid == "undefined") {
                    args.thanks = "1";
                } else {
                    args.thanks = "0";
                }
            }
            post_lead(args);
            return false;
        }
    });
});
function post_lead(args) {
    var nid = document.getElementById("login_nid").value;
    var agent_id = document.getElementById("login_agent_login_id").value;
    pns = "";
    var destination = document.getElementById("login_frm_destination_id").value;
    var destination = document.getElementById("login_frm_destination_id").value;
    var destination_temp = destination;
    destination_temp = destination_temp.replace(/!/g, "");
    destination_temp = destination_temp.replace(/,/g, "");
    destination_temp = destination_temp.replace(/\s/g, "");
    if (nid == "" && args.passdest == 0 && ((pageval != "things_2see_detail" && pageval != "destination_detail" && pageval != "events_detail" && pageval != "events" && pageval != "things_2_see") || destination_temp == "")) {
        var destination_text = $("#login_frm_destination_id").val();
        destination_text = destination_text.replace(/!/g, ",");
        destination_text = destination_text.replace(/(^,)|(,$)/g, "");
        if (destination_text == ",") {
            destination_text = "";
        }
        var destination_array = destination_text.split(",");
        if (pageName != "home") {
            $("#login_frm_destination_id").val(destination_array[0]);
        } else {
            $("#login_frm_destination_id").val(destination_text);
        }
        $("#login_frm_destination_id").val(destination_array[0]);
        $("#otpfrmmob").removeClass("dnone");
        $("#login_frm_emailid").css("display", "none");
        $("#otpresenddiv").css("display", "none");
        $("#newotpdiv").css("display", "none");
        $("#loginfrmmob").addClass("dnone");
        $("#destinationsubmit").prop("disabled", false);
        $("#destinationsubmit").css("display", "block");
        $("#otpsubmit").prop("disabled", true);
        $("#otpsubmit").css("display", "none");
        $("#destinationsubmit").css("display", "block");
        $("#otpsubmitspan").css("display", "none");
        $("#poptext").html("Where do you want to go?");
        $("#lpop").show();
    } else {
        pnsnumber = "";
        if (args.hasOwnProperty("state")) {
            pns = args.state;
            pnsnumber = args.pnsnumber;
        } else {
            if (nid != "" && (pageName != "fcp_package" || pageName != "fcp_home" || pageName != "story" || pageName != "listpage")) {
                $("#" + nid).hide();
                $("#sent_" + nid).show();
            } else if (nid != "") {
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                    document.getElementById("d_" + nid).style.display = "none";
                    document.getElementById("di_" + nid).style.display = "none";
                    document.getElementById("m_" + nid).style.display = "block";
                } else {
                    document.getElementById(nid).style.display = "none";
                    document.getElementById("sent_" + nid).style.display = "block";
                }
            }
        }
        $("#login_nid").val("");
        $("#login_agent_login_id").val("");
        var pagesource = "";
        if (typeof pageval != "undefined" && pageval != 0) {
            pagesource = pageval;
        }
        var pageaffid = 1044;
        if (typeof assaffid != "undefined" && assaffid != 0) {
            pageaffid = assaffid;
        }
        if (args.type == "pay_open_pop") {
            booking = "1";
        }
        var destination = document.getElementById("login_frm_destination_id").value;
        document.getElementById("login_frm_destination_id").value = "";
        $.ajax({
            url: baseurl + "utility/header_ajax.php?",
            cache: false,
            data: {
                destination: destination,
                post_lead: "1",
                nid: nid,
                agent_id: agent_id,
                self_url: pop_self_url,
                ref_url: pop_referer_url,
                pageemail_id: pageemail_id,
                pagesource: pagesource,
                pageaffid: pageaffid,
                leadaffid: pageaffid,
                booking: booking,
            },
            type: "post",
            success: function (data) {
                if (args.hasOwnProperty("display") && args.display == "none") {
                    var noneid = args.displayid;
                    if (noneid != "") {
                        $("#req" + noneid).hide();
                        $("#sent" + noneid).show();
                    }
                }
                var filter = JSON.parse(data);
                if (filter.status == 3) {
                    var lead_data = filter.lead_data;
                    lead_id = lead_data.lead_id;
                    trans = lead_data.trans;
                    $("#login_nid").val("");
                    $("#login_agent_login_id").val("");
                    $("#lpop").hide();
                    validateleadbylogin(lead_id, trans);
                    if (pns == "pns") {
                        window.location = "tel:" + pnsnumber;
                    } else {
                        if (args.thanks == 0) {
                        } else {
                            if (args.type == "pay_open_pop") {
                                document.getElementById("booking_leadid").value = lead_id;
                                book_amount_submit();
                            } else {
                                window.location = "https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + lead_id;
                            }
                        }
                    }
                }
            },
            error: function () {},
        });
    }
}
function submit_question(ques_id, type, pg_id, pg_typ, iso) {
    var ques = document.getElementById(ques_id).value;
    if (!ques) {
        document.getElementById(ques_id).focus();
        alert("Please enter text");
        return false;
    } else if (ques != "" && ques.length > 500) {
        document.getElementById(ques_id).focus();
        alert("Please enter less then 500 characters");
        return false;
    } else if (ques != "" && !ques.match(/^([a-zA-Z0-9 .,!?]+)$/)) {
        document.getElementById(ques_id).focus();
        alert("Please enter valid description");
        return false;
    }
    isquestionsubmit = true;
    questiondata = { login: 1, usn: userloginemail, text: ques, type: type, pg_id: pg_id, pg_typ: page_type, ques_id: ques_id, iso: iso, page_type: "feedback" };
    jsonquestiondata = JSON.stringify(questiondata);
    var args = { questiondata: questiondata, type: "feedback", page_type: "feedback" };
    open_login_popup_other(args);
    return false;
}
function submitdata(questiondata) {
    if (questiondata.type == "1") {
        $("#q_sub").hide();
        $("#load_sub").show();
    } else {
        $("#sbmt_" + questiondata.ques_id).hide();
        $("#load_" + questiondata.ques_id).show();
    }
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: false,
        data: questiondata,
        type: "post",
        success: function (data) {
            $("input[name=ques]").val("");
            if (data.trim() == "Success") {
                if (questiondata.type == "1") {
                    poptext = "Your question was posted successfully. You will get a notification by email.";
                    $("#q_sub").show();
                    $("#load_sub").hide();
                    $("#questextrep").html(poptext);
                    $("#questextrep").show();
                    setTimeout(function () {
                        $("#questextrep").show();
                    }, 1e3);
                } else {
                    poptext = "Your answer was successfully posted.";
                    $("#myquesnas" + questiondata.ques_id).html(poptext);
                }
                questiondata = "";
                isquestionsubmit = false;
                $("#lpop").hide();
                $("#qtext").text(poptext);
                $("#tques").show();
                $("#cont_que").click(function () {
                    $("#tques").hide();
                    window.location.reload();
                });
            } else {
                if (questiondata.type == "1") {
                    $("#q_sub").show();
                    $("#load_sub").hide();
                    poptext = "Your question was successfully submitted. You will be notified by email when it gets posted on the site.";
                    $("#questextrep").html(poptext);
                    $("#questextrep").show();
                    setTimeout(function () {
                        $("#questextrep").show();
                    }, 1e3);
                } else {
                    poptext = "Your answer was successfully submitted.";
                }
                $("#lpop").hide();
                $("#qtext").text(poptext);
                $("#tques").show();
                $("#cont_que").click(function () {
                    $("#tques").hide();
                    window.location.reload();
                });
            }
        },
        error: function () {},
    });
    return false;
}
function step1() {
    if (place_feed != "") {
        selectval1 = place_feed;
    } else {
        selectval1 = $("#PlVisit").val();
        if (selectval1 == "Other_place") {
            selectval1 = $("#Oplace").val();
        }
    }
    if (selectval1 == "") {
        alert("Please select place name");
        $("#PlVisit").focus();
        return false;
    }
    if ($("#star_rating").val() == 0) {
        alert("Please provide star rating");
        return false;
    }
    var vid_vl = getCookie("vid");
    var args = { page_type: "plc_feed", url: "https://www.hellotravel.com/plc-reviews.php?type_page=ttd&city=" + selectval1 + "&vid=" + vid_vl };
    $("#frm_redirect_url").val(args.url);
    open_login_popup_other(args);
    return false;
}
function step2() {
    if (place_feed != "") {
        var selectval2 = place_feed;
    } else {
        var selectval2 = $("#PlVisit").val();
        if (selectval2 == "Other_place") {
            var selectval2 = $("#Oplace").val();
        }
    }
    if (selectval2 == "") {
        alert("Please select activity");
        $("#PlVisit").focus();
        return false;
    }
    if ($("#star_rating").val() == 0) {
        alert("Please provide star rating");
        return false;
    }
    var args = { page_type: "ttd_feed" };
    $("#redirect_url").val("");
    open_login_popup_other(args);
    return false;
}
function continue_browsing() {
    var page_url = "";
    if (typeof Storage !== "undefined") {
        page_url = localStorage.getItem("referal_review");
    }
    if (page_url == "" || typeof page_url == "undefined") {
        page_url = "https://www.hellotravel.com";
    }
    window.open(page_url, "_self");
}
function check_post_destination(destination) {
    $("#login_frm_destination_id").val(destination);
    var args = { destination: destination, destination_flag: "1" };
    open_login_popup_plan(args);
}
function check_post_destination_agent(destination, agent_id) {
    $("#login_frm_destination_id").val(destination);
    var args = { destination: destination, destination_flag: "1", agent_id: agent_id, setagent_id: "1" };
    open_login_popup_plan(args);
}
function check_post_destination_none(destination, state, country, id) {
    if (destination != "") {
        $("#login_frm_destination_id").val(destination);
    } else if (state != "") {
        $("#login_frm_destination_id").val(state);
    } else if (country != "") {
        $("#login_frm_destination_id").val(country);
    }
    $("#display").val("none");
    $("#displayid").val(id);
    var args = { destination: destination, display: "none", displayid: id, destination_flag: "1" };
    args.thanks = 1;
    open_login_popup_plan(args);
}
function check_post_destination(destination, state, country) {
    $("#login_frm_destination_id").val(destination + "!" + state + "!" + country);
    var args = { destination: destination, destination_flag: "1" };
    open_login_popup_plan(args);
}
function check_post_call(nid, agent_id, pnsid) {
    lead_journey_data = {};
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        var pns_temp = pnsid;
        pns_temp = pns_temp.replace("+", "");
        create_call_history(pns_temp);
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            window.location = "tel:" + pnsid;
        } else {
            $("." + pns_temp + "_hide").hide();
            $("." + pns_temp + "_show").show();
        }
    } else {
        //lead_journey_data.nid = nid;
        //lead_journey_data.pnsid = pnsid;
        //lead_journey_data.agent_id = agent_id;
        //lead_journey_data.action = "pns";
       // leadJouneyEvent("nid", "");
	// var args = { nid: nid, agent_id: login_id, destination_flag: "1", };
	  var args = {nid: nid, agent_id: agent_id, destination_flag: "1", pnsnumber: pnsid, state: "pns", action: "pns" };
        $("#redirect_type").val("pns");
        $("#frm_redirect_url").val(pnsid);
        open_login_popup_plan(args);
    }
}
function check_post_call_destination(destination, iso, country, pnsid) {
    var leadval = getCookie("leadvalue");
    var ajxloginvalue = getCookie("loginvalue");
    var ajxpassvalue = getCookie("userpass");
    if (typeof leadval != "undefined" && leadval != "" && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        var pns_temp = pnsid;
        pns_temp = pns_temp.replace("+", "");
        create_call_history(pns_temp);
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            window.location = "tel:" + pnsid;
        } else {
            $("." + pns_temp + "_hide").hide();
            $("." + pns_temp + "_show").show();
        }
    } else {
        $("#login_frm_destination_id").val(destination + "!" + iso + "!" + country);
        var args = { destination: $("#login_frm_destination_id").val(), pnsnumber: pnsid, state: "pns", destination_flag: "1", action: "pns" };
        $("#redirect_type").val("pns");
        $("#frm_redirect_url").val(pnsid);
        open_login_popup_plan(args);
    }
}
function check_dup_buy(nid, login_id, id, hide) {
    var leadval = getCookie("leadvalue");
    if (typeof leadval != "undefined" && leadval != "") {
        leadid = atob(leadval);
        dup_buy(nid, login_id, id, hide);
    } else {
        var args = { nid: nid, agent_id: login_id, destination_flag: "1", action: "deals", "redirect-type": "lead" };
        open_login_popup_plan(args);
    }
}
$(function () {
    $("#frm_close_btn").click(function () {
        close_login_div();
    });
});
function close_login_div() {
    cleardata();
    $("#lpop").hide();
}
function cleardata() {
    $("#login_frm_destination_id").val("");
    $("#login_nid").val("");
    $("#from_login_loader2").hide();
    $("#from_login_loader1").hide();
    $("#login_agent_login_id").val("");
    $("#usernamepop").val("");
    $("#login_frm_otp").val();
}
function open_login_popup(args, destination_flag) {
    var args = { action: "login", "redirect-type": "login", "redirect-url": args };
    open_login_popup_plan(args);
}
function checkinput() {
    var value = document.getElementById("usernamepop").value.trim();
    var isnum = /^\d+$/.test(value);
    if (isnum) {
        var country = document.getElementById("country_listpop").value;
        if (country != "+91") {
        } else if (!(value.charAt(0) == "6" || value.charAt(0) == "7" || value.charAt(0) == "8" || value.charAt(0) == "9")) {
            alert("Please enter mobile no start with 6 or 7 or 8 or 9");
            return false;
        }
    } else {
        document.getElementById("usernamepop").value = value.slice(0, -1);
    }
}
$(function () {
    $("#country_listpop").on("change", function () {
        var country = this.value;
        var result = country.split("!");
        $("#country_codepop").val("+" + result[2]);
        if (result[2] != "91") {
            $("#mobilealertdigits").html("Enter your mobile no.");
        }
    });
});
function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return true;
    } else {
        return false;
    }
}
function track_actions(action_tag, action_button) {
    var url = window.location.href;
    var vid = getCookie("vid");
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: false,
        data: { url: url, action_tag: action_tag, action_button: action_button, vid: vid, action_url: pop_self_url, track_action: "1" },
        type: "post",
        success: function (data) {},
        error: function () {},
    });
}
function book_now_start(title, random_amnt, log_id, comp_name, nid, pns_num) {
    var args = { type: "pay_open_pop", page_type: "deals_book", nid: nid, log_id: log_id };
    document.getElementById("booking_val").value = "1";
    document.getElementById("resdiv_pwht").value = "Reserve seat for " + title;
    document.getElementById("amountdiv_pwht").value = random_amnt;
    document.getElementById("log_id_book").value = log_id;
    document.getElementById("comp_name_book").value = comp_name;
    document.getElementById("pns_num_booking").value = pns_num;
    document.getElementById("booking_nid").value = nid;
    booking_title = title;
    open_login_popup_other(args);
}
function book_amount_submit() {
    var amnt = document.getElementById("amountdiv_pwht").value;
    var res = document.getElementById("resdiv_pwht").value;
    booking_leadid = document.getElementById("booking_leadid").value;
    booking_nid = document.getElementById("booking_nid").value;
    if (amnt == "" || amnt == 0 || typeof amnt == "undefined") {
        alert("Please enter valid amount");
        document.getElementById("amountdiv_pwht").focus();
        return false;
    }
    if (res == "" || res == 0 || typeof res == "undefined") {
        alert("Please enter reason before proceeding further");
        document.getElementById("resdiv_pwht").focus();
        return false;
    }
    login_book = document.getElementById("log_id_book").value;
    comp_name_book = document.getElementById("comp_name_book").value;
    pns_num_booking = document.getElementById("pns_num_booking").value;
    $("#pwht_amt").hide();
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: false,
        data: { booking_pwht: 1, tuid: uid_client_book, loginid: login_book, res: res, booking_leadid: booking_leadid, booking_nid: booking_nid },
        type: "post",
        success: function (data) {
            var dataobj = JSON.parse(data);
            razorpay_window_book(amnt, res, dataobj.userid, dataobj.fcpimgurl);
        },
        error: function () {},
    });
}
$("#close_pwht").click(function () {
    $("#pwht_amt").hide();
    cleardata_booking();
});
function razorpay_window_book(amnt, res, refno, fcpimgurl) {
    var total_amnt = amnt * 100;
    cleardata_booking();
    var options = {
        key: "rzp_live_CaQlayjhKsUtnR",
        amount: total_amnt,
        name: comp_name_book,
        description: "Pay with Hellotravel",
        image: "https://www.hlimg.com/images/logo/" + fcpimgurl,
        modal: {
            ondismiss: function () {
                $.ajax({
                    url: baseurl + "utility/header_ajax.php",
                    type: "POST",
                    data: { mode: "payment_cancel", tuid: uid_client_book, loginid: login_book, merchant_id: refno },
                    success: function (data) {
                        cleardata_booking();
                    },
                });
            },
        },
        handler: function (response) {
            if (typeof response.razorpay_payment_id != "undefined" && response.razorpay_payment_id != "") {
                var pay_id = response.razorpay_payment_id;
                ga("require", "ecommerce");
                ga("ecommerce:addTransaction", { id: pay_id, affiliation: comp_name_book, revenue: amnt, shipping: "0", tax: "0" });
                ga("ecommerce:addItem", { id: pay_id, name: booking_title, sku: booking_nid, category: comp_name_book, price: amnt, quantity: "1" });
                ga("ecommerce:send");
                $.ajax({
                    url: baseurl + "utility/header_ajax.php",
                    type: "POST",
                    data: { pay_mode: "payment_done", tuid: uid_client_book, loginid: login_book, merchant_id: refno, payid: pay_id, booking: "1" },
                    success: function (data) {
                        var url_redirect_book = baseurl + "my_trips.php?leadid=" + booking_leadid + "logid=" + login_book;
                        var text =
                            "Your payment is successful. Payment details sent on your email id.<br/>You will be contacted by " +
                            comp_name_book +
                            " within 24 hours for your booking enquiry.<br/>For any immediate assistance, please contact support team at " +
                            pns_num_booking +
                            '<div align="center" class="mt1"> <button onclick="open_mytrips_url("' +
                            url_redirect_book +
                            '")" type="button" class="login_butn" style="padding:8px 50px"><span style="">Chat With Agent</span> </button> </div>';
                        $("#tbook_success").show();
                        $("#tbook_text").html(text);
                        setTimeout(function () {
                            window.location = url_redirect_book;
                        }, 5e3);
                    },
                });
            }
        },
        prefill: { name: username, email: userloginemail, contact: userlogincontact },
        notes: {
            reason_pay: "Pre Booking By PWHT payment from " + username + " - " + userlogincontact + ". " + res + " " + booking_leadid,
            tuid: uid_client_book,
            refno: refno,
            user_id: login_book,
            leadid: booking_leadid,
            nid: booking_nid,
            pay_type: 1,
            booking: 1,
        },
        theme: { color: "#00a65a" },
    };
    rzp1 = new Razorpay(options);
    rzp1.open();
}
function open_mytrips_url(url) {
    window.location = url;
}
function cleardata_booking() {
    $("#resdiv_pwht").val("");
    $("#booking_val").val("");
    $("#amountdiv_pwht").val("");
    $("#log_id_book").val("");
    $("#comp_name_book").val("");
    $("#pns_num_booking").val("");
    $("#booking_nid").val();
}
$("#journeydate").datepicker({
    dateFormat: "yy-mm-dd",
    minDate: "0",
    maxDate: "+5M +1D",
    onSelect: function (a, b) {
        $("#journeydate").val(a);
        lead_journey_data.dep_date = a;
        $("#journeydate").val(a);
    },
});
$(function () {
    $("#dDate").datepicker();
});
function leadJouneyEvent(event, idd) {
    var status = false;
    if (event == "") {
        $("#lpop").show();
        $("#leadj_pop").hide();
        return false;
    }
    var id = "";
    if (event != "" && event != "nid") {
        id = event.getAttribute("action-type");
    } else {
        if (lead_journey_data.agent_id == "0" || lead_journey_data.agent_id == null || lead_journey_data.agent_id == "undefined") {
            $("#stp1").show();
            $("#stp1h").show();
            $("#login_frm_destination_id").css("border", "1px solid #f00");
            return "";
        }
        id = event;
    }
    if (id == "desnext") {
        var destination_val = $("#" + idd).val();
        if (destination_val == "" || destination_val == null) {
            $("#login_frm_destination_id").css("border", "1px solid #f00");
            return false;
        }
        lead_journey_data.destination = destination_val;
        $("#stp1").hide();
        $("#stp2").show();
        $("#stp1h").hide();
        $("#stp2h").show();
    }
    if (id == "nid") {
        $("#leadj_pop").hide();
        $("#stp1").hide();
        $("#stp2").show();
        $("#stp1h").hide();
        $("#stp2h").show();
    }
    if (id == "decided") {
        lead_journey_data.datetype = id;
        $("#dd01").hide();
        $("#dd1").show();
    }
    if (id == "ndecided") {
        lead_journey_data.datetype = id;
        $("#dd01").hide();
        $("#ndd1").show();
    }
    if (id == "tripdur" && $("#" + id).val() != "") {
        var trip_dur_val = $("#" + id).val();
        $(id + "_hidden").val(trip_dur_val);
        $("#nooftrvlrspan").show();
    }
    if (id == "nooftrvlr" && $("#" + id).val() != "") {
        var nooftrvlr = $("#" + id).val();
        $("#" + id + "_hidden").val(nooftrvlr);
    }
    if (id == "ddatnext") {
        if ($("#dDate").val() == "") {
            $("#dDate").css("border", "1px solid #f00");
            return false;
        }
        if ($("#tripdur").val() == "Select Trip Duration") {
            $("#tripdur").css("border", "1px solid #f00");
            return false;
        } else {
            $("#nooftrvlr").removeClass("err");
        }
        if ($("#nooftrvlr").val() == "Select number of travelers") {
            $("#nooftrvlr").css("border", "1px solid #f00");
            return false;
        } else {
            $("#nooftrvlr").removeClass("err");
        }
        lead_journey_data.datetype = $("#dDate").val();
        lead_journey_data.no_of_traveller = $("#nooftrvlr").val();
        lead_journey_data.trip_duration = $("#tripdur").val();
        $("#stp2").hide();
        if (lead_journey_data.agent_id != "0" && lead_journey_data.agent_id != null && lead_journey_data.agent_id != "undefined") {
            var ajxloginvalue = getCookie("loginvalue");
            var ajxpassvalue = getCookie("userpass");
            if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                    lead_journey_data.email = $("#journeyemailtxt").val();
                    var postargs = {};
                    postargs.otp_state = 1;
                    postargs.traveldate = lead_journey_data.dep_date;
                    if (lead_journey_data.agentid != "" && lead_journey_data.agentid != "undefined" && lead_journey_data.agentid != null) {
                        postargs.agent_id = lead_journey_data.agentid;
                        postargs.nid = lead_journey_data.nid;
                    } else {
                        postargs.destination = lead_journey_data.destination;
                        postargs.duration = lead_journey_data.trip_duration;
                        postargs.budget = lead_journey_data.budget_prices;
                    }
                    postargs.noperson = lead_journey_data.no_of_traveller;
                    postargs.leadaffid = 1044;
                    postargs.pagesource = "";
                    postargs.email = lead_journey_data.email;
                    postargs.chatpostlead = 1;
                    postargs.emailupdate = 1;
                    lead_journey_data.action = "leadpost";
                    postargs.othersdata = JSON.stringify(lead_journey_data);
                    register_or_login_lead_journey(postargs);
                } else if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 0) {
                    $("#stp6h").show();
                    $("#emailfrmmob").show();
                } else {
                    resend_otp();
                    $("#stp7h").show();
                    $("#otpfrmmob").show();
                }
            } else {
                $("#stp4h").show();
                $("#loginfrmmob").show();
            }
        } else {
            $("#stp2").hide();
            $("#stp3").show();
            $("#stp2h").hide();
            $("#stp3h").show();
        }
    }
    if (idd == "fivestar" || idd == "fourstar" || idd == "threestar") {
        var budget_price = $("#price_" + idd).text();
        if (budget_price != "") {
            lead_journey_data.budget_prices = budget_price;
            $("#stp3").hide();
            $("#stp3h").hide();
            var ajxloginvalue = getCookie("loginvalue");
            var ajxpassvalue = getCookie("userpass");
            if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                    lead_journey_data.email = $("#journeyemailtxt").val();
                    var postargs = {};
                    postargs.otp_state = 1;
                    postargs.traveldate = lead_journey_data.dep_date;
                    if (lead_journey_data.agentid != "" && lead_journey_data.agentid != "undefined" && lead_journey_data.agentid != null) {
                        postargs.agent_id = lead_journey_data.agentid;
                        postargs.nid = lead_journey_data.nid;
                    } else {
                        postargs.destination = lead_journey_data.destination;
                        postargs.duration = lead_journey_data.trip_duration;
                        postargs.budget = lead_journey_data.budget_prices;
                    }
                    postargs.noperson = lead_journey_data.no_of_traveller;
                    postargs.leadaffid = 1044;
                    postargs.pagesource = "";
                    postargs.email = lead_journey_data.email;
                    postargs.chatpostlead = 1;
                    postargs.emailupdate = 1;
                    lead_journey_data.action = "leadpost";
                    postargs.othersdata = JSON.stringify(lead_journey_data);
                    register_or_login_lead_journey(postargs);
                } else if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 0) {
                    $("#stp6h").show();
                    $("#emailfrmmob").show();
                } else {
                    resend_otp();
                    $("#stp7h").show();
                    $("#otpfrmmob").show();
                }
            } else {
                $("#stp4h").show();
                $("#loginfrmmob").show();
            }
            status = true;
        }
    }
    if (id == "otpnext") {
        lead_journey_data.otp = $("#mobileotp0").val() + "" + $("#mobileotp1").val() + "" + $("#mobileotp2").val() + "" + $("#mobileotp3").val();
        if (lead_journey_data.otp == "") {
            $(".mobileotp").css("border", "1px solid #f00");
            return "";
        }
        var postargs = {};
        postargs.traveldate = lead_journey_data.dep_date;
        if (lead_journey_data.agentid != "" && lead_journey_data.agentid != "undefined" && lead_journey_data.agentid != null) {
            postargs.agent_id = lead_journey_data.agentid;
            postargs.nid = lead_journey_data.nid;
        } else {
            postargs.destination = lead_journey_data.destination;
            postargs.duration = lead_journey_data.trip_duration;
            postargs.budget = lead_journey_data.budget_prices;
        }
        postargs.noperson = lead_journey_data.no_of_traveller;
        postargs.leadaffid = 1044;
        postargs.pagesource = "";
        postargs.otp_state = 1;
        postargs.otp = lead_journey_data.otp;
        postargs.validatemobileotp = 1;
        postargs.skyp_otp = 0;
        postargs.leadaffid = 1044;
        postargs.pagesource = "";
        postargs.othersdata = JSON.stringify(lead_journey_data);
        postargs.username = atob(getCookie("loginvalue"));
        lead_journey_data.action = "otp";
        register_or_login_lead_journey(postargs);
    }
    if (id == "emailnextt") {
        lead_journey_data.email = $("#journeyemailtxt").val();
        if (lead_journey_data.email == "") {
            $("#journeyemailtxt").css("border", "1px solid #f00");
            return "";
        }
        var postargs = {};
        postargs.otp_state = 1;
        postargs.traveldate = lead_journey_data.dep_date;
        if (lead_journey_data.agentid != "" && lead_journey_data.agentid != "undefined" && lead_journey_data.agentid != null) {
            postargs.agent_id = lead_journey_data.agentid;
            postargs.nid = lead_journey_data.nid;
        } else {
            postargs.destination = lead_journey_data.destination;
            postargs.duration = lead_journey_data.trip_duration;
            postargs.budget = lead_journey_data.budget_prices;
        }
        postargs.noperson = lead_journey_data.no_of_traveller;
        postargs.leadaffid = 1044;
        postargs.pagesource = "";
        postargs.email = lead_journey_data.email;
        postargs.emailupdate = 1;
        lead_journey_data.action = "email";
        if ($("#emailotpflag").val() == 1) {
            lead_journey_data.emailotpflag = $("#emailotpflag").val();
            postargs.emailotpupdate = 1;
            lead_journey_data.otp = $("#emailotp").val() + "" + $("#emailotp1").val() + "" + $("#emailotp2").val() + "" + $("#emailotp3").val();
            if (lead_journey_data.otp == "") {
                $(".emailotp").css("border", "1px solid #f00");
                return "";
            }
            postargs.emailotpupdate = lead_journey_data.otp;
            lead_journey_data.action = "emailotp";
        }
        postargs.othersdata = JSON.stringify(lead_journey_data);
        register_or_login_lead_journey(postargs);
    }
    if (id == "frm_login_pop_btn") {
        var postargs = {};
        postargs.username = $("#usernamepop").val();
        postargs.newform = 1;
        lead_journey_data.action = "mobile";
        register_or_login_lead_journey(postargs);
    }
    return status;
}
$(document).ready(function () {
    if (pageName == "travelagent") {
        setTimeout(function () {
            if (!getCookie("loginvalue") || user_dest == "NA" || user_dest == "") refresh_with_lead();
            else {
                if (getCookie("pop_filter")) {
                } else {
                    $("#nam02").show();
                    setCookie("pop_filter", "5", 1);
                }
            }
        }, 3e3);
    }
});
$(document).ready(function () {
    $("#closeJurn").click(function () {
        if (pageName == "travelagent") {
            var leadid = getCookie("leadvalue");
            if (typeof leadid != "undefined" && leadid != "") {
                $("#lpop").hide();
            }
        } else {
            $("#lpop").hide();
        }
    });
    $(".leadjourney-btn").click(function (event) {
        var conid = this.getAttribute("action_type");
        //ga("send", "pageview", conid + "newlead.php");
        lead_journey_data.buttonid = this.id;
        if (conid == "destination") {
            var destination_val = $("#login_frm_destination_id").val();
            if (destination_val == "" || destination_val == null) {
                $("#login_frm_destination_id").css("border", "1px solid #f00");
                return false;
            }
            lead_journey_data.destination = destination_val;
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").hide();
            $("#stp4h").hide();
            if ((lead_journey_data.action == "deals" && lead_journey_data.agent_id > 0) || 1 == 1) {
                var ajxloginvalue = getCookie("loginvalue");
                var ajxpassvalue = getCookie("userpass");
                if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                    if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                        var postargs = {};
                        if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                            postargs.agent_id = lead_journey_data.agent_id;
                            postargs.nid = lead_journey_data.nid;
                        } else {
                            postargs.destination = lead_journey_data.destination;
                        }
                        postargs.leadaffid = 1044;
                        postargs.chatpostlead = 1;
                        lead_journey_data.action = "leadpost";
                        postargs.othersdata = JSON.stringify(lead_journey_data);
                        register_or_login_lead_journey(postargs);
                    } else {
                        if (ajxpassvalue == null || ajxpassvalue == "undefined" || ajxpassvalue == "") {
                            resend_otp();
                            $("#stp7").show();
                            $("#stp7h").show();
                            $("#mobileotp0").focus();
                        } else {
                            $("#stp8").show();
                            $("#stp8h").show();
                        }
                    }
                } else {
                    $("#stp6").show();
                    $("#stp6h").show();
                    $("#usernamepop").focus();
                }
            } else {
                $("#stp5").show();
                $("#stp5h").show();
            }
        } else if (conid == "journeydate") {
            var journeydate_val = $("#journeydate").val();
            if (journeydate_val == null || journeydate_val == "undefined" || journeydate_val == "") {
                $("#journeydate").css("border", "1px solid #f00");
                return false;
            } else {
                lead_journey_data.dep_date = journeydate_val;
                $("#stp1").hide();
                $("#stp2").hide();
                $("#stp1h").hide();
                $("#stp2h").hide();
                $("#stp2date").hide();
                if (lead_journey_data.action == "deals" && lead_journey_data.agent_id > 0) {
                    $("#stp4").show();
                    $("#stp4h").show();
                } else {
                    $("#stp3").show();
                    $("#stp3h").show();
                }
            }
        } else if (conid == "mobile_login") {
            var username = $("#usernamepop").val();
            var country_listpop = $("#country_listpop").val();
            var result = country_listpop.split("!");
            if (username == "") {
                $("#usernamepop").css("border", "1px solid #f00");
                return;
            }
            var postargs = {};
            postargs.username = username;
            postargs.countryname = result[0];
            postargs.isdcode = result[2];
            postargs.country = result[2];
            lead_journey_data.action = "mobile";
            postargs.newform = 1;
            register_or_login_lead_journey(postargs);
        } else if (conid == "otp_validation") {
            lead_journey_data.otp = $("#mobileotp0").val() + "" + $("#mobileotp1").val() + "" + $("#mobileotp2").val() + "" + $("#mobileotp3").val();
            if (lead_journey_data.otp == "") {
                $(".mobileotp").css("border", "1px solid #f00");
                return "";
            }
            var postargs = {};
            var postargs = {};
            postargs.traveldate = lead_journey_data.dep_date;
            if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                postargs.agent_id = lead_journey_data.agent_id;
                postargs.nid = lead_journey_data.nid;
            } else {
                postargs.destination = lead_journey_data.destination;
                postargs.duration = lead_journey_data.trip_duration;
                postargs.budget = lead_journey_data.budget_prices;
            }
            postargs.noperson = lead_journey_data.no_of_traveller;
            postargs.leadaffid = 1044;
            postargs.pagesource = "";
            postargs.otp_state = 1;
            postargs.otp = lead_journey_data.otp;
            postargs.validatemobileotp = 1;
            postargs.skyp_otp = 0;
            postargs.othersdata = JSON.stringify(lead_journey_data);
            postargs.username = atob(getCookie("loginvalue"));
            lead_journey_data.action = "otp";
            register_or_login_lead_journey(postargs);
        }






        else if (conid == "myaccountotp") {
            lead_journey_data.otp = $("#mobileotp0").val() + "" + $("#mobileotp1").val() + "" + $("#mobileotp2").val() + "" + $("#mobileotp3").val();
            if (lead_journey_data.otp == "") {
                $(".mobileotp").css("border", "1px solid #f00");
                return "";
            }
            
          var inputval = '';
          var userpass = lead_journey_data.otp; 
		  var countrycode = "91"; 
		  q = "loginvalidate=yes";
		  q += "&username="+inputval;
		  q += "&otpval="+userpass; 
	          q += "&country="+countrycode;
		  var xmlhttp = new XMLHttpRequest();
	        xmlhttp.onreadystatechange = function()
       		 {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        	        {
                        
				try{
				 response = JSON.parse(xmlhttp.responseText);
                 
					if(response.status){
                        $('#lpop').hide();
					  	location.reload();
					}else{
                        alert(response.msg);
                    }
            }catch(e){
            }		
			}
		}
		
		 	xmlhttp.open("GET", baseurl+"utility/loginprocess.php?"+q,true);
	        	xmlhttp.send();
            
        }





        else if (conid == "email_validate") {
            lead_journey_data.email = $("#journeyemailtxt").val();
            if (lead_journey_data.email == "") {
                $("#journeyemailtxt").css("border", "1px solid #f00");
                return "";
            }
            var postargs = {};
            postargs.otp_state = 1;
            postargs.traveldate = lead_journey_data.dep_date;
            if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                postargs.agent_id = lead_journey_data.agent_id;
                postargs.nid = lead_journey_data.nid;
            } else {
                postargs.destination = lead_journey_data.destination;
                postargs.duration = lead_journey_data.trip_duration;
                postargs.budget = lead_journey_data.budget_prices;
            }
            postargs.noperson = lead_journey_data.no_of_traveller;
            postargs.leadaffid = 1044;
            postargs.pagesource = "";
            postargs.email = lead_journey_data.email;
            postargs.emailupdate = 1;
            lead_journey_data.action = "email";
            postargs.othersdata = JSON.stringify(lead_journey_data);
            register_or_login_lead_journey(postargs);
        } else if (conid == "emailotp_validation") {
            var postargs = {};
            postargs.otp_state = 2;
            postargs.traveldate = lead_journey_data.dep_date;
            if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                postargs.agent_id = lead_journey_data.agent_id;
                postargs.nid = lead_journey_data.nid;
            } else {
                postargs.destination = lead_journey_data.destination;
                postargs.duration = lead_journey_data.trip_duration;
                postargs.budget = lead_journey_data.budget_prices;
            }
            postargs.noperson = lead_journey_data.no_of_traveller;
            postargs.leadaffid = 1044;
            postargs.pagesource = "";
            postargs.email = lead_journey_data.email;
            lead_journey_data.action = "email";
            postargs.emailotpupdate = 1;
            lead_journey_data.otp = $("#emailotp0").val() + "" + $("#emailotp1").val() + "" + $("#emailotp2").val() + "" + $("#emailotp3").val();
            if (lead_journey_data.otp == "") {
                $(".emailotp").css("border", "1px solid #f00");
                return "";
            }
            postargs.emailotpupdate = 1;
            postargs.otp = lead_journey_data.otp;
            lead_journey_data.action = "emailotp";
            postargs.othersdata = JSON.stringify(lead_journey_data);
            register_or_login_lead_journey(postargs);
        }
    });
    $(".leadjourney-checkbox-incl").click(function (event) {
        $(this).toggleClass("ddates01");
        $(this).toggleClass("ddates");
    });
    $(".leadjourney-checkbox-afterpost").click(function (event) {
        var conid = this.getAttribute("action_type");
        //ga("send", "pageview", conid + "newlead.php");
        if (conid == "datechoice") {
            var check_value = this.getAttribute("data_value");
            if (check_value == null || check_value == "undefined" || check_value == "") {
                $("#" + this.id).css("border", "1px solid #f00");
                return false;
            } else {
                if (check_value == "decided") {
                    $("#stp2date").show();
                } else {
                    $("#stp2date").hide();
                    $("#stp2month").show();
                }
            }
        } else if (conid == "journeymonth") {
            var check_value = this.getAttribute("data_value");
            var dep_date = get_date_from_month_journey(check_value);
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp2date").hide();
            $("#stp3").show();
            $("#stp3h").show();
            var updateargs = {};
            updateargs.leadid = getCookie("leadvalue");
            updateargs.leadid = atob(updateargs.leadid);
            updateargs.text = dep_date;
            updateargs.field = "dep_date";
            lead_update_after_post(updateargs);
        } else if (conid == "incls") {
            if ($(".ddates01").length > 0) {
                var incarr = Array();
                for (i = 0; i < $(".ddates01").length; i++) {
                    var incclassv = $(".ddates01")[i];
                    var aqq = incclassv.getAttribute("data_value");
                    incarr.push(aqq);
                }
                var check_value = incarr.join(",");
                var updateargs = {};
                $(".closejuurneydiv").hide();
                updateargs.leadid = getCookie("leadvalue");
                updateargs.leadid = atob(updateargs.leadid);
                updateargs.text = check_value;
                updateargs.field = "incls";
                lead_update_after_post(updateargs);
                $("#stp5").show();
                $("#stp5h").show();
                newjourney_price();
            }
        } else if (conid == "booked") {
            var check_value = this.getAttribute("data_value");
            var updateargs = {};
            $(".closejuurneydiv").hide();
            updateargs.leadid = getCookie("leadvalue");
            updateargs.leadid = atob(updateargs.leadid);
            updateargs.text = check_value;
            updateargs.field = "booked";
            lead_update_after_post(updateargs);
            $("#lead_journey_thanks").show();
            $("#lead_journey_thanks_msg").html("<a href='https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + updateargs.leadid + "'>Click Here to View Lead Details</a>");
            //dushyant comment
	    setTimeout(function () {
                window.location = "https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + updateargs.leadid;
            }, 1e3);
        } else if (conid == "budget") {
            var check_value = this.getAttribute("data_value");
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").hide();
            $("#stp4h").hide();
            $("#stp5").hide();
            $("#stp5h").hide();
            var updateargs = {};
            updateargs.leadid = getCookie("leadvalue");
            updateargs.leadid = atob(updateargs.leadid);
            updateargs.text = check_value;
            updateargs.field = "budget";
            lead_update_after_post(updateargs);
            $("#stp12").show();
            $("#stp5h").show();
        } else if (conid == "duration") {
            var check_value = this.getAttribute("data_value");
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            var updateargs = {};
            updateargs.leadid = getCookie("leadvalue");
            updateargs.leadid = atob(updateargs.leadid);
            updateargs.text = check_value;
            updateargs.field = "duration";
            lead_update_after_post(updateargs);
            $("#stp4").show();
            $("#stp4h").show();
        } else if (conid == "noperson") {
            var check_value = this.getAttribute("data_value");
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").hide();
            $("#stp4h").hide();
            var updateargs = {};
            updateargs.leadid = getCookie("leadvalue");
            updateargs.leadid = atob(updateargs.leadid);
            updateargs.text = check_value;
            updateargs.field = "noperson";
            lead_update_after_post(updateargs);
            $("#stp11").show();
            $("#stp5h").show();
        } else if (conid == "journeydate") {
            var journeydate_val = $("#journeydate").val();
            if (journeydate_val == null || journeydate_val == "undefined" || journeydate_val == "") {
                $("#journeydate").css("border", "1px solid #f00");
                return false;
            } else {
                var dep_date = journeydate_val;
                $("#stp1").hide();
                $("#stp2").hide();
                $("#stp1h").hide();
                $("#stp2h").hide();
                $("#stp2date").hide();
                var updateargs = {};
                updateargs.leadid = getCookie("leadvalue");
                updateargs.leadid = atob(updateargs.leadid);
                updateargs.text = dep_date;
                updateargs.field = "dep_date";
                lead_update_after_post(updateargs);
                $("#stp3").show();
                $("#stp3h").show();
            }
        }
    });
    $(".leadjourney-checkbox").click(function (event) {
        var conid = this.getAttribute("action_type");
        ga("send", "pageview", conid + "newlead.php");
        if (conid == "datechoice") {
            var check_value = this.getAttribute("data_value");
            if (check_value == null || check_value == "undefined" || check_value == "") {
                $("#" + this.id).css("border", "1px solid #f00");
                return false;
            } else {
                lead_journey_data.datetype = check_value;
                if (check_value == "decided") {
                    $("#stp2date").show();
                } else {
                    $("#stp2date").hide();
                    $("#stp2month").show();
                }
            }
        } else if (conid == "journeymonth") {
            var check_value = this.getAttribute("data_value");
            lead_journey_data.dep_date = get_date_from_month_journey(check_value);
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp2date").hide();
            if (lead_journey_data.action == "deals" && lead_journey_data.agent_id > 0) {
                $("#stp4").show();
                $("#stp4h").show();
            } else {
                $("#stp3").show();
                $("#stp3h").show();
            }
        } else if (conid == "duration") {
            var check_value = this.getAttribute("data_value");
            lead_journey_data.trip_duration = check_value;
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").show();
            $("#stp4h").show();
        } else if (conid == "noperson") {
            var check_value = this.getAttribute("data_value");
            lead_journey_data.no_of_traveller = check_value;
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").hide();
            $("#stp4h").hide();
            if ((lead_journey_data.action == "deals" && lead_journey_data.agent_id > 0) || 1 == 1) {
                var ajxloginvalue = getCookie("loginvalue");
                var ajxpassvalue = getCookie("userpass");
                if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                    if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                        var postargs = {};
                        postargs.traveldate = lead_journey_data.dep_date;
                        if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                            postargs.agent_id = lead_journey_data.agent_id;
                            postargs.nid = lead_journey_data.nid;
                        } else {
                            postargs.destination = lead_journey_data.destination;
                            postargs.duration = lead_journey_data.trip_duration;
                            postargs.budget = lead_journey_data.budget_prices;
                        }
                        postargs.noperson = lead_journey_data.no_of_traveller;
                        postargs.leadaffid = 1044;
                        postargs.chatpostlead = 1;
                        lead_journey_data.action = "leadpost";
                        postargs.othersdata = JSON.stringify(lead_journey_data);
                        register_or_login_lead_journey(postargs);
                    } else {
                        if (ajxpassvalue == null || ajxpassvalue == "undefined" || ajxpassvalue == "") {
                            resend_otp();
                            $("#stp7").show();
                            $("#stp7h").show();
                            $("#mobileotp0").focus();
                        } else {
                            $("#stp8").show();
                            $("#stp8h").show();
                        }
                    }
                } else {
                    $("#stp6").show();
                    $("#stp6h").show();
                    $("#usernamepop").focus();
                }
            } else {
                $("#stp5").show();
                $("#stp5h").show();
            }
        } else if (conid == "budget") {
            var check_value = this.getAttribute("data_value");
            lead_journey_data.budget_prices = check_value;
            $("#stp1").hide();
            $("#stp2").hide();
            $("#stp1h").hide();
            $("#stp2h").hide();
            $("#stp3").hide();
            $("#stp3h").hide();
            $("#stp2date").hide();
            $("#stp4").hide();
            $("#stp4h").hide();
            $("#stp5").hide();
            $("#stp5h").hide();
            var ajxloginvalue = getCookie("loginvalue");
            var ajxpassvalue = getCookie("userpass");
            if (ajxloginvalue != null && ajxloginvalue != "undefined" && ajxloginvalue != "") {
                if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "" && isEmailStatus == 1) {
                    var postargs = {};
                    postargs.traveldate = lead_journey_data.dep_date;
                    if (lead_journey_data.agent_id != "" && lead_journey_data.agent_id != "undefined" && lead_journey_data.agent_id != null) {
                        postargs.agent_id = lead_journey_data.agent_id;
                        postargs.nid = lead_journey_data.nid;
                    } else {
                        postargs.destination = lead_journey_data.destination;
                        postargs.duration = lead_journey_data.trip_duration;
                        postargs.budget = lead_journey_data.budget_prices;
                    }
                    postargs.noperson = lead_journey_data.no_of_traveller;
                    postargs.leadaffid = 1044;
                    postargs.chatpostlead = 1;
                    lead_journey_data.action = "leadpost";
                    postargs.othersdata = JSON.stringify(lead_journey_data);
                    register_or_login_lead_journey(postargs);
                } else {
                    var country_code = getCookie("countrycookie");
                    if (country_code != "91" && isEmailStatus == 0) {
                        $("#stp8").show();
                        $("#stp8h").show();
                        $("#journeyemailtxt").focus();
                    } else {
                        if (ajxpassvalue == null || ajxpassvalue == "undefined" || ajxpassvalue == "") {
                            resend_otp();
                            $("#stp7").show();
                            $("#stp7h").show();
                            $("#mobileotp0").focus();
                        } else {
                            $("#stp8").show();
                            $("#stp8h").show();
                        }
                    }
                }
            } else {
                $("#stp6").show();
                $("#stp6h").show();
                $("#usernamepop").focus();
            }
        }
    });
});
function get_date_from_month_journey(month) {
    var cdate = new Date();
    cm = cdate.getMonth();
    cm - cm + 1;
    var montharr = { January: 1, February: 2, March: 3, April: 4, May: "5", June: 6, July: 7, Augest: 8, August: 8, September: 9, October: 10, November: 11, December: 12 };
    var mm = cdate.getYear();
    var cd = cdate.getDay();
    ccd = Math.floor(Math.random() * (30 - cd + 1) + cd);
    var n = montharr[month];
    var t = new Date();
    var month = "";
    var date = "";
    if (n < cm) {
        t.setDate(t.getYear() + 1);
        month = "0" + n;
        date = "0" + ccd;
    } else {
        month = "0" + n;
        date = "0" + ccd;
    }
    month = month.slice(-2);
    date = date.slice(-2);
    var date = t.getFullYear() + "-" + month + "-" + date;
    return date;
}
function clear_all_journey_div() {
    $("#stp1").hide();
    $(".closejuurneydiv").hide();
}
function lead_update_after_post(args) {
    var leadid = args.leadid;
    $.ajax({ url: "http://local.hellotravel.noida/utility/header_ajax.php?updatedata=ss", data: { lead_ID: leadid, field: args.field, text: args.text, lead_data_post: "1" }, type: "post", success: function (data) {}, error: function () {} });
}
function register_or_login_lead_journey(args) {
    args.leadpost = 1;
    args.self_url = pop_self_url;
    args.ref_url = pop_referer_url;
    if (typeof pageval != "undefined" && pageval != 0) {
        pagesource = pageval;
    }
    var pageaffid = 1044;
    if (typeof assaffid != "undefined" && assaffid != 0) {
        pageaffid = assaffid;
    }
    args.pagesource = pagesource;
    args.pageaffid = pageaffid;
    button_journeyid = lead_journey_data.buttonid;
    $("#" + button_journeyid).hide();
    $("#loading" + button_journeyid).show();
    if (lead_journey_data.actionurl == "feedback" || lead_journey_data.actionurl == "login" || lead_journey_data.actionurl == "plc_feed" || lead_journey_data.actionurl == "ttd_feed") {
        args.leadpost = 0;
    }
    var leadval = getCookie("leadvalue");
    $.ajax({
        url: "http://local.hellotravel.noida/utility/header_ajax.php",
        type: "post",
        data: args,
        success: function (data) {
            $("#" + button_journeyid).show();
            $("#loading" + button_journeyid).hide();
            var dataobj = JSON.parse(data);
            if (dataobj.status == true) {
                if (dataobj.LeadID != "" && dataobj.LeadID != "0" && dataobj.LeadID != undefined) {
                    validateleadbynewjourney(dataobj.LeadID);
                    clear_all_journey_div();
                    if (lead_journey_data.actionurl == "pns") {
                        var pnsid = lead_journey_data.pnsid;
                        var pns_temp = pnsid;
                        pns_temp = pns_temp.replace("+", "");
                        $("#lpop").hide();
                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                            window.location = "tel:" + pnsid;
                        } else {
                            $("." + pns_temp + "_hide").hide();
                            $("." + pns_temp + "_show").show();
                        }
                    } else if (lead_journey_data.actionurl == "login" || lead_journey_data.actionurl == "refresh") {
                        location.reload();
                    } else {
                        if (leadval != "" && leadval != undefined) {
                            if (lead_journey_data.displayid != "" && lead_journey_data.displayid != undefined) {
                                $("#lpop").hide();
                                $("#req" + lead_journey_data.displayid).hide();
                                $("#sent" + lead_journey_data.displayid).show();
                            } else {
                                $("#stp7").hide();
                                $("#lpop").show();
                                $("#stp2").show();
                                $("#stp2h").show();
                                $("#lead_journey_thanks_msg").html("<a href='https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + dataobj.LeadID + "'>Click Here to View Lead Details</a>");
                            }
                        } else {
                            $("#stp7").hide();
                            $("#lpop").show();
                            $("#stp2").show();
                            $("#stp2h").show();
                            $("#lead_journey_thanks_msg").html("<a href='https://www.hellotravel.com/thanks_new.php?by_passmobile_validation=1&lid=" + dataobj.LeadID + "'>Click Here to View Lead Details</a>");
                        }
                    }
                } else if (lead_journey_data.action == "mobile") {
                    $("#stp6").hide();
                    $("#stp6h").hide();
                    country_code = getCookie("countrycookie");
                    if (country_code != "91" && dataobj.emailstatus == false) {
                        $("#stp8h").show();
                        $("#stp8").show();
                        $("#journeyemailtxt").focus();
                    } else {
                        resend_otp();
                        $("#stp7h").show();
                        $("#stp7").show();
                        $("#mobileotp0").focus();
                    }
                } else if (lead_journey_data.action == "emailnextt") {
                } else if (lead_journey_data.action == "otp") {
                    if (dataobj.email == 0) {
                        $("#stp7").hide();
                        $("#stp7h").hide();
                        $("#stp8h").show();
                        $("#stp8").show();
                    } else {
                        if (lead_journey_data.actionurl == "feedback") {
                            var feedback_ques_id = lead_journey_data.questiondata;
                            var questiondatas = feedback_ques_id;
                            submitdata(questiondatas);
                        } else if (lead_journey_data.actionurl == "plc_feed") {
                            var feedback_ques_id = lead_journey_data.frm_redirect_url;
                            lead_journey_data = {};
                            var win = window.open(feedback_ques_id);
                        } else if (lead_journey_data.actionurl == "ttd_feed") {
                            $("#brow").show();
                        } else if (lead_journey_data.actionurl == "login") {
                            location.reload();
                        }
                    }
                }
            } else {
                if (lead_journey_data.action == "otp") {
                    alert(dataobj.message);
                }
                if (lead_journey_data.action == "email") {
                    $("#stp8").hide();
                    $("#stp8h").hide();
                    $("#stp9h").show();
                    $("#stp9").show();
                    $("#otpemailmessage").html(dataobj.message);
                }
                if (lead_journey_data.action == "emailotp") {
                    alert(dataobj.message);
                }
            }
        },
    });
}
$("#journeyemailtxt").keypress(function (event) {
    $("#jry_emailotp").hide();
    $("#otpemailmessage").html("");
    $("#emailotpflag").val("0");
});
$(document).keydown(function (e) {
    if (e.keyCode == 27) {
        $("#trnSer").hide();
    }
});
var i = 1;
var id = "";
$(window).scroll(function () {
    var scroll = $(window).scrollTop();
    if (pageName != "story" && pageName != "things_2see_detail" && pageName != "things_2do_detail") {
        if (scroll >= 100) {
            $(".nav_mnu1").hide();
        } else if (scroll <= 100) {
            $(".nav_mnu1").show();
        }
    }
    var s_hight = 150;
    if (pageName == "listpage") {
        if (placeq != "") {
            s_hight = 300;
        } else {
            s_hight = 670;
        }
    }
    if (scroll >= s_hight) {
        $(".hmMenu2").addClass("hmM");
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".hmMenu1").addClass("hmM");
            $(".nav_mnu1").hide();
            $("#logo01").hide();
            $("#search01").hide();
            $("#lsM").show();
            $("#myhedBg").addClass("bgm");
        }
    } else if (scroll <= s_hight) {
        $(".hmMenu2").removeClass("hmM");
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".hmMenu1").removeClass("hmM");
            $(".nav_mnu1").hide();
            $("#logo01").show();
            $("#search01").show();
            $("#lsM").hide();
            $("#myhedBg").removeClass("bgm");
        }
    }
    if (pageName == "deal") {
        if (scroll >= 250) {
            $("#sticky_h").addClass("stk");
        } else {
            $("#sticky_h").removeClass("stk");
        }
        if (scroll >= 250) {
            $("#mbtnbottom").show();
        } else {
            $("#mbtnbottom").hide();
        }
        var y = $(this).scrollTop();
        if (y > 800 && !check) {
            $(".bottomD").fadeIn();
        } else {
            $(".bottomD").fadeOut();
        }
    }
});
function myFunctionBar() {
    var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var scrolled = (winScroll / height) * 140;
    document.getElementById("myBar").style.width = scrolled + "%";
}
function showmorestory(data) {
    $("#smalldesc").hide();
    $("#largedesc").show();
    $("#read-more").hide();
}
function resetsearch(data) {
    document.getElementById("serWidths").style.width = "130px";
}
function ScrollToResolver(elem) {
    var jump = parseInt(elem.getBoundingClientRect().top - 100);
    document.body.scrollTop += jump;
    document.documentElement.scrollTop += jump;
    if (!elem.lastjump || elem.lastjump > Math.abs(jump)) {
        elem.lastjump = Math.abs(jump);
        setTimeout(function () {
            ScrollToResolver(elem);
        }, "100");
    } else {
        elem.lastjump = null;
    }
}
$(document).ready(function () {
    if (pageName == "listpage") {
        try {
            $("#datepicker").datepicker();
        } catch (e) {
            setTimeout(function () {
                $("#datepicker").datepicker();
            }, 100);
        }
        if (placeq != "") {
            ScrollToResolver(document.getElementById("startads"));
        }
    } else {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".container_slide").carousel({ num: 5, maxWidth: 250, maxHeight: 200, distance: 20, scale: 0.6, animationTime: 800, showTime: 1500 });
        } else {
            $(".container_slide").carousel({ num: 5, maxWidth: 400, maxHeight: 300, distance: 50, scale: 0.6, animationTime: 800, showTime: 1500 });
        }
    }
});
$(document).ready(function () {
    getcountryip();
   getcounrtyc() ;
});
var getPopup_old_vid = getCookie("vid_old");
var getPopup_vid = getCookie("vid");
if (getPopup_old_vid) {
    localStorage.removeItem("serachdata");
    delete_cookie("vid_old");
}
if (!getPopup_vid) {
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: true,
        data: { chk_vid: 1 },
        type: "post",
        success: function (data) {
            console.log(data);
            vid_decoded_client = data;
        },
    });
}
function getcountryip() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var response = JSON.parse(this.responseText);
            $("[id^=f_country]").val(response.country);
            $("[id^=frm_country]").val(response.country_iso);
	    if(document.getElementById("city-from")){
		document.getElementById("city-from").value=response.CITY;
	    }
            privacy = response.privacy;
        }
    };
    xhttp.open("POST", baseurl + "utility/getipcountry.php", true);
    xhttp.send();
}
if (last_lead != "" && pageName != "feedback_for_places") {
    var get_30 = 0;
    var getPopup30 = getCookie("popup30");
    if (getPopup30) {
        delete_cookie("popup30");
        document.cookie = "popup_shown_30=0; path=/";
    }
    var getPopup30 = getCookie("popup30");
    if (!getCookie("getPopup30")) {
        var seconds = Math.round(new Date().getTime() / 1e3);
        cookie_30 = seconds + 30;
        document.cookie = "popup30=" + cookie_30 + "; path=/";
        get_30 = cookie_30;
    } else {
        get_30 = getCookie("popup30");
    }
    var pop_show_30 = 0;
    pop_show_30 = getCookie("popup_shown_30");
    close_pop_30 = getCookie("close_pop_30");
    $("#close_1_last").click(function () {
        $("#ratLT").hide();
        $("html,body").css({ overflow: "auto", height: "auto" });
        document.cookie = "close_pop_30=1; path=/";
    });
    document.addEventListener("keyup", function (e) {
        if (e.keyCode == 27) {
            $("#ratLT").hide();
            $("html,body").css({ overflow: "auto", height: "auto" });
        }
    });
}
function myTimer1() {
    var curr_time = Math.round(new Date().getTime() / 1e3);
    if (curr_time >= get_30 && pop_show_30 != 1 && close_pop_30 != 1) {
        $("#ratLT").show();
        $("html,body").css({ overflow: "hidden", height: "hidden" });
        document.cookie = "popup_shown_30=1; path=/";
        $("#close_1_last").click(function () {
            $("#ratLT").hide();
            $("html,body").css({ overflow: "auto", height: "auto" });
            document.cookie = "close_pop_30=1; path=/";
        });
        document.addEventListener("keyup", function (e) {
            if (e.keyCode == 27) {
                $("#ratLT").hide();
                $("html,body").css({ overflow: "auto", height: "auto" });
            }
        });
        clearInterval(myVar_30);
    }
}
function open_div(id) {
    $("#dw_0" + id).toggle();
    $("#ar_don" + id).toggle();
    $("#ar_up" + id).toggle();
    $("#dws" + id).toggleClass("day_wise");
}
function myFunction() {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
    } else {
        if (window.pageYOffset > sticky) {
            formN.classList.add("sticky");
        } else {
            formN.classList.remove("sticky");
        }
    }
    var y = $(window).scrollTop() + $(window).height();
    console.log(y);
    if (y > 6500) {
        $("#myForm").hide();
    } else {
        $("#myForm").show();
    }
}
if (pageName == "deal") {
    var check = false;
    $(document).scroll(function () {
        var y = $(this).scrollTop();
        if (y > 800 && !check) {
            $(".bottomD").fadeIn();
        } else {
            $(".bottomD").fadeOut();
        }
    });
    function closebtn() {
        check = true;
        $(".bottomD").hide();
    }
    function submitenquirybynew(mobcounter) {
        if (pageName == "deal") {
            var subajxloginvalue = getCookie("loginvalue");
            var subajxpassvalue = getCookie("userpass");
            if (subajxpassvalue != "undefined" && subajxpassvalue != "") {
                check_dup_buy(did, pvtid, "logincat", "nonlogincat");
            } else {
                if (subajxloginvalue != "undefined" && subajxloginvalue != "") {
                    check_dup_buy(did, pvtid, "logincat", "nonlogincat");
                } else {
                    mob_number = $("#usernamepopbottom" + mobcounter).val();
                    lead_journey_data.nid = did;
                    lead_journey_data.agent_id = pvtid;
                    $("#lpop").show();
                    $("#stp6").show();
                    $("#stp6h").show();
                    $("#usernamepop").val(mob_number);
                    $("#usernamepop").focus();
                }
            }
        } else {
            mob_number = $("#usernamepopbottom" + mobcounter).val();
            $("#lpop").show();
            $("#stp1").show();
            $("#stp1h").show();
            $("#usernamepop").val(mob_number);
        }
    }
    window.onscroll = function () {
        //myFunction();
    };
    var formN = document.getElementById("myForm");
    var sticky = 0;//formN.offsetTop;
 }
$(document).ready(function () {
    var slice = [].slice;
    (function (c, b) {
        var a;
        b.Starrr = a = (function () {
            d.prototype.defaults = { rating: void 0, max: 5, readOnly: false, emptyClass: "fa fa-star-o", fullClass: "fa fa-star", change: function (g, f) {} };
            function d(f, e) {
                this.options = c.extend({}, this.defaults, e);
                this.$el = f;
                this.createStars();
                this.syncRating();
                if (this.options.readOnly) {
                    return;
                }
                this.$el.on(
                    "mouseover.starrr",
                    "a",
                    (function (g) {
                        return function (h) {
                            return g.syncRating(g.getStars().index(h.currentTarget) + 1);
                        };
                    })(this)
                );
                this.$el.on(
                    "mouseout.starrr",
                    (function (g) {
                        return function () {
                            return g.syncRating();
                        };
                    })(this)
                );
                this.$el.on(
                    "click.starrr",
                    "a",
                    (function (g) {
                        return function (h) {
                            return g.setRating(g.getStars().index(h.currentTarget) + 1);
                        };
                    })(this)
                );
                this.$el.on("starrr:change", this.options.change);
            }
            d.prototype.getStars = function () {
                return this.$el.find("a");
            };
            d.prototype.createStars = function () {
                var e, g, f;
                f = [];
                for (e = 1, g = this.options.max; 1 <= g ? e <= g : e >= g; 1 <= g ? e++ : e--) {
                    f.push(this.$el.append("<a href='javascript:;' />"));
                }
                return f;
            };
            d.prototype.setRating = function (e) {
                if (this.options.rating === e) {
                    e = void 0;
                }
                this.options.rating = e;
                this.syncRating();
                return this.$el.trigger("starrr:change", e);
            };
            d.prototype.getRating = function () {
                return this.options.rating;
            };
            d.prototype.syncRating = function (h) {
                var l, g, e, k, f;
                h || (h = this.options.rating);
                l = this.getStars();
                f = [];
                for (g = e = 1, k = this.options.max; 1 <= k ? e <= k : e >= k; g = 1 <= k ? ++e : --e) {
                    f.push(
                        l
                            .eq(g - 1)
                            .removeClass(h >= g ? this.options.emptyClass : this.options.fullClass)
                            .addClass(h >= g ? this.options.fullClass : this.options.emptyClass)
                    );
                }
                return f;
            };
            return d;
        })();
        return c.fn.extend({
            starrr: function () {
                var d, e;
                (e = arguments[0]), (d = 2 <= arguments.length ? slice.call(arguments, 1) : []);
                return this.each(function () {
                    var f;
                    f = c(this).data("starrr");
                    if (!f) {
                        c(this).data("starrr", (f = new a(c(this), e)));
                    }
                    if (typeof e === "string") {
                        return f[e].apply(f, d);
                    }
                });
            },
        });
    })(window.jQuery, window);
    $("#star1_1").starrr({
        change: function (e, value) {
            $("#star_rating_val").val(value);
            var trvl = $("#save_other").val();
            var trvl_name = $("#other_company").val();
            if ($("#travelwithid_sel").val() == "") {
                alert("Please select agent name");
                $("#travelwithid_sel").focus;
                return false;
            }
            if ($("#travelwithid_sel").val() == "other" && $("#save_other").val() == "") {
                alert("Please select agent name");
                $("#other_company").focus;
                return false;
            }
            if (value) {
                $.ajax({
                    url: baseurl + "utility/header_ajax.php",
                    data: { last_lead: last_lead, star: value, mode: "update_star_rating", uid_client_feed: uid_client_feed, travelwith: trvl, travel_name: trvl_name },
                    type: "POST",
                    cache: false,
                    success: function (data) {},
                });
                window.open(
                    "https://www.hellotravel.com/feedback?id=" + last_lead + "&source=popup&star=" + value + "&comp=" + trvl + "&utm_source=post-travel-feedback&utm_medium=website&utm_campaign=feedback&utm_term=popup-last-trip-review",
                    "_self"
                );
                document.cookie = "close_pop_30=1; path=/";
                return false;
            }
        },
    });
    $("#other_company").bind("cut copy paste", function (e) {
        e.preventDefault();
    });
    $("#other_company").on("change", function () {
        var val = this.value;
        other_agent = val;
        var star_val = $("#star_rating_val").val();
        if (star_val == 0) {
            alert("Please select star rating");
        }
        if (other_agent.trim() != "") {
            $.ajax({
                url: baseurl + "utility/header_ajax.php",
                data: { last_lead: last_lead, value: val, mode: "travel_with_other", uid_client_feed: uid_client_feed, star_val: star_val },
                type: "POST",
                cache: false,
                success: function (data) {
                    $("#save_other").val(data);
                    if (star_val != 0) {
                        window.open(
                            "https://www.hellotravel.com/feedback?id=" +
                                last_lead +
                                "&source=popup&star=" +
                                star_val +
                                "&comp=" +
                                data +
                                "&utm_source=post-travel-feedback&utm_medium=website&utm_campaign=feedback&utm_term=popup-last-trip-review",
                            "_self"
                        );
                        document.cookie = "close_pop_30=1; path=/";
                        return false;
                    }
                },
            });
        }
    });
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        $(".m_chat").hide();
        $(".m_chat_01").hide();
        $(".bubble").hide();
    }
});
function getAgents_name(val) {
    if (val != "") {
        $.ajax({
            url: baseurl + "utility/feedbackajax.php",
            data: { value: val, getagent: "getagent" },
            cache: false,
            type: "POST",
            success: function (data) {
                $("datalist").html("");
                $("datalist").html(data);
            },
            error: function (error) {
                return false;
            },
        });
    }
}
function connection_agent(id) {
    travelwith = $("#" + id).val();
    $("#save_other").val(travelwith);
    var company_name = $("#" + id + " option:selected").text();
    var star_val = $("#star_rating_val").val();
    $("#travelwith" + travelwith).hide();
    $("#travelwith option[value='0']").hide();
    $("#others_sel").hide("slow");
    if (travelwith == 0) {
    } else if (travelwith == "other") {
        travelwith = "";
        $("#others_sel").show("slow");
    } else {
        if (star_val == 0) {
            alert("Please select star rating");
            return false;
        }
        $.ajax({
            url: baseurl + "utility/header_ajax.php",
            data: { last_lead: last_lead, value: travelwith, mode: "travel_with_save", uid_client_feed: uid_client_feed, companyname: company_name, star_val: star_val },
            type: "POST",
            cache: false,
            success: function (data) {},
        });
        window.open(
            "https://www.hellotravel.com/feedback?id=" + last_lead + "&source=popup&star=" + star_val + "&comp=" + travelwith + "&utm_source=post-travel-feedback&utm_medium=website&utm_campaign=feedback&utm_term=popup-last-trip-review",
            "_self"
        );
        document.cookie = "close_pop_30=1; path=/";
        return false;
    }
}
function open_add_review() {
    localStorage.setItem("referal_review", window.location);
    var vid_vl = getCookie("vid");
    var win = window.open("/plc-reviews.php?type_page=plc&source=header&vid=" + vid_vl, "_self");
    return false;
}
var logval = getCookie("loginvalue");
if (logval) {
    $.ajax({ url: baseurl + "utility/header_ajax.php", cache: true, data: { traveller_login_time: "update" }, type: "post", success: function (data) {} });
}
function filteropen() {
    $("#mySidebar1").show();
    $("#myOverlay1").show();
}
function hidefilter() {
    $("#mySidebar1").hide();
    $("#myOverlay1").hide();
}
var pollingForData = false;

function getdealslat(placeq) {
    if (placeq != "") {
        $.ajax({
            url: baseurl + "utility/getlatlong.php?splace=" + placeq,
            type: "GET",
            cache: false,
            success: function (data) {
                var response = data;
                if (response.status) {
                    $("#reqvisitedcount").html(response.leadcount + " visited");
                    $("#reqvisitedcount").show();
                }
                if (response.l_status) {
                    $("#reqdistancefrom").html(response.distance + "kms away");
                    $("#reqdistancefrom").show();
                }
                if (response.pstatus) {
                    $("#reqlsminprice").html("â‚¹ " + response.price + " onwards");
                    $("#reqlsminprice").show();
                }
            },
            error: function (error) {},
        });
    }
}
function search_relevence(sr, type, city, url, page_number, finalcount) {
    var hrefdelurl = window.location.href;
    $.ajax({
        url: baseurl + "utility/header_ajax.php",
        cache: true,
        data: { deals_sr: sr, page_city: city, clicktype: type, search_relevency_db: "1", page_url: hrefdelurl, page_number: page_number, finalcount: finalcount },
        type: "post",
        success: function (data) {},
    });
}
function autoclickurl(url) {
    window.location.href = url;
}
$("#close_pwht1").click(function () {
    $("#pwht_amt1").hide();
});
$("#imageplacetosee").keypress(function (event) {
    var keycode = event.keyCode ? event.keyCode : event.which;
    if (keycode == "13") {
        var main_clause = "";
        var place_to = "";
        place_to = document.getElementById("imageplacetosee").value;
        if (document.getElementById("imageplacetosee").value != "" && !document.getElementById("imageplacetosee").value.match(/^[a-zA-z0-9\s-_.,]+$/)) {
            document.getElementById("to").focus();
            alert("Please enter valid destination");
            return false;
        }
        place_to1 = place_to.toLowerCase();
        if (place_to != "" && place_to != "Where do you want to go") {
            var place_to_modified = place_to.replace(/\s*[,]+\s*/gi, "-s-");
            place_to_modified = place_to_modified.replace(/[\s]+/gi, "-");
            document.location = "https://www.hellotravel.com/deals/" + place_to_modified;
        }
        return false;
    }
});
$("#place_to").keypress(function (event) {
    if (event.which == 13) {
        if (isMobile == true) {
            starRating("m");
        } else {
            starRatingDesk();
        }
    }
});
function check_inter_indiadiv() {
    if ($("#radiopts_deals:checked").val() == "internationalpts") {
        $("#domesticpts").hide();
        $("#internationalpts").show();
    } else if ($("#radiopts_deals:checked").val() == "domesticpts") {
        $("#internationalpts").hide();
        $("#domesticpts").show();
    }
}
function closechatdicbut() {
    $("#closedchatdiv").hide();
}
$(".planatrip").click(function () {
    $(".overlay-bg, .overlay-content").hide();
});
function showVisible(id) {
    var tabid = id.replace(/[0-9]/g, "");
    $("." + tabid).hide();
    $("#" + id).show();
    $("#nav" + id).show();
    $(".tab" + tabid).removeClass("extr_f2_act");
    $("#sp" + id).addClass("extr_f2_act");
}
function showVisiblemonthstory(id) {
    var tabid = id.replace(/[0-9]/g, "");
    $("." + tabid).hide();
    $("#" + id).show();
}
function open_div_deals(idd) {
    $("#ar_don" + idd).toggle();
    $("#ar_up" + idd).toggle();
    $("#dw_" + idd).removeClass("days");
    $(".days").hide();
    $("#dw_" + idd).toggle();
    $("#dw_" + idd).addClass("days");
}
function price(obj) {
    var star = $("#hidden_star").val();
    var txt_box = $("#ip_con").val();
    var trip_dur = $("#trip_duration").val();
    var no_of_trav = $("#n_of_trav").val();
    var distance = $("#dis_in_km").val();
    var flight_checke = 0;
    if ($("#flight_check").is(":checked")) {
        flight_checke = 1;
    }
    if ((trip_dur && no_of_trav) || flight_checke == 1) {
        var teir = 1;
        $.ajax({
            url: "https://www.hellotravel.com/utility/calculate_trip_price_ajax-11.php",
            type: "POST",
            data: { country: txt_box, distance: distance, trip_dur: trip_dur, no_of_trav: no_of_trav, teir: teir, star: star, flight_checked: flight_checke },
            success: function (data) {
                $("#price").html(data);
                $("#price_id").css("display", "block");
            },
        });
    }
}
$(document).ready(function () {

    if (pageName == "home") {
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            $(".container_slide").carousel({ num: 5, maxWidth: 250, maxHeight: 200, distance: 20, scale: 0.6, animationTime: 800, showTime: 1500 });
        } else {
            $(".container_slide").carousel({ num: 5, maxWidth: 400, maxHeight: 300, distance: 50, scale: 0.6, animationTime: 800, showTime: 1500 });
        }
    }
});
function validateleadbynewjourney(lead_id) {
    trans = 0;
    var http = new XMLHttpRequest();
    var url = "../serveform/lead-publish-v3.php?lead_id=" + lead_id + "&tuidmaxtrans=" + trans;
    var ajxpassvalue = getCookie("userpass");
    if (ajxpassvalue != null && ajxpassvalue != "undefined" && ajxpassvalue != "") {
        url = "../serveform/lead-publish-_instantv3.php?by_passmobile_validation=1&lead_id=" + lead_id + "&tuidmaxtrans=" + trans;
    }
    http.open("GET", url, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.onreadystatechange = function () {
        if (http.readyState == 4 && http.status == 200) {
            if (http.responseText != "") {
                console.log(http.responseText);
                response = JSON.parse(http.responseText);
            }
        }
    };
    http.send();
}
function newjourney_price() {
    trans = 0;
    var http = new XMLHttpRequest();
    var url = "https://www.hellotravel.com/utility/calculate_trip_price_ajax-11_all.php?lkjehdfjsgdjhsg";
    http.open("GET", url, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.onreadystatechange = function () {
        if (http.readyState == 4 && http.status == 200) {
            if (http.responseText != "") {
                console.log(http.responseText);
                response = JSON.parse(http.responseText);
                $("#5starp").text(response["5"]);
                $("#4starp").text(response["4"]);
                $("#3starp").text(response["3"]);
            }
        }
    };
    http.send();
}
$(document).ready(function () {
    $(".arraowcls").click(function () {
        alert("You can now edit your trip details at the last step");
    });
});
function gotootpmnext(i) {
    i = i + 1;
    $("#mobileotp" + i).focus();
}
function gotootpenext(i) {
    i = i + 1;
    $("#emailotp" + i).focus();
}




