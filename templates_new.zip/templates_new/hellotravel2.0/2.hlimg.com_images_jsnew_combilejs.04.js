function validateForm1(e) {
    if ("" == document.getElementById("phone" + e).value) return document.getElementById("phone" + e).focus(), alert("Please Enter Your mobile no"), !1;
    if (document.getElementById("f_country" + e).value.toLowerCase() === "India".toLowerCase()) {
        var a = document.getElementById("phone" + e).value,
            t = document.getElementById("phone" + e).value.length;
        if (t < 10 || 10 < t) return alert("Please enter a valid 10 digit mobile no"), document.getElementById("phone" + e).focus(), !1;
        if ("9" != a.charAt(0) && "8" != a.charAt(0) && "7" != a.charAt(0) && "6" != a.charAt(0)) return alert("Please enter a valid mobile no starting with 6, 7, 8 or 9"), document.getElementById("phone" + e).focus(), !1;
    }
    if ("" == document.getElementById("f_country" + e).value) return document.getElementById("f_country" + e).focus(), alert("Please Enter Country"), !1;
    if ("" == document.getElementById("dest" + e).value) return document.getElementById("dest" + e).focus(), alert("Please Enter Your Going to city"), !1;
    var i = (n = new Date()).getTime();
    (i += 36e5), n.setTime(i);
    var n,
        r = "; expires=" + n.toUTCString() + "; path=/";
    if (((document.cookie = "pytd=" + document.getElementById("dest" + e).value + r), (document.cookie = "pytd=" + document.getElementById("dest" + e).value), "" === document.getElementById("dest" + e).value))
        return document.getElementById("dest" + e).focus(), !1;
    if (
        ((i = (n = new Date()).getTime()),
        (i += 36e5),
        n.setTime(i),
        (r = "; expires=" + n.toUTCString() + "; path=/"),
        (document.cookie = "pytd=" + document.getElementById("dest" + e).value + r),
        (document.cookie = "pytd=" + document.getElementById("dest" + e).value),
        "" == document.getElementById("adults" + e).options[document.getElementById("adults" + e).selectedIndex].value)
    )
        return document.getElementById("adults" + e).focus(), alert("Please Enter No. Of People"), !1;
    if ("" == document.getElementById("travel_date" + e).value) return document.getElementById("travel_date" + e).focus(), alert("Please Enter Your Travel Date"), !1;
    if ("" == document.getElementById("du_of_st" + e).options[document.getElementById("du_of_st" + e).selectedIndex].value) return document.getElementById("du_of_st" + e).focus(), alert("Please Enter Your Duration of Stay"), !1;
    if ("" == document.getElementById("depar_city" + e).value) return document.getElementById("depar_city").focus(), alert("Please Enter Your Departure city"), !1;
    if ("" == document.getElementById("depar_city" + e).value) return document.getElementById("depar_city" + e).focus(), !1;
    if ("" == document.getElementById("c_name" + e).value) return document.getElementById("c_name" + e).focus(), alert("Please Enter Your Name"), !1;
    if (
        ((i = (n = new Date()).getTime()),
        (i += 36e5),
        n.setTime(i),
        (r = "; expires=" + n.toUTCString() + "; path=/"),
        (document.cookie = "pytn=" + document.getElementById("c_name" + e).value + r),
        (document.cookie = "pytn=" + document.getElementById("c_name" + e).value),
        "" == document.getElementById("e_mail" + e).value)
    )
        return document.getElementById("e_mail" + e).focus(), alert("Please Enter Your Email id"), !1;
    if (
        ((i = (n = new Date()).getTime()),
        (i += 36e5),
        n.setTime(i),
        (r = "; expires=" + n.toUTCString() + "; path=/"),
        (document.cookie = "pytml=" + document.getElementById("e_mail" + e).value + r),
        (document.cookie = "pytml=" + document.getElementById("e_mail" + e).value),
        "" != document.getElementById("e_mail" + e).value && !document.getElementById("e_mail" + e).value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/))
    )
        return document.getElementById("e_mail" + e).focus(), alert("Please correct your email"), !1;
    if (
        ((i = (n = new Date()).getTime()),
        (i += 36e5),
        n.setTime(i),
        (r = "; expires=" + n.toUTCString() + "; path=/"),
        (document.cookie = "pytml=" + document.getElementById("e_mail" + e).value + r),
        (document.cookie = "pytml=" + document.getElementById("e_mail" + e).value),
        "" != document.getElementById("c_name" + e).value && !document.getElementById("c_name" + e).value.match(/^[a-zA-z ]+(,[a-zA-z ]+){0,11}$/))
    )
        return document.getElementById("c_name" + e).focus(), !1;
    if (
        ((i = (n = new Date()).getTime()),
        (i += 36e5),
        n.setTime(i),
        (r = "; expires=" + n.toUTCString() + "; path=/"),
        (document.cookie = "pytn=" + document.getElementById("c_name" + e).value + r),
        (document.cookie = "pytn=" + document.getElementById("c_name" + e).value),
        "" == document.getElementById("budget_f" + e).options[document.getElementById("budget_f" + e).selectedIndex].value)
    )
        return document.getElementById("budget_f" + e).focus(), alert("Please Enter Your Budget"), !1;
    if (null != document.getElementById("privacycheck" + e) && "undefined" != document.getElementById("privacycheck" + e) && !document.getElementById("privacycheck" + e).checked)
        return alert("Please check privacy policy"), document.getElementById("privacycheck" + e).focus(), !1;
    var s = document.getElementsByName("enqfrom" + e)[0];
    return document.getElementById("thanks"), s.submit(s), s.reset(), !1;
}
function o(e) {
    window.open("../thanks.php?lid=" + e, "_blank");
}
function isNumberKey1(e) {
    var a = e.which ? e.which : event.keyCode;
    return !(31 < a && (a < 48 || 57 < a));
}
function onlyAlphabets1(e) {
    var a = e.which ? e.which : event.keyCode;
    return a < 31 || (64 < a && a < 91) || (96 < a && a < 123) || 32 == a;
}
function getuser(o) {
    var e = document.getElementById("phone" + o).value;
    10 == e.length &&
        $.ajax({
            url: "https://www.hellotravel.com/chat/checklogin.php",
            type: "POST",
            data: { mobile: e, type: "mobile" },
            cache: !1,
            success: function (e) {
                var a = JSON.parse(e);
                if (a.status) {
                    var t = a.lead_email,
                        i = a.lead_name,
                        n = a.lead_city,
                        r = a.lead_country_iso,
                        s = a.lead_country_name;
                    "" != t && ((document.getElementById("e_mail" + o).value = t), (document.getElementById("e_mail" + o).style.display = "none")),
                        "" != i && ((document.getElementById("c_name" + o).value = i), (document.getElementById("c_name" + o).style.display = "none")),
                        "" != n && ((document.getElementById("depar_city" + o).value = n), (document.getElementById("depar_city" + o).style.display = "none")),
                        "" != r && (document.getElementById("frm_country" + o).value = r),
                        "" != s && ((document.getElementById("f_country" + o).value = s), (document.getElementById("countryfrm_full" + o).value = s));
                } else
                    (document.getElementById("e_mail" + o).value = ""),
                        (document.getElementById("c_name" + o).value = ""),
                        (document.getElementById("depar_city" + o).value = ""),
                        (document.getElementById("spandep" + o).style.display = "block"),
                        (document.getElementById("spanname" + o).style.display = "block"),
                        (document.getElementById("spanemail" + o).style.display = "block"),
                        (document.getElementById("e_mail" + o).style.display = "block"),
                        (document.getElementById("c_name" + o).style.display = "block"),
                        (document.getElementById("depar_city" + o).style.display = "block");
            },
        });
}
function getParameterByName(e, a) {
    a || (a = window.location.href), (e = e.replace(/[\[\]]/g, "\\$&"));
    var t = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)").exec(a);
    return t ? (t[2] ? decodeURIComponent(t[2].replace(/\+/g, " ")) : "") : null;
}
$(function () {
    var e;
    window.jQuery,
        window,
        document,
        (e = function (e) {
            function r(e, a) {
                return e.classList ? e.classList.contains(a) : new RegExp("\\b" + a + "\\b").test(e.className);
            }
            function t(e, a, t) {
                e.attachEvent ? e.attachEvent("on" + a, t) : e.addEventListener(a, t);
            }
            function i(e, a, t) {
                e.detachEvent ? e.detachEvent("on" + a, t) : e.removeEventListener(a, t);
            }
            function a(i, e, n, a) {
                t(a || document, e, function (e) {
                    for (var a, t = e.target || e.srcElement; t && !(a = r(t, i)); ) t = t.parentElement;
                    a && n.call(t, e);
                });
            }
            if (document.querySelector) {
                var s = {
                    selector: 0,
                    source: 0,
                    minChars: 3,
                    delay: 150,
                    offsetLeft: 0,
                    offsetTop: 1,
                    cache: 1,
                    menuClass: "",
                    renderItem: function (e, a) {
                        a = a.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                        var t = new RegExp("(" + a.split(" ").join("|") + ")", "gi");
                        return '<div class="autocomplete-suggestion" data-val="' + e + '">' + e.replace(t, "<b>$1</b>") + "</div>";
                    },
                    onSelect: function () {},
                };
                for (var n in e) e.hasOwnProperty(n) && (s[n] = e[n]);
                for (var o = "object" == typeof s.selector ? [s.selector] : document.querySelectorAll(s.selector), d = 0; d < o.length; d++) {
                    var l = o[d];
                    (l.sc = document.createElement("div")),
                        (l.sc.className = "autocomplete-suggestions " + s.menuClass),
                        (l.autocompleteAttr = l.getAttribute("autocomplete")),
                        l.setAttribute("autocomplete", "off"),
                        (l.cache = {}),
                        (l.last_val = ""),
                        (l.updateSC = function (e, a) {
                            var t = l.getBoundingClientRect();
                            if (
                                ((l.sc.style.left = Math.round(t.left + (window.pageXOffset || document.documentElement.scrollLeft) + s.offsetLeft) + "px"),
                                (l.sc.style.top = Math.round(t.bottom + (window.pageYOffset || document.documentElement.scrollTop) + s.offsetTop) + "px"),
                                (l.sc.style.width = Math.round(t.right - t.left) + "px"),
                                !e &&
                                    ((l.sc.style.display = "block"),
                                    l.sc.maxHeight || (l.sc.maxHeight = parseInt((window.getComputedStyle ? getComputedStyle(l.sc, null) : l.sc.currentStyle).maxHeight)),
                                    l.sc.suggestionHeight || (l.sc.suggestionHeight = l.sc.querySelector(".autocomplete-suggestion").offsetHeight),
                                    l.sc.suggestionHeight))
                            )
                                if (a) {
                                    var i = l.sc.scrollTop,
                                        n = a.getBoundingClientRect().top - l.sc.getBoundingClientRect().top;
                                    0 < n + l.sc.suggestionHeight - l.sc.maxHeight ? (l.sc.scrollTop = n + l.sc.suggestionHeight + i - l.sc.maxHeight) : n < 0 && (l.sc.scrollTop = n + i);
                                } else l.sc.scrollTop = 0;
                        }),
                        t(window, "resize", l.updateSC),
                        document.body.appendChild(l.sc),
                        a(
                            "autocomplete-suggestion",
                            "mouseleave",
                            function () {
                                var e = l.sc.querySelector(".autocomplete-suggestion.selected");
                                e &&
                                    setTimeout(function () {
                                        e.className = e.className.replace("selected", "");
                                    }, 20);
                            },
                            l.sc
                        ),
                        a(
                            "autocomplete-suggestion",
                            "mouseover",
                            function () {
                                var e = l.sc.querySelector(".autocomplete-suggestion.selected");
                                e && (e.className = e.className.replace("selected", "")), (this.className += " selected");
                            },
                            l.sc
                        ),
                        a(
                            "autocomplete-suggestion",
                            "mousedown",
                            function (e) {
                                if (r(this, "autocomplete-suggestion")) {
                                    var a = this.getAttribute("data-val");
                                    (l.value = a), s.onSelect(e, a, this), (l.sc.style.display = "none");
                                }
                            },
                            l.sc
                        ),
                        (l.blurHandler = function () {
                            try {
                                var a = document.querySelector(".autocomplete-suggestions:hover");
                            } catch (e) {
                                a = 0;
                            }
                            a
                                ? l !== document.activeElement &&
                                  setTimeout(function () {
                                      l.focus();
                                  }, 20)
                                : ((l.last_val = l.value),
                                  (l.sc.style.display = "none"),
                                  setTimeout(function () {
                                      l.sc.style.display = "none";
                                  }, 350));
                        }),
                        t(l, "blur", l.blurHandler);
                    var c = function (e) {
                        var a = l.value;
                        if ((l.cache[a] = e).length && a.length >= s.minChars) {
                            for (var t = "", i = 0; i < e.length; i++) t += s.renderItem(e[i], a);
                            (l.sc.innerHTML = t), l.updateSC(0);
                        } else l.sc.style.display = "none";
                    };
                    (l.keydownHandler = function (e) {
                        var a,
                            t,
                            i = window.event ? e.keyCode : e.which;
                        if ((40 == i || 38 == i) && l.sc.innerHTML)
                            return (
                                (t = l.sc.querySelector(".autocomplete-suggestion.selected"))
                                    ? (a = 40 == i ? t.nextSibling : t.previousSibling)
                                        ? ((t.className = t.className.replace("selected", "")), (a.className += " selected"), (l.value = a.getAttribute("data-val")))
                                        : ((t.className = t.className.replace("selected", "")), (l.value = l.last_val), (a = 0))
                                    : (((a = 40 == i ? l.sc.querySelector(".autocomplete-suggestion") : l.sc.childNodes[l.sc.childNodes.length - 1]).className += " selected"), (l.value = a.getAttribute("data-val"))),
                                l.updateSC(0, a),
                                !1
                            );
                        27 == i
                            ? ((l.value = l.last_val), (l.sc.style.display = "none"))
                            : (13 != i && 9 != i) ||
                              ((t = l.sc.querySelector(".autocomplete-suggestion.selected")) &&
                                  "none" != l.sc.style.display &&
                                  (s.onSelect(e, t.getAttribute("data-val"), t),
                                  setTimeout(function () {
                                      l.sc.style.display = "none";
                                  }, 20)));
                    }),
                        t(l, "keydown", l.keydownHandler),
                        (l.keyupHandler = function (e) {
                            var a = window.event ? e.keyCode : e.which;
                            if (!a || ((a < 35 || 40 < a) && 13 != a && 27 != a)) {
                                var t = l.value;
                                if (t.length >= s.minChars) {
                                    if (t != l.last_val) {
                                        if (((l.last_val = t), clearTimeout(l.timer), s.cache)) {
                                            if (t in l.cache) return void c(l.cache[t]);
                                            for (var i = 1; i < t.length - s.minChars; i++) {
                                                var n = t.slice(0, t.length - i);
                                                if (n in l.cache && !l.cache[n].length) return void c([]);
                                            }
                                        }
                                        l.timer = setTimeout(function () {
                                            s.source(t, c);
                                        }, s.delay);
                                    }
                                } else (l.last_val = t), (l.sc.style.display = "none");
                            }
                        }),
                        t(l, "keyup", l.keyupHandler),
                        (l.focusHandler = function (e) {
                            (l.last_val = "\n"), l.keyupHandler(e);
                        }),
                        s.minChars || t(l, "focus", l.focusHandler);
                }
                this.destroy = function () {
                    for (var e = 0; e < o.length; e++) {
                        var a = o[e];
                        i(window, "resize", a.updateSC),
                            i(a, "blur", a.blurHandler),
                            i(a, "focus", a.focusHandler),
                            i(a, "keydown", a.keydownHandler),
                            i(a, "keyup", a.keyupHandler),
                            a.autocompleteAttr ? a.setAttribute("autocomplete", a.autocompleteAttr) : a.removeAttribute("autocomplete"),
                            document.body.removeChild(a.sc),
                            (a = null);
                    }
                };
            }
        }),
        "function" == typeof define && define.amd
            ? define("autoComplete", function () {
                  return e;
              })
            : "undefined" != typeof module && module.exports
            ? (module.exports = e)
            : (window.autoComplete = e),
        (function (e) {
            var a = $("div[id^=enq-from]"),
                t = document.createElement("script");
            (t.id = "enqtemp"),
                (t.type = "text/x-handlebars-template"),
                (t.innerHTML =
                    '<div class="container"  style="max-width:1100px; margin:0 auto"><div class="jn_main_frm" align="center" style="position:relative"><div class="jn_fr_hed1"><h1 class="mainh">{{headdsc}}</h1></div><form action="https://www.hellotravel.com/hellotravel/blank.php" target="_blank"   method="POST" name="enqfrom{{formid}}" id="enqfrom{{formid}}" class="enqfrom" ><div class="jn_frmd1"><span {{#if userlogincontact}}style="display:none"{{/if}}><input type="number" required name="phone" placeholder="Mobile no." id="phone{{formid}}" class=""  value="{{userlogincontact}}" onKeyPress="return isNumberKey1(event)" pattern="[0-9]*" inputmode="numeric" min="0" onkeyup="getuser({{formid}});"/></span><input type="hidden" id="f_country{{formid}}"  name="f_country"   value="India" /><span {{#if going_to}}style="display:none"{{/if}}><input type="text" required name="going_to" data-formid="{{formid}}" id="dest{{formid}}" placeholder="Going to" class="autoplace" value="{{going_to}}" /></span><span><select title="Number of People" id="adults{{formid}}" required name="adults" style="width:99%" oninvalid="setCustomValidity(\'Please select no. of travelers\')" onChange=""><option value="">Adults</option><option value="Group">Group</option><option value="6">6 people</option><option value="5">5 people</option><option value="4">4 people</option><option value="3">3 people</option><option value="2" selected="selected">2 people</option><option value="1">1 person</option></select></span><span {{#if description}}style="display:none"{{/if}}><select title="Duration of stay" id="du_of_st{{formid}}" required name="du_of_st" style="width:99%"><option value="">Duration</option><option value="1 Night/2 Days"  >1 Night/2 Days</option><option value="2 Nights/3 Days" >2 Nights/3 Days</option><option value="3 Nights/4 Days"  >3 Nights/4 Days</option><option value="4 Nights/5 Days"  >4 Nights/5 Days</option><option value="5 Nights/6 Days"  >5 Nights/6 Days</option><option value="6 Nights/7 Days"  >6 Nights/7 Days</option><option value="7 Nights/8 Days"  >7 Nights/8 Days</option><option value="8 Nights/9 Days"  >8 Nights/9 Days</option><option value="9 Nights/10 Days"  >9 Nights/10 Days</option><option value="10 Nights/11 Days"  >10 Nights/11 Days</option><option value="11 Nights/12 Days"  >11 Nights/12 Days</option><option value="12 Nights/13 Days"  >12 Nights/13 Days</option><option value="13 Nights/14 Days"  >13 Nights/14 Days</option><option value="14 Nights/15 Days"  >14 Nights/15 Days</option><option value="More than 15 Days"  >More than 15 Days</option></select></span><span><input type="text" id="travel_date{{formid}}" required name="travel_date" placeholder="Travel Date" value="" class="datepicker-here calen_ico" data-language="en"   pattern="" onKeyPress="return isNumberKey1(event)" title="Please enter tentative travel date(e.g. 21.03.1999)" readonly/></span><span id="spandep{{formid}}" {{#if userlogincontact}}style="display:none"{{/if}}><input type="text" data-formid="{{formid}}" id="depar_city{{formid}}" required name="depar_city" value="{{userlogincity}}" placeholder="Departure City" class="autoplace"></span><span id="spanemail{{formid}}" {{#if userloginemail}}style="display:none"{{/if}}><input type="email" required name="e_mail" placeholder="Email Id" id="e_mail{{formid}}"   value="{{userloginemail}}" /></span><span  id="spanname{{formid}}" {{#if username}}style="display:none"{{/if}}><input type="text" required name="c_name" placeholder="Your Name" id="c_name{{formid}}" class="formname"  value="{{username}}" /></span><span style ="display:none;"><select title="Budget" id="budget_f{{formid}}" required name="budget"  style="width:99%"><option value="" selected="SELECTED">Budget</option><option value="Economy">Economy (0 - 2 star)</option><option value="Standard" selected="selected">Standard (3 - 4 star)</option><option value="Luxury">Luxury (5 star &amp; above)</option></select></span><input type="hidden" id="country{{formid}}" name="going_country_code"></input><input type="hidden" id="country_full{{formid}}" name="going_country"></input><input type="hidden" id="full_address{{formid}}" name="full_address"></input><input type="hidden" id="state{{formid}}" name="going_state"></input><input type="hidden" id="district{{formid}}" name="going_district"></input><input type="hidden" id="frm_country{{formid}}" name="frm_country_code"></input><input type="hidden" id="countryfrm_full{{formid}}" name="frm_country_full"></input><input type="hidden" id="full1_address{{formid}}" name="full1_address"></input><input type="hidden" id="from_state{{formid}}" name="from_state"></input><input type="hidden" id="from_district{{formid}}" name="from_district"></input><input type="hidden" value="{{form_pvt_id}}" name="form_pvt_id" ><input type="hidden" value="{{typetour}}" name="type_tour" ><input type="hidden" value="{{description}}" name="description" ><input type="hidden" value="{{aff_id}}" name="aff_id" ><input type="hidden" name="self_url" value="{{selfurl}}" ><input type="hidden" name="refer_url" value="{{reffrer}}" ><div class="cl"></div><button type="submit" onclick="return validateForm1(\'{{formid}}\');">Submit Enquiry</button>{{#if privacy}}{{#if userlogincontact}}<div style="margin-top:5px; font-size:12px"><input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled=""><i>I agree to get Email/SMS from you.</i></div>{{else}}<div style="margin-top:5px; font-size:12px;"><input type="checkbox" style="margin:0; width:12px;height:12px;"  id="privacycheck{{formid}}" ><i>I agree to <a href="../privacy-policy" target="_blank">privacy policy</a> & <a href="../terms-conditions" target="_blank">terms of service</a></i></div>{{/if}}{{else}}<div style="margin-top:5px; font-size:12px"><input type="checkbox" style="margin:0; width:12px;height:12px;" checked="" disabled=""><i>I agree to get Email/SMS from you.</i></div>{{/if}}<div style="clear:both"></div></div></form></div></div>'),
                document.body.appendChild(t);
            var i,
                n = $("#enqtemp").html(),
                r = Handlebars.compile(n),
                s = window.top.location.href,
                o = document.referrer,
                d = getParameterByName("aff_id"),
                l = "",
                c = "",
                u = "";
            if (
                ((typetour = "1"),
                "undefined" != typeof type_tour && "" != type_tour && 0 != type_tour && "1" != type_tour && (typetour = type_tour),
                "undefined" != typeof privacy && "" != privacy && 0 != privacy && (u = privacy),
                (i = "undefined" != typeof pvtid && "" != pvtid ? pvtid : getParameterByName("prvt_id")),
                "undefined" != typeof desc && "" != desc && (l = desc),
                "undefined" != typeof goingto && "" != goingto && (c = goingto),
                "" != l)
            )
                var h = "Enquire here for this package";
            else h = "Plan your trip now";
            a.each(function () {
                var e = this.id.substring(this.id.lastIndexOf("-") + 1),
                    a = {
                        formid: e,
                        username: username,
                        userloginemail: userloginemail,
                        userlogincity: userlogincity,
                        userlogincontact: userlogincontact,
                        selfurl: s,
                        reffrer: o,
                        aff_id: d,
                        form_pvt_id: i,
                        description: l,
                        going_to: c,
                        headdsc: h,
                        privacy: u,
                        typetour: typetour,
                    },
                    t = r(a);
                $("#" + this.id).html(t),
                    "undefined" != typeof new_duration && "" != new_duration
                        ? $("select#du_of_st" + e + " option[value='" + new_duration + "']").attr("selected", "selected")
                        : $("select#du_of_st" + e + " option[value='3 Nights/4 Days']").attr("selected", "selected");
            });
            var p = new Date(),
                m = p.getMonth() + 5,
                g = p.getDate(),
                f = p.getFullYear(),
                I = new Date();
            I.setDate(p.getDate() + 14),
                $(".datepicker-here")
                    .datepicker({ language: "en", showAnim: "show", dateFormat: "dd/mm/yy", defaultDate: new Date(), minDate: new Date(), maxDate: new Date(f, m, g), autoClose: !0 })
                    .datepicker("setDate", I);
        })();
});
var questionNo = 1,
    page = "",
    questemp = "",
    anstemp = "",
    datetemp = "",
    slidertemp = "",
    trevtemp = "",
    durationmanual = "",
    isreposne = !1,
    durtemp = "",
    packageid = "",
    loginid = "",
    pkgduration = "",
    pkgcountryto = "",
    pkgprice = "",
    storyslidertemp = "",
    pkgdatatitle = "",
    pkgdataloginid = "",
    pkgdatduration = "",
    pkgdataprice = "",
    pkgdatadest = "",
    loginname = "",
    loginemail = "",
    logincontact = "",
    logincity = "",
    pkgdatacountryto = "",
    pkgdest = "",
    pkgdataid = "",
    temp_lead = "",
    temp_leadid = "",
    quearray = [
        "Hey! Looking for a trip?",
        "I have great deals for you! Where would you like to visit?",
        "Choosing best packages for you. Please select below",
        "Great! When would you like to travel?",
        "From which city would you like to start your trip?",
        "Great! To contact you, please enter your email id",
        "Please enter your mobile number",
        "How many travelers?",
        "May I know your name please?",
        "Thank You! tell us more so that we can personalize it for you",
    ],
    ansarray = [];
function getCookie(e) {
    return 0 < document.cookie.length && ((c_start = document.cookie.indexOf(e + "=")), -1 != c_start)
        ? ((c_start = c_start + e.length + 1), (c_end = document.cookie.indexOf(";", c_start)), -1 == c_end && (c_end = document.cookie.length), unescape(document.cookie.substring(c_start, c_end)))
        : "";
}
function getnamefrmemail(e) {
    var a = e.substr(0, e.indexOf("@"));
    return (a = (a = (a = a.replace(/[0-9]/g, " ")).replace(/[._]/g, " ")).replace(/\s\s+/g, " ")).trim();
}
function hidebuble() {
    $(".bubble").hide();
}
function showchat() {
    $(".bubble").hide(),
        $(window).width() < 639 && $(".m_chat").toggleClass("ch_dis"),
        $("#chat-main").toggleClass("chat-hide"),
        $("#chat-main").hasClass("chat-hide") ? $(".m_chat").removeClass("with320") : $(".m_chat").addClass("with320"),
        3 != questionNo && $("#ansinp").focus();
}
function myChatMobile() {
    $(".bubble").hide(), $("#chat-main").toggleClass("chat-hide"), $(".m_chat").toggleClass("ch_dis"), $(".m_chat_01").toggleClass("chat-hide"), 3 != questionNo && 1 != questionNo && $("#ansinp").focus();
}
function formatAMPM(e) {
    var a = e.getHours(),
        t = e.getMinutes(),
        i = 12 <= a ? "pm" : "am";
    return (a = (a %= 12) || 12) + ":" + (t = t < 10 ? "0" + t : t) + " " + i;
}
function dateDropdownFormat() {
    var e = new Date();
    e.setDate(e.getDate() + 7);
    for (var a = e.getMonth(), t = e.getDate(), i = e.getFullYear(), n = [], r = [], s = [], o = [], d = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], l = 0, c = 1; c <= 31; c++)
        c == t ? (c < 10 && (c = "0" + c), r.push({ day: c.toString(), val: c, selected: "selected" })) : (c < 10 && (c = "0" + c), r.push({ day: c.toString(), val: c }));
    for (var u = 0; u < 12; u++) {
        var h = d[u];
        if (((l += 1), u == a)) {
            if (l < 10) var p = "0" + l;
            else p = l;
            s.push({ month: h, val: p, selected: "selected" });
        } else (p = l < 10 ? "0" + l : l), s.push({ month: h, val: p });
    }
    for (var m = i; m < i + 2; m++) m == i ? o.push({ year: m, val: m, selected: "selected" }) : o.push({ year: m, val: m });
    return n.push({ dd: r, mm: s, yy: o }), n;
}
function getpak(e) {
    var a = formatAMPM(new Date());
    packageid = e;
    var t = $("#id" + packageid)
        .find("img")
        .attr("alt");
    (loginid = $("#login" + packageid).val()),
        (pkgduration = $("#dur" + packageid).html()),
        (pkgprice = $("#price" + packageid).val()),
        (pkgdest = $("#dest" + packageid).html()),
        (pkgcountryto = $("#pkgcountryto" + packageid).val()),
        ansarray.push(t),
        $("#content-slider2").find("a").attr("onclick", "");
    var i = anstemp((n = { ans: t, datetext: a }));
    $("#chatmessages").append(i), $(".ch_du").fadeIn("slow");
    var n = { ques: quearray[++questionNo], datetext: a };
    (i = questemp(n)), $("#chatmessages").append(i), $(".ch_du1").fadeIn("slow"), scrolltobottom("chatmessages"), $("#inputdiv").hide(), $("#submit").hide(), getplaceholder(questionNo);
    var r = dateDropdownFormat();
    return (i = datetemp((n = { data: r }))), $("#inputdiv").html(i), $("#inputdiv").show(), $("#submit").show(), 3 != questionNo && $("#ansinp").focus(), !1;
}
function getplaceholder(e) {
    var a = "Field required";
    switch (questionNo) {
        case 1:
            a = "Where do you want to go?";
            break;
        case 3:
            a = "dd/mm/yyyy";
            break;
        case 4:
            a = "Your departure city";
            break;
        case 5:
            a = "Your email id";
            break;
        case 6:
            a = "Your mobile number";
            break;
        case 7:
            a = "Number of travelers";
            break;
        case 8:
            a = "Your name";
    }
    return a;
}
function isNumber(e) {
    var a = (e = e || window.event).which ? e.which : e.keyCode;
    return !(31 < a && (a < 48 || 57 < a));
}
function validatephone(e) {
    var a = e.length;
    return a < 10 || 10 < a ? "Please enter a valid 10 digit mobile no" : "9" != e.charAt(0) && "8" != e.charAt(0) && "7" != e.charAt(0) && "6" != e.charAt(0) ? "Please enter a valid mobile no starting with 6, 7, 8 or 9" : void 0;
}
function onlyAlphabets(e) {
    try {
        if (window.event) var a = window.event.keyCode;
        else {
            if (!e) return !0;
            a = e.which;
        }
        return (64 < a && a < 91) || (96 < a && a < 123) || 13 == a || 32 == a || 8 == a || "submit" == e.target.id;
    } catch (e) {
        alert(e.Description);
    }
}
function validateEmail(e) {
    return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(e);
}
function submitplace(e) {
    var a = formatAMPM(new Date()),
        t = e.trim();
    ansarray.push(t);
    var i = anstemp({ ans: t, datetext: a });
    $("#chatmessages").append(i),
        $(".ch_du").fadeIn("slow"),
        4 == questionNo &&
            $.ajax({
                url: "https://www.hellotravel.com/chat/checklogin.php",
                type: "POST",
                data: { place_start: t },
                success: function (e) {
                    country_code = e.trim();
                },
            });
    var n = { ques: quearray[++questionNo], datetext: a };
    if (((i = questemp(n)), $("#chatmessages").append(i), 1 == questionNo)) $("#toplacesdiv").show("slow");
    else if (4 == questionNo) $("#frmplacesdiv").show("slow");
    else {
        var r = $(window).height(),
            s = $(".m_chat_hed").outerHeight(!0);
        (r -= s += 100), $("#chatbox").css("height", r), $("#chatmessages").css("max-height", r), scrolltobottom("chatmessages"), $("#toplacesdiv").hide("slow"), $("#frmplacesdiv").hide("slow");
    }
    if ((2 == questionNo && ($("#inputdiv").hide(), $("#submit").hide(), $("#loader").show(), packageSlider(t)), 0 != questionNo && 2 != questionNo && 9 != questionNo)) {
        var o = getplaceholder(questionNo),
            d = "";
        if ((4 == questionNo && (d = logincity), 5 == questionNo && (d = loginemail), 6 == questionNo && (d = logincontact), 8 == questionNo && (d = loginname), 6 == questionNo))
            var l = '<input id="ansinp" placeholder="' + o + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + d + '" type="number" />';
        else l = 7 == questionNo ? trevtemp : '<input id="ansinp" placeholder="' + o + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + d + '" type="text" />';
        $("#inputdiv").html(l), $("#ansinp").focus();
    }
    return $(".ch_du1").fadeIn("slow"), scrolltobottom("chatmessages"), !1;
}
function submitans(e) {
    var o = formatAMPM(new Date());
    if ((1 == questionNo || 4 == questionNo || 8 == questionNo) && !onlyAlphabets(e)) return !1;
    if ((6 == questionNo || 7 == questionNo) && !isNumber(e)) return alert("Please enter valid mobile no"), !1;
    if (13 == e.keyCode || "submit" == e.target.id) {
        if (3 == questionNo) {
            var a = $("#ansinpdd").val(),
                t = $("#ansinpmm").val(),
                i = $("#ansinpyy").val(),
                n = new Date(i + "-" + t + "-" + a),
                r = new Date();
            if (((r = r.setMonth(r.getMonth() + 3)), n < new Date())) return alert("Please select a later date"), !1;
            if (r < n) return alert("Please select an earlier date"), !1;
            var d = a + "/" + t + "/" + i;
        } else (d = (d = 0 == questionNo ? $("#ansinp option:selected").text() : $("#ansinp").val()).trim()), isreposne || 2 != questionNo || (durationmanual = d);
        if (
            (4 == questionNo &&
                $.ajax({
                    url: "https://www.hellotravel.com/chat/checklogin.php",
                    type: "POST",
                    data: { place_start: d },
                    success: function (e) {
                        country_code = e.trim();
                    },
                }),
            6 == questionNo && "" != country_code && null != country_code && "undefined" != country_code && "IN" == country_code && validatephone(d))
        )
            return alert(validatephone(d)), !1;
        if (0 == questionNo && "No" == d) {
            var s = anstemp((l = { ans: d, datetext: o }));
            return (
                $("#chatmessages").append(s),
                $(".ch_du").fadeIn("slow"),
                (s = questemp((l = { ques: "Here are some stories for you", datetext: o }))),
                $("#chatmessages").append(s),
                $(".ch_du1").fadeIn("slow"),
                $("#inputdiv").hide(),
                $("#submit").hide(),
                storyslider(),
                !1
            );
        }
        if ("" == d.trim()) return !1;
        if (5 == questionNo)
            return (
                validateEmail(d)
                    ? ($("#inputdiv").hide(),
                      $("#submit").hide(),
                      $("#loader").show(),
                      $.ajax({
                          url: "https://www.hellotravel.com/chat/checklogin.php",
                          type: "POST",
                          data: { email: d },
                          success: function (e) {
                              try {
                                  var a = JSON.parse(e),
                                      t = "";
                                  if (a.status) {
                                      (logincontact = a.lead_phone), (loginname = a.lead_name), ansarray.push(d);
                                      var i = anstemp((n = { ans: d, datetext: o }));
                                      $("#chatmessages").append(i), $(".ch_du").fadeIn("slow"), ifLoggedin(++questionNo);
                                      var n = { ques: quearray[questionNo], datetext: o };
                                      (i = questemp(n)), $("#chatmessages").append(i), $(".ch_du1").fadeIn("slow");
                                      var r = getplaceholder(questionNo);
                                      if (6 == questionNo) var s = '<input id="ansinp" placeholder="' + r + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + t + '" type="number" />';
                                      else s = 7 == questionNo ? trevtemp : '<input id="ansinp" placeholder="' + r + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + t + '" type="text" />';
                                  } else
                                      ansarray.push(d),
                                          (i = anstemp((n = { ans: d, datetext: o }))),
                                          $("#chatmessages").append(i),
                                          $(".ch_du").fadeIn("slow"),
                                          ifLoggedin(++questionNo),
                                          (n = { ques: quearray[questionNo], datetext: o }),
                                          (i = questemp(n)),
                                          $("#chatmessages").append(i),
                                          $(".ch_du1").fadeIn("slow"),
                                          (r = getplaceholder(questionNo)),
                                          (s =
                                              6 == questionNo
                                                  ? '<input id="ansinp" placeholder="' + r + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + t + '" type="number" />'
                                                  : 7 == questionNo
                                                  ? trevtemp
                                                  : '<input id="ansinp" placeholder="' + r + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + t + '" type="text" />'),
                                          6 == questionNo && (t = logincontact);
                                  $("#loader").hide(), $("#inputdiv").html(s), $("#inputdiv").show(), $("#submit").show(), scrolltobottom("chatmessages");
                              } catch (e) {
                                  console.log(e);
                              }
                          },
                          error: function (e) {
                              console.log(e);
                          },
                      }))
                    : alert("You have entered an invalid email address!"),
                !1
            );
        ansarray.push(d), (s = anstemp((l = { ans: d, datetext: o }))), $("#chatmessages").append(s), $(".ch_du").fadeIn("slow"), ifLoggedin(++questionNo);
        var l = { ques: quearray[questionNo], datetext: o };
        if (((s = questemp(l)), $("#chatmessages").append(s), 1 == questionNo)) $("#toplacesdiv").show("slow");
        else if (4 == questionNo) $("#frmplacesdiv").show("slow");
        else {
            var c = $(window).height(),
                u = $(".m_chat_hed").outerHeight(!0);
            (c -= u += 100), $("#chatbox").css("height", c), $("#chatmessages").css("max-height", c), scrolltobottom("chatmessages"), $("#toplacesdiv").hide("slow"), $("#frmplacesdiv").hide("slow");
        }
        if (9 == questionNo) {
            if (($("#inputdiv").hide(), $("#submit").hide(), $("#loader").show(), (g = $("#hellotravelchat").attr("data-page")), "" != pkgdatatitle && void 0 !== pkgdatatitle))
                var h = {
                    choice: "YES",
                    tocity: pkgdatadest,
                    pkgtitle: pkgdatatitle,
                    dealid: pkgdataid,
                    loginid: pkgdataloginid,
                    pkgduration: pkgdatduration,
                    pkgprice: pkgdataprice,
                    pkgdest: pkgdatadest,
                    page: g,
                    traveldate: ansarray[3],
                    pkgcountryto: pkgdatacountryto,
                    fromcity: ansarray[4],
                    emailid: ansarray[5],
                    phoneno: ansarray[6],
                    groupsize: ansarray[7],
                    name: ansarray[8],
                    temp_leadid: temp_leadid,
                };
            else
                h = isreposne
                    ? {
                          choice: ansarray[0],
                          tocity: ansarray[1],
                          pkgtitle: ansarray[2],
                          dealid: packageid,
                          loginid: loginid,
                          pkgduration: pkgduration,
                          pkgprice: pkgprice,
                          pkgdest: pkgdest,
                          page: g,
                          traveldate: ansarray[3],
                          pkgcountryto: pkgcountryto,
                          fromcity: ansarray[4],
                          emailid: ansarray[5],
                          phoneno: ansarray[6],
                          groupsize: ansarray[7],
                          name: ansarray[8],
                          temp_leadid: temp_leadid,
                      }
                    : {
                          choice: ansarray[0],
                          tocity: ansarray[1],
                          pkgtitle: "",
                          dealid: "",
                          loginid: "",
                          pkgduration: durationmanual,
                          pkgprice: "",
                          pkgdest: "",
                          page: g,
                          traveldate: ansarray[3],
                          pkgcountryto: pkgcountryto,
                          fromcity: ansarray[4],
                          emailid: ansarray[5],
                          phoneno: ansarray[6],
                          groupsize: ansarray[7],
                          name: ansarray[8],
                          temp_leadid: temp_leadid,
                      };
            submitlead(h);
        }
        if (
            ($(".ch_du1").fadeIn("slow"),
            scrolltobottom("chatmessages"),
            2 == questionNo && ($("#inputdiv").hide(), $("#submit").hide(), $("#loader").show(), packageSlider(d)),
            3 == questionNo && ((h = dateDropdownFormat()), (s = datetemp((l = { data: h }))), $("#loader").hide(), $("#inputdiv").html(s), $("#inputdiv").show(), $("#submit").show()),
            0 != questionNo && 2 != questionNo && 3 != questionNo && 9 != questionNo)
        ) {
            var p = getplaceholder(questionNo),
                m = "";
            if ((4 == questionNo && (m = logincity), 5 == questionNo && (m = loginemail), 6 == questionNo && (m = logincontact), 7 == questionNo)) {
                var g = $("#hellotravelchat").attr("data-page");
                submittemplead(
                    (h =
                        "" != pkgdatatitle && void 0 !== pkgdatatitle
                            ? {
                                  choice: "YES",
                                  tocity: pkgdatadest,
                                  pkgtitle: pkgdatatitle,
                                  dealid: pkgdataid,
                                  loginid: pkgdataloginid,
                                  pkgduration: pkgdatduration,
                                  pkgprice: pkgdataprice,
                                  pkgdest: pkgdatadest,
                                  page: g,
                                  traveldate: ansarray[3],
                                  pkgcountryto: pkgdatacountryto,
                                  fromcity: ansarray[4],
                                  emailid: ansarray[5],
                                  phoneno: ansarray[6],
                                  temp_lead: "temp_lead",
                              }
                            : isreposne
                            ? {
                                  choice: ansarray[0],
                                  tocity: ansarray[1],
                                  pkgtitle: ansarray[2],
                                  dealid: packageid,
                                  loginid: loginid,
                                  pkgduration: pkgduration,
                                  pkgprice: pkgprice,
                                  pkgdest: pkgdest,
                                  page: g,
                                  traveldate: ansarray[3],
                                  pkgcountryto: pkgcountryto,
                                  fromcity: ansarray[4],
                                  emailid: ansarray[5],
                                  phoneno: ansarray[6],
                                  temp_lead: "temp_lead",
                              }
                            : {
                                  choice: ansarray[0],
                                  tocity: ansarray[1],
                                  pkgtitle: "",
                                  dealid: "",
                                  loginid: "",
                                  pkgduration: durationmanual,
                                  pkgprice: "",
                                  pkgdest: "",
                                  page: g,
                                  traveldate: ansarray[3],
                                  pkgcountryto: pkgcountryto,
                                  fromcity: ansarray[4],
                                  emailid: ansarray[5],
                                  phoneno: ansarray[6],
                                  temp_lead: "temp_lead",
                              })
                );
            }
            if ((8 == questionNo && (m = "" != loginname ? loginname : getnamefrmemail(ansarray[5])), 6 == questionNo))
                var f = '<input id="ansinp" placeholder="' + p + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + m + '" type="number" />';
            else f = 7 == questionNo ? trevtemp : '<input id="ansinp" placeholder="' + p + '"  class="chat_inp" onkeypress="return submitans(event);" value="' + m + '" type="text" />';
            $("#loader").hide(), $("#inputdiv").html(f), $("#inputdiv").show(), $("#submit").show();
        }
        return $("#ansinp").focus(), !1;
    }
}
function ifLoggedin(e) {
    "" != logincity.trim() && void 0 !== logincity && 4 == e && (ansarray.push(logincity), questionNo++, e++),
        "" != loginemail.trim() && void 0 !== loginemail && 5 == e && (ansarray.push(loginemail), questionNo++, e++),
        "" != logincontact.trim() && void 0 !== logincontact && 6 == e && (ansarray.push(logincontact), questionNo++, e++),
        "" != loginname.trim() && void 0 !== loginname && 8 == e && (ansarray.push(loginname), questionNo++, e++);
}
function submitlead(a) {
    $.ajax({
        url: "https://www.hellotravel.com/chat/chatlead.php",
        data: a,
        cache: !1,
        type: "POST",
        success: function (a) {
            try {
                (a = JSON.parse(a)), (window.location = a.url);
            } catch (e) {
                alert(a);
            }
        },
        error: function (e) {
            alert("Some error please try again"), submitlead(a);
        },
    });
}
function submittemplead(e) {
    $.ajax({
        url: "https://www.hellotravel.com/chat/chatlead.php",
        data: e,
        cache: !1,
        type: "POST",
        success: function (e) {
            temp_leadid = e;
        },
    });
}
function storyslider() {
    $.ajax({
        url: "https://www.hellotravel.com/chat/storyslider.php",
        cache: !1,
        type: "GET",
        success: function (e) {
            var a = JSON.parse(e),
                t = (Object.keys(a.data).length, storyslidertemp(a));
            $("#chatmessages").append(t), $(".ch_du").fadeIn("slow"), $("#content-slider2").lightSlider({ loop: !0, keyPress: !0, item: 1.2, pager: !1, auto: !1 }), scrolltobottom("chatmessages");
        },
        error: function (error) {
            alert("error; " + eval(error));
        },
    });
}
function packageSlider(e) {
    $.ajax({
        url: "https://www.hellotravel.com/chat/slider.php",
        data: { place: e },
        type: "GET",
        cache: !1,
        timeout: 5e3,
        success: function (e) {
            var a = JSON.parse(e);
            if ("true" === a.status) {
                if (((isreposne = !0), 1 == Object.keys(a.data).length)) var t = 1;
                else t = 1.2;
                var i = slidertemp(a);
                $("#chatmessages").append(i), $("#content-slider2").lightSlider({ loop: !0, keyPress: !0, item: t, pager: !1, auto: !1 }), scrolltobottom("chatmessages"), $("#loader").hide();
            } else {
                $("#loader").hide();
                var n = durtemp;
                $("#inputdiv").html(n), $("#inputdiv").show(), $("#submit").show();
            }
        },
        error: function (e) {
            $("#loader").hide();
            var a = durtemp;
            $("#inputdiv").html(a), $("#inputdiv").show(), $("#submit").show();
        },
    });
}
function scrolltobottom(e) {
    var a = document.getElementById(e);
    a.scrollTop = a.scrollHeight;
}
$(function () {
    !(function () {
        var e = function () {
            var e = formatAMPM(new Date());
            if ("" != pkgdatatitle && void 0 !== pkgdatatitle) {
                var a = questemp((t = { ques: "Hello! Looking for " + pkgdatatitle + "?", datetext: e }));
                $("#chatmessages").append(a), $(".ch_du1").fadeIn("slow");
                var t = { ques: quearray[questionNo], datetext: e };
                (a = questemp(t)), $("#chatmessages").append(a), $(".ch_du1").fadeIn("slow");
            } else (t = { ques: quearray[questionNo], datetext: e }), (a = questemp(t)), $("#chatmessages").append(a), $(".ch_du1").fadeIn("slow");
            if ("" != pkgdatatitle && void 0 !== pkgdatatitle) {
                getplaceholder(questionNo);
                var i = dateDropdownFormat();
                (a = datetemp((t = { data: i }))), $("#inputdiv").html(a), $("#submit").show();
            }
        };
        !(function (e) {
            (pkgdatatitle = $("#hellotravelchat").attr("data-pkg-title")),
                (pkgdataloginid = $("#hellotravelchat").attr("data-pkg-loginid")),
                (pkgdatadest = $("#hellotravelchat").attr("data-pkg-dest")),
                (pkgdataprice = $("#hellotravelchat").attr("data-pkg-price")),
                (pkgdatduration = $("#hellotravelchat").attr("data-pkg-dur")),
                (pkgdataid = $("#hellotravelchat").attr("data-pkg-nid")),
                (pkgdatacountryto = $("#hellotravelchat").attr("data-pkg-countryto")),
                "" != pkgdatatitle && void 0 !== pkgdatatitle && ((questionNo = 3), ansarray.push("Yes"), ansarray.push(pkgdatadest), ansarray.push(pkgdatatitle)),
                1 == questionNo && ansarray.push("Yes");
            var a = document.createElement("script");
            (a.id = "bodytemp"),
                (a.type = "text/x-handlebars-template"),
                (a.innerHTML =
                    '<div id="mtitlebubble" class="bubble"  style="display:none;background-color:#fff; z-index:1009; padding:10px;position:fixed; right:30px; bottom:100px; width:50%; border-radius:4px; box-shadow:3px 3px 6px 5px rgba(0, 0, 0, 0.3)"><div style="position:relative; font-size:12px;">Hi, {{bubblepkgtitle}} let me help you<span style="color:#fff;bottom:-22px; right:20px; position:absolute;">&#x25BD;</span><a href="javascript:void(0);" onclick="return hidebuble();" id="closebubble" style="text-decoration:none;color:#333;top:-15px; right:-15px; position:absolute;background-color:#fff; border:1px solid #999;border-radius:30px;padding:0 6px">&#10006;</a></div></div><div class="m_chat_01 pulse f25" style="padding-top:10px;" align="center"  id="chmo1" onclick="myChatMobile();ga(\'send\', \'event\', \'chat\', \'chatbox\',\'initiated\');"><i class="fa fa-comment-alt c1"></i></div><div class="m_chat box-shadow ch_dis" id="chmo2"><div id="titlebubble" class="bubble" style="display:none;background-color:#fff; z-index:1009; padding:10px;position:absolute; right:20px; bottom:50px; width:80%; border-radius:4px; box-shadow:3px 3px 6px 5px rgba(0, 0, 0, 0.3)"><div style="position:relative;font-size:12px;">Hi, {{bubblepkgtitle}} let me help you.<span style="color:#fff;bottom:-22px; right:20px; position:absolute;">&#x25BD;</span><a href="javascript:void(0);" onclick="return hidebuble();" id="closebubble" style="text-decoration:none;color:#333;top:-15px; right:-15px; position:absolute;background-color:#fff; border:1px solid #999;border-radius:30px;padding:0 6px">&#10006;</a></div></div><div class="m_chat_hed" onclick="showchat();ga(\'send\', \'event\', \'chat\', \'chatbox\',\'initiated\');"><div class="chat_fl_hed fl f17"><i class="fa fa-comment-alt"></i> Chat</div><span class="fr b f14" id="chup">&#9650;</span><span class="fr b f14" style="display:none" id="chdw" >&#9660;</span><div class="cl"></div></div><div id="chat-main" class="chat-hide"><div id="chatbox" ><div id="chatmessages"></div><div class="cl"></div></div><div class="ch_place" id="toplacesdiv" style="display:none;"><a href="#" onclick="return submitplace(&quot;Manali&quot;);">Manali</a> <a href="#" onclick="return submitplace(&quot;Shimla&quot;);">Shimla</a> <a href="#" onclick="return submitplace(&quot;Kerala&quot;);">Kerala</a> <a href="#" onclick="return submitplace(&quot;Sikkim&quot;);">Sikkim</a> <a href="#" onclick="return submitplace(&quot;Kashmir&quot;);">Kashmir</a> <a href="#" onclick="return submitplace(&quot;Thailand&quot;);">Thailand</a> <a href="#" onclick="return submitplace(&quot;Dubai&quot;);">Dubai</a> <a href="#" onclick="return submitplace(&quot;Singapore&quot;);">Singapore</a> <a href="#" onclick="return submitplace(&quot;Sri Lanka&quot;);">Sri Lanka</a> <a href="#" onclick="return submitplace(&quot;Bali&quot;);">Bali</a></div><div class="ch_place" id="frmplacesdiv" style="display:none;"><a href="#" onclick="return submitplace(&quot;Delhi&quot;);">Delhi</a> <a href="#" onclick="return submitplace(&quot;Mumbai&quot;);">Mumbai</a> <a href="#" onclick="return submitplace(&quot;Bengaluru&quot;);">Bengaluru</a> <a href="#" onclick="return submitplace(&quot;Pune&quot;);">Pune</a> <a href="#" onclick="return submitplace(&quot;Chennai&quot;);">Chennai</a> <a href="#" onclick="return submitplace(&quot;Hyderabad&quot;);">Hyderabad</a> <a href="#" onclick="return submitplace(&quot;Kolkata&quot;);">Kolkata</a> <a href="#" onclick="return submitplace(&quot;Ahmedabad&quot;);">Ahmedabad</a> <a href="#" onclick="return submitplace(&quot;Lucknow&quot;);">Lucknow</a> <a href="#" onclick="return submitplace(&quot;Gurugram&quot;);">Gurugram</a></div><div id="chat-footer" class="m_chat_f"><div align="center" style="display:none;" id="loader"><img src="https://www.hlimg.com/images/htloader-new.gif"/></div><div class="fl" id="inputdiv" style="width:80%"><select class="chat_inp" id="ansinp" onkeypress="return submitans(event)"><option value="1">Yes</option ><option value="2">No</option></select></div><input id="submit" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4RpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo0NTE3Y2M0Yi1mZWNkLTg0NDAtYjZmNi04NzBhYTdiYjJkYWIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODM1MUNFMjM3OUQ4MTFFNzlGOTNFREYwODUyOTZGMkUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODM1MUNFMjI3OUQ4MTFFNzlGOTNFREYwODUyOTZGMkUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YWJlZmIxMzktNWJkNi1hMTQ4LThiYWUtYTA0M2FhN2Y0YzZhIiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6NDZmMWEwOTktNzlkOC0xMWU3LWEwYmQtY2ZmMmUxOGQ4N2U5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+fOf7aQAACc1JREFUeNqkWWuIXkcZft9zzm6z25jELzbZWLuS0CUSjQ0GQVEoRlCosqIEGvpTRLEkbH4oCv4WRBCsLYpBKjQgWZNaIlQtSiVoTSmNuW1jY5Imu2ntmuhqm61x9ztnxue9zJzzRa2m/cjszJlzmWee9z6pZnpMVBIVBeWedczEZcSY9ZqLiJs+xivENI7BTvTbmeNmzNyJydVEeI7oFXTnMTpLgY9RjIdipLnYRL0dA6Ohx7X1+CAeiA1ZC23Pz92GP6UvXJIBKgUM/lWsPbethzYFUJ9m5q0kQBUwPo4LLKvwOLLBFDDRQAHoaQB6DJcPYOEFBYFGtYOUVrfgQsBLAvDMejZgZQKKpSoH1AJfCSBTAP9V3F8pwJRl2QwrJMWq8NjYMHAyybqQTtmiiwDxDbQHAGRRWWyMRbmfWWzsef7D213Eib0qYmygyUDvBKgHcX9MFjdgvgF2QPbPWMsDUmBBWBBcMueL6uKR5nG9B+NDQa6VSVaxh8Z6qoWDpHelgZNegVXQwoq+XZTxIACP6SaGBhsPMXr2sc9Xfq/yuWHvZV6+n57DhrH2QVtD1mKzg0L6mKVaMSdjcJAGbgRsHsD8pLBaVMauAk+6yqafib3OHxUnq0xd+ZOOybdEpGpk/mIdp6iijbi1K8R4vSDTXxUEvg+eYgvMRF2iBziatOuY9VMsW3anQNksnDiBzCZiMDvgyMXLInJRo9qmIr4htyHKSUxgTf6MPCn3CrwfsHaRmSmTe6FvYW5SxSFWjCai5CQiuRZx6HxH3MMxi1ues3lXgcrG+o3SRK4qoATY97B5rIm13bWR9xV3fB/G9+KhKXUzyXDcHxZJNwsfJ3+ofWGWkH7KnruRQl2MMkhJtI3rgbAeo3krMyTxFEfxuWl9X3Tx/LsKs9yKe9jJOey+ZyyZYieA1dh4VoW4MNdac3I51DVhW1isMjvg5JhhoQEWKyBDTTrW+7XNY24BIp9o0ItfLKfWcVr4m2DmbgWVRFgmtwMsq9ZQb98FKkZuJV5+jeLfLhnDFWW2NfoU7kuTj3TW2I2IfSMxj9gYp2RUNIJ2K179uUwZwIpuL0t6RFxL0TWYBFT6t6ymkU/C4Da9j6rNHyIeGYWyLxJdu9KqghtQUbQWng2Is5H7XOyw7sS3bRsY/yEG18q9G1gW+AoW+IgxwnnBxJAqOQCuuGfKPrmyR9WWj9LQB++jorcB1rmMSchp6dU2drM7fm5dEccuGNfTHBKdSZsv0a5j7kl+4b1FCYt7AVY2XiTnWrnT7lhftX6cVn/nAv23XzPzM2pO/YTC+d9Q+MulFNYsmng4kwhBfYkUFndV5/psY5+XvUbTxbnQp00VdotsRDKTjkhchwp3PTnDeZ1f+Z57tMWXn6Pm5KNUnzpM4fKM+jrTMHwPBhNEFcRwUiwX3Q0eKELrWwUT2vYKurIjpVFmlZxBptjL/wfAbMcb3k2VtB1fovr3B6h+ej8YnSO6etmctK/jICjbSDKmQq5Z3RYw7BAb3EbcgqGO5WVFvwmA+Tc8StUHPqutOfME9Y/up2buFDWzzysgkUooLJqk7IjTdRoTb0Mspq3uA4yBnEr52MFGpjf8K7d8XFu4fJKWn56m/syTVP/xWF6PEmMdX+qZ0VZhcCzHeWdLHUPHC3B++c39ijvuohVot3xsnpaP/4KWnvox9WfPEv9pNnuYBNRj+xhf2l4uwXKHcxpVeTwdim28xTZKWHE5ton4lmEwHBB7V1CxbiM+Y9kAr1xLvOYdsN6gK/HaCaKRHl5EvjWMHHfN7f8RdH3xJP11z3aKfbFkiy5RLLqvlr5cJb9Onbw4h9SObw0Ib/HVOfOJKcAv3gXAI5irKP59lOi1q/A3WOGtG6ESF4lGrxG/beJ/G1Yn2R1AgAG8XUQ4QK0hdURsg73ldOYeZLrs3UEjn3vYPrJqHdp6MAm0K1bdtKjjKy7i30LEc2dbiF4amGmrHi5i6zSPcS+mCKkOymsK4TS0L5ab735TOqhGchRGcvrX1D/3rIvTy4BMTvSSRkHOV2DpDK62mNf3wkXqiMA5NurL4Y0DUzfzu/1Uz56meu6M1hqqp4kx/34uslIlCGwS0FC30s4EhD1V0zzN61dKJeLN/Jb/QfWz5qgbOOpw5bKGPA19niuGmNgbrAQNqFJ6rMJTRww9ZyC6M2dTWOWbABgk1B1/FOHuMDUvnra8L9W5EouD5YImsVSvRM8fB8tUOIQjFSafwcQc+vFMdWbNH/YTgNcV48zjVB9/zJKFqxdzoaSseAkZbqx7G0tsk3qltV2l4DbiMwKwgR7ux4Nfk4wpphAXLPslNq8uH/w3a1xapP5Tj1B94jDFK+eRxF7OPiJl1DG0VR11CvKYCPDrELhl0UD+CKCbyip++h7AfRnAhsXPFk0bxDnZSgdg+PMFWj7yMKzxCYovnnJnmRTYQ1Xo6JWLVNIqcuYsBeuczXg5YCzGZVw/JK9XTutLALYPL+8uOOYiR8tCIZQ5i/ifv/oBWIPyP3+kzUyozYKSv0iWH7K6tOJV95LYTOcxg2zvg028pGcz5yasrITP7SE3O4cw19PMovKC3cvDobF35sI9eNFk2Y8H+m6wjq37iG4MKsKGstHEOiWxUQsmvdYkFsVSEyeQyC7IvUqsl63aXwAL94eaD2gBlNgjk3H/5dlcO3v97Poa8ylAjlHdVH6AwXT24mJvDFSeM/bux72FpMOV7k7WaTSkTeORD2Ph3XoSIKmA+EOgL1Jw9qI61bycEs7uqQLF7HSzVXaMgzKD7KLO8w8B6DSlwyM8X0mdkDYvQGEsewPHcQwnKUYvC4WEaLpYum/UsiAqi8yDCYYGzeSWOlacfB4lYHWrm1THnwLcXkqHm35OWMWmzWrVkZob3YWVDoaSPmFG47E8HSBwdBGnw8uUT8aB8vFGMSdnrVHEWbJDTHoc17uApYlJR/2ditJpU+wmWPE6+k9h8F188/Oqe9FZ80ckDKp4ixvzJrdi8uIocMtidFANdU9V97neNbHu+EHX0SrpBFGnt9jYoP8C5P9LrPNgUcSxWFgYlMorprMZsorM6HTx+mbVdWRr5lyKuvjmwdQeXB8KSS9D635S+C2/OMrd+t5iMsec8uMa6Qd9H4ssob0fCw5zpA4znGNo1jF3Kdm3NQORZBHt65i/D3MnWiftPrN7CitSmlnLA64jHVAWuUT0cxZ1PXQb+t2sp/txC3F7Rp1lP+ALu2fVdFaOe+UQHRu7GptW9KEj1q6eyjWfXuMnrNwemiegetLvh0GUDoVSxChoI7p75b8h0O6U8rUT6eR3AovKf0UcQz8NYBfbZKAj6tCKdEDULp1/CTAA5QdPo3GUOrMAAAAASUVORK5CYII=" name="submit" onclick="return submitans(event);"  class="fr" style="width:35px; height:35px" type="image"><div class="cl"></div></div><div style="background: white;padding: 8px;font-size:10px;text-align:center;">Powered By <a href="https://www.hellotravel.com"><span style="color: #de2101;">Hellotravel.com</span></a></div></div></div></div></div>'),
                document.body.appendChild(a);
            var t = document.createElement("script");
            (t.id = "trevtemp"),
                (t.type = "text/x-handlebars-template"),
                (t.innerHTML =
                    '<select class="chat_inp" id="ansinp" onkeypress="return submitans(event)"><option value="1">1</option><option value="2" selected>2</option><option value="3" >3</option><option value="4" >4</option><option value="5" >5</option><option value="6" >6</option><option value="7" >Group</option></select>'),
                document.body.appendChild(t);
            var i = document.createElement("script");
            (i.id = "durtemp"),
                (i.type = "text/x-handlebars-template"),
                (i.innerHTML =
                    '<select class="chat_inp" id="ansinp" onkeypress="return submitans(event)"><option value="2 Days/1 Night">1 Night/2 Days</option><option value="3 Days/2 Nights" selected>2 Nights/3 Days</option><option value="4 Days/3 Nights" >3 Nights/4 Days</option><option value="5 Days/4 Nights" >4 Nights/5 Days</option><option value="6 Days/5 Nights" >5 Nights/6 Days</option><option value="7 Days/6 Nights" >6 Nights/7 Days</option><option value="8 Days/7 Nights" >7 Nights/8 Days</option><option value="9 Days/8 Nights" >8 Nights/9 Days</option><option value="10 Days/9 Nights" >9 Nights/10 Days</option><option value="11 Days/10 Nights" >10 Nights/11 Days</option><option value="12 Days/11 Nights" >11 Nights/12 Days</option><option value="13 Days/12 Nights" >12 Nights/13 Days</option><option value="14 Days/13 Nights" >13 Nights/14 Days</option><option value="More than 15 Days" >More than 15 Days</option></select>'),
                document.body.appendChild(i);
            var n = document.createElement("script");
            (n.id = "caltemp"),
                (n.type = "text/x-handlebars-template"),
                (n.innerHTML =
                    '<select name="dd" class="chat_inp fl" id="ansinpdd" style="width:25%; -webkit-appearance: none; -moz-appearance: none; appearance: none;">{{#each data}}{{#each dd}}<option value="{{val}}" {{selected}}>{{day}}</option>{{/each}}{{/each}}</select><span class="fl c9 f25 mt1">&#47;</span><select name="mm" class="chat_inp fl"  id="ansinpmm" style="width:25%; -webkit-appearance: none; -moz-appearance: none; appearance: none;">{{#each data}}{{#each mm}}<option value="{{val}}" {{selected}} >{{month}}</option>{{/each}}{{/each}}</select><span class="fl c9 f25 mt1">&#47;</span><select name="yy" class="chat_inp fl" id="ansinpyy"  style="width:25%; -webkit-appearance: none; -moz-appearance: none; appearance: none;">{{#each data}}{{#each yy}}<option value="{{val}}" {{selected}}>{{year}}</option>{{/each}}{{/each}}</select>'),
                document.body.appendChild(n);
            var r = document.createElement("script");
            (r.id = "questiontemp"),
                (r.type = "text/x-handlebars-template"),
                (r.innerHTML =
                    '<div class="ch_du1" style="display:none;"><div class="mb f12 c_cht">HelloTravel</div>{{ques}}<p class="f11 trg c9">Today, {{datetext}}</p><span class="ar_right">ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Âº</span></div>'),
                document.body.appendChild(r);
            var s = document.createElement("script");
            (s.id = "anstemp"),
                (s.type = "text/x-handlebars-template"),
                (s.innerHTML = '<div class="ch_du" style="display:none;" ><div class="mb f12 c_cht">You</div>{{ans}}<p class="f11 trg c9">Today, {{datetext}}</p><span class="ar_left"></span></div>'),
                document.body.appendChild(s);
            var o = document.createElement("script");
            (o.id = "slidertemp"),
                (o.type = "text/x-handlebars-template"),
                (o.innerHTML =
                    '<div class="ch_du" style="width:96%;"><p class="slid_01"><p class="slid_item"><ul id="content-slider2" class="content-slider">{{#each data}}<li id="id{{nid}}" style="padding:5px; min-height:250px"><a href="#" onclick="return getpak({{nid}});" style="text-decoration:none"><div align="left"><img alt="{{imgtext}}" src="{{imgurl}}" style="height:140px"><span class="cl_g ellipsis">{{pkgtitle}}</span><span class="f12 c3 lh18 ellipsis" id="dest{{nid}}">{{pkgdest}}</span><span class="f12 l_blue ellipsis" id="dur{{nid}}">{{pkgduration}}</span><span class="cl_g b ellipsis" >&#x20B9;&nbsp;{{pkgprice}}</span><input type="hidden" value="{{loginid}}" id="login{{nid}}"/><input type="hidden" value="{{pkgprice}}" id="price{{nid}}""/><input type="hidden" value="{{pkgcountryto}}" id="pkgcountryto{{nid}}""/><div class="f12 l_blue" style="background-color: #09c; border: 1px solid #95d0e4; padding: 6px; border-radius:2px; text-align:center; color : #fff">Select This Package</div></div></a></li>{{/each}}</ul></p></p></div>'),
                document.body.appendChild(o);
            var d = document.createElement("script");
            (d.id = "storyslidertemp"),
                (d.type = "text/x-handlebars-template"),
                (d.innerHTML =
                    '<div class="ch_du" style="width:96%;"><p class="slid_01"><p class="slid_item"><ul id="content-slider2" class="content-slider">{{#each data}}<li  style="padding:5px; min-height:250px"><a href="{{storyurl}}" target="_blank" style="text-decoration:none"><div align="left"><img alt="{{storytitle}}" src="{{storyimg}}" style="height:140px"> <span class="cl_g ellipsis">{{storytitle}}</span></div></a></li>{{/each}}</ul></p></p></div>'),
                document.body.appendChild(d);
            var l = $("#bodytemp").html(),
                c = Handlebars.compile(l)("" != pkgdatatitle && void 0 !== pkgdatatitle ? { bubblepkgtitle: "Looking for " + pkgdatatitle + "?" } : { bubblepkgtitle: "Want to travel?" });
            $("body").append(c), $(window).width() < 639 ? $("#mtitlebubble").show() : $("#titlebubble").show();
            var u = $("#questiontemp").html();
            questemp = Handlebars.compile(u);
            var h = $("#anstemp").html();
            anstemp = Handlebars.compile(h);
            var p = $("#slidertemp").html();
            slidertemp = Handlebars.compile(p);
            var m = $("#storyslidertemp").html();
            storyslidertemp = Handlebars.compile(m);
            var g = $("#trevtemp").html();
            trevtemp = Handlebars.compile(g);
            var f = $("#durtemp").html();
            durtemp = Handlebars.compile(f);
            var I = $("#caltemp").html();
            if (((datetemp = Handlebars.compile(I)), (loginname = username), (loginemail = userloginemail), (logincontact = userlogincontact), (logincity = userlogincity), 1 == questionNo)) {
                $("#toplacesdiv").show("slow");
                var v = '<input id="ansinp" placeholder="' + getplaceholder(questionNo) + '"  class="chat_inp" onkeypress="return submitans(event);" value="" type="text" />';
                $("#inputdiv").html(v), $("#submit").show();
            }
        })(),
            e();
        var a = $(window).height();
        (e = $(".m_chat_hed").outerHeight(!0)),
            (a -= e += 290),
            $("#chatbox").css("height", a),
            $("#chatmessages").css("max-height", a),
            $(window).resize(function () {
                var e = $(window).height(),
                    a = $(".m_chat_hed").outerHeight(!0);
                (e -= a += 100), $("#chatbox").css("height", e), $("#chatmessages").css("max-height", e), scrolltobottom("chatmessages");
            });
    })(window.jQuery, window, document);
}),
    $(function () {
        var _, i;
        (_ = jQuery),
            (i = {
                item: 3,
                autoWidth: !1,
                slideMove: 1,
                slideMargin: 10,
                addClass: "",
                mode: "slide",
                useCSS: !0,
                cssEasing: "ease",
                easing: "linear",
                speed: 400,
                auto: !0,
                pauseOnHover: !1,
                loop: !1,
                slideEndAnimation: !0,
                pause: 2e3,
                keyPress: !1,
                controls: !0,
                prevHtml: "",
                nextHtml: "",
                rtl: !1,
                adaptiveHeight: !1,
                vertical: !1,
                verticalHeight: 500,
                vThumbWidth: 100,
                thumbItem: 10,
                pager: !0,
                gallery: !1,
                galleryMargin: 5,
                thumbMargin: 5,
                currentPagerPosition: "middle",
                enableTouch: !0,
                enableDrag: !0,
                freeMove: !0,
                swipeThreshold: 40,
                responsive: [],
                onBeforeStart: function (e) {},
                onSliderLoad: function (e) {},
                onBeforeSlide: function (e, a) {},
                onAfterSlide: function (e, a) {},
                onBeforeNextSlide: function (e, a) {},
                onBeforePrevSlide: function (e, a) {},
            }),
            (_.fn.lightSlider = function (e) {
                if (0 === this.length) return this;
                if (1 < this.length)
                    return (
                        this.each(function () {
                            _(this).lightSlider(e);
                        }),
                        this
                    );
                var t = {},
                    c = _.extend(!0, {}, i, e),
                    n = {},
                    u = this;
                (t.$el = this), "fade" === c.mode && (c.vertical = !1);
                var l = u.children(),
                    r = _(window).width(),
                    s = null,
                    o = 0,
                    h = 0,
                    a = !1,
                    p = 0,
                    m = "",
                    g = 0,
                    f = !0 === c.vertical ? "height" : "width",
                    I = !0 === c.vertical ? "margin-bottom" : "margin-right",
                    v = 0,
                    y = 0,
                    N = 0,
                    b = 0,
                    d = null,
                    k = "ontouchstart" in document.documentElement,
                    S = {
                        chbreakpoint: function () {
                            if (((r = _(window).width()), c.responsive.length)) {
                                var e;
                                if ((!1 === c.autoWidth && (e = c.item), r < c.responsive[0].breakpoint)) for (var a = 0; a < c.responsive.length; a++) r < c.responsive[a].breakpoint && (c.responsive[a].breakpoint, (s = c.responsive[a]));
                                if (null != s) for (var t in s.settings) s.settings.hasOwnProperty(t) && ((void 0 !== n[t] && null !== n[t]) || (n[t] = c[t]), (c[t] = s.settings[t]));
                                if (!_.isEmptyObject(n) && r > c.responsive[0].breakpoint) for (var i in n) n.hasOwnProperty(i) && (c[i] = n[i]);
                                !1 === c.autoWidth && 0 < v && 0 < N && e !== c.item && (g = Math.round(v / ((N + c.slideMargin) * c.slideMove)));
                            }
                        },
                        calSW: function () {
                            !1 === c.autoWidth && (N = (p - (c.item * c.slideMargin - c.slideMargin)) / c.item);
                        },
                        calWidth: function (e) {
                            var a = !0 === e ? m.find(".lslide").length : l.length;
                            if (!1 === c.autoWidth) h = a * (N + c.slideMargin);
                            else for (var t = (h = 0); t < a; t++) h += parseInt(l.eq(t).width()) + c.slideMargin;
                            return h;
                        },
                    };
                return (
                    (t = {
                        doCss: function () {
                            return !(
                                !c.useCSS ||
                                !(function () {
                                    for (var e = ["transition", "MozTransition", "WebkitTransition", "OTransition", "msTransition", "KhtmlTransition"], a = document.documentElement, t = 0; t < e.length; t++) if (e[t] in a.style) return !0;
                                })()
                            );
                        },
                        keyPress: function () {
                            c.keyPress &&
                                _(document).on("keyup.lightslider", function (e) {
                                    _(":focus").is("input, textarea") || (e.preventDefault ? e.preventDefault() : (e.returnValue = !1), 37 === e.keyCode ? u.goToPrevSlide() : 39 === e.keyCode && u.goToNextSlide());
                                });
                        },
                        controls: function () {
                            c.controls &&
                                (u.after('<div class="lSAction"><a class="lSPrev">' + c.prevHtml + '</a><a class="lSNext">' + c.nextHtml + "</a></div>"),
                                c.autoWidth ? S.calWidth(!1) < p && m.find(".lSAction").hide() : o <= c.item && m.find(".lSAction").hide(),
                                m.find(".lSAction a").on("click", function (e) {
                                    return e.preventDefault ? e.preventDefault() : (e.returnValue = !1), "lSPrev" === _(this).attr("class") ? u.goToPrevSlide() : u.goToNextSlide(), !1;
                                }));
                        },
                        initialStyle: function () {
                            var d = this;
                            "fade" === c.mode && ((c.autoWidth = !1), (c.slideEndAnimation = !1)),
                                c.auto && (c.slideEndAnimation = !1),
                                c.autoWidth && ((c.slideMove = 1), (c.item = 1)),
                                c.loop && ((c.slideMove = 1), (c.freeMove = !1)),
                                c.onBeforeStart.call(this, u),
                                S.chbreakpoint(),
                                u.addClass("lightSlider").wrap('<div class="lSSlideOuter ' + c.addClass + '"><div class="lSSlideWrapper"></div></div>'),
                                (m = u.parent(".lSSlideWrapper")),
                                !0 === c.rtl && m.parent().addClass("lSrtl"),
                                c.vertical ? (m.parent().addClass("vertical"), (p = c.verticalHeight), m.css("height", p + "px")) : (p = u.outerWidth()),
                                l.addClass("lslide"),
                                !0 === c.loop &&
                                    "slide" === c.mode &&
                                    (S.calSW(),
                                    (S.clone = function () {
                                        if (S.calWidth(!0) > p) {
                                            for (var e = 0, a = 0, t = 0; t < l.length && (a++, !((e += parseInt(u.find(".lslide").eq(t).width()) + c.slideMargin) >= p + c.slideMargin)); t++);
                                            var i = !0 === c.autoWidth ? a : c.item;
                                            if (i < u.find(".clone.left").length) for (var n = 0; n < u.find(".clone.left").length - i; n++) l.eq(n).remove();
                                            if (i < u.find(".clone.right").length) for (var r = l.length - 1; r > l.length - 1 - u.find(".clone.right").length; r--) g--, l.eq(r).remove();
                                            for (var s = u.find(".clone.right").length; s < i; s++) u.find(".lslide").eq(s).clone().removeClass("lslide").addClass("clone right").appendTo(u), g++;
                                            for (var o = u.find(".lslide").length - u.find(".clone.left").length; o > u.find(".lslide").length - i; o--)
                                                u.find(".lslide")
                                                    .eq(o - 1)
                                                    .clone()
                                                    .removeClass("lslide")
                                                    .addClass("clone left")
                                                    .prependTo(u);
                                            l = u.children();
                                        } else l.hasClass("clone") && (u.find(".clone").remove(), d.move(u, 0));
                                    }),
                                    S.clone()),
                                (S.sSW = function () {
                                    (o = l.length),
                                        !0 === c.rtl && !1 === c.vertical && (I = "margin-left"),
                                        !1 === c.autoWidth && l.css(f, N + "px"),
                                        l.css(I, c.slideMargin + "px"),
                                        (h = S.calWidth(!1)),
                                        u.css(f, h + "px"),
                                        !0 === c.loop && "slide" === c.mode && !1 === a && (g = u.find(".clone.left").length);
                                }),
                                (S.calL = function () {
                                    (l = u.children()), (o = l.length);
                                }),
                                this.doCss() && m.addClass("usingCss"),
                                S.calL(),
                                "slide" === c.mode
                                    ? (S.calSW(), S.sSW(), !0 === c.loop && ((v = d.slideValue()), this.move(u, v)), !1 === c.vertical && this.setHeight(u, !1))
                                    : (this.setHeight(u, !0), u.addClass("lSFade"), this.doCss() || (l.fadeOut(0), l.eq(g).fadeIn(0))),
                                !0 === c.loop && "slide" === c.mode ? l.eq(g).addClass("active") : l.first().addClass("active");
                        },
                        pager: function () {
                            var l = this;
                            if (
                                ((S.createPager = function () {
                                    b = (p - (c.thumbItem * c.thumbMargin - c.thumbMargin)) / c.thumbItem;
                                    var e = m.find(".lslide"),
                                        a = m.find(".lslide").length,
                                        t = 0,
                                        i = "",
                                        n = 0;
                                    for (t = 0; t < a; t++) {
                                        "slide" === c.mode && (c.autoWidth ? (n += (parseInt(e.eq(t).width()) + c.slideMargin) * c.slideMove) : (n = t * ((N + c.slideMargin) * c.slideMove)));
                                        var r = e.eq(t * c.slideMove).attr("data-thumb");
                                        if (
                                            (!0 === c.gallery
                                                ? (i += '<li style="width:100%;' + f + ":" + b + "px;" + I + ":" + c.thumbMargin + 'px"><a href="#"><img src="' + r + '" /></a></li>')
                                                : (i += '<li><a href="#">' + (t + 1) + "</a></li>"),
                                            "slide" === c.mode && n >= h - p - c.slideMargin)
                                        ) {
                                            t += 1;
                                            var s = 2;
                                            c.autoWidth && ((i += '<li><a href="#">' + (t + 1) + "</a></li>"), (s = 1)), t < s ? ((i = null), m.parent().addClass("noPager")) : m.parent().removeClass("noPager");
                                            break;
                                        }
                                    }
                                    var o = m.parent();
                                    o.find(".lSPager").html(i),
                                        !0 === c.gallery &&
                                            (!0 === c.vertical && o.find(".lSPager").css("width", c.vThumbWidth + "px"),
                                            (y = t * (c.thumbMargin + b) + 0.5),
                                            o.find(".lSPager").css({ property: y + "px", "transition-duration": c.speed + "ms" }),
                                            !0 === c.vertical && m.parent().css("padding-right", c.vThumbWidth + c.galleryMargin + "px"),
                                            o.find(".lSPager").css(f, y + "px"));
                                    var d = o.find(".lSPager").find("li");
                                    d.first().addClass("active"),
                                        d.on("click", function () {
                                            return !0 === c.loop && "slide" === c.mode ? (g += d.index(this) - o.find(".lSPager").find("li.active").index()) : (g = d.index(this)), u.mode(!1), !0 === c.gallery && l.slideThumb(), !1;
                                        });
                                }),
                                c.pager)
                            ) {
                                var e = "lSpg";
                                c.gallery && (e = "lSGallery"), m.after('<ul class="lSPager ' + e + '"></ul>');
                                var a = c.vertical ? "margin-left" : "margin-top";
                                m
                                    .parent()
                                    .find(".lSPager")
                                    .css(a, c.galleryMargin + "px"),
                                    S.createPager();
                            }
                            setTimeout(function () {
                                S.init();
                            }, 0);
                        },
                        setHeight: function (i, n) {
                            var r = null,
                                e = this;
                            r = c.loop ? i.children(".lslide ").first() : i.children().first();
                            var a = function () {
                                var e = r.outerHeight(),
                                    a = 0,
                                    t = e;
                                n && ((e = 0), (a = (100 * t) / p)), i.css({ height: e + "px", "padding-bottom": a + "%" });
                            };
                            a(),
                                r.find("img").length
                                    ? r.find("img")[0].complete
                                        ? (a(), d || e.auto())
                                        : r.find("img").on("load", function () {
                                              setTimeout(function () {
                                                  a(), d || e.auto();
                                              }, 100);
                                          })
                                    : d || e.auto();
                        },
                        active: function (e, a) {
                            this.doCss() && "fade" === c.mode && m.addClass("on");
                            var t,
                                i,
                                n = 0;
                            g * c.slideMove < o
                                ? (e.removeClass("active"),
                                  this.doCss() || "fade" !== c.mode || !1 !== a || e.fadeOut(c.speed),
                                  (n = !0 === a ? g : g * c.slideMove),
                                  !0 === a && ((i = (t = e.length) - 1), t <= n + 1 && (n = i)),
                                  !0 === c.loop && "slide" === c.mode && ((n = !0 === a ? g - u.find(".clone.left").length : g * c.slideMove), !0 === a && ((i = (t = e.length) - 1), n + 1 === t ? (n = i) : t < n + 1 && (n = 0))),
                                  this.doCss() || "fade" !== c.mode || !1 !== a || e.eq(n).fadeIn(c.speed),
                                  e.eq(n).addClass("active"))
                                : (e.removeClass("active"), e.eq(e.length - 1).addClass("active"), this.doCss() || "fade" !== c.mode || !1 !== a || (e.fadeOut(c.speed), e.eq(n).fadeIn(c.speed)));
                        },
                        move: function (e, a) {
                            !0 === c.rtl && (a = -a),
                                this.doCss()
                                    ? !0 === c.vertical
                                        ? e.css({ transform: "translate3d(0px, " + -a + "px, 0px)", "-webkit-transform": "translate3d(0px, " + -a + "px, 0px)" })
                                        : e.css({ transform: "translate3d(" + -a + "px, 0px, 0px)", "-webkit-transform": "translate3d(" + -a + "px, 0px, 0px)" })
                                    : !0 === c.vertical
                                    ? e.css("position", "relative").animate({ top: -a + "px" }, c.speed, c.easing)
                                    : e.css("position", "relative").animate({ left: -a + "px" }, c.speed, c.easing);
                            var t = m.parent().find(".lSPager").find("li");
                            this.active(t, !0);
                        },
                        fade: function () {
                            this.active(l, !1);
                            var e = m.parent().find(".lSPager").find("li");
                            this.active(e, !0);
                        },
                        slide: function () {
                            var e = this;
                            (S.calSlide = function () {
                                p < h &&
                                    ((v = e.slideValue()),
                                    e.active(l, !1),
                                    v > h - p - c.slideMargin ? (v = h - p - c.slideMargin) : v < 0 && (v = 0),
                                    e.move(u, v),
                                    !0 === c.loop && "slide" === c.mode && (g >= o - u.find(".clone.left").length / c.slideMove && e.resetSlide(u.find(".clone.left").length), 0 === g && e.resetSlide(m.find(".lslide").length)));
                            }),
                                S.calSlide();
                        },
                        resetSlide: function (e) {
                            var a = this;
                            m.find(".lSAction a").addClass("disabled"),
                                setTimeout(function () {
                                    (g = e),
                                        m.css("transition-duration", "0ms"),
                                        (v = a.slideValue()),
                                        a.active(l, !1),
                                        t.move(u, v),
                                        setTimeout(function () {
                                            m.css("transition-duration", c.speed + "ms"), m.find(".lSAction a").removeClass("disabled");
                                        }, 50);
                                }, c.speed + 100);
                        },
                        slideValue: function () {
                            var e = 0;
                            if (!1 === c.autoWidth) e = g * ((N + c.slideMargin) * c.slideMove);
                            else for (var a = (e = 0); a < g; a++) e += parseInt(l.eq(a).width()) + c.slideMargin;
                            return e;
                        },
                        slideThumb: function () {
                            var e;
                            switch (c.currentPagerPosition) {
                                case "left":
                                    e = 0;
                                    break;
                                case "middle":
                                    e = p / 2 - b / 2;
                                    break;
                                case "right":
                                    e = p - b;
                            }
                            var a = g - u.find(".clone.left").length,
                                t = m.parent().find(".lSPager");
                            "slide" === c.mode && !0 === c.loop && (a >= t.children().length ? (a = 0) : a < 0 && (a = t.children().length));
                            var i = a * (b + c.thumbMargin) - e;
                            y < i + p && (i = y - p - c.thumbMargin), i < 0 && (i = 0), this.move(t, i);
                        },
                        auto: function () {
                            c.auto &&
                                (clearInterval(d),
                                (d = setInterval(function () {
                                    u.goToNextSlide();
                                }, c.pause)));
                        },
                        pauseOnHover: function () {
                            var e = this;
                            c.auto &&
                                c.pauseOnHover &&
                                (m.on("mouseenter", function () {
                                    _(this).addClass("ls-hover"), u.pause(), (c.auto = !0);
                                }),
                                m.on("mouseleave", function () {
                                    _(this).removeClass("ls-hover"), m.find(".lightSlider").hasClass("lsGrabbing") || e.auto();
                                }));
                        },
                        touchMove: function (e, a) {
                            if ((m.css("transition-duration", "0ms"), "slide" === c.mode)) {
                                var t = v - (e - a);
                                if (t >= h - p - c.slideMargin)
                                    if (!1 === c.freeMove) t = h - p - c.slideMargin;
                                    else {
                                        var i = h - p - c.slideMargin;
                                        t = i + (t - i) / 5;
                                    }
                                else t < 0 && (!1 === c.freeMove ? (t = 0) : (t /= 5));
                                this.move(u, t);
                            }
                        },
                        touchEnd: function (e) {
                            if ((m.css("transition-duration", c.speed + "ms"), "slide" === c.mode)) {
                                var r = !1,
                                    a = !0;
                                (v -= e) > h - p - c.slideMargin ? ((v = h - p - c.slideMargin), !1 === c.autoWidth && (r = !0)) : v < 0 && (v = 0);
                                var t = function (e) {
                                    var a = 0;
                                    if ((r || (e && (a = 1)), c.autoWidth)) for (var t = 0, i = 0; i < l.length && ((t += parseInt(l.eq(i).width()) + c.slideMargin), (g = i + a), !(v <= t)); i++);
                                    else {
                                        var n = v / ((N + c.slideMargin) * c.slideMove);
                                        (g = parseInt(n) + a), v >= h - p - c.slideMargin && n % 1 != 0 && g++;
                                    }
                                };
                                e >= c.swipeThreshold ? (t(!1), (a = !1)) : e <= -c.swipeThreshold && (t(!0), (a = !1)), u.mode(a), this.slideThumb();
                            } else e >= c.swipeThreshold ? u.goToPrevSlide() : e <= -c.swipeThreshold && u.goToNextSlide();
                        },
                        enableDrag: function () {
                            var t = this;
                            if (!k) {
                                var i = 0,
                                    n = 0,
                                    r = !1;
                                m.find(".lightSlider").addClass("lsGrab"),
                                    m.on("mousedown", function (e) {
                                        if (h < p && 0 !== h) return !1;
                                        "lSPrev" !== _(e.target).attr("class") &&
                                            "lSNext" !== _(e.target).attr("class") &&
                                            ((i = !0 === c.vertical ? e.pageY : e.pageX),
                                            (r = !0),
                                            e.preventDefault ? e.preventDefault() : (e.returnValue = !1),
                                            (m.scrollLeft += 1),
                                            (m.scrollLeft -= 1),
                                            m.find(".lightSlider").removeClass("lsGrab").addClass("lsGrabbing"),
                                            clearInterval(d));
                                    }),
                                    _(window).on("mousemove", function (e) {
                                        r && ((n = !0 === c.vertical ? e.pageY : e.pageX), t.touchMove(n, i));
                                    }),
                                    _(window).on("mouseup", function (e) {
                                        if (r) {
                                            m.find(".lightSlider").removeClass("lsGrabbing").addClass("lsGrab");
                                            var a = (n = !(r = !1) === c.vertical ? e.pageY : e.pageX) - i;
                                            Math.abs(a) >= c.swipeThreshold &&
                                                _(window).on("click.ls", function (e) {
                                                    e.preventDefault ? e.preventDefault() : (e.returnValue = !1), e.stopImmediatePropagation(), e.stopPropagation(), _(window).off("click.ls");
                                                }),
                                                t.touchEnd(a);
                                        }
                                    });
                            }
                        },
                        enableTouch: function () {
                            var n = this;
                            if (k) {
                                var r = {},
                                    s = {};
                                m.on("touchstart", function (e) {
                                    (s = e.originalEvent.targetTouches[0]), (r.pageX = e.originalEvent.targetTouches[0].pageX), (r.pageY = e.originalEvent.targetTouches[0].pageY), clearInterval(d);
                                }),
                                    m.on("touchmove", function (e) {
                                        if (h < p && 0 !== h) return !1;
                                        var a = e.originalEvent;
                                        s = a.targetTouches[0];
                                        var t = Math.abs(s.pageX - r.pageX),
                                            i = Math.abs(s.pageY - r.pageY);
                                        !0 === c.vertical ? (t < 3 * i && e.preventDefault(), n.touchMove(s.pageY, r.pageY)) : (i < 3 * t && e.preventDefault(), n.touchMove(s.pageX, r.pageX));
                                    }),
                                    m.on("touchend", function () {
                                        if (h < p && 0 !== h) return !1;
                                        var e;
                                        (e = !0 === c.vertical ? s.pageY - r.pageY : s.pageX - r.pageX), n.touchEnd(e);
                                    });
                            }
                        },
                        build: function () {
                            var e = this;
                            e.initialStyle(),
                                this.doCss() && (!0 === c.enableTouch && e.enableTouch(), !0 === c.enableDrag && e.enableDrag()),
                                _(window).on("focus", function () {
                                    e.auto();
                                }),
                                _(window).on("blur", function () {
                                    clearInterval(d);
                                }),
                                e.pager(),
                                e.pauseOnHover(),
                                e.controls(),
                                e.keyPress();
                        },
                    }).build(),
                    (S.init = function () {
                        S.chbreakpoint(),
                            !0 === c.vertical ? ((p = 1 < c.item ? c.verticalHeight : l.outerHeight()), m.css("height", p + "px")) : (p = m.outerWidth()),
                            !0 === c.loop && "slide" === c.mode && S.clone(),
                            S.calL(),
                            "slide" === c.mode && u.removeClass("lSSlide"),
                            "slide" === c.mode && (S.calSW(), S.sSW()),
                            setTimeout(function () {
                                "slide" === c.mode && u.addClass("lSSlide");
                            }, 1e3),
                            c.pager && S.createPager(),
                            !0 === c.adaptiveHeight && !1 === c.vertical && u.css("height", l.eq(g).outerHeight(!0)),
                            !1 === c.adaptiveHeight && ("slide" === c.mode ? (!1 === c.vertical ? t.setHeight(u, !1) : t.auto()) : t.setHeight(u, !0)),
                            !0 === c.gallery && t.slideThumb(),
                            "slide" === c.mode && t.slide(),
                            !1 === c.autoWidth ? (l.length <= c.item ? m.find(".lSAction").hide() : m.find(".lSAction").show()) : S.calWidth(!1) < p && 0 !== h ? m.find(".lSAction").hide() : m.find(".lSAction").show();
                    }),
                    (u.goToPrevSlide = function () {
                        0 < g
                            ? (c.onBeforePrevSlide.call(this, u, g), g--, u.mode(!1), !0 === c.gallery && t.slideThumb())
                            : !0 === c.loop
                            ? (c.onBeforePrevSlide.call(this, u, g), "fade" === c.mode && (g = parseInt((o - 1) / c.slideMove)), u.mode(!1), !0 === c.gallery && t.slideThumb())
                            : !0 === c.slideEndAnimation &&
                              (u.addClass("leftEnd"),
                              setTimeout(function () {
                                  u.removeClass("leftEnd");
                              }, 400));
                    }),
                    (u.goToNextSlide = function () {
                        var e = !0;
                        "slide" === c.mode && (e = t.slideValue() < h - p - c.slideMargin),
                            g * c.slideMove < o - c.slideMove && e
                                ? (c.onBeforeNextSlide.call(this, u, g), g++, u.mode(!1), !0 === c.gallery && t.slideThumb())
                                : !0 === c.loop
                                ? (c.onBeforeNextSlide.call(this, u, g), (g = 0), u.mode(!1), !0 === c.gallery && t.slideThumb())
                                : !0 === c.slideEndAnimation &&
                                  (u.addClass("rightEnd"),
                                  setTimeout(function () {
                                      u.removeClass("rightEnd");
                                  }, 400));
                    }),
                    (u.mode = function (e) {
                        !0 === c.adaptiveHeight && !1 === c.vertical && u.css("height", l.eq(g).outerHeight(!0)),
                            !1 === a &&
                                ("slide" === c.mode
                                    ? t.doCss() && (u.addClass("lSSlide"), "" !== c.speed && m.css("transition-duration", c.speed + "ms"), "" !== c.cssEasing && m.css("transition-timing-function", c.cssEasing))
                                    : t.doCss() && ("" !== c.speed && u.css("transition-duration", c.speed + "ms"), "" !== c.cssEasing && u.css("transition-timing-function", c.cssEasing))),
                            e || c.onBeforeSlide.call(this, u, g),
                            "slide" === c.mode ? t.slide() : t.fade(),
                            m.hasClass("ls-hover") || t.auto(),
                            setTimeout(function () {
                                e || c.onAfterSlide.call(this, u, g);
                            }, c.speed),
                            (a = !0);
                    }),
                    (u.play = function () {
                        u.goToNextSlide(), (c.auto = !0), t.auto();
                    }),
                    (u.pause = function () {
                        (c.auto = !1), clearInterval(d);
                    }),
                    (u.refresh = function () {
                        S.init();
                    }),
                    (u.getCurrentSlideCount = function () {
                        var e = g;
                        if (c.loop) {
                            var a = m.find(".lslide").length,
                                t = u.find(".clone.left").length;
                            e = g <= t - 1 ? a + (g - t) : a + t <= g ? g - a - t : g - t;
                        }
                        return e + 1;
                    }),
                    (u.getTotalSlideCount = function () {
                        return m.find(".lslide").length;
                    }),
                    (u.goToSlide = function (e) {
                        (g = c.loop ? e + u.find(".clone.left").length - 1 : e), u.mode(!1), !0 === c.gallery && t.slideThumb();
                    }),
                    (u.destroy = function () {
                        u.lightSlider &&
                            ((u.goToPrevSlide = function () {}),
                            (u.goToNextSlide = function () {}),
                            (u.mode = function () {}),
                            (u.play = function () {}),
                            (u.pause = function () {}),
                            (u.refresh = function () {}),
                            (u.getCurrentSlideCount = function () {}),
                            (u.getTotalSlideCount = function () {}),
                            (u.goToSlide = function () {}),
                            (u.lightSlider = null),
                            (S = { init: function () {} }),
                            u.parent().parent().find(".lSAction, .lSPager").remove(),
                            u.removeClass("lightSlider lSFade lSSlide lsGrab lsGrabbing leftEnd right").removeAttr("style").unwrap().unwrap(),
                            u.children().removeAttr("style"),
                            l.removeClass("lslide active"),
                            u.find(".clone").remove(),
                            (d = l = null),
                            (a = !1),
                            (g = 0));
                    }),
                    setTimeout(function () {
                        c.onSliderLoad.call(this, u);
                    }, 10),
                    _(window).on("resize orientationchange", function (e) {
                        setTimeout(function () {
                            e.preventDefault ? e.preventDefault() : (e.returnValue = !1), S.init();
                        }, 200);
                    }),
                    this
                );
            });
    }),
    $(function () {
        var e,
            i =
                Object.assign ||
                function (e) {
                    for (var a = 1; a < arguments.length; a++) {
                        var t = arguments[a];
                        for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                    }
                    return e;
                },
            a =
                "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                    ? function (e) {
                          return typeof e;
                      }
                    : function (e) {
                          return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                      };
        (e = function () {
            var t = {
                    elements_selector: "img",
                    container: document,
                    threshold: 300,
                    data_src: "src",
                    data_srcset: "srcset",
                    class_loading: "loading",
                    class_loaded: "loaded",
                    class_error: "error",
                    callback_load: null,
                    callback_error: null,
                    callback_set: null,
                },
                d = function (e, a) {
                    return e.getAttribute("data-" + a);
                },
                n = function (e) {
                    return e.filter(function (e) {
                        return !d(e, "was-processed");
                    });
                },
                r = function (e, a) {
                    var t = new e(a),
                        i = new CustomEvent("LazyLoad::Initialized", { detail: { instance: t } });
                    window.dispatchEvent(i);
                },
                s = !!document.body.classList,
                o = function (e, a) {
                    s ? e.classList.add(a) : (e.className += (e.className ? " " : "") + a);
                },
                l = function (e, a) {
                    e && e(a);
                },
                c = function (e, a, t) {
                    e.removeEventListener("load", a), e.removeEventListener("error", t);
                },
                u = function (e, a, t) {
                    var i,
                        n,
                        r = e.target;
                    (i = r),
                        (n = t.class_loading),
                        s
                            ? i.classList.remove(n)
                            : (i.className = i.className
                                  .replace(new RegExp("(^|\\s+)" + n + "(\\s+|$)"), " ")
                                  .replace(/^\s+/, "")
                                  .replace(/\s+$/, "")),
                        o(r, a ? t.class_loaded : t.class_error),
                        l(a ? t.callback_load : t.callback_error, r);
                },
                h = function (e, a) {
                    var t, i, n, r;
                    -1 < ["IMG", "IFRAME"].indexOf(e.tagName) &&
                        ((i = a),
                        (n = function e(a) {
                            u(a, !0, i), c(t, e, r);
                        }),
                        (r = function e(a) {
                            u(a, !1, i), c(t, n, e);
                        }),
                        (t = e).addEventListener("load", n),
                        t.addEventListener("error", r),
                        o(e, a.class_loading)),
                        (function (e, o) {
                            var a = o.data_src,
                                t = o.data_srcset,
                                i = e.tagName,
                                n = d(e, a);
                            if ("IMG" === i) {
                                !(function (e, a) {
                                    var t = o.data_srcset,
                                        i = e.parentElement;
                                    if ("PICTURE" === i.tagName)
                                        for (var n, r = 0; (n = i.children[r]); r += 1)
                                            if ("SOURCE" === n.tagName) {
                                                var s = d(n, t);
                                                s && n.setAttribute("srcset", s);
                                            }
                                })(e);
                                var r = d(e, t);
                                return r && e.setAttribute("srcset", r), n && e.setAttribute("src", n);
                            }
                            "IFRAME" !== i ? n && (e.style.backgroundImage = 'url("' + n + '")') : n && e.setAttribute("src", n);
                        })(e, a),
                        e.setAttribute("data-was-processed", !0),
                        l(a.callback_set, e);
                },
                e = function (e, a) {
                    (this._settings = i({}, t, e)), this._setObserver(), this.update(a);
                };
            e.prototype = {
                _setObserver: function () {
                    var t = this;
                    if ("IntersectionObserver" in window) {
                        var i = this._settings;
                        this._observer = new IntersectionObserver(
                            function (e) {
                                e.forEach(function (e) {
                                    if (0 < e.intersectionRatio) {
                                        var a = e.target;
                                        h(a, i), t._observer.unobserve(a);
                                    }
                                }),
                                    (t._elements = n(t._elements));
                            },
                            { root: i.container === document ? null : i.container, rootMargin: i.threshold + "px" }
                        );
                    }
                },
                update: function (e) {
                    var a = this,
                        t = this._settings,
                        i = e || t.container.querySelectorAll(t.elements_selector);
                    (this._elements = n(Array.prototype.slice.call(i))),
                        this._observer
                            ? this._elements.forEach(function (e) {
                                  a._observer.observe(e);
                              })
                            : (this._elements.forEach(function (e) {
                                  h(e, t);
                              }),
                              (this._elements = n(this._elements)));
                },
                destroy: function () {
                    var a = this;
                    this._observer &&
                        (n(this._elements).forEach(function (e) {
                            a._observer.unobserve(e);
                        }),
                        (this._observer = null)),
                        (this._elements = null),
                        (this._settings = null);
                },
            };
            var a = window.lazyLoadOptions;
            return (
                a &&
                    (function (e, a) {
                        if (a.length) for (var t, i = 0; (t = a[i]); i += 1) r(e, t);
                        else r(e, a);
                    })(e, a),
                e
            );
        }),
            "object" === ("undefined" == typeof exports ? "undefined" : a(exports)) && "undefined" != typeof module ? (module.exports = e()) : "function" == typeof define && define.amd ? define(e) : (this.LazyLoad = e());
    }),
    (function (e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery);
    })(function (M) {
        function e() {
            (this._curInst = null),
                (this._keyEvent = !1),
                (this._disabledInputs = []),
                (this._datepickerShowing = !1),
                (this._inDialog = !1),
                (this._mainDivId = "ui-datepicker-div"),
                (this._inlineClass = "ui-datepicker-inline"),
                (this._appendClass = "ui-datepicker-append"),
                (this._triggerClass = "ui-datepicker-trigger"),
                (this._dialogClass = "ui-datepicker-dialog"),
                (this._disableClass = "ui-datepicker-disabled"),
                (this._unselectableClass = "ui-datepicker-unselectable"),
                (this._currentClass = "ui-datepicker-current-day"),
                (this._dayOverClass = "ui-datepicker-days-cell-over"),
                (this.regional = []),
                (this.regional[""] = {
                    closeText: "Done",
                    prevText: "Prev",
                    nextText: "Next",
                    currentText: "Today",
                    monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                    dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                    weekHeader: "Wk",
                    dateFormat: "mm/dd/yy",
                    firstDay: 0,
                    isRTL: !1,
                    showMonthAfterYear: !1,
                    yearSuffix: "",
                }),
                (this._defaults = {
                    showOn: "focus",
                    showAnim: "fadeIn",
                    showOptions: {},
                    defaultDate: null,
                    appendText: "",
                    buttonText: "...",
                    buttonImage: "",
                    buttonImageOnly: !1,
                    hideIfNoPrevNext: !1,
                    navigationAsDateFormat: !1,
                    gotoCurrent: !1,
                    changeMonth: !1,
                    changeYear: !1,
                    yearRange: "c-10:c+10",
                    showOtherMonths: !1,
                    selectOtherMonths: !1,
                    showWeek: !1,
                    calculateWeek: this.iso8601Week,
                    shortYearCutoff: "+10",
                    minDate: null,
                    maxDate: null,
                    duration: "fast",
                    beforeShowDay: null,
                    beforeShow: null,
                    onSelect: null,
                    onChangeMonthYear: null,
                    onClose: null,
                    numberOfMonths: 1,
                    showCurrentAtPos: 0,
                    stepMonths: 1,
                    stepBigMonths: 12,
                    altField: "",
                    altFormat: "",
                    constrainInput: !0,
                    showButtonPanel: !1,
                    autoSize: !1,
                    disabled: !1,
                }),
                M.extend(this._defaults, this.regional[""]),
                (this.regional.en = M.extend(!0, {}, this.regional[""])),
                (this.regional["en-US"] = M.extend(!0, {}, this.regional.en)),
                (this.dpDiv = t(M("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")));
        }
        function t(e) {
            var a = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
            return e
                .on("mouseout", a, function () {
                    M(this).removeClass("ui-state-hover"),
                        -1 !== this.className.indexOf("ui-datepicker-prev") && M(this).removeClass("ui-datepicker-prev-hover"),
                        -1 !== this.className.indexOf("ui-datepicker-next") && M(this).removeClass("ui-datepicker-next-hover");
                })
                .on("mouseover", a, r);
        }
        function r() {
            M.datepicker._isDisabledDatepicker(c.inline ? c.dpDiv.parent()[0] : c.input[0]) ||
                (M(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"),
                M(this).addClass("ui-state-hover"),
                -1 !== this.className.indexOf("ui-datepicker-prev") && M(this).addClass("ui-datepicker-prev-hover"),
                -1 !== this.className.indexOf("ui-datepicker-next") && M(this).addClass("ui-datepicker-next-hover"));
        }
        function u(e, a) {
            for (var t in (M.extend(e, a), a)) null == a[t] && (e[t] = a[t]);
            return e;
        }
        M.ui = M.ui || {};
        var n,
            i = ((M.ui.version = "1.12.1"), 0),
            o = Array.prototype.slice;
        (M.cleanData =
            ((n = M.cleanData),
            function (e) {
                var a, t, i;
                for (i = 0; null != (t = e[i]); i++)
                    try {
                        (a = M._data(t, "events")) && a.remove && M(t).triggerHandler("remove");
                    } catch (e) {}
                n(e);
            })),
            (M.widget = function (e, t, a) {
                var i,
                    n,
                    r,
                    s = {},
                    o = e.split(".")[0],
                    d = o + "-" + (e = e.split(".")[1]);
                return (
                    a || ((a = t), (t = M.Widget)),
                    M.isArray(a) && (a = M.extend.apply(null, [{}].concat(a))),
                    (M.expr[":"][d.toLowerCase()] = function (e) {
                        return !!M.data(e, d);
                    }),
                    (M[o] = M[o] || {}),
                    (i = M[o][e]),
                    (n = M[o][e] = function (e, a) {
                        return this._createWidget ? void (arguments.length && this._createWidget(e, a)) : new n(e, a);
                    }),
                    M.extend(n, i, { version: a.version, _proto: M.extend({}, a), _childConstructors: [] }),
                    ((r = new t()).options = M.widget.extend({}, r.options)),
                    M.each(a, function (a, r) {
                        return M.isFunction(r)
                            ? void (s[a] = (function () {
                                  function i() {
                                      return t.prototype[a].apply(this, arguments);
                                  }
                                  function n(e) {
                                      return t.prototype[a].apply(this, e);
                                  }
                                  return function () {
                                      var e,
                                          a = this._super,
                                          t = this._superApply;
                                      return (this._super = i), (this._superApply = n), (e = r.apply(this, arguments)), (this._super = a), (this._superApply = t), e;
                                  };
                              })())
                            : void (s[a] = r);
                    }),
                    (n.prototype = M.widget.extend(r, { widgetEventPrefix: (i && r.widgetEventPrefix) || e }, s, { constructor: n, namespace: o, widgetName: e, widgetFullName: d })),
                    i
                        ? (M.each(i._childConstructors, function (e, a) {
                              var t = a.prototype;
                              M.widget(t.namespace + "." + t.widgetName, n, a._proto);
                          }),
                          delete i._childConstructors)
                        : t._childConstructors.push(n),
                    M.widget.bridge(e, n),
                    n
                );
            }),
            (M.widget.extend = function (e) {
                for (var a, t, i = o.call(arguments, 1), n = 0, r = i.length; n < r; n++)
                    for (a in i[n]) (t = i[n][a]), i[n].hasOwnProperty(a) && void 0 !== t && (M.isPlainObject(t) ? (e[a] = M.isPlainObject(e[a]) ? M.widget.extend({}, e[a], t) : M.widget.extend({}, t)) : (e[a] = t));
                return e;
            }),
            (M.widget.bridge = function (r, a) {
                var s = a.prototype.widgetFullName || r;
                M.fn[r] = function (t) {
                    var e = "string" == typeof t,
                        i = o.call(arguments, 1),
                        n = this;
                    return (
                        e
                            ? this.length || "instance" !== t
                                ? this.each(function () {
                                      var e,
                                          a = M.data(this, s);
                                      return "instance" === t
                                          ? ((n = a), !1)
                                          : a
                                          ? M.isFunction(a[t]) && "_" !== t.charAt(0)
                                              ? (e = a[t].apply(a, i)) !== a && void 0 !== e
                                                  ? ((n = e && e.jquery ? n.pushStack(e.get()) : e), !1)
                                                  : void 0
                                              : M.error("no such method '" + t + "' for " + r + " widget instance")
                                          : M.error("cannot call methods on " + r + " prior to initialization; attempted to call method '" + t + "'");
                                  })
                                : (n = void 0)
                            : (i.length && (t = M.widget.extend.apply(null, [t].concat(i))),
                              this.each(function () {
                                  var e = M.data(this, s);
                                  e ? (e.option(t || {}), e._init && e._init()) : M.data(this, s, new a(t, this));
                              })),
                        n
                    );
                };
            }),
            (M.Widget = function () {}),
            (M.Widget._childConstructors = []),
            (M.Widget.prototype = {
                widgetName: "widget",
                widgetEventPrefix: "",
                defaultElement: "<div>",
                options: { classes: {}, disabled: !1, create: null },
                _createWidget: function (e, a) {
                    (a = M(a || this.defaultElement || this)[0]),
                        (this.element = M(a)),
                        (this.uuid = i++),
                        (this.eventNamespace = "." + this.widgetName + this.uuid),
                        (this.bindings = M()),
                        (this.hoverable = M()),
                        (this.focusable = M()),
                        (this.classesElementLookup = {}),
                        a !== this &&
                            (M.data(a, this.widgetFullName, this),
                            this._on(!0, this.element, {
                                remove: function (e) {
                                    e.target === a && this.destroy();
                                },
                            }),
                            (this.document = M(a.style ? a.ownerDocument : a.document || a)),
                            (this.window = M(this.document[0].defaultView || this.document[0].parentWindow))),
                        (this.options = M.widget.extend({}, this.options, this._getCreateOptions(), e)),
                        this._create(),
                        this.options.disabled && this._setOptionDisabled(this.options.disabled),
                        this._trigger("create", null, this._getCreateEventData()),
                        this._init();
                },
                _getCreateOptions: function () {
                    return {};
                },
                _getCreateEventData: M.noop,
                _create: M.noop,
                _init: M.noop,
                destroy: function () {
                    var t = this;
                    this._destroy(),
                        M.each(this.classesElementLookup, function (e, a) {
                            t._removeClass(a, e);
                        }),
                        this.element.off(this.eventNamespace).removeData(this.widgetFullName),
                        this.widget().off(this.eventNamespace).removeAttr("aria-disabled"),
                        this.bindings.off(this.eventNamespace);
                },
                _destroy: M.noop,
                widget: function () {
                    return this.element;
                },
                option: function (e, a) {
                    var t,
                        i,
                        n,
                        r = e;
                    if (0 === arguments.length) return M.widget.extend({}, this.options);
                    if ("string" == typeof e)
                        if (((r = {}), (e = (t = e.split(".")).shift()), t.length)) {
                            for (i = r[e] = M.widget.extend({}, this.options[e]), n = 0; n < t.length - 1; n++) (i[t[n]] = i[t[n]] || {}), (i = i[t[n]]);
                            if (((e = t.pop()), 1 === arguments.length)) return void 0 === i[e] ? null : i[e];
                            i[e] = a;
                        } else {
                            if (1 === arguments.length) return void 0 === this.options[e] ? null : this.options[e];
                            r[e] = a;
                        }
                    return this._setOptions(r), this;
                },
                _setOptions: function (e) {
                    var a;
                    for (a in e) this._setOption(a, e[a]);
                    return this;
                },
                _setOption: function (e, a) {
                    return "classes" === e && this._setOptionClasses(a), (this.options[e] = a), "disabled" === e && this._setOptionDisabled(a), this;
                },
                _setOptionClasses: function (e) {
                    var a, t, i;
                    for (a in e) (i = this.classesElementLookup[a]), e[a] !== this.options.classes[a] && i && i.length && ((t = M(i.get())), this._removeClass(i, a), t.addClass(this._classes({ element: t, keys: a, classes: e, add: !0 })));
                },
                _setOptionDisabled: function (e) {
                    this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!e), e && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"));
                },
                enable: function () {
                    return this._setOptions({ disabled: !1 });
                },
                disable: function () {
                    return this._setOptions({ disabled: !0 });
                },
                _classes: function (n) {
                    function e(e, a) {
                        var t, i;
                        for (i = 0; i < e.length; i++)
                            (t = s.classesElementLookup[e[i]] || M()),
                                (t = M(n.add ? M.unique(t.get().concat(n.element.get())) : t.not(n.element).get())),
                                (s.classesElementLookup[e[i]] = t),
                                r.push(e[i]),
                                a && n.classes[e[i]] && r.push(n.classes[e[i]]);
                    }
                    var r = [],
                        s = this;
                    return (
                        (n = M.extend({ element: this.element, classes: this.options.classes || {} }, n)),
                        this._on(n.element, { remove: "_untrackClassesElement" }),
                        n.keys && e(n.keys.match(/\S+/g) || [], !0),
                        n.extra && e(n.extra.match(/\S+/g) || []),
                        r.join(" ")
                    );
                },
                _untrackClassesElement: function (t) {
                    var i = this;
                    M.each(i.classesElementLookup, function (e, a) {
                        -1 !== M.inArray(t.target, a) && (i.classesElementLookup[e] = M(a.not(t.target).get()));
                    });
                },
                _removeClass: function (e, a, t) {
                    return this._toggleClass(e, a, t, !1);
                },
                _addClass: function (e, a, t) {
                    return this._toggleClass(e, a, t, !0);
                },
                _toggleClass: function (e, a, t, i) {
                    i = "boolean" == typeof i ? i : t;
                    var n = "string" == typeof e || null === e,
                        r = { extra: n ? a : t, keys: n ? e : a, element: n ? this.element : e, add: i };
                    return r.element.toggleClass(this._classes(r), i), this;
                },
                _on: function (s, o, e) {
                    var d,
                        l = this;
                    "boolean" != typeof s && ((e = o), (o = s), (s = !1)),
                        e ? ((o = d = M(o)), (this.bindings = this.bindings.add(o))) : ((e = o), (o = this.element), (d = this.widget())),
                        M.each(e, function (e, a) {
                            function t() {
                                return s || (!0 !== l.options.disabled && !M(this).hasClass("ui-state-disabled")) ? ("string" == typeof a ? l[a] : a).apply(l, arguments) : void 0;
                            }
                            "string" != typeof a && (t.guid = a.guid = a.guid || t.guid || M.guid++);
                            var i = e.match(/^([\w:-]*)\s*(.*)$/),
                                n = i[1] + l.eventNamespace,
                                r = i[2];
                            r ? d.on(n, r, t) : o.on(n, t);
                        });
                },
                _off: function (e, a) {
                    (a = (a || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace),
                        e.off(a).off(a),
                        (this.bindings = M(this.bindings.not(e).get())),
                        (this.focusable = M(this.focusable.not(e).get())),
                        (this.hoverable = M(this.hoverable.not(e).get()));
                },
                _delay: function (e, a) {
                    var t = this;
                    return setTimeout(function () {
                        return ("string" == typeof e ? t[e] : e).apply(t, arguments);
                    }, a || 0);
                },
                _hoverable: function (e) {
                    (this.hoverable = this.hoverable.add(e)),
                        this._on(e, {
                            mouseenter: function (e) {
                                this._addClass(M(e.currentTarget), null, "ui-state-hover");
                            },
                            mouseleave: function (e) {
                                this._removeClass(M(e.currentTarget), null, "ui-state-hover");
                            },
                        });
                },
                _focusable: function (e) {
                    (this.focusable = this.focusable.add(e)),
                        this._on(e, {
                            focusin: function (e) {
                                this._addClass(M(e.currentTarget), null, "ui-state-focus");
                            },
                            focusout: function (e) {
                                this._removeClass(M(e.currentTarget), null, "ui-state-focus");
                            },
                        });
                },
                _trigger: function (e, a, t) {
                    var i,
                        n,
                        r = this.options[e];
                    if (((t = t || {}), ((a = M.Event(a)).type = (e === this.widgetEventPrefix ? e : this.widgetEventPrefix + e).toLowerCase()), (a.target = this.element[0]), (n = a.originalEvent))) for (i in n) i in a || (a[i] = n[i]);
                    return this.element.trigger(a, t), !((M.isFunction(r) && !1 === r.apply(this.element[0], [a].concat(t))) || a.isDefaultPrevented());
                },
            }),
            M.each({ show: "fadeIn", hide: "fadeOut" }, function (r, s) {
                M.Widget.prototype["_" + r] = function (a, e, t) {
                    "string" == typeof e && (e = { effect: e });
                    var i,
                        n = e ? (!0 === e || "number" == typeof e ? s : e.effect || s) : r;
                    "number" == typeof (e = e || {}) && (e = { duration: e }),
                        (i = !M.isEmptyObject(e)),
                        (e.complete = t),
                        e.delay && a.delay(e.delay),
                        i && M.effects && M.effects.effect[n]
                            ? a[r](e)
                            : n !== r && a[n]
                            ? a[n](e.duration, e.easing, t)
                            : a.queue(function (e) {
                                  M(this)[r](), t && t.call(a[0]), e();
                              });
                };
            }),
            M.widget,
            (function () {
                function k(e, a, t) {
                    return [parseFloat(e[0]) * (d.test(e[0]) ? a / 100 : 1), parseFloat(e[1]) * (d.test(e[1]) ? t / 100 : 1)];
                }
                function S(e, a) {
                    return parseInt(M.css(e, a), 10) || 0;
                }
                var n,
                    _ = Math.max,
                    w = Math.abs,
                    i = /left|center|right/,
                    r = /top|center|bottom/,
                    s = /[\+\-]\d+(\.[\d]+)?%?/,
                    o = /^\w+/,
                    d = /%$/,
                    l = M.fn.position;
                (M.position = {
                    scrollbarWidth: function () {
                        if (void 0 !== n) return n;
                        var e,
                            a,
                            t = M("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),
                            i = t.children()[0];
                        return M("body").append(t), (e = i.offsetWidth), t.css("overflow", "scroll"), e === (a = i.offsetWidth) && (a = t[0].clientWidth), t.remove(), (n = e - a);
                    },
                    getScrollInfo: function (e) {
                        var a = e.isWindow || e.isDocument ? "" : e.element.css("overflow-x"),
                            t = e.isWindow || e.isDocument ? "" : e.element.css("overflow-y"),
                            i = "scroll" === a || ("auto" === a && e.width < e.element[0].scrollWidth);
                        return { width: "scroll" === t || ("auto" === t && e.height < e.element[0].scrollHeight) ? M.position.scrollbarWidth() : 0, height: i ? M.position.scrollbarWidth() : 0 };
                    },
                    getWithinInfo: function (e) {
                        var a = M(e || window),
                            t = M.isWindow(a[0]),
                            i = !!a[0] && 9 === a[0].nodeType;
                        return { element: a, isWindow: t, isDocument: i, offset: t || i ? { left: 0, top: 0 } : M(e).offset(), scrollLeft: a.scrollLeft(), scrollTop: a.scrollTop(), width: a.outerWidth(), height: a.outerHeight() };
                    },
                }),
                    (M.fn.position = function (u) {
                        if (!u || !u.of) return l.apply(this, arguments);
                        u = M.extend({}, u);
                        var h,
                            p,
                            m,
                            g,
                            f,
                            e,
                            a,
                            t,
                            I = M(u.of),
                            v = M.position.getWithinInfo(u.within),
                            y = M.position.getScrollInfo(v),
                            N = (u.collision || "flip").split(" "),
                            b = {};
                        return (
                            (e =
                                9 === (t = (a = I)[0]).nodeType
                                    ? { width: a.width(), height: a.height(), offset: { top: 0, left: 0 } }
                                    : M.isWindow(t)
                                    ? { width: a.width(), height: a.height(), offset: { top: a.scrollTop(), left: a.scrollLeft() } }
                                    : t.preventDefault
                                    ? { width: 0, height: 0, offset: { top: t.pageY, left: t.pageX } }
                                    : { width: a.outerWidth(), height: a.outerHeight(), offset: a.offset() }),
                            I[0].preventDefault && (u.at = "left top"),
                            (p = e.width),
                            (m = e.height),
                            (g = e.offset),
                            (f = M.extend({}, g)),
                            M.each(["my", "at"], function () {
                                var e,
                                    a,
                                    t = (u[this] || "").split(" ");
                                1 === t.length && (t = i.test(t[0]) ? t.concat(["center"]) : r.test(t[0]) ? ["center"].concat(t) : ["center", "center"]),
                                    (t[0] = i.test(t[0]) ? t[0] : "center"),
                                    (t[1] = r.test(t[1]) ? t[1] : "center"),
                                    (e = s.exec(t[0])),
                                    (a = s.exec(t[1])),
                                    (b[this] = [e ? e[0] : 0, a ? a[0] : 0]),
                                    (u[this] = [o.exec(t[0])[0], o.exec(t[1])[0]]);
                            }),
                            1 === N.length && (N[1] = N[0]),
                            "right" === u.at[0] ? (f.left += p) : "center" === u.at[0] && (f.left += p / 2),
                            "bottom" === u.at[1] ? (f.top += m) : "center" === u.at[1] && (f.top += m / 2),
                            (h = k(b.at, p, m)),
                            (f.left += h[0]),
                            (f.top += h[1]),
                            this.each(function () {
                                var t,
                                    e,
                                    s = M(this),
                                    o = s.outerWidth(),
                                    d = s.outerHeight(),
                                    a = S(this, "marginLeft"),
                                    i = S(this, "marginTop"),
                                    n = o + a + S(this, "marginRight") + y.width,
                                    r = d + i + S(this, "marginBottom") + y.height,
                                    l = M.extend({}, f),
                                    c = k(b.my, s.outerWidth(), s.outerHeight());
                                "right" === u.my[0] ? (l.left -= o) : "center" === u.my[0] && (l.left -= o / 2),
                                    "bottom" === u.my[1] ? (l.top -= d) : "center" === u.my[1] && (l.top -= d / 2),
                                    (l.left += c[0]),
                                    (l.top += c[1]),
                                    (t = { marginLeft: a, marginTop: i }),
                                    M.each(["left", "top"], function (e, a) {
                                        M.ui.position[N[e]] &&
                                            M.ui.position[N[e]][a](l, {
                                                targetWidth: p,
                                                targetHeight: m,
                                                elemWidth: o,
                                                elemHeight: d,
                                                collisionPosition: t,
                                                collisionWidth: n,
                                                collisionHeight: r,
                                                offset: [h[0] + c[0], h[1] + c[1]],
                                                my: u.my,
                                                at: u.at,
                                                within: v,
                                                elem: s,
                                            });
                                    }),
                                    u.using &&
                                        (e = function (e) {
                                            var a = g.left - l.left,
                                                t = a + p - o,
                                                i = g.top - l.top,
                                                n = i + m - d,
                                                r = {
                                                    target: { element: I, left: g.left, top: g.top, width: p, height: m },
                                                    element: { element: s, left: l.left, top: l.top, width: o, height: d },
                                                    horizontal: t < 0 ? "left" : 0 < a ? "right" : "center",
                                                    vertical: n < 0 ? "top" : 0 < i ? "bottom" : "middle",
                                                };
                                            p < o && w(a + t) < p && (r.horizontal = "center"),
                                                m < d && w(i + n) < m && (r.vertical = "middle"),
                                                _(w(a), w(t)) > _(w(i), w(n)) ? (r.important = "horizontal") : (r.important = "vertical"),
                                                u.using.call(this, e, r);
                                        }),
                                    s.offset(M.extend(l, { using: e }));
                            })
                        );
                    }),
                    (M.ui.position = {
                        fit: {
                            left: function (e, a) {
                                var t,
                                    i = a.within,
                                    n = i.isWindow ? i.scrollLeft : i.offset.left,
                                    r = i.width,
                                    s = e.left - a.collisionPosition.marginLeft,
                                    o = n - s,
                                    d = s + a.collisionWidth - r - n;
                                a.collisionWidth > r
                                    ? 0 < o && d <= 0
                                        ? ((t = e.left + o + a.collisionWidth - r - n), (e.left += o - t))
                                        : (e.left = 0 < d && o <= 0 ? n : d < o ? n + r - a.collisionWidth : n)
                                    : 0 < o
                                    ? (e.left += o)
                                    : 0 < d
                                    ? (e.left -= d)
                                    : (e.left = _(e.left - s, e.left));
                            },
                            top: function (e, a) {
                                var t,
                                    i = a.within,
                                    n = i.isWindow ? i.scrollTop : i.offset.top,
                                    r = a.within.height,
                                    s = e.top - a.collisionPosition.marginTop,
                                    o = n - s,
                                    d = s + a.collisionHeight - r - n;
                                a.collisionHeight > r
                                    ? 0 < o && d <= 0
                                        ? ((t = e.top + o + a.collisionHeight - r - n), (e.top += o - t))
                                        : (e.top = 0 < d && o <= 0 ? n : d < o ? n + r - a.collisionHeight : n)
                                    : 0 < o
                                    ? (e.top += o)
                                    : 0 < d
                                    ? (e.top -= d)
                                    : (e.top = _(e.top - s, e.top));
                            },
                        },
                        flip: {
                            left: function (e, a) {
                                var t,
                                    i,
                                    n = a.within,
                                    r = n.offset.left + n.scrollLeft,
                                    s = n.width,
                                    o = n.isWindow ? n.scrollLeft : n.offset.left,
                                    d = e.left - a.collisionPosition.marginLeft,
                                    l = d - o,
                                    c = d + a.collisionWidth - s - o,
                                    u = "left" === a.my[0] ? -a.elemWidth : "right" === a.my[0] ? a.elemWidth : 0,
                                    h = "left" === a.at[0] ? a.targetWidth : "right" === a.at[0] ? -a.targetWidth : 0,
                                    p = -2 * a.offset[0];
                                l < 0
                                    ? ((t = e.left + u + h + p + a.collisionWidth - s - r) < 0 || t < w(l)) && (e.left += u + h + p)
                                    : 0 < c && (0 < (i = e.left - a.collisionPosition.marginLeft + u + h + p - o) || w(i) < c) && (e.left += u + h + p);
                            },
                            top: function (e, a) {
                                var t,
                                    i,
                                    n = a.within,
                                    r = n.offset.top + n.scrollTop,
                                    s = n.height,
                                    o = n.isWindow ? n.scrollTop : n.offset.top,
                                    d = e.top - a.collisionPosition.marginTop,
                                    l = d - o,
                                    c = d + a.collisionHeight - s - o,
                                    u = "top" === a.my[1] ? -a.elemHeight : "bottom" === a.my[1] ? a.elemHeight : 0,
                                    h = "top" === a.at[1] ? a.targetHeight : "bottom" === a.at[1] ? -a.targetHeight : 0,
                                    p = -2 * a.offset[1];
                                l < 0
                                    ? ((i = e.top + u + h + p + a.collisionHeight - s - r) < 0 || i < w(l)) && (e.top += u + h + p)
                                    : 0 < c && (0 < (t = e.top - a.collisionPosition.marginTop + u + h + p - o) || w(t) < c) && (e.top += u + h + p);
                            },
                        },
                        flipfit: {
                            left: function () {
                                M.ui.position.flip.left.apply(this, arguments), M.ui.position.fit.left.apply(this, arguments);
                            },
                            top: function () {
                                M.ui.position.flip.top.apply(this, arguments), M.ui.position.fit.top.apply(this, arguments);
                            },
                        },
                    });
            })();
        var a,
            s,
            d,
            l,
            c,
            h =
                (M.ui.position,
                M.extend(M.expr[":"], {
                    data: M.expr.createPseudo
                        ? M.expr.createPseudo(function (a) {
                              return function (e) {
                                  return !!M.data(e, a);
                              };
                          })
                        : function (e, a, t) {
                              return !!M.data(e, t[3]);
                          },
                }),
                M.fn.extend({
                    disableSelection:
                        ((a = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown"),
                        function () {
                            return this.on(a + ".ui-disableSelection", function (e) {
                                e.preventDefault();
                            });
                        }),
                    enableSelection: function () {
                        return this.off(".ui-disableSelection");
                    },
                }),
                "ui-effects-"),
            p = "ui-effects-style",
            m = "ui-effects-animated",
            g = M;
        (M.effects = { effect: {} }),
            (function (c, u) {
                function h(e, a, t) {
                    var i = f[a.type] || {};
                    return null == e ? (t || !a.def ? null : a.def) : ((e = i.floor ? ~~e : parseFloat(e)), isNaN(e) ? a.def : i.mod ? (e + i.mod) % i.mod : e < 0 ? 0 : i.max < e ? i.max : e);
                }
                function o(s) {
                    var o = m(),
                        d = (o._rgba = []);
                    return (
                        (s = s.toLowerCase()),
                        I(e, function (e, a) {
                            var t,
                                i = a.re.exec(s),
                                n = i && a.parse(i),
                                r = a.space || "rgba";
                            return n ? ((t = o[r](n)), (o[g[r].cache] = t[g[r].cache]), (d = o._rgba = t._rgba), !1) : void 0;
                        }),
                        d.length ? ("0,0,0,0" === d.join() && c.extend(d, l.transparent), o) : l[s]
                    );
                }
                function d(e, a, t) {
                    return 6 * (t = (t + 1) % 1) < 1 ? e + (a - e) * t * 6 : 2 * t < 1 ? a : 3 * t < 2 ? e + (a - e) * (2 / 3 - t) * 6 : e;
                }
                var l,
                    p = /^([\-+])=\s*(\d+\.?\d*)/,
                    e = [
                        {
                            re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                            parse: function (e) {
                                return [e[1], e[2], e[3], e[4]];
                            },
                        },
                        {
                            re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                            parse: function (e) {
                                return [2.55 * e[1], 2.55 * e[2], 2.55 * e[3], e[4]];
                            },
                        },
                        {
                            re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                            parse: function (e) {
                                return [parseInt(e[1], 16), parseInt(e[2], 16), parseInt(e[3], 16)];
                            },
                        },
                        {
                            re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                            parse: function (e) {
                                return [parseInt(e[1] + e[1], 16), parseInt(e[2] + e[2], 16), parseInt(e[3] + e[3], 16)];
                            },
                        },
                        {
                            re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                            space: "hsla",
                            parse: function (e) {
                                return [e[1], e[2] / 100, e[3] / 100, e[4]];
                            },
                        },
                    ],
                    m = (c.Color = function (e, a, t, i) {
                        return new c.Color.fn.parse(e, a, t, i);
                    }),
                    g = {
                        rgba: { props: { red: { idx: 0, type: "byte" }, green: { idx: 1, type: "byte" }, blue: { idx: 2, type: "byte" } } },
                        hsla: { props: { hue: { idx: 0, type: "degrees" }, saturation: { idx: 1, type: "percent" }, lightness: { idx: 2, type: "percent" } } },
                    },
                    f = { byte: { floor: !0, max: 255 }, percent: { max: 1 }, degrees: { mod: 360, floor: !0 } },
                    s = (m.support = {}),
                    a = c("<p>")[0],
                    I = c.each;
                (a.style.cssText = "background-color:rgba(1,1,1,.5)"),
                    (s.rgba = -1 < a.style.backgroundColor.indexOf("rgba")),
                    I(g, function (e, a) {
                        (a.cache = "_" + e), (a.props.alpha = { idx: 3, type: "percent", def: 1 });
                    }),
                    (m.fn = c.extend(m.prototype, {
                        parse: function (n, e, a, t) {
                            if (n === u) return (this._rgba = [null, null, null, null]), this;
                            (n.jquery || n.nodeType) && ((n = c(n).css(e)), (e = u));
                            var r = this,
                                i = c.type(n),
                                s = (this._rgba = []);
                            return (
                                e !== u && ((n = [n, e, a, t]), (i = "array")),
                                "string" === i
                                    ? this.parse(o(n) || l._default)
                                    : "array" === i
                                    ? (I(g.rgba.props, function (e, a) {
                                          s[a.idx] = h(n[a.idx], a);
                                      }),
                                      this)
                                    : "object" === i
                                    ? (I(
                                          g,
                                          n instanceof m
                                              ? function (e, a) {
                                                    n[a.cache] && (r[a.cache] = n[a.cache].slice());
                                                }
                                              : function (e, t) {
                                                    var i = t.cache;
                                                    I(t.props, function (e, a) {
                                                        if (!r[i] && t.to) {
                                                            if ("alpha" === e || null == n[e]) return;
                                                            r[i] = t.to(r._rgba);
                                                        }
                                                        r[i][a.idx] = h(n[e], a, !0);
                                                    }),
                                                        r[i] && c.inArray(null, r[i].slice(0, 3)) < 0 && ((r[i][3] = 1), t.from && (r._rgba = t.from(r[i])));
                                                }
                                      ),
                                      this)
                                    : void 0
                            );
                        },
                        is: function (e) {
                            var n = m(e),
                                r = !0,
                                s = this;
                            return (
                                I(g, function (e, a) {
                                    var t,
                                        i = n[a.cache];
                                    return (
                                        i &&
                                            ((t = s[a.cache] || (a.to && a.to(s._rgba)) || []),
                                            I(a.props, function (e, a) {
                                                return null != i[a.idx] ? (r = i[a.idx] === t[a.idx]) : void 0;
                                            })),
                                        r
                                    );
                                }),
                                r
                            );
                        },
                        _space: function () {
                            var t = [],
                                i = this;
                            return (
                                I(g, function (e, a) {
                                    i[a.cache] && t.push(e);
                                }),
                                t.pop()
                            );
                        },
                        transition: function (e, s) {
                            var o = m(e),
                                a = o._space(),
                                t = g[a],
                                i = 0 === this.alpha() ? m("transparent") : this,
                                d = i[t.cache] || t.to(i._rgba),
                                l = d.slice();
                            return (
                                (o = o[t.cache]),
                                I(t.props, function (e, a) {
                                    var t = a.idx,
                                        i = d[t],
                                        n = o[t],
                                        r = f[a.type] || {};
                                    null !== n && (null === i ? (l[t] = n) : (r.mod && (n - i > r.mod / 2 ? (i += r.mod) : i - n > r.mod / 2 && (i -= r.mod)), (l[t] = h((n - i) * s + i, a))));
                                }),
                                this[a](l)
                            );
                        },
                        blend: function (e) {
                            if (1 === this._rgba[3]) return this;
                            var a = this._rgba.slice(),
                                t = a.pop(),
                                i = m(e)._rgba;
                            return m(
                                c.map(a, function (e, a) {
                                    return (1 - t) * i[a] + t * e;
                                })
                            );
                        },
                        toRgbaString: function () {
                            var e = "rgba(",
                                a = c.map(this._rgba, function (e, a) {
                                    return null == e ? (2 < a ? 1 : 0) : e;
                                });
                            return 1 === a[3] && (a.pop(), (e = "rgb(")), e + a.join() + ")";
                        },
                        toHslaString: function () {
                            var e = "hsla(",
                                a = c.map(this.hsla(), function (e, a) {
                                    return null == e && (e = 2 < a ? 1 : 0), a && a < 3 && (e = Math.round(100 * e) + "%"), e;
                                });
                            return 1 === a[3] && (a.pop(), (e = "hsl(")), e + a.join() + ")";
                        },
                        toHexString: function (e) {
                            var a = this._rgba.slice(),
                                t = a.pop();
                            return (
                                e && a.push(~~(255 * t)),
                                "#" +
                                    c
                                        .map(a, function (e) {
                                            return 1 === (e = (e || 0).toString(16)).length ? "0" + e : e;
                                        })
                                        .join("")
                            );
                        },
                        toString: function () {
                            return 0 === this._rgba[3] ? "transparent" : this.toRgbaString();
                        },
                    })),
                    (m.fn.parse.prototype = m.fn),
                    (g.hsla.to = function (e) {
                        if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                        var a,
                            t,
                            i = e[0] / 255,
                            n = e[1] / 255,
                            r = e[2] / 255,
                            s = e[3],
                            o = Math.max(i, n, r),
                            d = Math.min(i, n, r),
                            l = o - d,
                            c = o + d,
                            u = 0.5 * c;
                        return (
                            (a = d === o ? 0 : i === o ? (60 * (n - r)) / l + 360 : n === o ? (60 * (r - i)) / l + 120 : (60 * (i - n)) / l + 240),
                            (t = 0 === l ? 0 : u <= 0.5 ? l / c : l / (2 - c)),
                            [Math.round(a) % 360, t, u, null == s ? 1 : s]
                        );
                    }),
                    (g.hsla.from = function (e) {
                        if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                        var a = e[0] / 360,
                            t = e[1],
                            i = e[2],
                            n = e[3],
                            r = i <= 0.5 ? i * (1 + t) : i + t - i * t,
                            s = 2 * i - r;
                        return [Math.round(255 * d(s, r, a + 1 / 3)), Math.round(255 * d(s, r, a)), Math.round(255 * d(s, r, a - 1 / 3)), n];
                    }),
                    I(g, function (d, e) {
                        var t = e.props,
                            s = e.cache,
                            o = e.to,
                            l = e.from;
                        (m.fn[d] = function (e) {
                            if ((o && !this[s] && (this[s] = o(this._rgba)), e === u)) return this[s].slice();
                            var a,
                                i = c.type(e),
                                n = "array" === i || "object" === i ? e : arguments,
                                r = this[s].slice();
                            return (
                                I(t, function (e, a) {
                                    var t = n["object" === i ? e : a.idx];
                                    null == t && (t = r[a.idx]), (r[a.idx] = h(t, a));
                                }),
                                l ? (((a = m(l(r)))[s] = r), a) : m(r)
                            );
                        }),
                            I(t, function (s, o) {
                                m.fn[s] ||
                                    (m.fn[s] = function (e) {
                                        var a,
                                            t = c.type(e),
                                            i = "alpha" === s ? (this._hsla ? "hsla" : "rgba") : d,
                                            n = this[i](),
                                            r = n[o.idx];
                                        return "undefined" === t
                                            ? r
                                            : ("function" === t && ((e = e.call(this, r)), (t = c.type(e))),
                                              null == e && o.empty ? this : ("string" === t && (a = p.exec(e)) && (e = r + parseFloat(a[2]) * ("+" === a[1] ? 1 : -1)), (n[o.idx] = e), this[i](n)));
                                    });
                            });
                    }),
                    (m.hook = function (e) {
                        var a = e.split(" ");
                        I(a, function (e, r) {
                            (c.cssHooks[r] = {
                                set: function (e, a) {
                                    var t,
                                        i,
                                        n = "";
                                    if ("transparent" !== a && ("string" !== c.type(a) || (t = o(a)))) {
                                        if (((a = m(t || a)), !s.rgba && 1 !== a._rgba[3])) {
                                            for (i = "backgroundColor" === r ? e.parentNode : e; ("" === n || "transparent" === n) && i && i.style; )
                                                try {
                                                    (n = c.css(i, "backgroundColor")), (i = i.parentNode);
                                                } catch (e) {}
                                            a = a.blend(n && "transparent" !== n ? n : "_default");
                                        }
                                        a = a.toRgbaString();
                                    }
                                    try {
                                        e.style[r] = a;
                                    } catch (e) {}
                                },
                            }),
                                (c.fx.step[r] = function (e) {
                                    e.colorInit || ((e.start = m(e.elem, r)), (e.end = m(e.end)), (e.colorInit = !0)), c.cssHooks[r].set(e.elem, e.start.transition(e.end, e.pos));
                                });
                        });
                    }),
                    m.hook("backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor"),
                    (c.cssHooks.borderColor = {
                        expand: function (t) {
                            var i = {};
                            return (
                                I(["Top", "Right", "Bottom", "Left"], function (e, a) {
                                    i["border" + a + "Color"] = t;
                                }),
                                i
                            );
                        },
                    }),
                    (l = c.Color.names = {
                        aqua: "#00ffff",
                        black: "#000000",
                        blue: "#0000ff",
                        fuchsia: "#ff00ff",
                        gray: "#808080",
                        green: "#008000",
                        lime: "#00ff00",
                        maroon: "#800000",
                        navy: "#000080",
                        olive: "#808000",
                        purple: "#800080",
                        red: "#ff0000",
                        silver: "#c0c0c0",
                        teal: "#008080",
                        white: "#ffffff",
                        yellow: "#ffff00",
                        transparent: [null, null, null, 0],
                        _default: "#ffffff",
                    });
            })(g),
            (function () {
                function s(e) {
                    var a,
                        t,
                        i = e.ownerDocument.defaultView ? e.ownerDocument.defaultView.getComputedStyle(e, null) : e.currentStyle,
                        n = {};
                    if (i && i.length && i[0] && i[i[0]]) for (t = i.length; t--; ) "string" == typeof i[(a = i[t])] && (n[M.camelCase(a)] = i[a]);
                    else for (a in i) "string" == typeof i[a] && (n[a] = i[a]);
                    return n;
                }
                var r,
                    n,
                    o,
                    d = ["add", "remove", "toggle"],
                    l = { border: 1, borderBottom: 1, borderColor: 1, borderLeft: 1, borderRight: 1, borderTop: 1, borderWidth: 1, margin: 1, padding: 1 };
                M.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function (e, a) {
                    M.fx.step[a] = function (e) {
                        (("none" !== e.end && !e.setAttr) || (1 === e.pos && !e.setAttr)) && (g.style(e.elem, a, e.end), (e.setAttr = !0));
                    };
                }),
                    M.fn.addBack ||
                        (M.fn.addBack = function (e) {
                            return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
                        }),
                    (M.effects.animateClass = function (n, e, a, t) {
                        var r = M.speed(e, a, t);
                        return this.queue(function () {
                            var e,
                                t = M(this),
                                a = t.attr("class") || "",
                                i = r.children ? t.find("*").addBack() : t;
                            (i = i.map(function () {
                                return { el: M(this), start: s(this) };
                            })),
                                (e = function () {
                                    M.each(d, function (e, a) {
                                        n[a] && t[a + "Class"](n[a]);
                                    });
                                })(),
                                (i = i.map(function () {
                                    return (
                                        (this.end = s(this.el[0])),
                                        (this.diff = (function (e, a) {
                                            var t,
                                                i,
                                                n = {};
                                            for (t in a) (i = a[t]), e[t] !== i && (l[t] || ((M.fx.step[t] || !isNaN(parseFloat(i))) && (n[t] = i)));
                                            return n;
                                        })(this.start, this.end)),
                                        this
                                    );
                                })),
                                t.attr("class", a),
                                (i = i.map(function () {
                                    var e = this,
                                        a = M.Deferred(),
                                        t = M.extend({}, r, {
                                            queue: !1,
                                            complete: function () {
                                                a.resolve(e);
                                            },
                                        });
                                    return this.el.animate(this.diff, t), a.promise();
                                })),
                                M.when.apply(M, i.get()).done(function () {
                                    e(),
                                        M.each(arguments, function () {
                                            var a = this.el;
                                            M.each(this.diff, function (e) {
                                                a.css(e, "");
                                            });
                                        }),
                                        r.complete.call(t[0]);
                                });
                        });
                    }),
                    M.fn.extend({
                        addClass:
                            ((o = M.fn.addClass),
                            function (e, a, t, i) {
                                return a ? M.effects.animateClass.call(this, { add: e }, a, t, i) : o.apply(this, arguments);
                            }),
                        removeClass:
                            ((n = M.fn.removeClass),
                            function (e, a, t, i) {
                                return 1 < arguments.length ? M.effects.animateClass.call(this, { remove: e }, a, t, i) : n.apply(this, arguments);
                            }),
                        toggleClass:
                            ((r = M.fn.toggleClass),
                            function (e, a, t, i, n) {
                                return "boolean" == typeof a || void 0 === a
                                    ? t
                                        ? M.effects.animateClass.call(this, a ? { add: e } : { remove: e }, t, i, n)
                                        : r.apply(this, arguments)
                                    : M.effects.animateClass.call(this, { toggle: e }, a, t, i);
                            }),
                        switchClass: function (e, a, t, i, n) {
                            return M.effects.animateClass.call(this, { add: a, remove: e }, t, i, n);
                        },
                    });
            })(),
            (function () {
                function c(e, a, t, i) {
                    return (
                        M.isPlainObject(e) && (e = (a = e).effect),
                        (e = { effect: e }),
                        null == a && (a = {}),
                        M.isFunction(a) && ((i = a), (t = null), (a = {})),
                        ("number" == typeof a || M.fx.speeds[a]) && ((i = t), (t = a), (a = {})),
                        M.isFunction(t) && ((i = t), (t = null)),
                        a && M.extend(e, a),
                        (t = t || a.duration),
                        (e.duration = M.fx.off ? 0 : "number" == typeof t ? t : t in M.fx.speeds ? M.fx.speeds[t] : M.fx.speeds._default),
                        (e.complete = i || a.complete),
                        e
                    );
                }
                function t(e) {
                    return !(e && "number" != typeof e && !M.fx.speeds[e]) || ("string" == typeof e && !M.effects.effect[e]) || !!M.isFunction(e) || ("object" == typeof e && !e.effect);
                }
                function a(e, a) {
                    var t = a.outerWidth(),
                        i = a.outerHeight(),
                        n = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/.exec(e) || ["", 0, t, i, 0];
                    return { top: parseFloat(n[1]) || 0, right: "auto" === n[2] ? t : parseFloat(n[2]), bottom: "auto" === n[3] ? i : parseFloat(n[3]), left: parseFloat(n[4]) || 0 };
                }
                var i, n, r, s;
                M.expr &&
                    M.expr.filters &&
                    M.expr.filters.animated &&
                    (M.expr.filters.animated =
                        ((s = M.expr.filters.animated),
                        function (e) {
                            return !!M(e).data(m) || s(e);
                        })),
                    !1 !== M.uiBackCompat &&
                        M.extend(M.effects, {
                            save: function (e, a) {
                                for (var t = 0, i = a.length; t < i; t++) null !== a[t] && e.data(h + a[t], e[0].style[a[t]]);
                            },
                            restore: function (e, a) {
                                for (var t, i = 0, n = a.length; i < n; i++) null !== a[i] && ((t = e.data(h + a[i])), e.css(a[i], t));
                            },
                            setMode: function (e, a) {
                                return "toggle" === a && (a = e.is(":hidden") ? "show" : "hide"), a;
                            },
                            createWrapper: function (t) {
                                if (t.parent().is(".ui-effects-wrapper")) return t.parent();
                                var i = { width: t.outerWidth(!0), height: t.outerHeight(!0), float: t.css("float") },
                                    e = M("<div></div>").addClass("ui-effects-wrapper").css({ fontSize: "100%", background: "transparent", border: "none", margin: 0, padding: 0 }),
                                    a = { width: t.width(), height: t.height() },
                                    n = document.activeElement;
                                try {
                                    n.id;
                                } catch (e) {
                                    n = document.body;
                                }
                                return (
                                    t.wrap(e),
                                    (t[0] === n || M.contains(t[0], n)) && M(n).trigger("focus"),
                                    (e = t.parent()),
                                    "static" === t.css("position")
                                        ? (e.css({ position: "relative" }), t.css({ position: "relative" }))
                                        : (M.extend(i, { position: t.css("position"), zIndex: t.css("z-index") }),
                                          M.each(["top", "left", "bottom", "right"], function (e, a) {
                                              (i[a] = t.css(a)), isNaN(parseInt(i[a], 10)) && (i[a] = "auto");
                                          }),
                                          t.css({ position: "relative", top: 0, left: 0, right: "auto", bottom: "auto" })),
                                    t.css(a),
                                    e.css(i).show()
                                );
                            },
                            removeWrapper: function (e) {
                                var a = document.activeElement;
                                return e.parent().is(".ui-effects-wrapper") && (e.parent().replaceWith(e), (e[0] === a || M.contains(e[0], a)) && M(a).trigger("focus")), e;
                            },
                        }),
                    M.extend(M.effects, {
                        version: "1.12.1",
                        define: function (e, a, t) {
                            return t || ((t = a), (a = "effect")), (M.effects.effect[e] = t), (M.effects.effect[e].mode = a), t;
                        },
                        scaledDimensions: function (e, a, t) {
                            if (0 === a) return { height: 0, width: 0, outerHeight: 0, outerWidth: 0 };
                            var i = "horizontal" !== t ? (a || 100) / 100 : 1,
                                n = "vertical" !== t ? (a || 100) / 100 : 1;
                            return { height: e.height() * n, width: e.width() * i, outerHeight: e.outerHeight() * n, outerWidth: e.outerWidth() * i };
                        },
                        clipToBox: function (e) {
                            return { width: e.clip.right - e.clip.left, height: e.clip.bottom - e.clip.top, left: e.clip.left, top: e.clip.top };
                        },
                        unshift: function (e, a, t) {
                            var i = e.queue();
                            1 < a && i.splice.apply(i, [1, 0].concat(i.splice(a, t))), e.dequeue();
                        },
                        saveStyle: function (e) {
                            e.data(p, e[0].style.cssText);
                        },
                        restoreStyle: function (e) {
                            (e[0].style.cssText = e.data(p) || ""), e.removeData(p);
                        },
                        mode: function (e, a) {
                            var t = e.is(":hidden");
                            return "toggle" === a && (a = t ? "show" : "hide"), (t ? "hide" === a : "show" === a) && (a = "none"), a;
                        },
                        getBaseline: function (e, a) {
                            var t, i;
                            switch (e[0]) {
                                case "top":
                                    t = 0;
                                    break;
                                case "middle":
                                    t = 0.5;
                                    break;
                                case "bottom":
                                    t = 1;
                                    break;
                                default:
                                    t = e[0] / a.height;
                            }
                            switch (e[1]) {
                                case "left":
                                    i = 0;
                                    break;
                                case "center":
                                    i = 0.5;
                                    break;
                                case "right":
                                    i = 1;
                                    break;
                                default:
                                    i = e[1] / a.width;
                            }
                            return { x: i, y: t };
                        },
                        createPlaceholder: function (e) {
                            var a,
                                t = e.css("position"),
                                i = e.position();
                            return (
                                e
                                    .css({ marginTop: e.css("marginTop"), marginBottom: e.css("marginBottom"), marginLeft: e.css("marginLeft"), marginRight: e.css("marginRight") })
                                    .outerWidth(e.outerWidth())
                                    .outerHeight(e.outerHeight()),
                                /^(static|relative)/.test(t) &&
                                    ((t = "absolute"),
                                    (a = M("<" + e[0].nodeName + ">")
                                        .insertAfter(e)
                                        .css({
                                            display: /^(inline|ruby)/.test(e.css("display")) ? "inline-block" : "block",
                                            visibility: "hidden",
                                            marginTop: e.css("marginTop"),
                                            marginBottom: e.css("marginBottom"),
                                            marginLeft: e.css("marginLeft"),
                                            marginRight: e.css("marginRight"),
                                            float: e.css("float"),
                                        })
                                        .outerWidth(e.outerWidth())
                                        .outerHeight(e.outerHeight())
                                        .addClass("ui-effects-placeholder")),
                                    e.data(h + "placeholder", a)),
                                e.css({ position: t, left: i.left, top: i.top }),
                                a
                            );
                        },
                        removePlaceholder: function (e) {
                            var a = h + "placeholder",
                                t = e.data(a);
                            t && (t.remove(), e.removeData(a));
                        },
                        cleanUp: function (e) {
                            M.effects.restoreStyle(e), M.effects.removePlaceholder(e);
                        },
                        setTransition: function (i, e, n, r) {
                            return (
                                (r = r || {}),
                                M.each(e, function (e, a) {
                                    var t = i.cssUnit(a);
                                    0 < t[0] && (r[a] = t[0] * n + t[1]);
                                }),
                                r
                            );
                        },
                    }),
                    M.fn.extend({
                        effect: function () {
                            function e(e) {
                                function a() {
                                    M.isFunction(s) && s.call(t[0]), M.isFunction(e) && e();
                                }
                                var t = M(this);
                                (i.mode = d.shift()),
                                    !1 === M.uiBackCompat || r
                                        ? "none" === i.mode
                                            ? (t[o](), a())
                                            : n.call(t[0], i, function () {
                                                  t.removeData(m), M.effects.cleanUp(t), "hide" === i.mode && t.hide(), a();
                                              })
                                        : (t.is(":hidden") ? "hide" === o : "show" === o)
                                        ? (t[o](), a())
                                        : n.call(t[0], i, a);
                            }
                            var i = c.apply(this, arguments),
                                n = M.effects.effect[i.effect],
                                r = n.mode,
                                a = i.queue,
                                t = a || "fx",
                                s = i.complete,
                                o = i.mode,
                                d = [],
                                l = function (e) {
                                    var a = M(this),
                                        t = M.effects.mode(a, o) || r;
                                    a.data(m, !0), d.push(t), r && ("show" === t || (t === r && "hide" === t)) && a.show(), (r && "none" === t) || M.effects.saveStyle(a), M.isFunction(e) && e();
                                };
                            return M.fx.off || !n
                                ? o
                                    ? this[o](i.duration, s)
                                    : this.each(function () {
                                          s && s.call(this);
                                      })
                                : !1 === a
                                ? this.each(l).each(e)
                                : this.queue(t, l).queue(t, e);
                        },
                        show:
                            ((r = M.fn.show),
                            function (e) {
                                if (t(e)) return r.apply(this, arguments);
                                var a = c.apply(this, arguments);
                                return (a.mode = "show"), this.effect.call(this, a);
                            }),
                        hide:
                            ((n = M.fn.hide),
                            function (e) {
                                if (t(e)) return n.apply(this, arguments);
                                var a = c.apply(this, arguments);
                                return (a.mode = "hide"), this.effect.call(this, a);
                            }),
                        toggle:
                            ((i = M.fn.toggle),
                            function (e) {
                                if (t(e) || "boolean" == typeof e) return i.apply(this, arguments);
                                var a = c.apply(this, arguments);
                                return (a.mode = "toggle"), this.effect.call(this, a);
                            }),
                        cssUnit: function (e) {
                            var t = this.css(e),
                                i = [];
                            return (
                                M.each(["em", "px", "%", "pt"], function (e, a) {
                                    0 < t.indexOf(a) && (i = [parseFloat(t), a]);
                                }),
                                i
                            );
                        },
                        cssClip: function (e) {
                            return e ? this.css("clip", "rect(" + e.top + "px " + e.right + "px " + e.bottom + "px " + e.left + "px)") : a(this.css("clip"), this);
                        },
                        transfer: function (e, a) {
                            var t = M(this),
                                i = M(e.to),
                                n = "fixed" === i.css("position"),
                                r = M("body"),
                                s = n ? r.scrollTop() : 0,
                                o = n ? r.scrollLeft() : 0,
                                d = i.offset(),
                                l = { top: d.top - s, left: d.left - o, height: i.innerHeight(), width: i.innerWidth() },
                                c = t.offset(),
                                u = M("<div class='ui-effects-transfer'></div>")
                                    .appendTo("body")
                                    .addClass(e.className)
                                    .css({ top: c.top - s, left: c.left - o, height: t.innerHeight(), width: t.innerWidth(), position: n ? "fixed" : "absolute" })
                                    .animate(l, e.duration, e.easing, function () {
                                        u.remove(), M.isFunction(a) && a();
                                    });
                        },
                    }),
                    (M.fx.step.clip = function (e) {
                        e.clipInit || ((e.start = M(e.elem).cssClip()), "string" == typeof e.end && (e.end = a(e.end, e.elem)), (e.clipInit = !0)),
                            M(e.elem).cssClip({
                                top: e.pos * (e.end.top - e.start.top) + e.start.top,
                                right: e.pos * (e.end.right - e.start.right) + e.start.right,
                                bottom: e.pos * (e.end.bottom - e.start.bottom) + e.start.bottom,
                                left: e.pos * (e.end.left - e.start.left) + e.start.left,
                            });
                    });
            })(),
            (s = {}),
            M.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function (a, e) {
                s[e] = function (e) {
                    return Math.pow(e, a + 2);
                };
            }),
            M.extend(s, {
                Sine: function (e) {
                    return 1 - Math.cos((e * Math.PI) / 2);
                },
                Circ: function (e) {
                    return 1 - Math.sqrt(1 - e * e);
                },
                Elastic: function (e) {
                    return 0 === e || 1 === e ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin(((80 * (e - 1) - 7.5) * Math.PI) / 15);
                },
                Back: function (e) {
                    return e * e * (3 * e - 2);
                },
                Bounce: function (e) {
                    for (var a, t = 4; e < ((a = Math.pow(2, --t)) - 1) / 11; );
                    return 1 / Math.pow(4, 3 - t) - 7.5625 * Math.pow((3 * a - 2) / 22 - e, 2);
                },
            }),
            M.each(s, function (e, a) {
                (M.easing["easeIn" + e] = a),
                    (M.easing["easeOut" + e] = function (e) {
                        return 1 - a(1 - e);
                    }),
                    (M.easing["easeInOut" + e] = function (e) {
                        return e < 0.5 ? a(2 * e) / 2 : 1 - a(-2 * e + 2) / 2;
                    });
            }),
            M.effects,
            M.effects.define("blind", "hide", function (e, a) {
                var t = { up: ["bottom", "top"], vertical: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], horizontal: ["right", "left"], right: ["left", "right"] },
                    i = M(this),
                    n = e.direction || "up",
                    r = i.cssClip(),
                    s = { clip: M.extend({}, r) },
                    o = M.effects.createPlaceholder(i);
                (s.clip[t[n][0]] = s.clip[t[n][1]]),
                    "show" === e.mode && (i.cssClip(s.clip), o && o.css(M.effects.clipToBox(s)), (s.clip = r)),
                    o && o.animate(M.effects.clipToBox(s), e.duration, e.easing),
                    i.animate(s, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            M.effects.define("bounce", function (e, a) {
                var t,
                    i,
                    n,
                    r = M(this),
                    s = e.mode,
                    o = "hide" === s,
                    d = "show" === s,
                    l = e.direction || "up",
                    c = e.distance,
                    u = e.times || 5,
                    h = 2 * u + (d || o ? 1 : 0),
                    p = e.duration / h,
                    m = e.easing,
                    g = "up" === l || "down" === l ? "top" : "left",
                    f = "up" === l || "left" === l,
                    I = 0,
                    v = r.queue().length;
                for (
                    M.effects.createPlaceholder(r),
                        n = r.css(g),
                        c || (c = r["top" === g ? "outerHeight" : "outerWidth"]() / 3),
                        d &&
                            (((i = { opacity: 1 })[g] = n),
                            r
                                .css("opacity", 0)
                                .css(g, f ? 2 * -c : 2 * c)
                                .animate(i, p, m)),
                        o && (c /= Math.pow(2, u - 1)),
                        (i = {})[g] = n;
                    I < u;
                    I++
                )
                    ((t = {})[g] = (f ? "-=" : "+=") + c), r.animate(t, p, m).animate(i, p, m), (c = o ? 2 * c : c / 2);
                o && (((t = { opacity: 0 })[g] = (f ? "-=" : "+=") + c), r.animate(t, p, m)), r.queue(a), M.effects.unshift(r, v, h + 1);
            }),
            M.effects.define("clip", "hide", function (e, a) {
                var t,
                    i = {},
                    n = M(this),
                    r = e.direction || "vertical",
                    s = "both" === r,
                    o = s || "horizontal" === r,
                    d = s || "vertical" === r;
                (t = n.cssClip()),
                    (i.clip = { top: d ? (t.bottom - t.top) / 2 : t.top, right: o ? (t.right - t.left) / 2 : t.right, bottom: d ? (t.bottom - t.top) / 2 : t.bottom, left: o ? (t.right - t.left) / 2 : t.left }),
                    M.effects.createPlaceholder(n),
                    "show" === e.mode && (n.cssClip(i.clip), (i.clip = t)),
                    n.animate(i, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            M.effects.define("drop", "hide", function (e, a) {
                var t,
                    i = M(this),
                    n = "show" === e.mode,
                    r = e.direction || "left",
                    s = "up" === r || "down" === r ? "top" : "left",
                    o = "up" === r || "left" === r ? "-=" : "+=",
                    d = "+=" === o ? "-=" : "+=",
                    l = { opacity: 0 };
                M.effects.createPlaceholder(i),
                    (t = e.distance || i["top" === s ? "outerHeight" : "outerWidth"](!0) / 2),
                    (l[s] = o + t),
                    n && (i.css(l), (l[s] = d + t), (l.opacity = 1)),
                    i.animate(l, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            M.effects.define("explode", "hide", function (e, a) {
                function t() {
                    f.push(this), f.length === l * c && (u.css({ visibility: "visible" }), M(f).remove(), a());
                }
                var i,
                    n,
                    r,
                    s,
                    o,
                    d,
                    l = e.pieces ? Math.round(Math.sqrt(e.pieces)) : 3,
                    c = l,
                    u = M(this),
                    h = "show" === e.mode,
                    p = u.show().css("visibility", "hidden").offset(),
                    m = Math.ceil(u.outerWidth() / c),
                    g = Math.ceil(u.outerHeight() / l),
                    f = [];
                for (i = 0; i < l; i++)
                    for (s = p.top + i * g, d = i - (l - 1) / 2, n = 0; n < c; n++)
                        (r = p.left + n * m),
                            (o = n - (c - 1) / 2),
                            u
                                .clone()
                                .appendTo("body")
                                .wrap("<div></div>")
                                .css({ position: "absolute", visibility: "visible", left: -n * m, top: -i * g })
                                .parent()
                                .addClass("ui-effects-explode")
                                .css({ position: "absolute", overflow: "hidden", width: m, height: g, left: r + (h ? o * m : 0), top: s + (h ? d * g : 0), opacity: h ? 0 : 1 })
                                .animate({ left: r + (h ? 0 : o * m), top: s + (h ? 0 : d * g), opacity: h ? 1 : 0 }, e.duration || 500, e.easing, t);
            }),
            M.effects.define("fade", "toggle", function (e, a) {
                var t = "show" === e.mode;
                M(this)
                    .css("opacity", t ? 0 : 1)
                    .animate({ opacity: t ? 1 : 0 }, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            M.effects.define("fold", "hide", function (a, e) {
                var t = M(this),
                    i = a.mode,
                    n = "show" === i,
                    r = "hide" === i,
                    s = a.size || 15,
                    o = /([0-9]+)%/.exec(s),
                    d = a.horizFirst ? ["right", "bottom"] : ["bottom", "right"],
                    l = a.duration / 2,
                    c = M.effects.createPlaceholder(t),
                    u = t.cssClip(),
                    h = { clip: M.extend({}, u) },
                    p = { clip: M.extend({}, u) },
                    m = [u[d[0]], u[d[1]]],
                    g = t.queue().length;
                o && (s = (parseInt(o[1], 10) / 100) * m[r ? 0 : 1]),
                    (h.clip[d[0]] = s),
                    (p.clip[d[0]] = s),
                    (p.clip[d[1]] = 0),
                    n && (t.cssClip(p.clip), c && c.css(M.effects.clipToBox(p)), (p.clip = u)),
                    t
                        .queue(function (e) {
                            c && c.animate(M.effects.clipToBox(h), l, a.easing).animate(M.effects.clipToBox(p), l, a.easing), e();
                        })
                        .animate(h, l, a.easing)
                        .animate(p, l, a.easing)
                        .queue(e),
                    M.effects.unshift(t, g, 4);
            }),
            M.effects.define("highlight", "show", function (e, a) {
                var t = M(this),
                    i = { backgroundColor: t.css("backgroundColor") };
                "hide" === e.mode && (i.opacity = 0), M.effects.saveStyle(t), t.css({ backgroundImage: "none", backgroundColor: e.color || "#ffff99" }).animate(i, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            M.effects.define("size", function (n, a) {
                var e,
                    r,
                    t,
                    i = M(this),
                    s = ["fontSize"],
                    o = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
                    d = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
                    l = n.mode,
                    c = "effect" !== l,
                    u = n.scale || "both",
                    h = n.origin || ["middle", "center"],
                    p = i.css("position"),
                    m = i.position(),
                    g = M.effects.scaledDimensions(i),
                    f = n.from || g,
                    I = n.to || M.effects.scaledDimensions(i, 0);
                M.effects.createPlaceholder(i),
                    "show" === l && ((t = f), (f = I), (I = t)),
                    (r = { from: { y: f.height / g.height, x: f.width / g.width }, to: { y: I.height / g.height, x: I.width / g.width } }),
                    ("box" === u || "both" === u) &&
                        (r.from.y !== r.to.y && ((f = M.effects.setTransition(i, o, r.from.y, f)), (I = M.effects.setTransition(i, o, r.to.y, I))),
                        r.from.x !== r.to.x && ((f = M.effects.setTransition(i, d, r.from.x, f)), (I = M.effects.setTransition(i, d, r.to.x, I)))),
                    ("content" === u || "both" === u) && r.from.y !== r.to.y && ((f = M.effects.setTransition(i, s, r.from.y, f)), (I = M.effects.setTransition(i, s, r.to.y, I))),
                    h &&
                        ((e = M.effects.getBaseline(h, g)),
                        (f.top = (g.outerHeight - f.outerHeight) * e.y + m.top),
                        (f.left = (g.outerWidth - f.outerWidth) * e.x + m.left),
                        (I.top = (g.outerHeight - I.outerHeight) * e.y + m.top),
                        (I.left = (g.outerWidth - I.outerWidth) * e.x + m.left)),
                    i.css(f),
                    ("content" === u || "both" === u) &&
                        ((o = o.concat(["marginTop", "marginBottom"]).concat(s)),
                        (d = d.concat(["marginLeft", "marginRight"])),
                        i.find("*[width]").each(function () {
                            var e = M(this),
                                a = M.effects.scaledDimensions(e),
                                t = { height: a.height * r.from.y, width: a.width * r.from.x, outerHeight: a.outerHeight * r.from.y, outerWidth: a.outerWidth * r.from.x },
                                i = { height: a.height * r.to.y, width: a.width * r.to.x, outerHeight: a.height * r.to.y, outerWidth: a.width * r.to.x };
                            r.from.y !== r.to.y && ((t = M.effects.setTransition(e, o, r.from.y, t)), (i = M.effects.setTransition(e, o, r.to.y, i))),
                                r.from.x !== r.to.x && ((t = M.effects.setTransition(e, d, r.from.x, t)), (i = M.effects.setTransition(e, d, r.to.x, i))),
                                c && M.effects.saveStyle(e),
                                e.css(t),
                                e.animate(i, n.duration, n.easing, function () {
                                    c && M.effects.restoreStyle(e);
                                });
                        })),
                    i.animate(I, {
                        queue: !1,
                        duration: n.duration,
                        easing: n.easing,
                        complete: function () {
                            var e = i.offset();
                            0 === I.opacity && i.css("opacity", f.opacity), c || (i.css("position", "static" === p ? "relative" : p).offset(e), M.effects.saveStyle(i)), a();
                        },
                    });
            }),
            M.effects.define("scale", function (e, a) {
                var t = M(this),
                    i = e.mode,
                    n = parseInt(e.percent, 10) || (0 === parseInt(e.percent, 10) ? 0 : "effect" !== i ? 0 : 100),
                    r = M.extend(!0, { from: M.effects.scaledDimensions(t), to: M.effects.scaledDimensions(t, n, e.direction || "both"), origin: e.origin || ["middle", "center"] }, e);
                e.fade && ((r.from.opacity = 1), (r.to.opacity = 0)), M.effects.effect.size.call(this, r, a);
            }),
            M.effects.define("puff", "hide", function (e, a) {
                var t = M.extend(!0, {}, e, { fade: !0, percent: parseInt(e.percent, 10) || 150 });
                M.effects.effect.scale.call(this, t, a);
            }),
            M.effects.define("pulsate", "show", function (e, a) {
                var t = M(this),
                    i = e.mode,
                    n = "show" === i,
                    r = n || "hide" === i,
                    s = 2 * (e.times || 5) + (r ? 1 : 0),
                    o = e.duration / s,
                    d = 0,
                    l = 1,
                    c = t.queue().length;
                for ((n || !t.is(":visible")) && (t.css("opacity", 0).show(), (d = 1)); l < s; l++) t.animate({ opacity: d }, o, e.easing), (d = 1 - d);
                t.animate({ opacity: d }, o, e.easing), t.queue(a), M.effects.unshift(t, c, s + 1);
            }),
            M.effects.define("shake", function (e, a) {
                var t = 1,
                    i = M(this),
                    n = e.direction || "left",
                    r = e.distance || 20,
                    s = e.times || 3,
                    o = 2 * s + 1,
                    d = Math.round(e.duration / o),
                    l = "up" === n || "down" === n ? "top" : "left",
                    c = "up" === n || "left" === n,
                    u = {},
                    h = {},
                    p = {},
                    m = i.queue().length;
                for (M.effects.createPlaceholder(i), u[l] = (c ? "-=" : "+=") + r, h[l] = (c ? "+=" : "-=") + 2 * r, p[l] = (c ? "-=" : "+=") + 2 * r, i.animate(u, d, e.easing); t < s; t++) i.animate(h, d, e.easing).animate(p, d, e.easing);
                i
                    .animate(h, d, e.easing)
                    .animate(u, d / 2, e.easing)
                    .queue(a),
                    M.effects.unshift(i, m, o + 1);
            }),
            M.effects.define("slide", "show", function (e, a) {
                var t,
                    i,
                    n = M(this),
                    r = { up: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], right: ["left", "right"] },
                    s = e.mode,
                    o = e.direction || "left",
                    d = "up" === o || "down" === o ? "top" : "left",
                    l = "up" === o || "left" === o,
                    c = e.distance || n["top" === d ? "outerHeight" : "outerWidth"](!0),
                    u = {};
                M.effects.createPlaceholder(n),
                    (t = n.cssClip()),
                    (i = n.position()[d]),
                    (u[d] = (l ? -1 : 1) * c + i),
                    (u.clip = n.cssClip()),
                    (u.clip[r[o][1]] = u.clip[r[o][0]]),
                    "show" === s && (n.cssClip(u.clip), n.css(d, u[d]), (u.clip = t), (u[d] = i)),
                    n.animate(u, { queue: !1, duration: e.duration, easing: e.easing, complete: a });
            }),
            !1 !== M.uiBackCompat &&
                M.effects.define("transfer", function (e, a) {
                    M(this).transfer(e, a);
                }),
            (M.ui.focusable = function (e, a) {
                var t,
                    i,
                    n,
                    r,
                    s,
                    o = e.nodeName.toLowerCase();
                return "area" === o
                    ? ((i = (t = e.parentNode).name), !(!e.href || !i || "map" !== t.nodeName.toLowerCase()) && 0 < (n = M("img[usemap='#" + i + "']")).length && n.is(":visible"))
                    : (/^(input|select|textarea|button|object)$/.test(o) ? (r = !e.disabled) && (s = M(e).closest("fieldset")[0]) && (r = !s.disabled) : (r = ("a" === o && e.href) || a),
                      r &&
                          M(e).is(":visible") &&
                          (function (e) {
                              for (var a = e.css("visibility"); "inherit" === a; ) a = (e = e.parent()).css("visibility");
                              return "hidden" !== a;
                          })(M(e)));
            }),
            M.extend(M.expr[":"], {
                focusable: function (e) {
                    return M.ui.focusable(e, null != M.attr(e, "tabindex"));
                },
            }),
            M.ui.focusable,
            (M.fn.form = function () {
                return "string" == typeof this[0].form ? this.closest("form") : M(this[0].form);
            }),
            (M.ui.formResetMixin = {
                _formResetHandler: function () {
                    var a = M(this);
                    setTimeout(function () {
                        var e = a.data("ui-form-reset-instances");
                        M.each(e, function () {
                            this.refresh();
                        });
                    });
                },
                _bindFormResetHandler: function () {
                    if (((this.form = this.element.form()), this.form.length)) {
                        var e = this.form.data("ui-form-reset-instances") || [];
                        e.length || this.form.on("reset.ui-form-reset", this._formResetHandler), e.push(this), this.form.data("ui-form-reset-instances", e);
                    }
                },
                _unbindFormResetHandler: function () {
                    if (this.form.length) {
                        var e = this.form.data("ui-form-reset-instances");
                        e.splice(M.inArray(this, e), 1), e.length ? this.form.data("ui-form-reset-instances", e) : this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset");
                    }
                },
            }),
            "1.7" === M.fn.jquery.substring(0, 3) &&
                (M.each(["Width", "Height"], function (e, t) {
                    function i(e, a, t, i) {
                        return (
                            M.each(n, function () {
                                (a -= parseFloat(M.css(e, "padding" + this)) || 0), t && (a -= parseFloat(M.css(e, "border" + this + "Width")) || 0), i && (a -= parseFloat(M.css(e, "margin" + this)) || 0);
                            }),
                            a
                        );
                    }
                    var n = "Width" === t ? ["Left", "Right"] : ["Top", "Bottom"],
                        r = t.toLowerCase(),
                        s = { innerWidth: M.fn.innerWidth, innerHeight: M.fn.innerHeight, outerWidth: M.fn.outerWidth, outerHeight: M.fn.outerHeight };
                    (M.fn["inner" + t] = function (e) {
                        return void 0 === e
                            ? s["inner" + t].call(this)
                            : this.each(function () {
                                  M(this).css(r, i(this, e) + "px");
                              });
                    }),
                        (M.fn["outer" + t] = function (e, a) {
                            return "number" != typeof e
                                ? s["outer" + t].call(this, e)
                                : this.each(function () {
                                      M(this).css(r, i(this, e, !0, a) + "px");
                                  });
                        });
                }),
                (M.fn.addBack = function (e) {
                    return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
                })),
            (M.ui.keyCode = { BACKSPACE: 8, COMMA: 188, DELETE: 46, DOWN: 40, END: 35, ENTER: 13, ESCAPE: 27, HOME: 36, LEFT: 37, PAGE_DOWN: 34, PAGE_UP: 33, PERIOD: 190, RIGHT: 39, SPACE: 32, TAB: 9, UP: 38 }),
            (M.ui.escapeSelector =
                ((l = /([!"#$%&'()*+,.\/:;<=>?@[\]^`{|}~])/g),
                function (e) {
                    return e.replace(l, "\\$1");
                })),
            (M.fn.labels = function () {
                var e, a, t, i, n;
                return this[0].labels && this[0].labels.length
                    ? this.pushStack(this[0].labels)
                    : ((i = this.eq(0).parents("label")),
                      (t = this.attr("id")) && ((n = (e = this.eq(0).parents().last()).add(e.length ? e.siblings() : this.siblings())), (a = "label[for='" + M.ui.escapeSelector(t) + "']"), (i = i.add(n.find(a).addBack(a)))),
                      this.pushStack(i));
            }),
            (M.fn.scrollParent = function (e) {
                var a = this.css("position"),
                    t = "absolute" === a,
                    i = e ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                    n = this.parents()
                        .filter(function () {
                            var e = M(this);
                            return (!t || "static" !== e.css("position")) && i.test(e.css("overflow") + e.css("overflow-y") + e.css("overflow-x"));
                        })
                        .eq(0);
                return "fixed" !== a && n.length ? n : M(this[0].ownerDocument || document);
            }),
            M.extend(M.expr[":"], {
                tabbable: function (e) {
                    var a = M.attr(e, "tabindex"),
                        t = null != a;
                    return (!t || 0 <= a) && M.ui.focusable(e, t);
                },
            }),
            M.fn.extend({
                uniqueId:
                    ((d = 0),
                    function () {
                        return this.each(function () {
                            this.id || (this.id = "ui-id-" + ++d);
                        });
                    }),
                removeUniqueId: function () {
                    return this.each(function () {
                        /^ui-id-\d+$/.test(this.id) && M(this).removeAttr("id");
                    });
                },
            }),
            M.widget("ui.accordion", {
                version: "1.12.1",
                options: {
                    active: 0,
                    animate: {},
                    classes: { "ui-accordion-header": "ui-corner-top", "ui-accordion-header-collapsed": "ui-corner-all", "ui-accordion-content": "ui-corner-bottom" },
                    collapsible: !1,
                    event: "click",
                    header: "> li > :first-child, > :not(li):even",
                    heightStyle: "auto",
                    icons: { activeHeader: "ui-icon-triangle-1-s", header: "ui-icon-triangle-1-e" },
                    activate: null,
                    beforeActivate: null,
                },
                hideProps: { borderTopWidth: "hide", borderBottomWidth: "hide", paddingTop: "hide", paddingBottom: "hide", height: "hide" },
                showProps: { borderTopWidth: "show", borderBottomWidth: "show", paddingTop: "show", paddingBottom: "show", height: "show" },
                _create: function () {
                    var e = this.options;
                    (this.prevShow = this.prevHide = M()),
                        this._addClass("ui-accordion", "ui-widget ui-helper-reset"),
                        this.element.attr("role", "tablist"),
                        e.collapsible || (!1 !== e.active && null != e.active) || (e.active = 0),
                        this._processPanels(),
                        e.active < 0 && (e.active += this.headers.length),
                        this._refresh();
                },
                _getCreateEventData: function () {
                    return { header: this.active, panel: this.active.length ? this.active.next() : M() };
                },
                _createIcons: function () {
                    var e,
                        a,
                        t = this.options.icons;
                    t &&
                        ((e = M("<span>")),
                        this._addClass(e, "ui-accordion-header-icon", "ui-icon " + t.header),
                        e.prependTo(this.headers),
                        (a = this.active.children(".ui-accordion-header-icon")),
                        this._removeClass(a, t.header)._addClass(a, null, t.activeHeader)._addClass(this.headers, "ui-accordion-icons"));
                },
                _destroyIcons: function () {
                    this._removeClass(this.headers, "ui-accordion-icons"), this.headers.children(".ui-accordion-header-icon").remove();
                },
                _destroy: function () {
                    var e;
                    this.element.removeAttr("role"),
                        this.headers.removeAttr("role aria-expanded aria-selected aria-controls tabIndex").removeUniqueId(),
                        this._destroyIcons(),
                        (e = this.headers.next().css("display", "").removeAttr("role aria-hidden aria-labelledby").removeUniqueId()),
                        "content" !== this.options.heightStyle && e.css("height", "");
                },
                _setOption: function (e, a) {
                    return "active" === e
                        ? void this._activate(a)
                        : ("event" === e && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(a)),
                          this._super(e, a),
                          "collapsible" !== e || a || !1 !== this.options.active || this._activate(0),
                          void ("icons" === e && (this._destroyIcons(), a && this._createIcons())));
                },
                _setOptionDisabled: function (e) {
                    this._super(e), this.element.attr("aria-disabled", e), this._toggleClass(null, "ui-state-disabled", !!e), this._toggleClass(this.headers.add(this.headers.next()), null, "ui-state-disabled", !!e);
                },
                _keydown: function (e) {
                    if (!e.altKey && !e.ctrlKey) {
                        var a = M.ui.keyCode,
                            t = this.headers.length,
                            i = this.headers.index(e.target),
                            n = !1;
                        switch (e.keyCode) {
                            case a.RIGHT:
                            case a.DOWN:
                                n = this.headers[(i + 1) % t];
                                break;
                            case a.LEFT:
                            case a.UP:
                                n = this.headers[(i - 1 + t) % t];
                                break;
                            case a.SPACE:
                            case a.ENTER:
                                this._eventHandler(e);
                                break;
                            case a.HOME:
                                n = this.headers[0];
                                break;
                            case a.END:
                                n = this.headers[t - 1];
                        }
                        n && (M(e.target).attr("tabIndex", -1), M(n).attr("tabIndex", 0), M(n).trigger("focus"), e.preventDefault());
                    }
                },
                _panelKeyDown: function (e) {
                    e.keyCode === M.ui.keyCode.UP && e.ctrlKey && M(e.currentTarget).prev().trigger("focus");
                },
                refresh: function () {
                    var e = this.options;
                    this._processPanels(),
                        (!1 === e.active && !0 === e.collapsible) || !this.headers.length
                            ? ((e.active = !1), (this.active = M()))
                            : !1 === e.active
                            ? this._activate(0)
                            : this.active.length && !M.contains(this.element[0], this.active[0])
                            ? this.headers.length === this.headers.find(".ui-state-disabled").length
                                ? ((e.active = !1), (this.active = M()))
                                : this._activate(Math.max(0, e.active - 1))
                            : (e.active = this.headers.index(this.active)),
                        this._destroyIcons(),
                        this._refresh();
                },
                _processPanels: function () {
                    var e = this.headers,
                        a = this.panels;
                    (this.headers = this.element.find(this.options.header)),
                        this._addClass(this.headers, "ui-accordion-header ui-accordion-header-collapsed", "ui-state-default"),
                        (this.panels = this.headers.next().filter(":not(.ui-accordion-content-active)").hide()),
                        this._addClass(this.panels, "ui-accordion-content", "ui-helper-reset ui-widget-content"),
                        a && (this._off(e.not(this.headers)), this._off(a.not(this.panels)));
                },
                _refresh: function () {
                    var t,
                        e = this.options,
                        a = e.heightStyle,
                        i = this.element.parent();
                    (this.active = this._findActive(e.active)),
                        this._addClass(this.active, "ui-accordion-header-active", "ui-state-active")._removeClass(this.active, "ui-accordion-header-collapsed"),
                        this._addClass(this.active.next(), "ui-accordion-content-active"),
                        this.active.next().show(),
                        this.headers
                            .attr("role", "tab")
                            .each(function () {
                                var e = M(this),
                                    a = e.uniqueId().attr("id"),
                                    t = e.next(),
                                    i = t.uniqueId().attr("id");
                                e.attr("aria-controls", i), t.attr("aria-labelledby", a);
                            })
                            .next()
                            .attr("role", "tabpanel"),
                        this.headers.not(this.active).attr({ "aria-selected": "false", "aria-expanded": "false", tabIndex: -1 }).next().attr({ "aria-hidden": "true" }).hide(),
                        this.active.length ? this.active.attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 }).next().attr({ "aria-hidden": "false" }) : this.headers.eq(0).attr("tabIndex", 0),
                        this._createIcons(),
                        this._setupEvents(e.event),
                        "fill" === a
                            ? ((t = i.height()),
                              this.element.siblings(":visible").each(function () {
                                  var e = M(this),
                                      a = e.css("position");
                                  "absolute" !== a && "fixed" !== a && (t -= e.outerHeight(!0));
                              }),
                              this.headers.each(function () {
                                  t -= M(this).outerHeight(!0);
                              }),
                              this.headers
                                  .next()
                                  .each(function () {
                                      M(this).height(Math.max(0, t - M(this).innerHeight() + M(this).height()));
                                  })
                                  .css("overflow", "auto"))
                            : "auto" === a &&
                              ((t = 0),
                              this.headers
                                  .next()
                                  .each(function () {
                                      var e = M(this).is(":visible");
                                      e || M(this).show(), (t = Math.max(t, M(this).css("height", "").height())), e || M(this).hide();
                                  })
                                  .height(t));
                },
                _activate: function (e) {
                    var a = this._findActive(e)[0];
                    a !== this.active[0] && ((a = a || this.active[0]), this._eventHandler({ target: a, currentTarget: a, preventDefault: M.noop }));
                },
                _findActive: function (e) {
                    return "number" == typeof e ? this.headers.eq(e) : M();
                },
                _setupEvents: function (e) {
                    var t = { keydown: "_keydown" };
                    e &&
                        M.each(e.split(" "), function (e, a) {
                            t[a] = "_eventHandler";
                        }),
                        this._off(this.headers.add(this.headers.next())),
                        this._on(this.headers, t),
                        this._on(this.headers.next(), { keydown: "_panelKeyDown" }),
                        this._hoverable(this.headers),
                        this._focusable(this.headers);
                },
                _eventHandler: function (e) {
                    var a,
                        t,
                        i = this.options,
                        n = this.active,
                        r = M(e.currentTarget),
                        s = r[0] === n[0],
                        o = s && i.collapsible,
                        d = o ? M() : r.next(),
                        l = { oldHeader: n, oldPanel: n.next(), newHeader: o ? M() : r, newPanel: d };
                    e.preventDefault(),
                        (s && !i.collapsible) ||
                            !1 === this._trigger("beforeActivate", e, l) ||
                            ((i.active = !o && this.headers.index(r)),
                            (this.active = s ? M() : r),
                            this._toggle(l),
                            this._removeClass(n, "ui-accordion-header-active", "ui-state-active"),
                            i.icons && ((a = n.children(".ui-accordion-header-icon")), this._removeClass(a, null, i.icons.activeHeader)._addClass(a, null, i.icons.header)),
                            s ||
                                (this._removeClass(r, "ui-accordion-header-collapsed")._addClass(r, "ui-accordion-header-active", "ui-state-active"),
                                i.icons && ((t = r.children(".ui-accordion-header-icon")), this._removeClass(t, null, i.icons.header)._addClass(t, null, i.icons.activeHeader)),
                                this._addClass(r.next(), "ui-accordion-content-active")));
                },
                _toggle: function (e) {
                    var a = e.newPanel,
                        t = this.prevShow.length ? this.prevShow : e.oldPanel;
                    this.prevShow.add(this.prevHide).stop(!0, !0),
                        (this.prevShow = a),
                        (this.prevHide = t),
                        this.options.animate ? this._animate(a, t, e) : (t.hide(), a.show(), this._toggleComplete(e)),
                        t.attr({ "aria-hidden": "true" }),
                        t.prev().attr({ "aria-selected": "false", "aria-expanded": "false" }),
                        a.length && t.length
                            ? t.prev().attr({ tabIndex: -1, "aria-expanded": "false" })
                            : a.length &&
                              this.headers
                                  .filter(function () {
                                      return 0 === parseInt(M(this).attr("tabIndex"), 10);
                                  })
                                  .attr("tabIndex", -1),
                        a.attr("aria-hidden", "false").prev().attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 });
                },
                _animate: function (e, t, a) {
                    var i,
                        n,
                        r,
                        s = this,
                        o = 0,
                        d = e.css("box-sizing"),
                        l = e.length && (!t.length || e.index() < t.index()),
                        c = this.options.animate || {},
                        u = (l && c.down) || c,
                        h = function () {
                            s._toggleComplete(a);
                        };
                    return (
                        "number" == typeof u && (r = u),
                        "string" == typeof u && (n = u),
                        (n = n || u.easing || c.easing),
                        (r = r || u.duration || c.duration),
                        t.length
                            ? e.length
                                ? ((i = e.show().outerHeight()),
                                  t.animate(this.hideProps, {
                                      duration: r,
                                      easing: n,
                                      step: function (e, a) {
                                          a.now = Math.round(e);
                                      },
                                  }),
                                  void e.hide().animate(this.showProps, {
                                      duration: r,
                                      easing: n,
                                      complete: h,
                                      step: function (e, a) {
                                          (a.now = Math.round(e)), "height" !== a.prop ? "content-box" === d && (o += a.now) : "content" !== s.options.heightStyle && ((a.now = Math.round(i - t.outerHeight() - o)), (o = 0));
                                      },
                                  }))
                                : t.animate(this.hideProps, r, n, h)
                            : e.animate(this.showProps, r, n, h)
                    );
                },
                _toggleComplete: function (e) {
                    var a = e.oldPanel,
                        t = a.prev();
                    this._removeClass(a, "ui-accordion-content-active"),
                        this._removeClass(t, "ui-accordion-header-active")._addClass(t, "ui-accordion-header-collapsed"),
                        a.length && (a.parent()[0].className = a.parent()[0].className),
                        this._trigger("activate", null, e);
                },
            }),
            (M.ui.safeActiveElement = function (a) {
                var t;
                try {
                    t = a.activeElement;
                } catch (e) {
                    t = a.body;
                }
                return t || (t = a.body), t.nodeName || (t = a.body), t;
            }),
            M.widget("ui.menu", {
                version: "1.12.1",
                defaultElement: "<ul>",
                delay: 300,
                options: { icons: { submenu: "ui-icon-caret-1-e" }, items: "> *", menus: "ul", position: { my: "left top", at: "right top" }, role: "menu", blur: null, focus: null, select: null },
                _create: function () {
                    (this.activeMenu = this.element),
                        (this.mouseHandled = !1),
                        this.element.uniqueId().attr({ role: this.options.role, tabIndex: 0 }),
                        this._addClass("ui-menu", "ui-widget ui-widget-content"),
                        this._on({
                            "mousedown .ui-menu-item": function (e) {
                                e.preventDefault();
                            },
                            "click .ui-menu-item": function (e) {
                                var a = M(e.target),
                                    t = M(M.ui.safeActiveElement(this.document[0]));
                                !this.mouseHandled &&
                                    a.not(".ui-state-disabled").length &&
                                    (this.select(e),
                                    e.isPropagationStopped() || (this.mouseHandled = !0),
                                    a.has(".ui-menu").length
                                        ? this.expand(e)
                                        : !this.element.is(":focus") && t.closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer)));
                            },
                            "mouseenter .ui-menu-item": function (e) {
                                if (!this.previousFilter) {
                                    var a = M(e.target).closest(".ui-menu-item"),
                                        t = M(e.currentTarget);
                                    a[0] === t[0] && (this._removeClass(t.siblings().children(".ui-state-active"), null, "ui-state-active"), this.focus(e, t));
                                }
                            },
                            mouseleave: "collapseAll",
                            "mouseleave .ui-menu": "collapseAll",
                            focus: function (e, a) {
                                var t = this.active || this.element.find(this.options.items).eq(0);
                                a || this.focus(e, t);
                            },
                            blur: function (e) {
                                this._delay(function () {
                                    !M.contains(this.element[0], M.ui.safeActiveElement(this.document[0])) && this.collapseAll(e);
                                });
                            },
                            keydown: "_keydown",
                        }),
                        this.refresh(),
                        this._on(this.document, {
                            click: function (e) {
                                this._closeOnDocumentClick(e) && this.collapseAll(e), (this.mouseHandled = !1);
                            },
                        });
                },
                _destroy: function () {
                    var e = this.element.find(".ui-menu-item").removeAttr("role aria-disabled").children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup");
                    this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(),
                        e.children().each(function () {
                            var e = M(this);
                            e.data("ui-menu-submenu-caret") && e.remove();
                        });
                },
                _keydown: function (e) {
                    var a,
                        t,
                        i,
                        n,
                        r = !0;
                    switch (e.keyCode) {
                        case M.ui.keyCode.PAGE_UP:
                            this.previousPage(e);
                            break;
                        case M.ui.keyCode.PAGE_DOWN:
                            this.nextPage(e);
                            break;
                        case M.ui.keyCode.HOME:
                            this._move("first", "first", e);
                            break;
                        case M.ui.keyCode.END:
                            this._move("last", "last", e);
                            break;
                        case M.ui.keyCode.UP:
                            this.previous(e);
                            break;
                        case M.ui.keyCode.DOWN:
                            this.next(e);
                            break;
                        case M.ui.keyCode.LEFT:
                            this.collapse(e);
                            break;
                        case M.ui.keyCode.RIGHT:
                            this.active && !this.active.is(".ui-state-disabled") && this.expand(e);
                            break;
                        case M.ui.keyCode.ENTER:
                        case M.ui.keyCode.SPACE:
                            this._activate(e);
                            break;
                        case M.ui.keyCode.ESCAPE:
                            this.collapse(e);
                            break;
                        default:
                            (r = !1),
                                (t = this.previousFilter || ""),
                                (n = !1),
                                (i = 96 <= e.keyCode && e.keyCode <= 105 ? (e.keyCode - 96).toString() : String.fromCharCode(e.keyCode)),
                                clearTimeout(this.filterTimer),
                                i === t ? (n = !0) : (i = t + i),
                                (a = this._filterMenuItems(i)),
                                (a = n && -1 !== a.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : a).length || ((i = String.fromCharCode(e.keyCode)), (a = this._filterMenuItems(i))),
                                a.length
                                    ? (this.focus(e, a),
                                      (this.previousFilter = i),
                                      (this.filterTimer = this._delay(function () {
                                          delete this.previousFilter;
                                      }, 1e3)))
                                    : delete this.previousFilter;
                    }
                    r && e.preventDefault();
                },
                _activate: function (e) {
                    this.active && !this.active.is(".ui-state-disabled") && (this.active.children("[aria-haspopup='true']").length ? this.expand(e) : this.select(e));
                },
                refresh: function () {
                    var e,
                        a,
                        t,
                        i,
                        n = this,
                        r = this.options.icons.submenu,
                        s = this.element.find(this.options.menus);
                    this._toggleClass("ui-menu-icons", null, !!this.element.find(".ui-icon").length),
                        (a = s
                            .filter(":not(.ui-menu)")
                            .hide()
                            .attr({ role: this.options.role, "aria-hidden": "true", "aria-expanded": "false" })
                            .each(function () {
                                var e = M(this),
                                    a = e.prev(),
                                    t = M("<span>").data("ui-menu-submenu-caret", !0);
                                n._addClass(t, "ui-menu-icon", "ui-icon " + r), a.attr("aria-haspopup", "true").prepend(t), e.attr("aria-labelledby", a.attr("id"));
                            })),
                        this._addClass(a, "ui-menu", "ui-widget ui-widget-content ui-front"),
                        (e = s.add(this.element).find(this.options.items)).not(".ui-menu-item").each(function () {
                            var e = M(this);
                            n._isDivider(e) && n._addClass(e, "ui-menu-divider", "ui-widget-content");
                        }),
                        (i = (t = e.not(".ui-menu-item, .ui-menu-divider")).children().not(".ui-menu").uniqueId().attr({ tabIndex: -1, role: this._itemRole() })),
                        this._addClass(t, "ui-menu-item")._addClass(i, "ui-menu-item-wrapper"),
                        e.filter(".ui-state-disabled").attr("aria-disabled", "true"),
                        this.active && !M.contains(this.element[0], this.active[0]) && this.blur();
                },
                _itemRole: function () {
                    return { menu: "menuitem", listbox: "option" }[this.options.role];
                },
                _setOption: function (e, a) {
                    if ("icons" === e) {
                        var t = this.element.find(".ui-menu-icon");
                        this._removeClass(t, null, this.options.icons.submenu)._addClass(t, null, a.submenu);
                    }
                    this._super(e, a);
                },
                _setOptionDisabled: function (e) {
                    this._super(e), this.element.attr("aria-disabled", String(e)), this._toggleClass(null, "ui-state-disabled", !!e);
                },
                focus: function (e, a) {
                    var t, i, n;
                    this.blur(e, e && "focus" === e.type),
                        this._scrollIntoView(a),
                        (this.active = a.first()),
                        (i = this.active.children(".ui-menu-item-wrapper")),
                        this._addClass(i, null, "ui-state-active"),
                        this.options.role && this.element.attr("aria-activedescendant", i.attr("id")),
                        (n = this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper")),
                        this._addClass(n, null, "ui-state-active"),
                        e && "keydown" === e.type
                            ? this._close()
                            : (this.timer = this._delay(function () {
                                  this._close();
                              }, this.delay)),
                        (t = a.children(".ui-menu")).length && e && /^mouse/.test(e.type) && this._startOpening(t),
                        (this.activeMenu = a.parent()),
                        this._trigger("focus", e, { item: a });
                },
                _scrollIntoView: function (e) {
                    var a, t, i, n, r, s;
                    this._hasScroll() &&
                        ((a = parseFloat(M.css(this.activeMenu[0], "borderTopWidth")) || 0),
                        (t = parseFloat(M.css(this.activeMenu[0], "paddingTop")) || 0),
                        (i = e.offset().top - this.activeMenu.offset().top - a - t),
                        (n = this.activeMenu.scrollTop()),
                        (r = this.activeMenu.height()),
                        (s = e.outerHeight()),
                        i < 0 ? this.activeMenu.scrollTop(n + i) : r < i + s && this.activeMenu.scrollTop(n + i - r + s));
                },
                blur: function (e, a) {
                    a || clearTimeout(this.timer), this.active && (this._removeClass(this.active.children(".ui-menu-item-wrapper"), null, "ui-state-active"), this._trigger("blur", e, { item: this.active }), (this.active = null));
                },
                _startOpening: function (e) {
                    clearTimeout(this.timer),
                        "true" === e.attr("aria-hidden") &&
                            (this.timer = this._delay(function () {
                                this._close(), this._open(e);
                            }, this.delay));
                },
                _open: function (e) {
                    var a = M.extend({ of: this.active }, this.options.position);
                    clearTimeout(this.timer), this.element.find(".ui-menu").not(e.parents(".ui-menu")).hide().attr("aria-hidden", "true"), e.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(a);
                },
                collapseAll: function (a, t) {
                    clearTimeout(this.timer),
                        (this.timer = this._delay(function () {
                            var e = t ? this.element : M(a && a.target).closest(this.element.find(".ui-menu"));
                            e.length || (e = this.element), this._close(e), this.blur(a), this._removeClass(e.find(".ui-state-active"), null, "ui-state-active"), (this.activeMenu = e);
                        }, this.delay));
                },
                _close: function (e) {
                    e || (e = this.active ? this.active.parent() : this.element), e.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false");
                },
                _closeOnDocumentClick: function (e) {
                    return !M(e.target).closest(".ui-menu").length;
                },
                _isDivider: function (e) {
                    return !/[^\-\u2014\u2013\s]/.test(e.text());
                },
                collapse: function (e) {
                    var a = this.active && this.active.parent().closest(".ui-menu-item", this.element);
                    a && a.length && (this._close(), this.focus(e, a));
                },
                expand: function (e) {
                    var a = this.active && this.active.children(".ui-menu ").find(this.options.items).first();
                    a &&
                        a.length &&
                        (this._open(a.parent()),
                        this._delay(function () {
                            this.focus(e, a);
                        }));
                },
                next: function (e) {
                    this._move("next", "first", e);
                },
                previous: function (e) {
                    this._move("prev", "last", e);
                },
                isFirstItem: function () {
                    return this.active && !this.active.prevAll(".ui-menu-item").length;
                },
                isLastItem: function () {
                    return this.active && !this.active.nextAll(".ui-menu-item").length;
                },
                _move: function (e, a, t) {
                    var i;
                    this.active && (i = "first" === e || "last" === e ? this.active["first" === e ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : this.active[e + "All"](".ui-menu-item").eq(0)),
                        (i && i.length && this.active) || (i = this.activeMenu.find(this.options.items)[a]()),
                        this.focus(t, i);
                },
                nextPage: function (e) {
                    var a, t, i;
                    return this.active
                        ? void (
                              this.isLastItem() ||
                              (this._hasScroll()
                                  ? ((t = this.active.offset().top),
                                    (i = this.element.height()),
                                    this.active.nextAll(".ui-menu-item").each(function () {
                                        return (a = M(this)).offset().top - t - i < 0;
                                    }),
                                    this.focus(e, a))
                                  : this.focus(e, this.activeMenu.find(this.options.items)[this.active ? "last" : "first"]()))
                          )
                        : void this.next(e);
                },
                previousPage: function (e) {
                    var a, t, i;
                    return this.active
                        ? void (
                              this.isFirstItem() ||
                              (this._hasScroll()
                                  ? ((t = this.active.offset().top),
                                    (i = this.element.height()),
                                    this.active.prevAll(".ui-menu-item").each(function () {
                                        return 0 < (a = M(this)).offset().top - t + i;
                                    }),
                                    this.focus(e, a))
                                  : this.focus(e, this.activeMenu.find(this.options.items).first()))
                          )
                        : void this.next(e);
                },
                _hasScroll: function () {
                    return this.element.outerHeight() < this.element.prop("scrollHeight");
                },
                select: function (e) {
                    this.active = this.active || M(e.target).closest(".ui-menu-item");
                    var a = { item: this.active };
                    this.active.has(".ui-menu").length || this.collapseAll(e, !0), this._trigger("select", e, a);
                },
                _filterMenuItems: function (e) {
                    var a = e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"),
                        t = new RegExp("^" + a, "i");
                    return this.activeMenu
                        .find(this.options.items)
                        .filter(".ui-menu-item")
                        .filter(function () {
                            return t.test(M.trim(M(this).children(".ui-menu-item-wrapper").text()));
                        });
                },
            }),
            M.extend(M.ui, { datepicker: { version: "1.12.1" } }),
            M.extend(e.prototype, {
                markerClassName: "hasDatepicker",
                maxRows: 4,
                _widgetDatepicker: function () {
                    return this.dpDiv;
                },
                setDefaults: function (e) {
                    return u(this._defaults, e || {}), this;
                },
                _attachDatepicker: function (e, a) {
                    var t, i, n;
                    (i = "div" === (t = e.nodeName.toLowerCase()) || "span" === t),
                        e.id || ((this.uuid += 1), (e.id = "dp" + this.uuid)),
                        ((n = this._newInst(M(e), i)).settings = M.extend({}, a || {})),
                        "input" === t ? this._connectDatepicker(e, n) : i && this._inlineDatepicker(e, n);
                },
                _newInst: function (e, a) {
                    return {
                        id: e[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1"),
                        input: e,
                        selectedDay: 0,
                        selectedMonth: 0,
                        selectedYear: 0,
                        drawMonth: 0,
                        drawYear: 0,
                        inline: a,
                        dpDiv: a ? t(M("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv,
                    };
                },
                _connectDatepicker: function (e, a) {
                    var t = M(e);
                    (a.append = M([])),
                        (a.trigger = M([])),
                        t.hasClass(this.markerClassName) ||
                            (this._attachments(t, a),
                            t.addClass(this.markerClassName).on("keydown", this._doKeyDown).on("keypress", this._doKeyPress).on("keyup", this._doKeyUp),
                            this._autoSize(a),
                            M.data(e, "datepicker", a),
                            a.settings.disabled && this._disableDatepicker(e));
                },
                _attachments: function (e, a) {
                    var t,
                        i,
                        n,
                        r = this._get(a, "appendText"),
                        s = this._get(a, "isRTL");
                    a.append && a.append.remove(),
                        r && ((a.append = M("<span class='" + this._appendClass + "'>" + r + "</span>")), e[s ? "before" : "after"](a.append)),
                        e.off("focus", this._showDatepicker),
                        a.trigger && a.trigger.remove(),
                        ("focus" === (t = this._get(a, "showOn")) || "both" === t) && e.on("focus", this._showDatepicker),
                        ("button" === t || "both" === t) &&
                            ((i = this._get(a, "buttonText")),
                            (n = this._get(a, "buttonImage")),
                            (a.trigger = M(
                                this._get(a, "buttonImageOnly")
                                    ? M("<img/>").addClass(this._triggerClass).attr({ src: n, alt: i, title: i })
                                    : M("<button type='button'></button>")
                                          .addClass(this._triggerClass)
                                          .html(n ? M("<img/>").attr({ src: n, alt: i, title: i }) : i)
                            )),
                            e[s ? "before" : "after"](a.trigger),
                            a.trigger.on("click", function () {
                                return (
                                    M.datepicker._datepickerShowing && M.datepicker._lastInput === e[0]
                                        ? M.datepicker._hideDatepicker()
                                        : (M.datepicker._datepickerShowing && M.datepicker._lastInput !== e[0] && M.datepicker._hideDatepicker(), M.datepicker._showDatepicker(e[0])),
                                    !1
                                );
                            }));
                },
                _autoSize: function (e) {
                    if (this._get(e, "autoSize") && !e.inline) {
                        var a,
                            t,
                            i,
                            n,
                            r = new Date(2009, 11, 20),
                            s = this._get(e, "dateFormat");
                        s.match(/[DM]/) &&
                            ((a = function (e) {
                                for (n = i = t = 0; n < e.length; n++) e[n].length > t && ((t = e[n].length), (i = n));
                                return i;
                            }),
                            r.setMonth(a(this._get(e, s.match(/MM/) ? "monthNames" : "monthNamesShort"))),
                            r.setDate(a(this._get(e, s.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - r.getDay())),
                            e.input.attr("size", this._formatDate(e, r).length);
                    }
                },
                _inlineDatepicker: function (e, a) {
                    var t = M(e);
                    t.hasClass(this.markerClassName) ||
                        (t.addClass(this.markerClassName).append(a.dpDiv),
                        M.data(e, "datepicker", a),
                        this._setDate(a, this._getDefaultDate(a), !0),
                        this._updateDatepicker(a),
                        this._updateAlternate(a),
                        a.settings.disabled && this._disableDatepicker(e),
                        a.dpDiv.css("display", "block"));
                },
                _dialogDatepicker: function (e, a, t, i, n) {
                    var r,
                        s,
                        o,
                        d,
                        l,
                        c = this._dialogInst;
                    return (
                        c ||
                            ((this.uuid += 1),
                            (r = "dp" + this.uuid),
                            (this._dialogInput = M("<input type='text' id='" + r + "' style='position: absolute; top: -100px; width: 0px;'/>")),
                            this._dialogInput.on("keydown", this._doKeyDown),
                            M("body").append(this._dialogInput),
                            ((c = this._dialogInst = this._newInst(this._dialogInput, !1)).settings = {}),
                            M.data(this._dialogInput[0], "datepicker", c)),
                        u(c.settings, i || {}),
                        (a = a && a.constructor === Date ? this._formatDate(c, a) : a),
                        this._dialogInput.val(a),
                        (this._pos = n ? (n.length ? n : [n.pageX, n.pageY]) : null),
                        this._pos ||
                            ((s = document.documentElement.clientWidth),
                            (o = document.documentElement.clientHeight),
                            (d = document.documentElement.scrollLeft || document.body.scrollLeft),
                            (l = document.documentElement.scrollTop || document.body.scrollTop),
                            (this._pos = [s / 2 - 100 + d, o / 2 - 150 + l])),
                        this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"),
                        (c.settings.onSelect = t),
                        (this._inDialog = !0),
                        this.dpDiv.addClass(this._dialogClass),
                        this._showDatepicker(this._dialogInput[0]),
                        M.blockUI && M.blockUI(this.dpDiv),
                        M.data(this._dialogInput[0], "datepicker", c),
                        this
                    );
                },
                _destroyDatepicker: function (e) {
                    var a,
                        t = M(e),
                        i = M.data(e, "datepicker");
                    t.hasClass(this.markerClassName) &&
                        ((a = e.nodeName.toLowerCase()),
                        M.removeData(e, "datepicker"),
                        "input" === a
                            ? (i.append.remove(), i.trigger.remove(), t.removeClass(this.markerClassName).off("focus", this._showDatepicker).off("keydown", this._doKeyDown).off("keypress", this._doKeyPress).off("keyup", this._doKeyUp))
                            : ("div" === a || "span" === a) && t.removeClass(this.markerClassName).empty(),
                        c === i && (c = null));
                },
                _enableDatepicker: function (a) {
                    var e,
                        t,
                        i = M(a),
                        n = M.data(a, "datepicker");
                    i.hasClass(this.markerClassName) &&
                        ("input" === (e = a.nodeName.toLowerCase())
                            ? ((a.disabled = !1),
                              n.trigger
                                  .filter("button")
                                  .each(function () {
                                      this.disabled = !1;
                                  })
                                  .end()
                                  .filter("img")
                                  .css({ opacity: "1.0", cursor: "" }))
                            : ("div" === e || "span" === e) && ((t = i.children("." + this._inlineClass)).children().removeClass("ui-state-disabled"), t.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)),
                        (this._disabledInputs = M.map(this._disabledInputs, function (e) {
                            return e === a ? null : e;
                        })));
                },
                _disableDatepicker: function (a) {
                    var e,
                        t,
                        i = M(a),
                        n = M.data(a, "datepicker");
                    i.hasClass(this.markerClassName) &&
                        ("input" === (e = a.nodeName.toLowerCase())
                            ? ((a.disabled = !0),
                              n.trigger
                                  .filter("button")
                                  .each(function () {
                                      this.disabled = !0;
                                  })
                                  .end()
                                  .filter("img")
                                  .css({ opacity: "0.5", cursor: "default" }))
                            : ("div" === e || "span" === e) && ((t = i.children("." + this._inlineClass)).children().addClass("ui-state-disabled"), t.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)),
                        (this._disabledInputs = M.map(this._disabledInputs, function (e) {
                            return e === a ? null : e;
                        })),
                        (this._disabledInputs[this._disabledInputs.length] = a));
                },
                _isDisabledDatepicker: function (e) {
                    if (!e) return !1;
                    for (var a = 0; a < this._disabledInputs.length; a++) if (this._disabledInputs[a] === e) return !0;
                    return !1;
                },
                _getInst: function (e) {
                    try {
                        return M.data(e, "datepicker");
                    } catch (e) {
                        throw "Missing instance data for this datepicker";
                    }
                },
                _optionDatepicker: function (e, a, t) {
                    var i,
                        n,
                        r,
                        s,
                        o = this._getInst(e);
                    return 2 === arguments.length && "string" == typeof a
                        ? "defaults" === a
                            ? M.extend({}, M.datepicker._defaults)
                            : o
                            ? "all" === a
                                ? M.extend({}, o.settings)
                                : this._get(o, a)
                            : null
                        : ((i = a || {}),
                          "string" == typeof a && ((i = {})[a] = t),
                          void (
                              o &&
                              (this._curInst === o && this._hideDatepicker(),
                              (n = this._getDateDatepicker(e, !0)),
                              (r = this._getMinMaxDate(o, "min")),
                              (s = this._getMinMaxDate(o, "max")),
                              u(o.settings, i),
                              null !== r && void 0 !== i.dateFormat && void 0 === i.minDate && (o.settings.minDate = this._formatDate(o, r)),
                              null !== s && void 0 !== i.dateFormat && void 0 === i.maxDate && (o.settings.maxDate = this._formatDate(o, s)),
                              "disabled" in i && (i.disabled ? this._disableDatepicker(e) : this._enableDatepicker(e)),
                              this._attachments(M(e), o),
                              this._autoSize(o),
                              this._setDate(o, n),
                              this._updateAlternate(o),
                              this._updateDatepicker(o))
                          ));
                },
                _changeDatepicker: function (e, a, t) {
                    this._optionDatepicker(e, a, t);
                },
                _refreshDatepicker: function (e) {
                    var a = this._getInst(e);
                    a && this._updateDatepicker(a);
                },
                _setDateDatepicker: function (e, a) {
                    var t = this._getInst(e);
                    t && (this._setDate(t, a), this._updateDatepicker(t), this._updateAlternate(t));
                },
                _getDateDatepicker: function (e, a) {
                    var t = this._getInst(e);
                    return t && !t.inline && this._setDateFromField(t, a), t ? this._getDate(t) : null;
                },
                _doKeyDown: function (e) {
                    var a,
                        t,
                        i,
                        n = M.datepicker._getInst(e.target),
                        r = !0,
                        s = n.dpDiv.is(".ui-datepicker-rtl");
                    if (((n._keyEvent = !0), M.datepicker._datepickerShowing))
                        switch (e.keyCode) {
                            case 9:
                                M.datepicker._hideDatepicker(), (r = !1);
                                break;
                            case 13:
                                return (
                                    (i = M("td." + M.datepicker._dayOverClass + ":not(." + M.datepicker._currentClass + ")", n.dpDiv))[0] && M.datepicker._selectDay(e.target, n.selectedMonth, n.selectedYear, i[0]),
                                    (a = M.datepicker._get(n, "onSelect")) ? ((t = M.datepicker._formatDate(n)), a.apply(n.input ? n.input[0] : null, [t, n])) : M.datepicker._hideDatepicker(),
                                    !1
                                );
                            case 27:
                                M.datepicker._hideDatepicker();
                                break;
                            case 33:
                                M.datepicker._adjustDate(e.target, e.ctrlKey ? -M.datepicker._get(n, "stepBigMonths") : -M.datepicker._get(n, "stepMonths"), "M");
                                break;
                            case 34:
                                M.datepicker._adjustDate(e.target, e.ctrlKey ? +M.datepicker._get(n, "stepBigMonths") : +M.datepicker._get(n, "stepMonths"), "M");
                                break;
                            case 35:
                                (e.ctrlKey || e.metaKey) && M.datepicker._clearDate(e.target), (r = e.ctrlKey || e.metaKey);
                                break;
                            case 36:
                                (e.ctrlKey || e.metaKey) && M.datepicker._gotoToday(e.target), (r = e.ctrlKey || e.metaKey);
                                break;
                            case 37:
                                (e.ctrlKey || e.metaKey) && M.datepicker._adjustDate(e.target, s ? 1 : -1, "D"),
                                    (r = e.ctrlKey || e.metaKey),
                                    e.originalEvent.altKey && M.datepicker._adjustDate(e.target, e.ctrlKey ? -M.datepicker._get(n, "stepBigMonths") : -M.datepicker._get(n, "stepMonths"), "M");
                                break;
                            case 38:
                                (e.ctrlKey || e.metaKey) && M.datepicker._adjustDate(e.target, -7, "D"), (r = e.ctrlKey || e.metaKey);
                                break;
                            case 39:
                                (e.ctrlKey || e.metaKey) && M.datepicker._adjustDate(e.target, s ? -1 : 1, "D"),
                                    (r = e.ctrlKey || e.metaKey),
                                    e.originalEvent.altKey && M.datepicker._adjustDate(e.target, e.ctrlKey ? +M.datepicker._get(n, "stepBigMonths") : +M.datepicker._get(n, "stepMonths"), "M");
                                break;
                            case 40:
                                (e.ctrlKey || e.metaKey) && M.datepicker._adjustDate(e.target, 7, "D"), (r = e.ctrlKey || e.metaKey);
                                break;
                            default:
                                r = !1;
                        }
                    else 36 === e.keyCode && e.ctrlKey ? M.datepicker._showDatepicker(this) : (r = !1);
                    r && (e.preventDefault(), e.stopPropagation());
                },
                _doKeyPress: function (e) {
                    var a,
                        t,
                        i = M.datepicker._getInst(e.target);
                    return M.datepicker._get(i, "constrainInput")
                        ? ((a = M.datepicker._possibleChars(M.datepicker._get(i, "dateFormat"))), (t = String.fromCharCode(null == e.charCode ? e.keyCode : e.charCode)), e.ctrlKey || e.metaKey || t < " " || !a || -1 < a.indexOf(t))
                        : void 0;
                },
                _doKeyUp: function (e) {
                    var a = M.datepicker._getInst(e.target);
                    if (a.input.val() !== a.lastVal)
                        try {
                            M.datepicker.parseDate(M.datepicker._get(a, "dateFormat"), a.input ? a.input.val() : null, M.datepicker._getFormatConfig(a)) &&
                                (M.datepicker._setDateFromField(a), M.datepicker._updateAlternate(a), M.datepicker._updateDatepicker(a));
                        } catch (e) {}
                    return !0;
                },
                _showDatepicker: function (e) {
                    var a, t, i, n, r, s, o;
                    "input" !== (e = e.target || e).nodeName.toLowerCase() && (e = M("input", e.parentNode)[0]),
                        M.datepicker._isDisabledDatepicker(e) ||
                            M.datepicker._lastInput === e ||
                            ((a = M.datepicker._getInst(e)),
                            M.datepicker._curInst && M.datepicker._curInst !== a && (M.datepicker._curInst.dpDiv.stop(!0, !0), a && M.datepicker._datepickerShowing && M.datepicker._hideDatepicker(M.datepicker._curInst.input[0])),
                            !1 !== (i = (t = M.datepicker._get(a, "beforeShow")) ? t.apply(e, [e, a]) : {}) &&
                                (u(a.settings, i),
                                (a.lastVal = null),
                                (M.datepicker._lastInput = e),
                                M.datepicker._setDateFromField(a),
                                M.datepicker._inDialog && (e.value = ""),
                                M.datepicker._pos || ((M.datepicker._pos = M.datepicker._findPos(e)), (M.datepicker._pos[1] += e.offsetHeight)),
                                (n = !1),
                                M(e)
                                    .parents()
                                    .each(function () {
                                        return !(n |= "fixed" === M(this).css("position"));
                                    }),
                                (r = { left: M.datepicker._pos[0], top: M.datepicker._pos[1] }),
                                (M.datepicker._pos = null),
                                a.dpDiv.empty(),
                                a.dpDiv.css({ position: "absolute", display: "block", top: "-1000px" }),
                                M.datepicker._updateDatepicker(a),
                                (r = M.datepicker._checkOffset(a, r, n)),
                                a.dpDiv.css({ position: M.datepicker._inDialog && M.blockUI ? "static" : n ? "fixed" : "absolute", display: "none", left: r.left + "px", top: r.top + "px" }),
                                a.inline ||
                                    ((s = M.datepicker._get(a, "showAnim")),
                                    (o = M.datepicker._get(a, "duration")),
                                    a.dpDiv.css(
                                        "z-index",
                                        (function (e) {
                                            for (var a, t; e.length && e[0] !== document; ) {
                                                if (("absolute" === (a = e.css("position")) || "relative" === a || "fixed" === a) && ((t = parseInt(e.css("zIndex"), 10)), !isNaN(t) && 0 !== t)) return t;
                                                e = e.parent();
                                            }
                                            return 0;
                                        })(M(e)) + 1
                                    ),
                                    (M.datepicker._datepickerShowing = !0),
                                    M.effects && M.effects.effect[s] ? a.dpDiv.show(s, M.datepicker._get(a, "showOptions"), o) : a.dpDiv[s || "show"](s ? o : null),
                                    M.datepicker._shouldFocusInput(a) && a.input.trigger("focus"),
                                    (M.datepicker._curInst = a))));
                },
                _updateDatepicker: function (e) {
                    (this.maxRows = 4), (c = e).dpDiv.empty().append(this._generateHTML(e)), this._attachHandlers(e);
                    var a,
                        t = this._getNumberOfMonths(e),
                        i = t[1],
                        n = e.dpDiv.find("." + this._dayOverClass + " a");
                    0 < n.length && r.apply(n.get(0)),
                        e.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""),
                        1 < i && e.dpDiv.addClass("ui-datepicker-multi-" + i).css("width", 17 * i + "em"),
                        e.dpDiv[(1 !== t[0] || 1 !== t[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"),
                        e.dpDiv[(this._get(e, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"),
                        e === M.datepicker._curInst && M.datepicker._datepickerShowing && M.datepicker._shouldFocusInput(e) && e.input.trigger("focus"),
                        e.yearshtml &&
                            ((a = e.yearshtml),
                            setTimeout(function () {
                                a === e.yearshtml && e.yearshtml && e.dpDiv.find("select.ui-datepicker-year:first").replaceWith(e.yearshtml), (a = e.yearshtml = null);
                            }, 0));
                },
                _shouldFocusInput: function (e) {
                    return e.input && e.input.is(":visible") && !e.input.is(":disabled") && !e.input.is(":focus");
                },
                _checkOffset: function (e, a, t) {
                    var i = e.dpDiv.outerWidth(),
                        n = e.dpDiv.outerHeight(),
                        r = e.input ? e.input.outerWidth() : 0,
                        s = e.input ? e.input.outerHeight() : 0,
                        o = document.documentElement.clientWidth + (t ? 0 : M(document).scrollLeft()),
                        d = document.documentElement.clientHeight + (t ? 0 : M(document).scrollTop());
                    return (
                        (a.left -= this._get(e, "isRTL") ? i - r : 0),
                        (a.left -= t && a.left === e.input.offset().left ? M(document).scrollLeft() : 0),
                        (a.top -= t && a.top === e.input.offset().top + s ? M(document).scrollTop() : 0),
                        (a.left -= Math.min(a.left, a.left + i > o && i < o ? Math.abs(a.left + i - o) : 0)),
                        (a.top -= Math.min(a.top, a.top + n > d && n < d ? Math.abs(n + s) : 0)),
                        a
                    );
                },
                _findPos: function (e) {
                    for (var a, t = this._getInst(e), i = this._get(t, "isRTL"); e && ("hidden" === e.type || 1 !== e.nodeType || M.expr.filters.hidden(e)); ) e = e[i ? "previousSibling" : "nextSibling"];
                    return [(a = M(e).offset()).left, a.top];
                },
                _hideDatepicker: function (e) {
                    var a,
                        t,
                        i,
                        n,
                        r = this._curInst;
                    !r ||
                        (e && r !== M.data(e, "datepicker")) ||
                        (this._datepickerShowing &&
                            ((a = this._get(r, "showAnim")),
                            (t = this._get(r, "duration")),
                            (i = function () {
                                M.datepicker._tidyDialog(r);
                            }),
                            M.effects && (M.effects.effect[a] || M.effects[a]) ? r.dpDiv.hide(a, M.datepicker._get(r, "showOptions"), t, i) : r.dpDiv["slideDown" === a ? "slideUp" : "fadeIn" === a ? "fadeOut" : "hide"](a ? t : null, i),
                            a || i(),
                            (this._datepickerShowing = !1),
                            (n = this._get(r, "onClose")) && n.apply(r.input ? r.input[0] : null, [r.input ? r.input.val() : "", r]),
                            (this._lastInput = null),
                            this._inDialog && (this._dialogInput.css({ position: "absolute", left: "0", top: "-100px" }), M.blockUI && (M.unblockUI(), M("body").append(this.dpDiv))),
                            (this._inDialog = !1)));
                },
                _tidyDialog: function (e) {
                    e.dpDiv.removeClass(this._dialogClass).off(".ui-datepicker-calendar");
                },
                _checkExternalClick: function (e) {
                    if (M.datepicker._curInst) {
                        var a = M(e.target),
                            t = M.datepicker._getInst(a[0]);
                        ((a[0].id !== M.datepicker._mainDivId &&
                            0 === a.parents("#" + M.datepicker._mainDivId).length &&
                            !a.hasClass(M.datepicker.markerClassName) &&
                            !a.closest("." + M.datepicker._triggerClass).length &&
                            M.datepicker._datepickerShowing &&
                            (!M.datepicker._inDialog || !M.blockUI)) ||
                            (a.hasClass(M.datepicker.markerClassName) && M.datepicker._curInst !== t)) &&
                            M.datepicker._hideDatepicker();
                    }
                },
                _adjustDate: function (e, a, t) {
                    var i = M(e),
                        n = this._getInst(i[0]);
                    this._isDisabledDatepicker(i[0]) || (this._adjustInstDate(n, a + ("M" === t ? this._get(n, "showCurrentAtPos") : 0), t), this._updateDatepicker(n));
                },
                _gotoToday: function (e) {
                    var a,
                        t = M(e),
                        i = this._getInst(t[0]);
                    this._get(i, "gotoCurrent") && i.currentDay
                        ? ((i.selectedDay = i.currentDay), (i.drawMonth = i.selectedMonth = i.currentMonth), (i.drawYear = i.selectedYear = i.currentYear))
                        : ((a = new Date()), (i.selectedDay = a.getDate()), (i.drawMonth = i.selectedMonth = a.getMonth()), (i.drawYear = i.selectedYear = a.getFullYear())),
                        this._notifyChange(i),
                        this._adjustDate(t);
                },
                _selectMonthYear: function (e, a, t) {
                    var i = M(e),
                        n = this._getInst(i[0]);
                    (n["selected" + ("M" === t ? "Month" : "Year")] = n["draw" + ("M" === t ? "Month" : "Year")] = parseInt(a.options[a.selectedIndex].value, 10)), this._notifyChange(n), this._adjustDate(i);
                },
                _selectDay: function (e, a, t, i) {
                    var n,
                        r = M(e);
                    M(i).hasClass(this._unselectableClass) ||
                        this._isDisabledDatepicker(r[0]) ||
                        (((n = this._getInst(r[0])).selectedDay = n.currentDay = M("a", i).html()),
                        (n.selectedMonth = n.currentMonth = a),
                        (n.selectedYear = n.currentYear = t),
                        this._selectDate(e, this._formatDate(n, n.currentDay, n.currentMonth, n.currentYear)));
                },
                _clearDate: function (e) {
                    var a = M(e);
                    this._selectDate(a, "");
                },
                _selectDate: function (e, a) {
                    var t,
                        i = M(e),
                        n = this._getInst(i[0]);
                    (a = null != a ? a : this._formatDate(n)),
                        n.input && n.input.val(a),
                        this._updateAlternate(n),
                        (t = this._get(n, "onSelect")) ? t.apply(n.input ? n.input[0] : null, [a, n]) : n.input && n.input.trigger("change"),
                        n.inline ? this._updateDatepicker(n) : (this._hideDatepicker(), (this._lastInput = n.input[0]), "object" != typeof n.input[0] && n.input.trigger("focus"), (this._lastInput = null));
                },
                _updateAlternate: function (e) {
                    var a,
                        t,
                        i,
                        n = this._get(e, "altField");
                    n && ((a = this._get(e, "altFormat") || this._get(e, "dateFormat")), (t = this._getDate(e)), (i = this.formatDate(a, t, this._getFormatConfig(e))), M(n).val(i));
                },
                noWeekends: function (e) {
                    var a = e.getDay();
                    return [0 < a && a < 6, ""];
                },
                iso8601Week: function (e) {
                    var a,
                        t = new Date(e.getTime());
                    return t.setDate(t.getDate() + 4 - (t.getDay() || 7)), (a = t.getTime()), t.setMonth(0), t.setDate(1), Math.floor(Math.round((a - t) / 864e5) / 7) + 1;
                },
                parseDate: function (t, r, e) {
                    if (null == t || null == r) throw "Invalid arguments";
                    if ("" === (r = "object" == typeof r ? r.toString() : r + "")) return null;
                    var i,
                        a,
                        n,
                        s,
                        o = 0,
                        d = (e ? e.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                        l = "string" != typeof d ? d : (new Date().getFullYear() % 100) + parseInt(d, 10),
                        c = (e ? e.dayNamesShort : null) || this._defaults.dayNamesShort,
                        u = (e ? e.dayNames : null) || this._defaults.dayNames,
                        h = (e ? e.monthNamesShort : null) || this._defaults.monthNamesShort,
                        p = (e ? e.monthNames : null) || this._defaults.monthNames,
                        m = -1,
                        g = -1,
                        f = -1,
                        I = -1,
                        v = !1,
                        y = function (e) {
                            var a = i + 1 < t.length && t.charAt(i + 1) === e;
                            return a && i++, a;
                        },
                        N = function (e) {
                            var a = y(e),
                                t = "@" === e ? 14 : "!" === e ? 20 : "y" === e && a ? 4 : "o" === e ? 3 : 2,
                                i = new RegExp("^\\d{" + ("y" === e ? t : 1) + "," + t + "}"),
                                n = r.substring(o).match(i);
                            if (!n) throw "Missing number at position " + o;
                            return (o += n[0].length), parseInt(n[0], 10);
                        },
                        b = function (e, a, t) {
                            var i = -1,
                                n = M.map(y(e) ? t : a, function (e, a) {
                                    return [[a, e]];
                                }).sort(function (e, a) {
                                    return -(e[1].length - a[1].length);
                                });
                            if (
                                (M.each(n, function (e, a) {
                                    var t = a[1];
                                    return r.substr(o, t.length).toLowerCase() === t.toLowerCase() ? ((i = a[0]), (o += t.length), !1) : void 0;
                                }),
                                -1 !== i)
                            )
                                return i + 1;
                            throw "Unknown name at position " + o;
                        },
                        k = function () {
                            if (r.charAt(o) !== t.charAt(i)) throw "Unexpected literal at position " + o;
                            o++;
                        };
                    for (i = 0; i < t.length; i++)
                        if (v) "'" !== t.charAt(i) || y("'") ? k() : (v = !1);
                        else
                            switch (t.charAt(i)) {
                                case "d":
                                    f = N("d");
                                    break;
                                case "D":
                                    b("D", c, u);
                                    break;
                                case "o":
                                    I = N("o");
                                    break;
                                case "m":
                                    g = N("m");
                                    break;
                                case "M":
                                    g = b("M", h, p);
                                    break;
                                case "y":
                                    m = N("y");
                                    break;
                                case "@":
                                    (m = (s = new Date(N("@"))).getFullYear()), (g = s.getMonth() + 1), (f = s.getDate());
                                    break;
                                case "!":
                                    (m = (s = new Date((N("!") - this._ticksTo1970) / 1e4)).getFullYear()), (g = s.getMonth() + 1), (f = s.getDate());
                                    break;
                                case "'":
                                    y("'") ? k() : (v = !0);
                                    break;
                                default:
                                    k();
                            }
                    if (o < r.length && ((n = r.substr(o)), !/^\s+/.test(n))) throw "Extra/unparsed characters found in date: " + n;
                    if ((-1 === m ? (m = new Date().getFullYear()) : m < 100 && (m += new Date().getFullYear() - (new Date().getFullYear() % 100) + (m <= l ? 0 : -100)), -1 < I))
                        for (g = 1, f = I; !((a = this._getDaysInMonth(m, g - 1)) >= f); ) g++, (f -= a);
                    if ((s = this._daylightSavingAdjust(new Date(m, g - 1, f))).getFullYear() !== m || s.getMonth() + 1 !== g || s.getDate() !== f) throw "Invalid date";
                    return s;
                },
                ATOM: "yy-mm-dd",
                COOKIE: "D, dd M yy",
                ISO_8601: "yy-mm-dd",
                RFC_822: "D, d M y",
                RFC_850: "DD, dd-M-y",
                RFC_1036: "D, d M y",
                RFC_1123: "D, d M yy",
                RFC_2822: "D, d M yy",
                RSS: "D, d M y",
                TICKS: "!",
                TIMESTAMP: "@",
                W3C: "yy-mm-dd",
                _ticksTo1970: 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) * 60 * 60 * 1e7,
                formatDate: function (t, e, a) {
                    if (!e) return "";
                    var i,
                        n = (a ? a.dayNamesShort : null) || this._defaults.dayNamesShort,
                        r = (a ? a.dayNames : null) || this._defaults.dayNames,
                        s = (a ? a.monthNamesShort : null) || this._defaults.monthNamesShort,
                        o = (a ? a.monthNames : null) || this._defaults.monthNames,
                        d = function (e) {
                            var a = i + 1 < t.length && t.charAt(i + 1) === e;
                            return a && i++, a;
                        },
                        l = function (e, a, t) {
                            var i = "" + a;
                            if (d(e)) for (; i.length < t; ) i = "0" + i;
                            return i;
                        },
                        c = function (e, a, t, i) {
                            return d(e) ? i[a] : t[a];
                        },
                        u = "",
                        h = !1;
                    if (e)
                        for (i = 0; i < t.length; i++)
                            if (h) "'" !== t.charAt(i) || d("'") ? (u += t.charAt(i)) : (h = !1);
                            else
                                switch (t.charAt(i)) {
                                    case "d":
                                        u += l("d", e.getDate(), 2);
                                        break;
                                    case "D":
                                        u += c("D", e.getDay(), n, r);
                                        break;
                                    case "o":
                                        u += l("o", Math.round((new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime() - new Date(e.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                                        break;
                                    case "m":
                                        u += l("m", e.getMonth() + 1, 2);
                                        break;
                                    case "M":
                                        u += c("M", e.getMonth(), s, o);
                                        break;
                                    case "y":
                                        u += d("y") ? e.getFullYear() : (e.getFullYear() % 100 < 10 ? "0" : "") + (e.getFullYear() % 100);
                                        break;
                                    case "@":
                                        u += e.getTime();
                                        break;
                                    case "!":
                                        u += 1e4 * e.getTime() + this._ticksTo1970;
                                        break;
                                    case "'":
                                        d("'") ? (u += "'") : (h = !0);
                                        break;
                                    default:
                                        u += t.charAt(i);
                                }
                    return u;
                },
                _possibleChars: function (t) {
                    var i,
                        e = "",
                        a = !1,
                        n = function (e) {
                            var a = i + 1 < t.length && t.charAt(i + 1) === e;
                            return a && i++, a;
                        };
                    for (i = 0; i < t.length; i++)
                        if (a) "'" !== t.charAt(i) || n("'") ? (e += t.charAt(i)) : (a = !1);
                        else
                            switch (t.charAt(i)) {
                                case "d":
                                case "m":
                                case "y":
                                case "@":
                                    e += "0123456789";
                                    break;
                                case "D":
                                case "M":
                                    return null;
                                case "'":
                                    n("'") ? (e += "'") : (a = !0);
                                    break;
                                default:
                                    e += t.charAt(i);
                            }
                    return e;
                },
                _get: function (e, a) {
                    return void 0 !== e.settings[a] ? e.settings[a] : this._defaults[a];
                },
                _setDateFromField: function (e, a) {
                    if (e.input.val() !== e.lastVal) {
                        var t = this._get(e, "dateFormat"),
                            i = (e.lastVal = e.input ? e.input.val() : null),
                            n = this._getDefaultDate(e),
                            r = n,
                            s = this._getFormatConfig(e);
                        try {
                            r = this.parseDate(t, i, s) || n;
                        } catch (e) {
                            i = a ? "" : i;
                        }
                        (e.selectedDay = r.getDate()),
                            (e.drawMonth = e.selectedMonth = r.getMonth()),
                            (e.drawYear = e.selectedYear = r.getFullYear()),
                            (e.currentDay = i ? r.getDate() : 0),
                            (e.currentMonth = i ? r.getMonth() : 0),
                            (e.currentYear = i ? r.getFullYear() : 0),
                            this._adjustInstDate(e);
                    }
                },
                _getDefaultDate: function (e) {
                    return this._restrictMinMax(e, this._determineDate(e, this._get(e, "defaultDate"), new Date()));
                },
                _determineDate: function (o, e, a) {
                    var t,
                        i,
                        n =
                            null == e || "" === e
                                ? a
                                : "string" == typeof e
                                ? (function (e) {
                                      try {
                                          return M.datepicker.parseDate(M.datepicker._get(o, "dateFormat"), e, M.datepicker._getFormatConfig(o));
                                      } catch (e) {}
                                      for (
                                          var a = (e.toLowerCase().match(/^c/) ? M.datepicker._getDate(o) : null) || new Date(),
                                              t = a.getFullYear(),
                                              i = a.getMonth(),
                                              n = a.getDate(),
                                              r = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g,
                                              s = r.exec(e);
                                          s;

                                      ) {
                                          switch (s[2] || "d") {
                                              case "d":
                                              case "D":
                                                  n += parseInt(s[1], 10);
                                                  break;
                                              case "w":
                                              case "W":
                                                  n += 7 * parseInt(s[1], 10);
                                                  break;
                                              case "m":
                                              case "M":
                                                  (i += parseInt(s[1], 10)), (n = Math.min(n, M.datepicker._getDaysInMonth(t, i)));
                                                  break;
                                              case "y":
                                              case "Y":
                                                  (t += parseInt(s[1], 10)), (n = Math.min(n, M.datepicker._getDaysInMonth(t, i)));
                                          }
                                          s = r.exec(e);
                                      }
                                      return new Date(t, i, n);
                                  })(e)
                                : "number" == typeof e
                                ? isNaN(e)
                                    ? a
                                    : ((t = e), (i = new Date()).setDate(i.getDate() + t), i)
                                : new Date(e.getTime());
                    return (n = n && "Invalid Date" === n.toString() ? a : n) && (n.setHours(0), n.setMinutes(0), n.setSeconds(0), n.setMilliseconds(0)), this._daylightSavingAdjust(n);
                },
                _daylightSavingAdjust: function (e) {
                    return e ? (e.setHours(12 < e.getHours() ? e.getHours() + 2 : 0), e) : null;
                },
                _setDate: function (e, a, t) {
                    var i = !a,
                        n = e.selectedMonth,
                        r = e.selectedYear,
                        s = this._restrictMinMax(e, this._determineDate(e, a, new Date()));
                    (e.selectedDay = e.currentDay = s.getDate()),
                        (e.drawMonth = e.selectedMonth = e.currentMonth = s.getMonth()),
                        (e.drawYear = e.selectedYear = e.currentYear = s.getFullYear()),
                        (n === e.selectedMonth && r === e.selectedYear) || t || this._notifyChange(e),
                        this._adjustInstDate(e),
                        e.input && e.input.val(i ? "" : this._formatDate(e));
                },
                _getDate: function (e) {
                    return !e.currentYear || (e.input && "" === e.input.val()) ? null : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
                },
                _attachHandlers: function (e) {
                    var a = this._get(e, "stepMonths"),
                        t = "#" + e.id.replace(/\\\\/g, "\\");
                    e.dpDiv.find("[data-handler]").map(function () {
                        var e = {
                            prev: function () {
                                M.datepicker._adjustDate(t, -a, "M");
                            },
                            next: function () {
                                M.datepicker._adjustDate(t, +a, "M");
                            },
                            hide: function () {
                                M.datepicker._hideDatepicker();
                            },
                            today: function () {
                                M.datepicker._gotoToday(t);
                            },
                            selectDay: function () {
                                return M.datepicker._selectDay(t, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1;
                            },
                            selectMonth: function () {
                                return M.datepicker._selectMonthYear(t, this, "M"), !1;
                            },
                            selectYear: function () {
                                return M.datepicker._selectMonthYear(t, this, "Y"), !1;
                            },
                        };
                        M(this).on(this.getAttribute("data-event"), e[this.getAttribute("data-handler")]);
                    });
                },
                _generateHTML: function (e) {
                    var a,
                        t,
                        i,
                        n,
                        r,
                        s,
                        o,
                        d,
                        l,
                        c,
                        u,
                        h,
                        p,
                        m,
                        g,
                        f,
                        I,
                        v,
                        y,
                        N,
                        b,
                        k,
                        S,
                        _,
                        w,
                        M,
                        A,
                        C,
                        D,
                        E,
                        x,
                        T,
                        B,
                        U,
                        P,
                        K,
                        R,
                        H,
                        O,
                        L = new Date(),
                        F = this._daylightSavingAdjust(new Date(L.getFullYear(), L.getMonth(), L.getDate())),
                        G = this._get(e, "isRTL"),
                        q = this._get(e, "showButtonPanel"),
                        W = this._get(e, "hideIfNoPrevNext"),
                        Y = this._get(e, "navigationAsDateFormat"),
                        j = this._getNumberOfMonths(e),
                        z = this._get(e, "showCurrentAtPos"),
                        $ = this._get(e, "stepMonths"),
                        J = 1 !== j[0] || 1 !== j[1],
                        V = this._daylightSavingAdjust(e.currentDay ? new Date(e.currentYear, e.currentMonth, e.currentDay) : new Date(9999, 9, 9)),
                        Z = this._getMinMaxDate(e, "min"),
                        Q = this._getMinMaxDate(e, "max"),
                        X = e.drawMonth - z,
                        ee = e.drawYear;
                    if ((X < 0 && ((X += 12), ee--), Q))
                        for (a = this._daylightSavingAdjust(new Date(Q.getFullYear(), Q.getMonth() - j[0] * j[1] + 1, Q.getDate())), a = Z && a < Z ? Z : a; this._daylightSavingAdjust(new Date(ee, X, 1)) > a; ) --X < 0 && ((X = 11), ee--);
                    for (
                        e.drawMonth = X,
                            e.drawYear = ee,
                            t = this._get(e, "prevText"),
                            t = Y ? this.formatDate(t, this._daylightSavingAdjust(new Date(ee, X - $, 1)), this._getFormatConfig(e)) : t,
                            i = this._canAdjustMonth(e, -1, ee, X)
                                ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + t + "'><span class='ui-icon ui-icon-circle-triangle-" + (G ? "e" : "w") + "'>" + t + "</span></a>"
                                : W
                                ? ""
                                : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + t + "'><span class='ui-icon ui-icon-circle-triangle-" + (G ? "e" : "w") + "'>" + t + "</span></a>",
                            n = this._get(e, "nextText"),
                            n = Y ? this.formatDate(n, this._daylightSavingAdjust(new Date(ee, X + $, 1)), this._getFormatConfig(e)) : n,
                            r = this._canAdjustMonth(e, 1, ee, X)
                                ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (G ? "w" : "e") + "'>" + n + "</span></a>"
                                : W
                                ? ""
                                : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (G ? "w" : "e") + "'>" + n + "</span></a>",
                            s = this._get(e, "currentText"),
                            o = this._get(e, "gotoCurrent") && e.currentDay ? V : F,
                            s = Y ? this.formatDate(s, o, this._getFormatConfig(e)) : s,
                            d = e.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(e, "closeText") + "</button>",
                            l = q
                                ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" +
                                  (G ? d : "") +
                                  (this._isInRange(e, o) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + s + "</button>" : "") +
                                  (G ? "" : d) +
                                  "</div>"
                                : "",
                            c = parseInt(this._get(e, "firstDay"), 10),
                            c = isNaN(c) ? 0 : c,
                            u = this._get(e, "showWeek"),
                            h = this._get(e, "dayNames"),
                            p = this._get(e, "dayNamesMin"),
                            m = this._get(e, "monthNames"),
                            g = this._get(e, "monthNamesShort"),
                            f = this._get(e, "beforeShowDay"),
                            I = this._get(e, "showOtherMonths"),
                            v = this._get(e, "selectOtherMonths"),
                            y = this._getDefaultDate(e),
                            N = "",
                            k = 0;
                        k < j[0];
                        k++
                    ) {
                        for (S = "", this.maxRows = 4, _ = 0; _ < j[1]; _++) {
                            if (((w = this._daylightSavingAdjust(new Date(ee, X, e.selectedDay))), (M = " ui-corner-all"), (A = ""), J)) {
                                if (((A += "<div class='ui-datepicker-group"), 1 < j[1]))
                                    switch (_) {
                                        case 0:
                                            (A += " ui-datepicker-group-first"), (M = " ui-corner-" + (G ? "right" : "left"));
                                            break;
                                        case j[1] - 1:
                                            (A += " ui-datepicker-group-last"), (M = " ui-corner-" + (G ? "left" : "right"));
                                            break;
                                        default:
                                            (A += " ui-datepicker-group-middle"), (M = "");
                                    }
                                A += "'>";
                            }
                            for (
                                A +=
                                    "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" +
                                    M +
                                    "'>" +
                                    (/all|left/.test(M) && 0 === k ? (G ? r : i) : "") +
                                    (/all|right/.test(M) && 0 === k ? (G ? i : r) : "") +
                                    this._generateMonthYearHeader(e, X, ee, Z, Q, 0 < k || 0 < _, m, g) +
                                    "</div><table class='ui-datepicker-calendar'><thead><tr>",
                                    C = u ? "<th class='ui-datepicker-week-col'>" + this._get(e, "weekHeader") + "</th>" : "",
                                    b = 0;
                                b < 7;
                                b++
                            )
                                C += "<th scope='col'" + (5 <= (b + c + 6) % 7 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + h[(D = (b + c) % 7)] + "'>" + p[D] + "</span></th>";
                            for (
                                A += C + "</tr></thead><tbody>",
                                    E = this._getDaysInMonth(ee, X),
                                    ee === e.selectedYear && X === e.selectedMonth && (e.selectedDay = Math.min(e.selectedDay, E)),
                                    x = (this._getFirstDayOfMonth(ee, X) - c + 7) % 7,
                                    T = Math.ceil((x + E) / 7),
                                    B = J && this.maxRows > T ? this.maxRows : T,
                                    this.maxRows = B,
                                    U = this._daylightSavingAdjust(new Date(ee, X, 1 - x)),
                                    P = 0;
                                P < B;
                                P++
                            ) {
                                for (A += "<tr>", K = u ? "<td class='ui-datepicker-week-col'>" + this._get(e, "calculateWeek")(U) + "</td>" : "", b = 0; b < 7; b++)
                                    (R = f ? f.apply(e.input ? e.input[0] : null, [U]) : [!0, ""]),
                                        (O = ((H = U.getMonth() !== X) && !v) || !R[0] || (Z && U < Z) || (Q && Q < U)),
                                        (K +=
                                            "<td class='" +
                                            (5 <= (b + c + 6) % 7 ? " ui-datepicker-week-end" : "") +
                                            (H ? " ui-datepicker-other-month" : "") +
                                            ((U.getTime() === w.getTime() && X === e.selectedMonth && e._keyEvent) || (y.getTime() === U.getTime() && y.getTime() === w.getTime()) ? " " + this._dayOverClass : "") +
                                            (O ? " " + this._unselectableClass + " ui-state-disabled" : "") +
                                            (H && !I ? "" : " " + R[1] + (U.getTime() === V.getTime() ? " " + this._currentClass : "") + (U.getTime() === F.getTime() ? " ui-datepicker-today" : "")) +
                                            "'" +
                                            ((H && !I) || !R[2] ? "" : " title='" + R[2].replace(/'/g, "&#39;") + "'") +
                                            (O ? "" : " data-handler='selectDay' data-event='click' data-month='" + U.getMonth() + "' data-year='" + U.getFullYear() + "'") +
                                            ">" +
                                            (H && !I
                                                ? "&#xa0;"
                                                : O
                                                ? "<span class='ui-state-default'>" + U.getDate() + "</span>"
                                                : "<a class='ui-state-default" +
                                                  (U.getTime() === F.getTime() ? " ui-state-highlight" : "") +
                                                  (U.getTime() === V.getTime() ? " ui-state-active" : "") +
                                                  (H ? " ui-priority-secondary" : "") +
                                                  "' href='#'>" +
                                                  U.getDate() +
                                                  "</a>") +
                                            "</td>"),
                                        U.setDate(U.getDate() + 1),
                                        (U = this._daylightSavingAdjust(U));
                                A += K + "</tr>";
                            }
                            11 < ++X && ((X = 0), ee++), (S += A += "</tbody></table>" + (J ? "</div>" + (0 < j[0] && _ === j[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : ""));
                        }
                        N += S;
                    }
                    return (N += l), (e._keyEvent = !1), N;
                },
                _generateMonthYearHeader: function (e, a, t, i, n, r, s, o) {
                    var d,
                        l,
                        c,
                        u,
                        h,
                        p,
                        m,
                        g,
                        f = this._get(e, "changeMonth"),
                        I = this._get(e, "changeYear"),
                        v = this._get(e, "showMonthAfterYear"),
                        y = "<div class='ui-datepicker-title'>",
                        N = "";
                    if (r || !f) N += "<span class='ui-datepicker-month'>" + s[a] + "</span>";
                    else {
                        for (d = i && i.getFullYear() === t, l = n && n.getFullYear() === t, N += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", c = 0; c < 12; c++)
                            (!d || c >= i.getMonth()) && (!l || c <= n.getMonth()) && (N += "<option value='" + c + "'" + (c === a ? " selected='selected'" : "") + ">" + o[c] + "</option>");
                        N += "</select>";
                    }
                    if ((v || (y += N + (!r && f && I ? "" : "&#xa0;")), !e.yearshtml))
                        if (((e.yearshtml = ""), r || !I)) y += "<span class='ui-datepicker-year'>" + t + "</span>";
                        else {
                            for (
                                u = this._get(e, "yearRange").split(":"),
                                    h = new Date().getFullYear(),
                                    m = (p = function (e) {
                                        var a = e.match(/c[+\-].*/) ? t + parseInt(e.substring(1), 10) : e.match(/[+\-].*/) ? h + parseInt(e, 10) : parseInt(e, 10);
                                        return isNaN(a) ? h : a;
                                    })(u[0]),
                                    g = Math.max(m, p(u[1] || "")),
                                    m = i ? Math.max(m, i.getFullYear()) : m,
                                    g = n ? Math.min(g, n.getFullYear()) : g,
                                    e.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>";
                                m <= g;
                                m++
                            )
                                e.yearshtml += "<option value='" + m + "'" + (m === t ? " selected='selected'" : "") + ">" + m + "</option>";
                            (e.yearshtml += "</select>"), (y += e.yearshtml), (e.yearshtml = null);
                        }
                    return (y += this._get(e, "yearSuffix")), v && (y += (!r && f && I ? "" : "&#xa0;") + N), y + "</div>";
                },
                _adjustInstDate: function (e, a, t) {
                    var i = e.selectedYear + ("Y" === t ? a : 0),
                        n = e.selectedMonth + ("M" === t ? a : 0),
                        r = Math.min(e.selectedDay, this._getDaysInMonth(i, n)) + ("D" === t ? a : 0),
                        s = this._restrictMinMax(e, this._daylightSavingAdjust(new Date(i, n, r)));
                    (e.selectedDay = s.getDate()), (e.drawMonth = e.selectedMonth = s.getMonth()), (e.drawYear = e.selectedYear = s.getFullYear()), ("M" === t || "Y" === t) && this._notifyChange(e);
                },
                _restrictMinMax: function (e, a) {
                    var t = this._getMinMaxDate(e, "min"),
                        i = this._getMinMaxDate(e, "max"),
                        n = t && a < t ? t : a;
                    return i && i < n ? i : n;
                },
                _notifyChange: function (e) {
                    var a = this._get(e, "onChangeMonthYear");
                    a && a.apply(e.input ? e.input[0] : null, [e.selectedYear, e.selectedMonth + 1, e]);
                },
                _getNumberOfMonths: function (e) {
                    var a = this._get(e, "numberOfMonths");
                    return null == a ? [1, 1] : "number" == typeof a ? [1, a] : a;
                },
                _getMinMaxDate: function (e, a) {
                    return this._determineDate(e, this._get(e, a + "Date"), null);
                },
                _getDaysInMonth: function (e, a) {
                    return 32 - this._daylightSavingAdjust(new Date(e, a, 32)).getDate();
                },
                _getFirstDayOfMonth: function (e, a) {
                    return new Date(e, a, 1).getDay();
                },
                _canAdjustMonth: function (e, a, t, i) {
                    var n = this._getNumberOfMonths(e),
                        r = this._daylightSavingAdjust(new Date(t, i + (a < 0 ? a : n[0] * n[1]), 1));
                    return a < 0 && r.setDate(this._getDaysInMonth(r.getFullYear(), r.getMonth())), this._isInRange(e, r);
                },
                _isInRange: function (e, a) {
                    var t,
                        i,
                        n = this._getMinMaxDate(e, "min"),
                        r = this._getMinMaxDate(e, "max"),
                        s = null,
                        o = null,
                        d = this._get(e, "yearRange");
                    return (
                        d && ((t = d.split(":")), (i = new Date().getFullYear()), (s = parseInt(t[0], 10)), (o = parseInt(t[1], 10)), t[0].match(/[+\-].*/) && (s += i), t[1].match(/[+\-].*/) && (o += i)),
                        (!n || a.getTime() >= n.getTime()) && (!r || a.getTime() <= r.getTime()) && (!s || a.getFullYear() >= s) && (!o || a.getFullYear() <= o)
                    );
                },
                _getFormatConfig: function (e) {
                    var a = this._get(e, "shortYearCutoff");
                    return {
                        shortYearCutoff: (a = "string" != typeof a ? a : (new Date().getFullYear() % 100) + parseInt(a, 10)),
                        dayNamesShort: this._get(e, "dayNamesShort"),
                        dayNames: this._get(e, "dayNames"),
                        monthNamesShort: this._get(e, "monthNamesShort"),
                        monthNames: this._get(e, "monthNames"),
                    };
                },
                _formatDate: function (e, a, t, i) {
                    a || ((e.currentDay = e.selectedDay), (e.currentMonth = e.selectedMonth), (e.currentYear = e.selectedYear));
                    var n = a ? ("object" == typeof a ? a : this._daylightSavingAdjust(new Date(i, t, a))) : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
                    return this.formatDate(this._get(e, "dateFormat"), n, this._getFormatConfig(e));
                },
            }),
            (M.fn.datepicker = function (e) {
                if (!this.length) return this;
                M.datepicker.initialized || (M(document).on("mousedown", M.datepicker._checkExternalClick), (M.datepicker.initialized = !0)), 0 === M("#" + M.datepicker._mainDivId).length && M("body").append(M.datepicker.dpDiv);
                var a = Array.prototype.slice.call(arguments, 1);
                return "string" != typeof e || ("isDisabled" !== e && "getDate" !== e && "widget" !== e)
                    ? "option" === e && 2 === arguments.length && "string" == typeof arguments[1]
                        ? M.datepicker["_" + e + "Datepicker"].apply(M.datepicker, [this[0]].concat(a))
                        : this.each(function () {
                              "string" == typeof e ? M.datepicker["_" + e + "Datepicker"].apply(M.datepicker, [this].concat(a)) : M.datepicker._attachDatepicker(this, e);
                          })
                    : M.datepicker["_" + e + "Datepicker"].apply(M.datepicker, [this[0]].concat(a));
            }),
            (M.datepicker = new e()),
            (M.datepicker.initialized = !1),
            (M.datepicker.uuid = new Date().getTime()),
            (M.datepicker.version = "1.12.1"),
            M.datepicker,
            (M.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()));
    }),
    $(document).ready(function () {
        $(".autoplace").each(function () {
            var r = document.getElementById(this.id);
            new autoComplete({
                selector: r,
                minChars: 1,
                source: function (e, a) {
                    e = e.toLowerCase();
                    var t = [
                            ["Destination", "iso", "Destination"],
                            ["Manali", "IN", "India"],
                            ["Shimla", "IN", "India"],
                            ["Kerala", "IN", "India"],
                            ["Goa", "IN", "India"],
                            ["Munnar", "IN", "India"],
                            ["Kufri", "IN", "India"],
                            ["Thekkady", "IN", "India"],
                            ["Darjeeling", "IN", "India"],
                            ["Ooty", "IN", "India"],
                            ["Cochin", "IN", "India"],
                            ["Alleppey", "IN", "India"],
                            ["Gangtok", "IN", "India"],
                            ["Kullu", "IN", "India"],
                            ["Delhi", "IN", "India"],
                            ["Chandigarh", "IN", "India"],
                            ["Port Blair", "IN", "India"],
                            ["Coonoor", "IN", "India"],
                            ["Nainital", "IN", "India"],
                            ["Mumbai", "IN", "India"],
                            ["Manikaran", "IN", "India"],
                            ["Coorg", "IN", "India"],
                            ["Srinagar", "IN", "India"],
                            ["Sikkim", "IN", "India"],
                            ["Haridwar", "IN", "India"],
                            ["Rishikesh", "IN", "India"],
                            ["Agra", "IN", "India"],
                            ["Jaipur", "IN", "India"],
                            ["Shillong", "IN", "India"],
                            ["Panchgani", "IN", "India"],
                            ["Mysore", "IN", "India"],
                            ["Mahabaleshwar", "IN", "India"],
                            ["Gulmarg", "IN", "India"],
                            ["Katra", "IN", "India"],
                            ["Bangalore", "IN", "India"],
                            ["Guwahati", "IN", "India"],
                            ["Jammu", "IN", "India"],
                            ["Dharamshala", "IN", "India"],
                            ["Kedarnath", "IN", "India"],
                            ["Kasol", "IN", "India"],
                            ["Lonavala", "IN", "India"],
                            ["Pahalgam", "IN", "India"],
                            ["Kolkata", "IN", "India"],
                            ["Dalhousie", "IN", "India"],
                            ["Himachal Pradesh", "IN", "India"],
                            ["Ranikhet", "IN", "India"],
                            ["Hyderabad", "IN", "India"],
                            ["Kodaikanal", "IN", "India"],
                            ["Badrinath", "IN", "India"],
                            ["Udaipur", "IN", "India"],
                            ["Chennai", "IN", "India"],
                            ["Uttarakhand", "IN", "India"],
                            ["Dehradun", "IN", "India"],
                            ["Shirdi", "IN", "India"],
                            ["Rajasthan", "IN", "India"],
                            ["Lansdowne", "IN", "India"],
                            ["Kanyakumari", "IN", "India"],
                            ["Pune", "IN", "India"],
                            ["Lakshadweep", "IN", "India"],
                            ["Amritsar", "IN", "India"],
                            ["Ahmedabad", "IN", "India"],
                            ["Tawang", "IN", "India"],
                            ["Kochi", "IN", "India"],
                            ["Kasauli", "IN", "India"],
                            ["Bengaluru", "IN", "India"],
                            ["Mount Abu", "IN", "India"],
                            ["Kalimpong", "IN", "India"],
                            ["Mcleodganj", "IN", "India"],
                            ["Lakshadweep Islands", "IN", "India"],
                            ["Pelling", "IN", "India"],
                            ["Tirupati", "IN", "India"],
                            ["Matheran", "IN", "India"],
                            ["Varanasi", "IN", "India"],
                            ["Auli", "IN", "India"],
                            ["Madurai", "IN", "India"],
                            ["Kausani", "IN", "India"],
                            ["Ajmer", "IN", "India"],
                            ["Wayanad", "IN", "India"],
                            ["Kaziranga", "IN", "India"],
                            ["Coimbatore", "IN", "India"],
                            ["Pondicherry", "IN", "India"],
                            ["Madikeri", "IN", "India"],
                            ["Visakhapatnam", "IN", "India"],
                            ["Gangotri", "IN", "India"],
                            ["Puri", "IN", "India"],
                            ["Jodhpur", "IN", "India"],
                            ["Puducherry", "IN", "India"],
                            ["Somnath", "IN", "India"],
                            ["Trivandrum", "IN", "India"],
                            ["Lachung", "IN", "India"],
                            ["Khajjiar", "IN", "India"],
                            ["Dwarka", "IN", "India"],
                            ["Aurangabad", "IN", "India"],
                            ["Mathura", "IN", "India"],
                            ["Zuluk", "IN", "India"],
                            ["Nashik", "IN", "India"],
                            ["Kumarakom", "IN", "India"],
                            ["Saputara", "IN", "India"],
                            ["Rameshwaram", "IN", "India"],
                            ["Patnitop", "IN", "India"],
                            ["Gujarat", "IN", "India"],
                            ["Vrindavan", "IN", "India"],
                            ["Srisailam", "IN", "India"],
                            ["Jaisalmer", "IN", "India"],
                            ["Meghalaya", "IN", "India"],
                            ["Yercaud", "IN", "India"],
                            ["Lachen", "IN", "India"],
                            ["Solang Valley", "IN", "India"],
                            ["Bhubaneswar", "IN", "India"],
                            ["Ujjain", "IN", "India"],
                            ["Sangla", "IN", "India"],
                            ["Rameswaram", "IN", "India"],
                            ["Namchi", "IN", "India"],
                            ["Almora", "IN", "India"],
                            ["Nagpur", "IN", "India"],
                            ["Mahabalipuram", "IN", "India"],
                            ["Ratnagiri", "IN", "India"],
                            ["Pushkar", "IN", "India"],
                            ["Nandi Hills", "IN", "India"],
                            ["Shiv Khori", "IN", "India"],
                            ["Assam", "IN", "India"],
                            ["Chopta", "IN", "India"],
                            ["Hampi", "IN", "India"],
                            ["Lavasa", "IN", "India"],
                            ["Gokarna", "IN", "India"],
                            ["Alappuzha", "IN", "India"],
                            ["Arunachal Pradesh", "IN", "India"],
                            ["Dhanaulti", "IN", "India"],
                            ["Bikaner", "IN", "India"],
                            ["Kovalam", "IN", "India"],
                            ["Leh", "IN", "India"],
                            ["Bagdogra", "IN", "India"],
                            ["Ladakh", "IN", "India"],
                            ["Havelock Island", "IN", "India"],
                            ["Corbett", "IN", "India"],
                            ["Andaman And Nicobar Islands", "IN", "India"],
                            ["Kathgodam", "IN", "India"],
                            ["Sonmarg", "IN", "India"],
                            ["Bomdila", "IN", "India"],
                            ["Cherrapunjee", "IN", "India"],
                            ["Cherrapunji", "IN", "India"],
                            ["Rohtang", "IN", "India"],
                            ["Bhalukpong", "IN", "India"],
                            ["Karnataka", "IN", "India"],
                            ["Jammu And Kashmir", "IN", "India"],
                            ["Pachmarhi", "IN", "India"],
                            ["Agatti Island", "IN", "India"],
                            ["Dirang", "IN", "India"],
                            ["Triund", "IN", "India"],
                            ["Lucknow", "IN", "India"],
                            ["Baratang", "IN", "India"],
                            ["Panjim", "IN", "India"],
                            ["Palampur", "IN", "India"],
                            ["Chail", "IN", "India"],
                            ["Yamunotri", "IN", "India"],
                            ["Sillery Gaon", "IN", "India"],
                            ["Naggar", "IN", "India"],
                            ["Tosh", "IN", "India"],
                            ["Maharashtra", "IN", "India"],
                            ["Tamil Nadu", "IN", "India"],
                            ["Aritar", "IN", "India"],
                            ["Reshikhola", "IN", "India"],
                            ["Kalpa", "IN", "India"],
                            ["Dawki", "IN", "India"],
                            ["Sarahan", "IN", "India"],
                            ["Nathang Valley", "IN", "India"],
                            ["Rudraprayag", "IN", "India"],
                            ["Rajkot", "IN", "India"],
                            ["Bhagsunag", "IN", "India"],
                            ["Mawlynnong", "IN", "India"],
                            ["Diu", "IN", "India"],
                            ["Kheerganga", "IN", "India"],
                            ["Rampur", "IN", "India"],
                            ["Kalpeni Island", "IN", "India"],
                            ["Goa Velha", "IN", "India"],
                            ["Patna", "IN", "India"],
                            ["Indore", "IN", "India"],
                            ["Mashobra", "IN", "India"],
                            ["Kavarathi", "IN", "India"],
                            ["Chikmagalur", "IN", "India"],
                            ["North Bay Island", "IN", "India"],
                            ["Joshimath", "IN", "India"],
                            ["Nasik", "IN", "India"],
                            ["Taacharu", "IN", "India"],
                            ["West Bengal", "IN", "India"],
                            ["Vizag", "IN", "India"],
                            ["Varca", "IN", "India"],
                            ["Chamba", "IN", "India"],
                            ["Malvan", "IN", "India"],
                            ["Ramnagar", "IN", "India"],
                            ["Gopalpur", "IN", "India"],
                            ["Binsar", "IN", "India"],
                            ["Sarchu", "IN", "India"],
                            ["Bhopal", "IN", "India"],
                            ["Barkot", "IN", "India"],
                            ["Malana", "IN", "India"],
                            ["Bangaram Island", "IN", "India"],
                            ["Gurgaon", "IN", "India"],
                            ["Bhavnagar", "IN", "India"],
                            ["Mirik", "IN", "India"],
                            ["Calangute", "IN", "India"],
                            ["North Goa", "IN", "India"],
                            ["Brahampur", "IN", "India"],
                            ["Daringbadi", "IN", "India"],
                            ["Jamnagar", "IN", "India"],
                            ["Kangra Valley", "IN", "India"],
                            ["Mysuru", "IN", "India"],
                            ["Kaza", "IN", "India"],
                            ["Udupi", "IN", "India"],
                            ["Siliguri", "IN", "India"],
                            ["Tamabil", "IN", "India"],
                            ["Sandakphu", "IN", "India"],
                            ["Surat", "IN", "India"],
                            ["South Goa", "IN", "India"],
                            ["Devprayag", "IN", "India"],
                            ["Neil Island", "IN", "India"],
                            ["Thane", "IN", "India"],
                            ["Pratapgarh", "IN", "India"],
                            ["Keylong", "IN", "India"],
                            ["Trichy", "IN", "India"],
                            ["Allahabad", "IN", "India"],
                            ["Vadodara", "IN", "India"],
                            ["Nicobar", "IN", "India"],
                            ["Rajgir", "IN", "India"],
                            ["Anjuna", "IN", "India"],
                            ["Baga", "IN", "India"],
                            ["Jabalpur", "IN", "India"],
                            ["Khandala", "IN", "India"],
                            ["Nako", "IN", "India"],
                            ["Phalut", "IN", "India"],
                            ["Uttarkashi", "IN", "India"],
                            ["Amarnath", "IN", "India"],
                            ["Araku Valley", "IN", "India"],
                            ["Alibag", "IN", "India"],
                            ["Noida", "IN", "India"],
                            ["Mangalore", "IN", "India"],
                            ["Bangkok", "TH", "Thailand"],
                            ["Thiruvananthapuram", "IN", "India"],
                            ["Imphal", "IN", "India"],
                            ["Dapoli", "IN", "India"],
                            ["Kibber", "IN", "India"],
                            ["Ganpatipule", "IN", "India"],
                            ["Pratapgad", "IN", "India"],
                            ["Pathankot", "IN", "India"],
                            ["Tuljapur", "IN", "India"],
                            ["Konark", "IN", "India"],
                            ["Tehri", "IN", "India"],
                            ["Akkalkot", "IN", "India"],
                            ["Rackcham", "IN", "India"],
                            ["Daman", "IN", "India"],
                            ["Pandharpur", "IN", "India"],
                            ["Chamoli", "IN", "India"],
                            ["Ranakpur", "IN", "India"],
                            ["Nubra", "IN", "India"],
                            ["Yumthang", "IN", "India"],
                            ["Digha", "IN", "India"],
                            ["Bhimtal", "IN", "India"],
                            ["Munsiyari", "IN", "India"],
                            ["Chittorgarh", "IN", "India"],
                            ["Yelagiri", "IN", "India"],
                            ["Karjat", "IN", "India"],
                            ["Khajuraho", "IN", "India"],
                            ["Nahan", "IN", "India"],
                            ["Pipariya", "IN", "India"],
                            ["Mangaluru", "IN", "India"],
                            ["Ghaziabad", "IN", "India"],
                            ["Naldehra", "IN", "India"],
                            ["Vengurla", "IN", "India"],
                            ["Kanchipuram", "IN", "India"],
                            ["Santhanpara", "IN", "India"],
                            ["Andhra Pradesh", "IN", "India"],
                            ["Kanpur", "IN", "India"],
                            ["Bharatpur", "IN", "India"],
                            ["Dharmasthala", "IN", "India"],
                            ["Ravangla", "IN", "India"],
                            ["Kumbhalgarh", "IN", "India"],
                            ["Trimbakeshwar", "IN", "India"],
                            ["Kotdwara", "IN", "India"],
                            ["Badami", "IN", "India"],
                            ["Kollur", "IN", "India"],
                            ["Gurugram", "IN", "India"],
                            ["Guptkashi", "IN", "India"],
                            ["Kargil", "IN", "India"],
                            ["Kumbakonam", "IN", "India"],
                            ["Raipur", "IN", "India"],
                            ["Bir", "IN", "India"],
                            ["Pedong", "IN", "India"],
                            ["Jhansi", "IN", "India"],
                            ["Bodhgaya", "IN", "India"],
                            ["Omkareshwar", "IN", "India"],
                            ["Ranthambore", "IN", "India"],
                            ["Bandipur", "IN", "India"],
                            ["Kohima", "IN", "India"],
                            ["Ludhiana", "IN", "India"],
                            ["Nalanda", "IN", "India"],
                            ["Island", "IN", "India"],
                            ["Lataguri", "IN", "India"],
                            ["Mussoorie", "IN", "India"],
                            ["Dabolim", "IN", "India"],
                            ["Barsaini", "IN", "India"],
                            ["Fatehpur Sikri", "IN", "India"],
                            ["Kanatal", "IN", "India"],
                            ["Ranchi", "IN", "India"],
                            ["Sundarban", "IN", "India"],
                            ["Kanha National Park", "IN", "India"],
                            ["Mandarmani", "IN", "India"],
                            ["Faridabad", "IN", "India"],
                            ["Poovar", "IN", "India"],
                            ["Kundalpur", "IN", "India"],
                            ["Gunawaji", "IN", "India"],
                            ["Pawapuri", "IN", "India"],
                            ["Parasnath", "IN", "India"],
                            ["Madhya Pradesh", "IN", "India"],
                            ["Navi Mumbai", "IN", "India"],
                            ["Kabini", "IN", "India"],
                            ["Gwalior", "IN", "India"],
                            ["Aamby Valley", "IN", "India"],
                            ["Mandi", "IN", "India"],
                            ["Calicut", "IN", "India"],
                            ["Rishikhola", "IN", "India"],
                            ["Rishop", "IN", "India"],
                            ["Khardungla", "IN", "India"],
                            ["Junagadh", "IN", "India"],
                            ["Mauritius", "IN", "India"],
                            ["Gaya", "IN", "India"],
                            ["Dharamkot", "IN", "India"],
                            ["Horanadu", "IN", "India"],
                            ["Moreh", "IN", "India"],
                            ["Dimapur", "IN", "India"],
                            ["Loktak", "IN", "India"],
                            ["Secunderabad", "IN", "India"],
                            ["Igatpuri", "IN", "India"],
                            ["Lepchajagat Village", "IN", "India"],
                            ["Bangaram", "IN", "India"],
                            ["Odisha", "IN", "India"],
                            ["Palani", "IN", "India"],
                            ["Sar Pass", "IN", "India"],
                            ["Kota", "IN", "India"],
                            ["Mukteshwar", "IN", "India"],
                            ["Kangra", "IN", "India"],
                            ["Periyar", "IN", "India"],
                            ["Howrah", "IN", "India"],
                            ["Tanjore", "IN", "India"],
                            ["Anegundi", "IN", "India"],
                            ["Kolhapur", "IN", "India"],
                            ["Hansi", "IN", "India"],
                            ["Guruvayoor", "IN", "India"],
                            ["Ambaji", "IN", "India"],
                            ["Palakkad", "IN", "India"],
                            ["Sringeri", "IN", "India"],
                            ["Srirangam", "IN", "India"],
                            ["Horsley Hills", "IN", "India"],
                            ["Rohtak", "IN", "India"],
                            ["Tezpur", "IN", "India"],
                            ["Gadiara", "IN", "India"],
                            ["Anjarle", "IN", "India"],
                            ["Chalal", "IN", "India"],
                            ["Bhuj", "IN", "India"],
                            ["Vijayawada", "IN", "India"],
                            ["Rasol", "IN", "India"],
                            ["Manirarn", "IN", "India"],
                            ["Fagu", "IN", "India"],
                            ["Thanjavur", "IN", "India"],
                            ["Bodh Gaya", "IN", "India"],
                            ["Punjab", "IN", "India"],
                            ["Kushalnagar", "IN", "India"],
                            ["Chopta Valley", "IN", "India"],
                            ["Gurudongmar", "IN", "India"],
                            ["Tumling", "IN", "India"],
                            ["Andaman And Nicobar", "IN", "India"],
                            ["Gandhinagar", "IN", "India"],
                            ["Paro", "IN", "India"],
                            ["Joshinath", "IN", "India"],
                            ["Gir", "IN", "India"],
                            ["Kushinagar", "IN", "India"],
                            ["Raichur", "IN", "India"],
                            ["Gangasagar", "IN", "India"],
                            ["Ramanagaram", "IN", "India"],
                            ["Gorakhpur", "IN", "India"],
                            ["Ayodhya", "IN", "India"],
                            ["Lumbini", "IN", "India"],
                            ["Agartala", "IN", "India"],
                            ["Uttar Pradesh", "IN", "India"],
                            ["Kelshi", "IN", "India"],
                            ["Jamshedpur", "IN", "India"],
                            ["Panvel", "IN", "India"],
                            ["Pithapuram", "IN", "India"],
                            ["Samalkot", "IN", "India"],
                            ["Karwar", "IN", "India"],
                            ["Vellore", "IN", "India"],
                            ["Chitrakoot", "IN", "India"],
                            ["Raichak", "IN", "India"],
                            ["Jalandhar", "IN", "India"],
                            ["Dibrugarh", "IN", "India"],
                            ["Shivpuri", "IN", "India"],
                            ["Orchha", "IN", "India"],
                            ["Chittoor", "IN", "India"],
                            ["Warangal", "IN", "India"],
                            ["Chakrata", "IN", "India"],
                            ["Bijapur", "IN", "India"],
                            ["Chikkamagaluru", "IN", "India"],
                            ["Delwara", "IN", "India"],
                            ["Porbandar", "IN", "India"],
                            ["Dervan", "IN", "India"],
                            ["Shivamogga", "IN", "India"],
                            ["Tarakeswar", "IN", "India"],
                            ["Silvassa", "IN", "India"],
                            ["Vaishali", "IN", "India"],
                            ["Hadimba", "IN", "India"],
                            ["Sadhupul", "IN", "India"],
                            ["Shrivardhan", "IN", "India"],
                            ["Durshet", "IN", "India"],
                            ["Lolegaon", "IN", "India"],
                            ["Solan", "IN", "India"],
                            ["Nameri", "IN", "India"],
                            ["Orissa", "IN", "India"],
                            ["Kozhikode", "IN", "India"],
                            ["Neemrana", "IN", "India"],
                            ["Sabarimala", "IN", "India"],
                            ["Himalayas", "IN", "India"],
                            ["Haryana", "IN", "India"],
                            ["Nanded", "IN", "India"],
                            ["Sasan", "IN", "India"],
                            ["Courtallam", "IN", "India"],
                            ["Ernakulam", "IN", "India"],
                            ["Amboli", "IN", "India"],
                            ["Jispa", "IN", "India"],
                            ["Yumthang Valley", "IN", "India"],
                            ["Hemalkasa", "IN", "India"],
                            ["Bareilly", "IN", "India"],
                            ["New Jalpaiguri", "IN", "India"],
                            ["Maheshwar", "IN", "India"],
                            ["Bhangarh", "IN", "India"],
                            ["Tarkarli", "IN", "India"],
                            ["Tabo", "IN", "India"],
                            ["Roychak", "IN", "India"],
                            ["Velankanni", "IN", "India"],
                            ["Santiniketan", "IN", "India"],
                            ["Kinnaur", "IN", "India"],
                            ["Varkala", "IN", "India"],
                            ["Chilka", "IN", "India"],
                            ["Harihareshwar", "IN", "India"],
                            ["Ramoji", "IN", "India"],
                            ["Parambikulam", "IN", "India"],
                            ["Thirunallur", "IN", "India"],
                            ["Kanchanoor", "IN", "India"],
                            ["Keezhperumpallam", "IN", "India"],
                            ["Nathula", "IN", "India"],
                            ["Chungthang", "IN", "India"],
                            ["Bheemeshwari", "IN", "India"],
                            ["Tiruvannamalai", "IN", "India"],
                            ["Mangan", "IN", "India"],
                            ["Thimphu", "IN", "India"],
                            ["Wayyand", "IN", "India"],
                            ["Andro", "IN", "India"],
                            ["Panaji", "IN", "India"],
                            ["Murdeshwar", "IN", "India"],
                            ["Nagarhole", "IN", "India"],
                            ["Dooars", "IN", "India"],
                            ["Chidambaram", "IN", "India"],
                            ["Jagdalpur", "IN", "India"],
                            ["Bilaspur", "IN", "India"],
                            ["Sawai Madhopur", "IN", "India"],
                            ["Gondal", "IN", "India"],
                            ["Meerut", "IN", "India"],
                            ["Giridih", "IN", "India"],
                            ["Dandeli", "IN", "India"],
                            ["Mandu", "IN", "India"],
                            ["Minicoy Island", "IN", "India"],
                            ["Anandvan", "IN", "India"],
                            ["Hassan", "IN", "India"],
                            ["Manebhanjyang", "IN", "India"],
                            ["Kalapokhri", "IN", "India"],
                            ["Sasan Gir", "IN", "India"],
                            ["Sillerygaon", "IN", "India"],
                            ["Alwar", "IN", "India"],
                            ["Kavaratti Island", "IN", "India"],
                            ["Loleygaon", "IN", "India"],
                            ["Murudeshwar", "IN", "India"],
                            ["Kamshet", "IN", "India"],
                            ["Deoghar", "IN", "India"],
                            ["Bihar", "IN", "India"],
                            ["Silerygaon", "IN", "India"],
                            ["Govindghat", "IN", "India"],
                            ["Ganeshgudi", "IN", "India"],
                            ["Bhandardara", "IN", "India"],
                            ["Sham Valley", "IN", "India"],
                            ["Jaldapara", "IN", "India"],
                            ["Patiala", "IN", "India"],
                            ["Subramanya", "IN", "India"],
                            ["Kalyan", "IN", "India"],
                            ["Murud Harnai", "IN", "India"],
                            ["Solangnala", "IN", "India"],
                            ["Sawantvadi", "IN", "India"],
                            ["Tiruchendur", "IN", "India"],
                            ["Virpur", "IN", "India"],
                            ["Langkawi", "IN", "India"],
                            ["Phuentsholing", "IN", "India"],
                            ["Baltal", "IN", "India"],
                            ["Moradabad", "IN", "India"],
                            ["Hazur Sahib", "IN", "India"],
                            ["Sasangir", "IN", "India"],
                            ["Sagar", "IN", "India"],
                            ["Nainadevi", "IN", "India"],
                            ["Barsheni", "IN", "India"],
                            ["Patliputra", "IN", "India"],
                            ["Thrissur", "IN", "India"],
                            ["Haldwani", "IN", "India"],
                            ["Jhandi", "IN", "India"],
                            ["Pasighat", "IN", "India"],
                            ["Ziro", "IN", "India"],
                            ["Chhindwara", "IN", "India"],
                            ["Pangot", "IN", "India"],
                            ["Tirunelveli", "IN", "India"],
                            ["Ajanta", "IN", "India"],
                            ["Chintpurni", "IN", "India"],
                            ["Tsomgolake", "IN", "India"],
                            ["Murshidabad", "IN", "India"],
                            ["Mayapur", "IN", "India"],
                            ["Kutch", "IN", "India"],
                            ["Neelkanth", "IN", "India"],
                            ["Ghangaria", "IN", "India"],
                            ["Hisar", "IN", "India"],
                            ["Tiruttani", "IN", "India"],
                            ["Dabhol Bandar", "IN", "India"],
                            ["Chiplun", "IN", "India"],
                            ["Tirupathi", "IN", "India"],
                            ["Ambala", "IN", "India"],
                            ["Mandvi", "IN", "India"],
                            ["Rajahmundry", "IN", "India"],
                            ["Cuttack", "IN", "India"],
                            ["Amravati", "IN", "India"],
                            ["Changu", "IN", "India"],
                            ["Dhanolti", "IN", "India"],
                            ["Shivthar Ghal", "IN", "India"],
                            ["Narkanda", "IN", "India"],
                            ["Belgaum", "IN", "India"],
                            ["Daporijo", "IN", "India"],
                            ["Mlenyadri", "IN", "India"],
                            ["Tadoba", "IN", "India"],
                            ["Mandawa", "IN", "India"],
                            ["Parwanoo", "IN", "India"],
                            ["Vagamon", "IN", "India"],
                            ["Kottayam", "IN", "India"],
                            ["Palitana", "IN", "India"],
                            ["Dantewada", "IN", "India"],
                            ["Viper Island", "IN", "India"],
                            ["Kadmat", "IN", "India"],
                            ["Roorkee", "IN", "India"],
                            ["Pokhara", "IN", "India"],
                            ["Bhubaneshwar", "IN", "India"],
                            ["Rameshewaram", "IN", "India"],
                            ["Jharkhand", "IN", "India"],
                            ["Nathang", "IN", "India"],
                            ["Manipal", "IN", "India"],
                            ["Kalpetta", "IN", "India"],
                            ["Salem", "IN", "India"],
                            ["Jayanti", "IN", "India"],
                            ["Mawsynram", "IN", "India"],
                            ["Guntur", "IN", "India"],
                            ["Bhaderwah", "IN", "India"],
                            ["Gulbarga", "IN", "India"],
                            ["Silchar", "IN", "India"],
                            ["Nagaland", "IN", "India"],
                            ["Kannur", "IN", "India"],
                            ["Agumbe", "IN", "India"],
                            ["Konkan", "IN", "India"],
                            ["Solapur", "IN", "India"],
                            ["Lepchajagat", "IN", "India"],
                            ["Karnal", "IN", "India"],
                            ["Baratang Island", "IN", "India"],
                            ["Timber Trail", "IN", "India"],
                            ["Tsomgo", "IN", "India"],
                            ["Nagar", "IN", "India"],
                            ["Bhuntar", "IN", "India"],
                            ["Nanpara", "IN", "India"],
                            ["Bhilwara", "IN", "India"],
                            ["Aligarh", "IN", "India"],
                            ["Harsil", "IN", "India"],
                            ["Srikhola", "IN", "India"],
                            ["Tonglu", "IN", "India"],
                            ["Nathdwara", "IN", "India"],
                            ["Asansol", "IN", "India"],
                            ["Manipur", "IN", "India"],
                            ["Sanchi", "IN", "India"],
                            ["Manebhanjan", "IN", "India"],
                            ["Bandhavgarh", "IN", "India"],
                            ["Tirathgarh", "IN", "India"],
                            ["Tsomoriri", "IN", "India"],
                            ["Bhedaghat", "IN", "India"],
                            ["Pithoragarh", "IN", "India"],
                            ["Kurukshetra", "IN", "India"],
                            ["Bhitarkanika", "IN", "India"],
                            ["Hubli", "IN", "India"],
                            ["Abbey Falls", "IN", "India"],
                            ["Chitwan", "IN", "India"],
                            ["Suryanelli", "IN", "India"],
                            ["Hospet", "IN", "India"],
                            ["Vapi", "IN", "India"],
                            ["Banaras", "IN", "India"],
                            ["Khopoli", "IN", "India"],
                            ["Biling", "IN", "India"],
                            ["Sonprayag", "IN", "India"],
                            ["Kalka", "IN", "India"],
                            ["Kollam", "IN", "India"],
                            ["Chandrapur", "IN", "India"],
                            ["Athirapally", "IN", "India"],
                            ["Bhojbasa", "IN", "India"],
                            ["Mohali", "IN", "India"],
                            ["Ankola", "IN", "India"],
                            ["Parvati", "IN", "India"],
                            ["Dhanbad", "IN", "India"],
                            ["Govind Ghat", "IN", "India"],
                            ["Thinnakara", "IN", "India"],
                            ["Muzaffarnagar", "IN", "India"],
                            ["Bhadrachalam", "IN", "India"],
                            ["Udipi", "IN", "India"],
                            ["Spiti Valley", "IN", "India"],
                            ["Shimoga", "IN", "India"],
                            ["Jalpaiguri", "IN", "India"],
                            ["Rudrapur", "IN", "India"],
                            ["Bhowali", "IN", "India"],
                            ["Diveagar", "IN", "India"],
                            ["Hogenakkal", "IN", "India"],
                            ["Pattadakal", "IN", "India"],
                            ["Bidar", "IN", "India"],
                            ["Chikhaldara", "IN", "India"],
                            ["Akshardham", "IN", "India"],
                            ["Durg", "IN", "India"],
                            ["Bhilai", "IN", "India"],
                            ["Guruvayur", "IN", "India"],
                            ["Aihole", "IN", "India"],
                            ["Tiruchirappalli", "IN", "India"],
                            ["Yusmarg", "IN", "India"],
                            ["Jorhat", "IN", "India"],
                            ["Unakoti", "IN", "India"],
                            ["Rourkela", "IN", "India"],
                            ["Rishyap", "IN", "India"],
                            ["Ramgarh", "IN", "India"],
                            ["Punakha", "IN", "India"],
                            ["Tripura", "IN", "India"],
                            ["Greater Noida", "IN", "India"],
                            ["Skandagiri Hills", "IN", "India"],
                            ["Kailash Mansarovar", "IN", "India"],
                            ["Kukke Subramanya", "IN", "India"],
                            ["Kolad", "IN", "India"],
                            ["Raigad", "IN", "India"],
                            ["Radhanagar", "IN", "India"],
                            ["North Bay", "IN", "India"],
                            ["Margao", "IN", "India"],
                            ["Gomukh", "IN", "India"],
                            ["Madras", "IN", "India"],
                            ["Nilambur", "IN", "India"],
                            ["Padong", "IN", "India"],
                            ["Satara", "IN", "India"],
                            ["Itanagar", "IN", "India"],
                            ["Indrahar Pass", "IN", "India"],
                            ["Chilika", "IN", "India"],
                            ["Gokul", "IN", "India"],
                            ["Deoria Tal", "IN", "India"],
                            ["Kodungallur", "IN", "India"],
                            ["Pahal", "IN", "India"],
                            ["Khonoma", "IN", "India"],
                            ["Muzaffarpur", "IN", "India"],
                            ["Patan", "IN", "India"],
                            ["Alipura", "IN", "India"],
                            ["Muthathi", "IN", "India"],
                            ["Wagha Border", "IN", "India"],
                            ["Chandannagar", "IN", "India"],
                            ["Gaurikund", "IN", "India"],
                            ["Munsyari", "IN", "India"],
                            ["Sattal", "IN", "India"],
                            ["Alchi", "IN", "India"],
                            ["Karla", "IN", "India"],
                            ["Jalgaon", "IN", "India"],
                            ["Chitkul", "IN", "India"],
                            ["Vasundhara", "IN", "India"],
                            ["Shivkhori", "IN", "India"],
                            ["Balasore", "IN", "India"],
                            ["Faizabad", "IN", "India"],
                            ["Govardhan", "IN", "India"],
                            ["Gao", "IN", "India"],
                            ["Kodagu", "IN", "India"],
                            ["Rose Island", "IN", "India"],
                            ["Nellore", "IN", "India"],
                            ["Thenmala", "IN", "India"],
                            ["Ankleshwar", "IN", "India"],
                            ["Jhalong", "IN", "India"],
                            ["Diskit", "IN", "India"],
                            ["Abu Road", "IN", "India"],
                            ["Spitalyi", "IN", "India"],
                            ["Kazerbaijana", "IN", "India"],
                            ["Mawphu", "IN", "India"],
                            ["Guptakashi", "IN", "India"],
                            ["Valsad", "IN", "India"],
                            ["Sirsi", "IN", "India"],
                            ["Bhimashankar", "IN", "India"],
                            ["Khardungla Top", "IN", "India"],
                            ["Wandoor", "IN", "India"],
                            ["Rewari", "IN", "India"],
                            ["Bathinda", "IN", "India"],
                            ["Nagercoil", "IN", "India"],
                            ["Ratlam", "IN", "India"],
                            ["Fatehpur", "IN", "India"],
                            ["Ahmadabad", "IN", "India"],
                            ["Akola", "IN", "India"],
                            ["Sariska", "IN", "India"],
                            ["Bolpur", "IN", "India"],
                            ["Neermahal", "IN", "India"],
                            ["Madhopur", "IN", "India"],
                            ["Malana Dam", "IN", "India"],
                            ["Dhauli", "IN", "India"],
                            ["Vythiri", "IN", "India"],
                            ["Calcutta", "IN", "India"],
                            ["Vagator", "IN", "India"],
                            ["Charkhole", "IN", "India"],
                            ["Kanya Kumari", "IN", "India"],
                            ["Rado Valley", "IN", "India"],
                            ["Ellappatti Camp", "IN", "India"],
                            ["Jind", "IN", "India"],
                            ["Panipat", "IN", "India"],
                            ["Sarnath", "IN", "India"],
                            ["Kakinada", "IN", "India"],
                            ["Yuksom", "IN", "India"],
                            ["Malda", "IN", "India"],
                            ["Ganapatipule", "IN", "India"],
                            ["Thiksey", "IN", "India"],
                            ["Pykara", "IN", "India"],
                            ["Jharsuguda", "IN", "India"],
                            ["Aizawl", "IN", "India"],
                            ["Bakkhali", "IN", "India"],
                            ["Ellora", "IN", "India"],
                            ["Thirunallar", "IN", "India"],
                            ["Kanjanur", "IN", "India"],
                            ["Alangudi", "IN", "India"],
                            ["Thiruvenkadu", "IN", "India"],
                            ["Vaitheeswaran Koil", "IN", "India"],
                            ["Suriyanar Koil", "IN", "India"],
                            ["Tungnath", "IN", "India"],
                            ["Sonipat", "IN", "India"],
                            ["Jageshwar", "IN", "India"],
                            ["Hikkim", "IN", "India"],
                            ["Chottanikkara", "IN", "India"],
                            ["Hubballi", "IN", "India"],
                            ["Anantapur", "IN", "India"],
                            ["Bharuch", "IN", "India"],
                            ["Kosi", "IN", "India"],
                            ["Cuddalore", "IN", "India"],
                            ["Mizoram", "IN", "India"],
                            ["Karimnagar", "IN", "India"],
                            ["Malshej Ghat", "IN", "India"],
                            ["Dombivli", "IN", "India"],
                            ["Chokhi Dhani", "IN", "India"],
                            ["Tanakpur", "IN", "India"],
                            ["Baroda", "IN", "India"],
                            ["Pench", "IN", "India"],
                            ["Ganagapur", "IN", "India"],
                            ["Pandharpuur", "IN", "India"],
                            ["Athirappally", "IN", "India"],
                            ["Thirunageswaram", "IN", "India"],
                            ["Durgapur", "IN", "India"],
                            ["Ghum", "IN", "India"],
                            ["Lingtam", "IN", "India"],
                            ["Satkosia", "IN", "India"],
                            ["Baralacha", "IN", "India"],
                            ["Bhagsu", "IN", "India"],
                            ["Naddi", "IN", "India"],
                            ["Pong", "IN", "India"],
                            ["Agara", "IN", "India"],
                            ["Khir Ganga", "IN", "India"],
                            ["Kharagpur", "IN", "India"],
                            ["Scandal Point", "IN", "India"],
                            ["Lakkar Bazaar", "IN", "India"],
                            ["Suntalekhola", "IN", "India"],
                            ["Connor", "IN", "India"],
                            ["Sultanpur", "IN", "India"],
                            ["Lapchakha", "IN", "India"],
                            ["Santrabarie", "IN", "India"],
                            ["Vantawang", "IN", "India"],
                            ["Champai", "IN", "India"],
                            ["Telangana", "IN", "India"],
                            ["Kurnool", "IN", "India"],
                            ["Skandagiri Trek", "IN", "India"],
                            ["Konaseema", "IN", "India"],
                            ["Nagarjunasagar", "IN", "India"],
                            ["Ramanagara", "IN", "India"],
                            ["Shegaon", "IN", "India"],
                            ["Chaukori", "IN", "India"],
                            ["Sitapur", "IN", "India"],
                            ["Kunzum", "IN", "India"],
                            ["Sikar", "IN", "India"],
                            ["Veraval", "IN", "India"],
                            ["Auroville", "IN", "India"],
                            ["Azamgarh", "IN", "India"],
                            ["Kashi", "IN", "India"],
                            ["Jagannath Puri", "IN", "India"],
                            ["Baharampur", "IN", "India"],
                            ["Someshwar", "IN", "India"],
                            ["Kanchi", "IN", "India"],
                            ["Chaubatia", "IN", "India"],
                            ["Gavi", "IN", "India"],
                            ["Sawantwad", "IN", "India"],
                            ["Jaigadh", "IN", "India"],
                            ["Berhampur", "IN", "India"],
                            ["Pashupati", "IN", "India"],
                            ["Korba", "IN", "India"],
                            ["Latur", "IN", "India"],
                            ["Masinagudi", "IN", "India"],
                            ["Jaunpur", "IN", "India"],
                            ["Darbhanga", "IN", "India"],
                            ["Batal", "IN", "India"],
                            ["Alipurduar", "IN", "India"],
                            ["Ramdhura", "IN", "India"],
                            ["Begusarai", "IN", "India"],
                            ["Kankhal", "IN", "India"],
                            ["Bhandara", "IN", "India"],
                            ["Bageshwar", "IN", "India"],
                            ["Idukki", "IN", "India"],
                            ["Pali", "IN", "India"],
                            ["Aluva", "IN", "India"],
                            ["Kamarpukur", "IN", "India"],
                            ["Naukuchiatal", "IN", "India"],
                            ["Sawantwadi", "IN", "India"],
                            ["Tarkeshwar", "IN", "India"],
                            ["Borong", "IN", "India"],
                            ["Manesar", "IN", "India"],
                            ["Naldhara", "IN", "India"],
                            ["Chail Palace", "IN", "India"],
                            ["Kokernag", "IN", "India"],
                            ["Vashi", "IN", "India"],
                            ["Bhiwadi", "IN", "India"],
                            ["Sangli", "IN", "India"],
                            ["Bharmour", "IN", "India"],
                            ["Unnao", "IN", "India"],
                            ["Minakshi Puram", "IN", "India"],
                            ["Malappuram", "IN", "India"],
                            ["Pipli", "IN", "India"],
                            ["Hirapur", "IN", "India"],
                            ["Angul", "IN", "India"],
                            ["Japan", "IN", "India"],
                            ["Virar", "IN", "India"],
                            ["Bundi", "IN", "India"],
                            ["Sangrur", "IN", "India"],
                            ["Valera Falls", "IN", "India"],
                            ["Mandwa", "IN", "India"],
                            ["Gandhidham", "IN", "India"],
                            ["Yamuna Nagar", "IN", "India"],
                            ["Kaudiyala", "IN", "India"],
                            ["Srikakulam", "IN", "India"],
                            ["Dhordo", "IN", "India"],
                            ["Sambalpur", "IN", "India"],
                            ["Uttarey", "IN", "India"],
                            ["Mana", "IN", "India"],
                            ["Kausan", "IN", "India"],
                            ["Morbi", "IN", "India"],
                            ["Kopargaon", "IN", "India"],
                            ["Kirti Nagar", "IN", "India"],
                            ["Kalaburagi", "IN", "India"],
                            ["Saharanpur", "IN", "India"],
                            ["Narayan Sarovar", "IN", "India"],
                            ["Ganga Sagar", "IN", "India"],
                            ["Dasada", "IN", "India"],
                            ["Abhayapuri", "IN", "India"],
                            ["Pin Valley", "IN", "India"],
                            ["Bhiwandi", "IN", "India"],
                            ["Rewalsar", "IN", "India"],
                            ["Mirzapur", "IN", "India"],
                            ["Chandratal", "IN", "India"],
                            ["Vishakhapatnam", "IN", "India"],
                            ["Herur", "IN", "India"],
                            ["Kadapa", "IN", "India"],
                            ["Nagarkot", "IN", "India"],
                            ["Rumtek", "IN", "India"],
                            ["Simikot", "IN", "India"],
                            ["Mehsana", "IN", "India"],
                            ["Hoshiarpur", "IN", "India"],
                            ["Kashid", "IN", "India"],
                            ["Pipalkoti", "IN", "India"],
                            ["Pemayangtse", "IN", "India"],
                            ["Balotra", "IN", "India"],
                            ["Erode", "IN", "India"],
                            ["Ahmednagar", "IN", "India"],
                            ["Kashmandu", "NP", "Nepal"],
                            ["Malaysia", "MY", "Malaysia"],
                            ["Aalborg", "DK", "Denmark"],
                            ["Abakan", "RU", "Russia"],
                            ["Aberdare", "KE", "Kenya"],
                            ["Accra", "GH", "Ghana"],
                            ["Acropolis", "GR", "Greece"],
                            ["Addis", "ET", "Ethiopia"],
                            ["Adelaide", "AU", "Australia"],
                            ["Afghanistan", "AF", "Afghanistan"],
                            ["Africa", "RAF", "Africa"],
                            ["Alabama", "US", "United States Of America"],
                            ["Alaska", "US", "United States Of America"],
                            ["Albania", "CO", "Colombia"],
                            ["Alexandria", "PS", "Palestine"],
                            ["Alicante", "ES", "Spain"],
                            ["Allentown", "US", "United States Of America"],
                            ["Allestree", "AU", "Australia"],
                            ["Almaty", "KG", "Kyrgyzstan"],
                            ["Alpine", "IT", "Italy"],
                            ["Alta", "REU", "Europe"],
                            ["Amalfi", "GR", "Greece"],
                            ["Amarapura", "MM", "Myanmar"],
                            ["Amarillo", "US", "United States Of America"],
                            ["Ambla", "EE", "Estonia"],
                            ["Amboseli", "KE", "Kenya"],
                            ["Amerstdam", "UK", "United Kingdom"],
                            ["Amman", "RME", "MiddleEast"],
                            ["Amsterdam", "REU", "Europe"],
                            ["Anaheim", "US", "United States Of America"],
                            ["Anchorage", "US", "United States Of America"],
                            ["Andorra", "REU", "Europe"],
                            ["Angkor", "KH", "Cambodia"],
                            ["Angkorwat", "KH", "Cambodia"],
                            ["Angor", "RME", "MiddleEast"],
                            ["Ankara", "TR", "Turkey"],
                            ["Annemasse", "REU", "Europe"],
                            ["Anruadhapura", "LK", "Sri Lanka"],
                            ["Antaliya", "TR", "Turkey"],
                            ["Antalya", "TR", "Turkey"],
                            ["Antananarivo", "MG", "Madagascar"],
                            ["Antarctica", "AQ", "Antarctica"],
                            ["Antipolo", "PH", "Philippines"],
                            ["Antwerp", "BE", "Belgium"],
                            ["Anuradhapura", "LK", "Sri Lanka"],
                            ["Aomori", "JP", "Japan"],
                            ["Aphrodisias", "TR", "Turkey"],
                            ["Aquarium", "SG", "Singapore"],
                            ["Arab", "US", "United States Of America"],
                            ["Arbaeen", "RME", "MiddleEast"],
                            ["Ardebil", "IR", "Iran"],
                            ["Arenal", "CR", "Costa Rica"],
                            ["Arizona", "US", "United States Of America"],
                            ["Arkhangelsk", "RU", "Russia"],
                            ["Armenia", "REU", "Europe"],
                            ["Arusha", "TZ", "Tanzania"],
                            ["Asturias", "ES", "Spain"],
                            ["Aswan", "EG", "Egypt"],
                            ["Athens", "GR", "Greece"],
                            ["Athina", "GR", "Greece"],
                            ["Atlanta", "US", "United States Of America"],
                            ["Atlantic", "US", "United States Of America"],
                            ["Auckland", "NZ", "New Zealand"],
                            ["Audincourt", "FR", "France"],
                            ["Aukana", "LK", "Sri Lanka"],
                            ["Austin", "US", "United States Of America"],
                            ["Australia", "AU", "Australia"],
                            ["Australian", "AU", "Australia"],
                            ["Austrelia", "NZ", "New Zealand"],
                            ["Austria", "FR", "France"],
                            ["Ayutthaya", "TH", "Thailand"],
                            ["Azad", "PK", "Pakistan"],
                            ["Azerbaijan", "AZ", "Azerbaijan"],
                            ["Bacolod", "PH", "Philippines"],
                            ["Bagan", "MM", "Myanmar"],
                            ["Baghdad", "RME", "MiddleEast"],
                            ["Baguio", "PH", "Philippines"],
                            ["Bahamas", "BS", "Bahamas"],
                            ["Bahrain", "BH", "Bahrain"],
                            ["Baitul", "RME", "MiddleEast"],
                            ["Baja", "MX", "Mexico"],
                            ["Baku", "AZ", "Azerbaijan"],
                            ["Balakong", "MY", "Malaysia"],
                            ["Balestrand", "REU", "Europe"],
                            ["Balibago", "PH", "Philippines"],
                            ["Ballina", "IE", "Ireland"],
                            ["Balore", "US", "United States Of America"],
                            ["Baltimore", "US", "United States Of America"],
                            ["Baltra", "EC", "Ecuador"],
                            ["Bandar", "BN", "Brunei"],
                            ["Bandarawela", "LK", "Sri Lanka"],
                            ["Bandelierkop", "ZA", "South Africa"],
                            ["Bandos", "MV", "Maldives"],
                            ["Bandung", "ID", "Indonesia"],
                            ["Bangladesh", "BD", "Bangladesh"],
                            ["Barcelona", "ES", "Spain"],
                            ["Barisal", "BD", "Bangladesh"],
                            ["Barong", "ID", "Indonesia"],
                            ["Batan Island", "PH", "Philippines"],
                            ["Baton", "US", "United States Of America"],
                            ["Batticaloa", "LK", "Sri Lanka"],
                            ["Batu", "SG", "Singapore"],
                            ["Batucaves", "MY", "Malaysia"],
                            ["Batumi", "GE", "Georgia"],
                            ["Bedford", "GB", "Great Britain"],
                            ["Bedugul", "ID", "Indonesia"],
                            ["Behrensdorf", "DE", "Germany"],
                            ["Beijing", "CN", "China"],
                            ["Beira", "MZ", "Mozambique"],
                            ["Beirut", "LB", "Lebanon"],
                            ["Belgium", "MC", "Monaco"],
                            ["Belgorod", "RU", "Russia"],
                            ["Belize", "RSA", "South America"],
                            ["Bengkong", "ID", "Indonesia"],
                            ["Benin", "BJ", "Benin"],
                            ["Benoa", "ID", "Indonesia"],
                            ["Bergen", "REU", "Europe"],
                            ["Berlin", "DE", "Germany"],
                            ["Bermingham", "UK", "United Kingdom"],
                            ["Bermuda", "BM", "Bermuda"],
                            ["Bern", "REU", "Europe"],
                            ["Bethlehem", "IL", "Israel"],
                            ["Bhagdad", "RME", "MiddleEast"],
                            ["Bhaktapur", "NP", "Nepal"],
                            ["Bhurj", "AE", "United Arab Emirates"],
                            ["Bhutan", "BT", "Bhutan"],
                            ["Biarritz", "FR", "France"],
                            ["Bicol", "PH", "Philippines"],
                            ["Bicton", "AU", "Australia"],
                            ["Bidart", "FR", "France"],
                            ["Birmingham", "GB", "Great Britain"],
                            ["Bishkek", "KG", "Kyrgyzstan"],
                            ["Blanquilla", "RCA", "Caribbean"],
                            ["Blasket", "IE", "Ireland"],
                            ["Bogor", "ID", "Indonesia"],
                            ["Bogota", "CO", "Colombia"],
                            ["Bogra", "BD", "Bangladesh"],
                            ["Bolivar", "CO", "Colombia"],
                            ["Bolivia", "BO", "Bolivia"],
                            ["Bolwarra", "AU", "Australia"],
                            ["Bora", "PF", "French Polynesia"],
                            ["Borabora", "FR", "France"],
                            ["Bosnai", "REU", "Europe"],
                            ["Bosnia", "MY", "Malaysia"],
                            ["Boston", "US", "United States Of America"],
                            ["Botswana", "ZA", "South Africa"],
                            ["Bratislava", "AT", "Austria"],
                            ["Brazil", "BR", "Brazil"],
                            ["Brentwood", "UK", "United Kingdom"],
                            ["Brisbane", "AU", "Australia"],
                            ["British", "CA", "Canada"],
                            ["Brno", "CZ", "Czech Republic"],
                            ["Brooklyn", "US", "United States Of America"],
                            ["Bruges", "BE", "Belgium"],
                            ["Brussels", "BE", "Belgium"],
                            ["Bucaramanga", "CO", "Colombia"],
                            ["Bucharest", "RO", "Romania"],
                            ["Budapest", "HU", "Hungary"],
                            ["Buena", "US", "United States Of America"],
                            ["Buffalo", "US", "United States Of America"],
                            ["Bullet", "JP", "Japan"],
                            ["Bumthang", "BT", "Bhutan"],
                            ["Bunaken", "ID", "Indonesia"],
                            ["Burkina", "RAF", "Africa"],
                            ["Burlington", "CA", "Canada"],
                            ["Burundi", "BI", "Burundi"],
                            ["Buyan", "ID", "Indonesia"],
                            ["Cairns", "AU", "Australia"],
                            ["Cairopyramids", "EG", "Egypt"],
                            ["Calgary", "CA", "Canada"],
                            ["California", "US", "United States Of America"],
                            ["Cambodia", "KH", "Cambodia"],
                            ["Cameroon", "CM", "Cameroon"],
                            ["Camperdown", "AU", "Australia"],
                            ["Campleakey", "ID", "Indonesia"],
                            ["Canada", "CA", "Canada"],
                            ["Canadaperu", "ZA", "South Africa"],
                            ["Cancun", "US", "United States Of America"],
                            ["Cannes", "FR", "France"],
                            ["Canning", "CA", "Canada"],
                            ["Canton", "US", "United States Of America"],
                            ["Cao", "RFE", "Far East"],
                            ["Capetown", "KE", "Kenya"],
                            ["Cape_Town", "ZA", "South Africa"],
                            ["Capitol", "US", "United States Of America"],
                            ["Capo", "REU", "Europe"],
                            ["Cappadocia", "TR", "Turkey"],
                            ["Caribbean", "RCA", "Caribbean"],
                            ["Carnegie", "AU", "Australia"],
                            ["Carpathians", "RO", "Romania"],
                            ["Cary", "US", "United States Of America"],
                            ["Casablanca", "MA", "Morocco"],
                            ["Cayman", "KY", "Cayman Islands"],
                            ["Celuk", "ID", "Indonesia"],
                            ["Central", "SG", "Singapore"],
                            ["Cerfs", "MU", "Mauritius"],
                            ["Cesky", "CZ", "Czech Republic"],
                            ["Changmai", "TH", "Thailand"],
                            ["Changunarayan", "NP", "Nepal"],
                            ["Chania", "GR", "Greece"],
                            ["Charvak", "UZ", "Uzbekistan"],
                            ["Chau", "VN", "Vietnam"],
                            ["Chefchaoun", "MA", "Morocco"],
                            ["Chegaga", "MA", "Morocco"],
                            ["Chelela", "BT", "Bhutan"],
                            ["Chengde", "CN", "China"],
                            ["Chengdu", "CN", "China"],
                            ["Cheras", "MY", "Malaysia"],
                            ["Chiangmai", "TH", "Thailand"],
                            ["Chiapas", "MX", "Mexico"],
                            ["Chicago", "US", "United States Of America"],
                            ["Chickamaugalur", "US", "United States Of America"],
                            ["Chilaw", "LK", "Sri Lanka"],
                            ["Chile", "CL", "Chile"],
                            ["Chimgan", "UZ", "Uzbekistan"],
                            ["China", "CN", "China"],
                            ["Chinagreatwall", "CN", "China"],
                            ["Chinatown", "MY", "Malaysia"],
                            ["Chino", "US", "United States Of America"],
                            ["Chisinau", "MD", "Moldova"],
                            ["Chitran", "NP", "Nepal"],
                            ["Chittagong", "BD", "Bangladesh"],
                            ["Chongqing", "CN", "China"],
                            ["Christchurch", "NZ", "New Zealand"],
                            ["Cimahi", "ID", "Indonesia"],
                            ["Ciudad", "US", "United States Of America"],
                            ["Claremont", "US", "United States Of America"],
                            ["Cleveland", "US", "United States Of America"],
                            ["Clonmacnoise", "IE", "Ireland"],
                            ["Codrington", "AU", "Australia"],
                            ["Cognac", "FR", "France"],
                            ["Cologne", "CH", "Switzerland"],
                            ["Colombia", "CO", "Colombia"],
                            ["Colombo", "LK", "Sri Lanka"],
                            ["Combo", "AU", "Australia"],
                            ["Comillas", "ES", "Spain"],
                            ["Comoros", "KM", "Comoros"],
                            ["Conakry", "GN", "Guinea"],
                            ["Connemara", "IE", "Ireland"],
                            ["Copenhagen", "REU", "Europe"],
                            ["Corfu", "US", "United States Of America"],
                            ["Coria", "ES", "Spain"],
                            ["Cork", "IE", "Ireland"],
                            ["Coron", "PH", "Philippines"],
                            ["Corsica", "FR", "France"],
                            ["Costa", "CR", "Costa Rica"],
                            ["Cranbrook", "CA", "Canada"],
                            ["Crest", "US", "United States Of America"],
                            ["Croatia", "IT", "Italy"],
                            ["Crook", "US", "United States Of America"],
                            ["Crouse", "UK", "United Kingdom"],
                            ["Cuba", "CU", "Cuba"],
                            ["Curacao", "CH", "Switzerland"],
                            ["Curepipe", "MU", "Mauritius"],
                            ["Cuzco", "PE", "Peru"],
                            ["Cyprus", "CY", "Cyprus"],
                            ["Dades", "MA", "Morocco"],
                            ["Daegu", "KR", "South Korea"],
                            ["Dakar", "SN", "Senegal"],
                            ["Dalat", "VN", "Vietnam"],
                            ["Dallas", "US", "United States Of America"],
                            ["Dambulla", "LK", "Sri Lanka"],
                            ["Dammam", "SA", "Saudi Arabia"],
                            ["Denmark", "REU", "Europe"],
                            ["Dargi", "RFE", "Far East"],
                            ["Darlinghurst", "AU", "Australia"],
                            ["Dartmouth", "CA", "Canada"],
                            ["Davao", "PH", "Philippines"],
                            ["Deira", "AE", "United Arab Emirates"],
                            ["Delray", "US", "United States Of America"],
                            ["Denarau", "FJ", "Fiji"],
                            ["Denpasar", "ID", "Indonesia"],
                            ["Denver", "US", "United States Of America"],
                            ["Detroit", "US", "United States Of America"],
                            ["Dexter", "SG", "Singapore"],
                            ["Dhaka", "BD", "Bangladesh"],
                            ["Dhow", "AE", "United Arab Emirates"],
                            ["Dhudh", "NP", "Nepal"],
                            ["Dhulikhel", "NP", "Nepal"],
                            ["Diani", "KE", "Kenya"],
                            ["Dinajpur", "BD", "Bangladesh"],
                            ["Dingboche", "NP", "Nepal"],
                            ["Dirapuk", "NP", "Nepal"],
                            ["Disneyland", "CN", "China"],
                            ["Division", "BD", "Bangladesh"],
                            ["Djibouti", "DJ", "Djibouti"],
                            ["Dlingo", "ID", "Indonesia"],
                            ["Dochula", "BT", "Bhutan"],
                            ["Doha", "QA", "Qatar"],
                            ["Dominica", "DM", "Dominica"],
                            ["Dominican", "DO", "Dominican Republic"],
                            ["Dongguan", "RFE", "Far East"],
                            ["Dorset", "UK", "United Kingdom"],
                            ["Drakensberg", "ZA", "South Africa"],
                            ["Drukgyel", "BT", "Bhutan"],
                            ["Drukgyeldzong", "BT", "Bhutan"],
                            ["Dubai", "AE", "United Arab Emirates"],
                            ["Dublin", "IE", "Ireland"],
                            ["Dubrovnik", "REU", "Europe"],
                            ["Dumaguete", "PH", "Philippines"],
                            ["Dunes", "MA", "Morocco"],
                            ["Ecuador", "EC", "Ecuador"],
                            ["Edinburgh", "UK", "United Kingdom"],
                            ["Egypt", "IL", "Israel"],
                            ["Elsalvador", "US", "United States Of America"],
                            ["Engelberg", "CH", "Switzerland"],
                            ["Epcot", "US", "United States Of America"],
                            ["Ephesus", "TR", "Turkey"],
                            ["Equador", "RSA", "South America"],
                            ["Eritrea", "ER", "Eritrea"],
                            ["Estonia", "FI", "Finland"],
                            ["Etali", "RSA", "South America"],
                            ["Ethiopia", "ET", "Ethiopia"],
                            ["Eureka", "US", "United States Of America"],
                            ["Everest", "NP", "Nepal"],
                            ["Faridpur", "BD", "Bangladesh"],
                            ["Faro", "PT", "Portugal"],
                            ["Fethiye", "TR", "Turkey"],
                            ["Fihalhohi", "MV", "Maldives"],
                            ["Fiji", "AU", "Australia"],
                            ["Finland", "FI", "Finland"],
                            ["Floreana", "EC", "Ecuador"],
                            ["Florence", "FR", "France"],
                            ["Florida", "US", "United States Of America"],
                            ["Fortune", "CA", "Canada"],
                            ["France", "FR", "France"],
                            ["Frankfurt", "DE", "Germany"],
                            ["Freiburg", "DE", "Germany"],
                            ["Fuji", "JP", "Japan"],
                            ["Galle", "LK", "Sri Lanka"],
                            ["Gangtey", "BT", "Bhutan"],
                            ["Garden", "SG", "Singapore"],
                            ["Gardenroute", "KE", "Kenya"],
                            ["Garelt", "CA", "Canada"],
                            ["Gaul", "RME", "MiddleEast"],
                            ["Gawagala", "LK", "Sri Lanka"],
                            ["Geilo", "REU", "Europe"],
                            ["Gelang", "MY", "Malaysia"],
                            ["Gemini", "SG", "Singapore"],
                            ["George", "ZA", "South Africa"],
                            ["Georgetown", "US", "United States Of America"],
                            ["Georgia", "GE", "Georgia"],
                            ["Georgiaritreamoroccony", "REU", "Europe"],
                            ["Gerik", "MY", "Malaysia"],
                            ["Ghana", "GH", "Ghana"],
                            ["Ghent", "BE", "Belgium"],
                            ["Ghorepani", "NP", "Nepal"],
                            ["Giza", "EG", "Egypt"],
                            ["Glacier", "NZ", "New Zealand"],
                            ["Glasgow", "GB", "Great Britain"],
                            ["Glattbrugg", "CH", "Switzerland"],
                            ["Glendale", "US", "United States Of America"],
                            ["Godagari", "BD", "Bangladesh"],
                            ["Goias", "RSA", "South America"],
                            ["Gokyo", "NP", "Nepal"],
                            ["Gold", "AE", "United Arab Emirates"],
                            ["Gold Coast", "AU", "Australia"],
                            ["Golden", "US", "United States Of America"],
                            ["Gorakshep", "NP", "Nepal"],
                            ["Gorey", "REU", "Europe"],
                            ["Gorkha", "NP", "Nepal"],
                            ["Gorky", "KZ", "Kazakhstan"],
                            ["Gornergrat", "CH", "Switzerland"],
                            ["Granada", "ES", "Spain"],
                            ["Grandcanyon", "RNA", "North America"],
                            ["Greece", "GR", "Greece"],
                            ["Greenland", "US", "United States Of America"],
                            ["Grindelwald", "CH", "Switzerland"],
                            ["Gruyeres", "CH", "Switzerland"],
                            ["Guam", "GU", "Guam"],
                            ["Guanabara", "BR", "Brazil"],
                            ["Guanabarabay", "RSA", "South America"],
                            ["Guangzhou", "CN", "China"],
                            ["Gumpa", "DM", "Dominica"],
                            ["Gwadar", "PK", "Pakistan"],
                            ["Haifa", "IL", "Israel"],
                            ["Hajj", "SA", "Saudi Arabia"],
                            ["Halong", "KH", "Cambodia"],
                            ["Halongbay", "KH", "Cambodia"],
                            ["Hambantota", "LK", "Sri Lanka"],
                            ["Hamburg", "DE", "Germany"],
                            ["Hamilton", "NZ", "New Zealand"],
                            ["Hammerfest", "REU", "Europe"],
                            ["Hangzhou", "CN", "China"],
                            ["Hanoi", "VN", "Vietnam"],
                            ["Hardangerfjord", "REU", "Europe"],
                            ["Harrisburg", "US", "United States Of America"],
                            ["Hatshpsut", "EG", "Egypt"],
                            ["Haugesund", "NO", "Norway"],
                            ["Havana", "CU", "Cuba"],
                            ["Havant", "GB", "Great Britain"],
                            ["Hawaiian", "US", "United States Of America"],
                            ["Hawally", "KW", "Kuwait"],
                            ["Heckenberg", "AU", "Australia"],
                            ["Heidelberg", "FR", "France"],
                            ["Helsinki", "REU", "Europe"],
                            ["Hemel", "GB", "Great Britain"],
                            ["Heraklion", "REU", "Europe"],
                            ["Heroica", "MX", "Mexico"],
                            ["Hikkaduwa", "LK", "Sri Lanka"],
                            ["Hiroshima", "JP", "Japan"],
                            ["Hochiminhcity", "VN", "Vietnam"],
                            ["Hokkaido", "JP", "Japan"],
                            ["Holland", "AT", "Austria"],
                            ["Holyland", "RME", "MiddleEast"],
                            ["Homestead", "US", "United States Of America"],
                            ["Honduras", "HN", "Honduras"],
                            ["Hongkong", "HK", "Hong Kong"],
                            ["Honningsvag", "REU", "Europe"],
                            ["Honolulu", "US", "United States Of America"],
                            ["Hooghly", "BD", "Bangladesh"],
                            ["Houston", "US", "United States Of America"],
                            ["Hujand", "RME", "MiddleEast"],
                            ["Humble", "UK", "United Kingdom"],
                            ["Hungary", "HU", "Hungary"],
                            ["Hurghada", "EG", "Egypt"],
                            ["Ibiza", "ES", "Spain"],
                            ["Ice", "CA", "Canada"],
                            ["Iguassu", "BR", "Brazil"],
                            ["Ile", "RAF", "Africa"],
                            ["Ileauxcerfs", "RAF", "Africa"],
                            ["Imilchil", "MA", "Morocco"],
                            ["Incheon", "KR", "South Korea"],
                            ["Indiana", "US", "United States Of America"],
                            ["Indianapolis", "US", "United States Of America"],
                            ["Indonasia", "ID", "Indonesia"],
                            ["Indus", "DM", "Dominica"],
                            ["Inglewood", "US", "United States Of America"],
                            ["Inle", "MM", "Myanmar"],
                            ["Innersbruck", "UK", "United Kingdom"],
                            ["Innsbruck", "CH", "Switzerland"],
                            ["Interlaken", "CH", "Switzerland"],
                            ["Ipoh", "MY", "Malaysia"],
                            ["Iraklio", "GR", "Greece"],
                            ["Iran", "ES", "Spain"],
                            ["Iraq", "RME", "MiddleEast"],
                            ["Ireland", "UK", "United Kingdom"],
                            ["Israel", "IL", "Israel"],
                            ["Issykkul", "KG", "Kyrgyzstan"],
                            ["Istanbul", "TR", "Turkey"],
                            ["Italy", "FR", "France"],
                            ["Itlay", "IT", "Italy"],
                            ["Izmir", "TR", "Turkey"],
                            ["Jacksonville", "US", "United States Of America"],
                            ["Jaffna", "LK", "Sri Lanka"],
                            ["Jakar", "BT", "Bhutan"],
                            ["Jakarta", "ID", "Indonesia"],
                            ["Jamaica", "JM", "Jamaica"],
                            ["Jamalpur", "BD", "Bangladesh"],
                            ["Jasper", "CA", "Canada"],
                            ["Jeddah", "SA", "Saudi Arabia"],
                            ["Jerash", "JO", "Jordan"],
                            ["Jerusalem", "PS", "Palestine"],
                            ["Jessore", "BD", "Bangladesh"],
                            ["Jizan", "SA", "Saudi Arabia"],
                            ["Johannesburg", "ZA", "South Africa"],
                            ["Johor", "MY", "Malaysia"],
                            ["Johorbahru", "MY", "Malaysia"],
                            ["Jomsom", "NP", "Nepal"],
                            ["Jonesborough", "US", "United States Of America"],
                            ["Jordan", "IL", "Israel"],
                            ["Jim Corbett", "IN", "India"],
                            ["Jumeirah", "AE", "United Arab Emirates"],
                            ["Junrog", "SG", "Singapore"],
                            ["Jurong", "SG", "Singapore"],
                            ["Kagbeni", "NP", "Nepal"],
                            ["Kaghan", "PK", "Pakistan"],
                            ["Kaikoura", "NZ", "New Zealand"],
                            ["Kailash", "NP", "Nepal"],
                            ["Kajang", "MY", "Malaysia"],
                            ["Kalba", "AE", "United Arab Emirates"],
                            ["Kaley", "MM", "Myanmar"],
                            ["Kalipokhri", "NP", "Nepal"],
                            ["Kamchatka", "RU", "Russia"],
                            ["Kamloops", "CA", "Canada"],
                            ["Kampala", "UG", "Uganda"],
                            ["Kanazawa", "JP", "Japan"],
                            ["Kandy", "LK", "Sri Lanka"],
                            ["Kansas", "US", "United States Of America"],
                            ["Kanthmandu", "NP", "Nepal"],
                            ["Kapilavastu", "NP", "Nepal"],
                            ["Karachi", "PK", "Pakistan"],
                            ["Karak", "JO", "Jordan"],
                            ["Karank", "EG", "Egypt"],
                            ["Karbi", "TH", "Thailand"],
                            ["Karlaplan", "SE", "Sweden"],
                            ["Karnak", "EG", "Egypt"],
                            ["Karnaktemple", "EG", "Egypt"],
                            ["Katakombs", "EG", "Egypt"],
                            ["Katar", "AE", "United Arab Emirates"],
                            ["Kataragama", "LK", "Sri Lanka"],
                            ["Katarakama", "LK", "Sri Lanka"],
                            ["Kathmandu", "NP", "Nepal"],
                            ["Katy", "US", "United States Of America"],
                            ["Kauai", "US", "United States Of America"],
                            ["Kawaguchiko", "JP", "Japan"],
                            ["Kazan", "RU", "Russia"],
                            ["Kedah", "MY", "Malaysia"],
                            ["Kef", "IS", "Iceland"],
                            ["Kelala", "ET", "Ethiopia"],
                            ["Kemerovo", "RU", "Russia"],
                            ["Kendal", "UK", "United Kingdom"],
                            ["Kentucky", "US", "United States Of America"],
                            ["Kenya", "KE", "Kenya"],
                            ["Kerry", "IE", "Ireland"],
                            ["Key", "US", "United States Of America"],
                            ["Khardong", "LK", "Sri Lanka"],
                            ["Kharkiv", "UA", "Ukraine"],
                            ["Khuan", "TH", "Thailand"],
                            ["Khulna", "BD", "Bangladesh"],
                            ["Kiev", "REU", "Europe"],
                            ["Killarney", "IE", "Ireland"],
                            ["Kingston", "CA", "Canada"],
                            ["Kintamani", "ID", "Indonesia"],
                            ["Kitulgala", "LK", "Sri Lanka"],
                            ["Kleine", "IT", "Italy"],
                            ["Kloten", "CH", "Switzerland"],
                            ["Knysna", "ZA", "South Africa"],
                            ["Kohsamui", "TH", "Thailand"],
                            ["Koneswaram", "LK", "Sri Lanka"],
                            ["Konigsberg", "RU", "Russia"],
                            ["Konya", "TR", "Turkey"],
                            ["Kophangan", "TH", "Thailand"],
                            ["Kotiyal", "RFE", "Far East"],
                            ["Krabhi", "TH", "Thailand"],
                            ["Krabi", "TH", "Thailand"],
                            ["Krakow", "DE", "Germany"],
                            ["Krong", "KH", "Cambodia"],
                            ["Kruger", "ZA", "South Africa"],
                            ["Krugerregion", "ZA", "South Africa"],
                            ["Kuala", "SG", "Singapore"],
                            ["Kuala Lumpur", "MY", "Malaysia"],
                            ["Kuching", "MY", "Malaysia"],
                            ["Kudacan", "GB", "Great Britain"],
                            ["Kuden", "REU", "Europe"],
                            ["Kufa", "RME", "MiddleEast"],
                            ["Kumai", "ID", "Indonesia"],
                            ["Kunming", "CN", "China"],
                            ["Kusadasi", "TR", "Turkey"],
                            ["Kuta", "ID", "Indonesia"],
                            ["Kuzuko", "ZA", "South Africa"],
                            ["Kwantu", "ZA", "South Africa"],
                            ["Kynsna", "ZA", "South Africa"],
                            ["Kyoto", "JP", "Japan"],
                            ["Kyrgyzstan", "KG", "Kyrgyzstan"],
                            ["Lahijan", "IR", "Iran"],
                            ["Lahore", "PK", "Pakistan"],
                            ["Lakenaivasha", "KE", "Kenya"],
                            ["Lakenakuru", "KE", "Kenya"],
                            ["Lanarkshire", "UK", "United Kingdom"],
                            ["Landan", "UK", "United Kingdom"],
                            ["Landon", "UK", "United Kingdom"],
                            ["Lankanfinolhu", "MV", "Maldives"],
                            ["Laohekou", "REU", "Europe"],
                            ["Laos", "LA", "Laos"],
                            ["Larkana", "PK", "Pakistan"],
                            ["Larnaca", "CY", "Cyprus"],
                            ["Las", "ES", "Spain"],
                            ["Lasvegas", "US", "United States Of America"],
                            ["Latvia", "LV", "Latvia"],
                            ["Lausanne", "CH", "Switzerland"],
                            ["Lawrenceville", "US", "United States Of America"],
                            ["Lea", "GB", "Great Britain"],
                            ["Lebanon", "RME", "MiddleEast"],
                            ["Lehi", "US", "United States Of America"],
                            ["Lehigh", "US", "United States Of America"],
                            ["Leicester", "GB", "Great Britain"],
                            ["Leuven", "BE", "Belgium"],
                            ["Lexington", "US", "United States Of America"],
                            ["Liberia", "RAF", "Africa"],
                            ["Libreville", "GA", "Gabon"],
                            ["Liechtenstein", "FR", "France"],
                            ["Lima", "PE", "Peru"],
                            ["Limerick", "IE", "Ireland"],
                            ["Linggi", "MY", "Malaysia"],
                            ["Lisbon", "PT", "Portugal"],
                            ["Lithuania", "LT", "Lithuania"],
                            ["Lo-Manthang", "NP", "Nepal"],
                            ["Lobuche", "NP", "Nepal"],
                            ["Lomani", "IS", "Iceland"],
                            ["Londan", "UK", "United Kingdom"],
                            ["London", "UK", "United Kingdom"],
                            ["Long", "US", "United States Of America"],
                            ["Longford", "GB", "Great Britain"],
                            ["Longyearbyen", "SJ", "Svalbard &amp"],
                            ["Losangeles", "US", "United States Of America"],
                            ["Lost", "AE", "United Arab Emirates"],
                            ["Lucern", "UK", "United Kingdom"],
                            ["Lucerne", "FR", "France"],
                            ["Lugano", "CH", "Switzerland"],
                            ["Lukla", "NP", "Nepal"],
                            ["Lumbadzi", "MW", "Malawi"],
                            ["Lumpur", "SG", "Singapore"],
                            ["Luxembourg", "REU", "Europe"],
                            ["Luxor", "EG", "Egypt"],
                            ["Luzern", "CH", "Switzerland"],
                            ["Lyon", "FR", "France"],
                            ["Maasai", "KE", "Kenya"],
                            ["Macau", "HK", "Hong Kong"],
                            ["Macca", "SA", "Saudi Arabia"],
                            ["Maccau", "HK", "Hong Kong"],
                            ["Macedonia", "REU", "Europe"],
                            ["Machu", "PE", "Peru"],
                            ["Macquarie", "AU", "Australia"],
                            ["Madaba", "JO", "Jordan"],
                            ["Madagascar", "RAF", "Africa"],
                            ["Madame", "CH", "Switzerland"],
                            ["Madarihat", "BT", "Bhutan"],
                            ["Madina", "SA", "Saudi Arabia"],
                            ["Madrid", "ES", "Spain"],
                            ["Mainland", "UK", "United Kingdom"],
                            ["Makati", "RFE", "Far East"],
                            ["Makka", "SA", "Saudi Arabia"],
                            ["Makkah", "SA", "Saudi Arabia"],
                            ["Malaca", "TH", "Thailand"],
                            ["Malacca", "MY", "Malaysia"],
                            ["Malas", "SG", "Singapore"],
                            ["Malawi", "MW", "Malawi"],
                            ["Maldives", "MV", "Maldives"],
                            ["Malta", "MT", "Malta"],
                            ["Manado", "ID", "Indonesia"],
                            ["Manaiceland", "FJ", "Fiji"],
                            ["Manakamana", "NP", "Nepal"],
                            ["Manama", "BH", "Bahrain"],
                            ["Manaus", "BR", "Brazil"],
                            ["Manchester", "GB", "Great Britain"],
                            ["Mandalay", "MM", "Myanmar"],
                            ["Mandao", "PH", "Philippines"],
                            ["Mangolia", "RU", "Russia"],
                            ["Manila", "PH", "Philippines"],
                            ["Manile", "PH", "Philippines"],
                            ["Mansarovar", "NP", "Nepal"],
                            ["Manyara", "KE", "Kenya"],
                            ["Marble", "ZA", "South Africa"],
                            ["Marikina", "ROC", "Pacific/Oceania"],
                            ["Marina", "US", "United States Of America"],
                            ["Marine", "ID", "Indonesia"],
                            ["Market", "DM", "Dominica"],
                            ["Marrakech", "MA", "Morocco"],
                            ["Masai", "KE", "Kenya"],
                            ["Masaimara", "KE", "Kenya"],
                            ["Mascow", "RU", "Russia"],
                            ["Mashhad", "IR", "Iran"],
                            ["Masouleh", "IR", "Iran"],
                            ["Masouri", "GR", "Greece"],
                            ["Massachusetts", "US", "United States Of America"],
                            ["Matale", "LK", "Sri Lanka"],
                            ["Maui", "US", "United States Of America"],
                            ["Maurices", "IE", "Ireland"],
                            ["Mauritania", "RAF", "Africa"],
                            ["Maurtius", "MU", "Mauritius"],
                            ["Mecca", "RME", "MiddleEast"],
                            ["Meccah", "SA", "Saudi Arabia"],
                            ["Medan", "ID", "Indonesia"],
                            ["Medina", "SA", "Saudi Arabia"],
                            ["Mekong", "VN", "Vietnam"],
                            ["Melaka", "MY", "Malaysia"],
                            ["Melbourne", "AU", "Australia"],
                            ["Memphis", "EG", "Egypt"],
                            ["Mergouga", "MA", "Morocco"],
                            ["Merlion", "SG", "Singapore"],
                            ["Mexico", "US", "United States Of America"],
                            ["Miami", "US", "United States Of America"],
                            ["Michigan", "US", "United States Of America"],
                            ["Mihintale", "LK", "Sri Lanka"],
                            ["Milan", "FR", "France"],
                            ["Millicent", "AU", "Australia"],
                            ["Milpitas", "US", "United States Of America"],
                            ["Minneapolis", "US", "United States Of America"],
                            ["Minneriya", "LK", "Sri Lanka"],
                            ["Minorca", "ES", "Spain"],
                            ["Minsk", "BY", "Belarus"],
                            ["Minuwangoda", "LK", "Sri Lanka"],
                            ["Moheshpur", "BD", "Bangladesh"],
                            ["Moka", "RAF", "Africa"],
                            ["Moldova", "MD", "Moldova"],
                            ["Mombasa", "KE", "Kenya"],
                            ["Monaco", "MC", "Monaco"],
                            ["Monestries", "DM", "Dominica"],
                            ["Montenegro", "ME", "Montenegro"],
                            ["Monteriggioni", "IT", "Italy"],
                            ["Montevideo", "US", "United States Of America"],
                            ["Montreal", "CA", "Canada"],
                            ["Montreux", "CH", "Switzerland"],
                            ["Moratuwa", "LK", "Sri Lanka"],
                            ["Moreshes", "TH", "Thailand"],
                            ["Morocco", "MA", "Morocco"],
                            ["Morosis", "ID", "Indonesia"],
                            ["Moscow", "RU", "Russia"],
                            ["Moskow", "RFE", "Far East"],
                            ["Muktinath", "NP", "Nepal"],
                            ["Munich", "DE", "Germany"],
                            ["Muscat", "OM", "Oman"],
                            ["Musikot", "NP", "Nepal"],
                            ["Myconos", "GR", "Greece"],
                            ["Mykonos", "GR", "Greece"],
                            ["Myrtle", "US", "United States Of America"],
                            ["Nadi", "FJ", "Fiji"],
                            ["Nagoya", "JP", "Japan"],
                            ["Naiobi", "KE", "Kenya"],
                            ["Nairobi", "KE", "Kenya"],
                            ["Najaf", "RME", "MiddleEast"],
                            ["Nakuru", "KE", "Kenya"],
                            ["Namche", "NP", "Nepal"],
                            ["Nanaimo", "CA", "Canada"],
                            ["Naples", "IT", "Italy"],
                            ["Nara", "JP", "Japan"],
                            ["Narail", "BD", "Bangladesh"],
                            ["Narita", "JP", "Japan"],
                            ["Natal", "BR", "Brazil"],
                            ["Natore", "BD", "Bangladesh"],
                            ["Nauru", "NR", "Nauru"],
                            ["Nazareth", "IL", "Israel"],
                            ["Ncr", "RFE", "Far East"],
                            ["Negombo", "LK", "Sri Lanka"],
                            ["Nellaidhoo", "MV", "Maldives"],
                            ["Nepal", "NP", "Nepal"],
                            ["Nepalgunj", "NP", "Nepal"],
                            ["Netherlands", "NL", "Netherlands"],
                            ["Nevada", "US", "United States Of America"],
                            ["Newark", "US", "United States Of America"],
                            ["Newport", "US", "United States Of America"],
                            ["Newyork", "US", "United States Of America"],
                            ["Ngurah", "ID", "Indonesia"],
                            ["Niagara Falls", "US", "United States Of America"],
                            ["Nigerisrael", "RCA", "Caribbean"],
                            ["Nile", "EG", "Egypt"],
                            ["Nilecruise", "EG", "Egypt"],
                            ["Niue", "NU", "Niue"],
                            ["Nomads", "MA", "Morocco"],
                            ["Nong", "TH", "Thailand"],
                            ["Norfolk", "US", "United States Of America"],
                            ["Northtour", "RAF", "Africa"],
                            ["Norway", "US", "United States Of America"],
                            ["Nottingham", "GB", "Great Britain"],
                            ["Nusa", "ID", "Indonesia"],
                            ["Nuwara", "LK", "Sri Lanka"],
                            ["Nuwara-Eliya", "LK", "Sri Lanka"],
                            ["Nuwaraeliya", "LK", "Sri Lanka"],
                            ["Nyalam", "NP", "Nepal"],
                            ["Oklahoma", "RFE", "Far East"],
                            ["Omaha", "US", "United States Of America"],
                            ["Ontario", "CA", "Canada"],
                            ["Oosterhout", "NL", "Netherlands"],
                            ["Orange", "US", "United States Of America"],
                            ["Orchard", "SG", "Singapore"],
                            ["Oregon", "US", "United States Of America"],
                            ["Orkney", "GB", "Great Britain"],
                            ["Orlando", "US", "United States Of America"],
                            ["Osaka", "JP", "Japan"],
                            ["Oslo", "REU", "Europe"],
                            ["Ottawa", "CA", "Canada"],
                            ["Ouarzazate", "MA", "Morocco"],
                            ["Oudtshoorn", "ZA", "South Africa"],
                            ["Pabna", "BD", "Bangladesh"],
                            ["Pacific", "IS", "Iceland"],
                            ["Padang", "ID", "Indonesia"],
                            ["Pahang", "MY", "Malaysia"],
                            ["Pakistan", "PK", "Pakistan"],
                            ["Palastine", "IL", "Israel"],
                            ["Palau", "IT", "Italy"],
                            ["Palma", "ES", "Spain"],
                            ["Pamplemousse", "MU", "Mauritius"],
                            ["Pamukkale", "TR", "Turkey"],
                            ["Panama", "RSA", "South America"],
                            ["Pangboche", "NP", "Nepal"],
                            ["Pangkalanbun", "ID", "Indonesia"],
                            ["Papeete", "FR", "France"],
                            ["Papua", "PG", "Papua New Guinea"],
                            ["Paradise", "US", "United States Of America"],
                            ["Paraguay", "PY", "Paraguay"],
                            ["Paris", "FR", "France"],
                            ["Parish", "US", "United States Of America"],
                            ["Pasay", "PH", "Philippines"],
                            ["Pashupatinath", "NP", "Nepal"],
                            ["Pattaya", "TH", "Thailand"],
                            ["Pattivasal", "RIS", "Indian Subcontinent"],
                            ["Penang", "MY", "Malaysia"],
                            ["Pennington", "US", "United States Of America"],
                            ["Pennsylvania", "US", "United States Of America"],
                            ["Perdana", "SG", "Singapore"],
                            ["Perhentian", "MY", "Malaysia"],
                            ["Perth", "AU", "Australia"],
                            ["Peru", "PE", "Peru"],
                            ["Peshawar", "PK", "Pakistan"],
                            ["St. Petersburg", "RU", "Russia"],
                            ["Petra", "JO", "Jordan"],
                            ["Phakding", "NP", "Nepal"],
                            ["Phang", "TH", "Thailand"],
                            ["Pheuntsholing", "BT", "Bhutan"],
                            ["Phi Phi Islands", "TH", "Thailand"],
                            ["Philadelphia", "US", "United States Of America"],
                            ["Philippines", "ROC", "Pacific/Oceania"],
                            ["Phnompenh", "KH", "Cambodia"],
                            ["Phuket", "TH", "Thailand"],
                            ["Phulshillong", "BT", "Bhutan"],
                            ["Phunakha", "BT", "Bhutan"],
                            ["Phunchulling", "BT", "Bhutan"],
                            ["Phuntsholing", "BT", "Bhutan"],
                            ["Pilgrims", "UK", "United Kingdom"],
                            ["Pillipens", "RFE", "Far East"],
                            ["Pinnawala", "LK", "Sri Lanka"],
                            ["Pisa", "CH", "Switzerland"],
                            ["Plan", "ES", "Spain"],
                            ["Plymouth", "US", "United States Of America"],
                            ["Poblet", "ES", "Spain"],
                            ["Pointe", "MU", "Mauritius"],
                            ["Poland", "PL", "Poland"],
                            ["Polannaruwa", "LK", "Sri Lanka"],
                            ["Polonnaruwa", "LK", "Sri Lanka"],
                            ["Polynesia", "WS", "Samoa"],
                            ["Pondoktangguy", "ID", "Indonesia"],
                            ["Pontianak", "ID", "Indonesia"],
                            ["Poon", "NP", "Nepal"],
                            ["Portland", "US", "United States Of America"],
                            ["Porto", "ES", "Spain"],
                            ["Portugal", "REU", "Europe"],
                            ["Prague", "CZ", "Czech Republic"],
                            ["Prasilin", "SC", "Seychelles"],
                            ["Praslin", "SC", "Seychelles"],
                            ["Princes", "AU", "Australia"],
                            ["Puebla", "MX", "Mexico"],
                            ["Puerto", "ES", "Spain"],
                            ["Puket", "TH", "Thailand"],
                            ["Pullman", "US", "United States Of America"],
                            ["Purang", "NP", "Nepal"],
                            ["Putra", "SG", "Singapore"],
                            ["Putrajaya", "MY", "Malaysia"],
                            ["Queensland", "AU", "Australia"],
                            ["Queenstown", "NZ", "New Zealand"],
                            ["Quezon", "PH", "Philippines"],
                            ["Quito", "EC", "Ecuador"],
                            ["Qutar", "RME", "MiddleEast"],
                            ["Kuwait", "SA", "Saudi Arabia"],
                            ["Raba", "MA", "Morocco"],
                            ["Rangpur", "BD", "Bangladesh"],
                            ["Ranipauwa", "NP", "Nepal"],
                            ["Ravanusa", "IT", "Italy"],
                            ["Red", "AE", "United Arab Emirates"],
                            ["Redwood", "US", "United States Of America"],
                            ["Rennes", "FR", "France"],
                            ["Reston", "US", "United States Of America"],
                            ["Rhine", "UK", "United Kingdom"],
                            ["Richmond", "US", "United States Of America"],
                            ["Rio", "BR", "Brazil"],
                            ["Riska", "REU", "Europe"],
                            ["Ritigala", "LK", "Sri Lanka"],
                            ["River", "GB", "Great Britain"],
                            ["Riyadh", "SA", "Saudi Arabia"],
                            ["Road", "VG", "Virgin Islands"],
                            ["Rocca", "IT", "Italy"],
                            ["Romania", "RO", "Romania"],
                            ["Rome", "IT", "Italy"],
                            ["Rotorua", "NZ", "New Zealand"],
                            ["Roudkhan", "IR", "Iran"],
                            ["Sagam", "DM", "Dominica"],
                            ["Sagarmatha", "NP", "Nepal"],
                            ["Saint", "RCA", "Caribbean"],
                            ["Saitama", "JP", "Japan"],
                            ["Sakkra", "EG", "Egypt"],
                            ["Salalah", "OM", "Oman"],
                            ["Salvador", "BR", "Brazil"],
                            ["Salzburg", "CZ", "Czech Republic"],
                            ["Samarkand", "UZ", "Uzbekistan"],
                            ["Samburu", "KE", "Kenya"],
                            ["San Diego", "US", "United States Of America"],
                            ["San Francisco", "US", "United States Of America"],
                            ["Sangir", "ID", "Indonesia"],
                            ["Sanluisobipspo", "US", "United States Of America"],
                            ["Santa", "BO", "Bolivia"],
                            ["Santacruze", "EC", "Ecuador"],
                            ["Santiago", "RSA", "South America"],
                            ["Santo", "DO", "Dominican Republic"],
                            ["Santorini", "GR", "Greece"],
                            ["Sarangkot", "NP", "Nepal"],
                            ["Saratoga", "ES", "Spain"],
                            ["Scandinavia", "REU", "Europe"],
                            ["Schaffhausen", "REU", "Europe"],
                            ["Schiphol", "NL", "Netherlands"],
                            ["Scotland", "REU", "Europe"],
                            ["Sea", "SG", "Singapore"],
                            ["Seattle", "US", "United States Of America"],
                            ["Semarang", "ID", "Indonesia"],
                            ["Senegal", "SN", "Senegal"],
                            ["Sentosa", "ID", "Indonesia"],
                            ["Sentosa Island", "SG", "Singapore"],
                            ["Seorak", "KR", "South Korea"],
                            ["Seoul", "KR", "South Korea"],
                            ["Sepang", "MY", "Malaysia"],
                            ["Serengeti", "TZ", "Tanzania"],
                            ["Seri", "RIS", "Indian Subcontinent"],
                            ["Serua", "ROC", "Pacific/Oceania"],
                            ["Sevilla", "ES", "Spain"],
                            ["Shanghai", "CN", "China"],
                            ["Shanti", "DM", "Dominica"],
                            ["Sharjah", "AE", "United Arab Emirates"],
                            ["Shenzhen", "CN", "China"],
                            ["Shinjuku", "JP", "Japan"],
                            ["Shinkansen", "JP", "Japan"],
                            ["Shiraz", "IR", "Iran"],
                            ["Siberia", "RU", "Russia"],
                            ["Sierranegravocano", "EC", "Ecuador"],
                            ["Sigiriya", "LK", "Sri Lanka"],
                            ["Siingapore", "RFE", "Far East"],
                            ["Silang", "PH", "Philippines"],
                            ["Simalla", "ET", "Ethiopia"],
                            ["Simmikot", "NP", "Nepal"],
                            ["Simsbury", "US", "United States Of America"],
                            ["Sinagapore", "SG", "Singapore"],
                            ["Skopje", "MK", "Macedonia"],
                            ["Skoura", "MA", "Morocco"],
                            ["Slovakia", "DE", "Germany"],
                            ["Slovenia", "IT", "Italy"],
                            ["Smila", "UA", "Ukraine"],
                            ["Smithsonian", "US", "United States Of America"],
                            ["Snow", "AE", "United Arab Emirates"],
                            ["Sochi", "RU", "Russia"],
                            ["Soekarno", "ID", "Indonesia"],
                            ["Sofia", "REU", "Europe"],
                            ["Solomon", "SB", "Solomon Islands"],
                            ["Soule", "KR", "South Korea"],
                            ["Southampton", "UK", "United Kingdom"],
                            ["Spain", "ES", "Spain"],
                            ["Sparta", "US", "United States Of America"],
                            ["Sphinx", "EG", "Egypt"],
                            ["Srilanka", "LK", "Sri Lanka"],
                            ["Stanfordville", "US", "United States Of America"],
                            ["Stockholm", "SE", "Sweden"],
                            ["Storm", "AU", "Australia"],
                            ["Strasbourg", "FR", "France"],
                            ["Stumpa", "DM", "Dominica"],
                            ["Stuttgart", "DE", "Germany"],
                            ["Sucre", "VE", "Venezuela"],
                            ["Summerkhand", "UZ", "Uzbekistan"],
                            ["Superstargeminicruise", "MY", "Malaysia"],
                            ["Surabaya", "ID", "Indonesia"],
                            ["Surry", "AU", "Australia"],
                            ["Swakopmund", "NA", "Namibia"],
                            ["Swarovski", "REU", "Europe"],
                            ["Switzerland", "FR", "France"],
                            ["Sydney", "AU", "Australia"],
                            ["Sylhet", "BD", "Bangladesh"],
                            ["Syria", "RME", "MiddleEast"],
                            ["Taiwang", "RFE", "Far East"],
                            ["Tanjungharapan", "ID", "Indonesia"],
                            ["Tannersville", "US", "United States Of America"],
                            ["Tanzania", "KE", "Kenya"],
                            ["Tarboche", "NP", "Nepal"],
                            ["Taringa", "AU", "Australia"],
                            ["Tashkent", "UZ", "Uzbekistan"],
                            ["Tasmania", "AU", "Australia"],
                            ["Taveuni", "FJ", "Fiji"],
                            ["Tawangmangu", "ID", "Indonesia"],
                            ["Thailand", "TH", "Thailand"],
                            ["Thakudwara", "NP", "Nepal"],
                            ["Thangnak", "NP", "Nepal"],
                            ["Thimpu", "BT", "Bhutan"],
                            ["Thinadhoo", "MV", "Maldives"],
                            ["Thirappane", "LK", "Sri Lanka"],
                            ["Thulusdhoo", "MV", "Maldives"],
                            ["Tiananmen", "CN", "China"],
                            ["Tibet", "CN", "China"],
                            ["Timberlake", "US", "United States Of America"],
                            ["Timor", "ID", "Indonesia"],
                            ["Tioman", "MY", "Malaysia"],
                            ["Tirana", "REU", "Europe"],
                            ["Tirinadad", "RCA", "Caribbean"],
                            ["Tissa", "LK", "Sri Lanka"],
                            ["Todra", "MA", "Morocco"],
                            ["Tokyo", "JP", "Japan"],
                            ["Tongi", "BD", "Bangladesh"],
                            ["Tongsa", "BT", "Bhutan"],
                            ["Tonka", "UK", "United Kingdom"],
                            ["Tonle", "RFE", "Far East"],
                            ["Tornado", "US", "United States Of America"],
                            ["Toronto", "CA", "Canada"],
                            ["Triconomallee", "LK", "Sri Lanka"],
                            ["Trincomalee", "LK", "Sri Lanka"],
                            ["Trinidad", "TT", "Trinidad And Tobago"],
                            ["Trongsa", "BT", "Bhutan"],
                            ["Trou", "MU", "Mauritius"],
                            ["Tsavo", "KE", "Kenya"],
                            ["Tunisia", "TN", "Tunisia"],
                            ["Turkey", "TR", "Turkey"],
                            ["Turku", "FI", "Finland"],
                            ["Uganda", "UG", "Uganda"],
                            ["Ukraine", "UA", "Ukraine"],
                            ["Umarh", "SA", "Saudi Arabia"],
                            ["Unawatuna", "LK", "Sri Lanka"],
                            ["Universal", "SG", "Singapore"],
                            ["Uruguay", "UY", "Uruguay"],
                            ["USA", "US", "United States Of America"],
                            ["Uzbekistan", "UZ", "Uzbekistan"],
                            ["Vancouver", "CA", "Canada"],
                            ["Vanish", "UK", "United Kingdom"],
                            ["Vapiano", "GB", "Great Britain"],
                            ["Varani", "US", "United States Of America"],
                            ["Vatican", "REU", "Europe"],
                            ["Vaughan", "CA", "Canada"],
                            ["Venezuela", "VE", "Venezuela"],
                            ["Venice", "FR", "France"],
                            ["Verginia", "US", "United States Of America"],
                            ["Victoria", "MT", "Malta"],
                            ["Vietnam", "VN", "Vietnam"],
                            ["Virginia", "US", "United States Of America"],
                            ["Waitomo", "NZ", "New Zealand"],
                            ["Wanak", "NZ", "New Zealand"],
                            ["Wanaka", "NZ", "New Zealand"],
                            ["Wangdi", "BT", "Bhutan"],
                            ["Warsaw", "DE", "Germany"],
                            ["Washington", "US", "United States Of America"],
                            ["Wellington", "NZ", "New Zealand"],
                            ["Williamsburg", "US", "United States Of America"],
                            ["Yangon", "MM", "Myanmar"],
                            ["Yojiya", "SE", "Sweden"],
                            ["Zagreb", "IT", "Italy"],
                            ["Zambezi", "RME", "MiddleEast"],
                            ["Zamboanga", "PH", "Philippines"],
                            ["Zanasker", "DM", "Dominica"],
                            ["Zanzibar", "US", "United States Of America"],
                            ["Zaragoza", "ES", "Spain"],
                            ["Zermatt", "CH", "Switzerland"],
                            ["Zimbabwe", "ZA", "South Africa"],
                            ["Zimut", "RME", "MiddleEast"],
                            ["Zurich", "CH", "Switzerland"],
                            ["Zuthulphuk", "NP", "Nepal"],
                            ["Portblair", "IN", "India"],
                            ["Rohtang Pass", "IN", "India"],
                            ["Kashmir", "IN", "India"],
                            ["Vaishno Devi", "IN", "India"],
                            ["Tamilnadu", "IN", "India"],
                            ["Dharamsala", "IN", "India"],
                            ["Singapore", "SG", "Singapore"],
                            ["United Arab Emirates", "AE", "United Arab Emirates"],
                            ["Indonesia", "ID", "Indonesia"],
                            ["United States Of America", "US", "United States Of America"],
                            ["Europe", "REU", "Europe"],
                            ["Saudi Arabia", "SA", "Saudi Arabia"],
                            ["United Kingdom", "UK", "United Kingdom"],
                            ["Russia", "RU", "Russia"],
                            ["Seychelles", "SC", "Seychelles"],
                            ["South Africa", "ZA", "South Africa"],
                            ["Belarus", "BY", "Belarus"],
                            ["South Korea", "KR", "South Korea"],
                            ["New Zealand", "NZ", "New Zealand"],
                            ["South America", "RSA", "South America"],
                            ["Qatar", "QA", "Qatar"],
                            ["Iceland", "IS", "Iceland"],
                            ["North America", "RNA", "North America"],
                            ["Czech Republic", "CZ", "Czech Republic"],
                            ["Sweden", "SE", "Sweden"],
                            ["Kazakhstan", "KZ", "Kazakhstan"],
                            ["Oman", "OM", "Oman"],
                            ["Myanmar", "MM", "Myanmar"],
                            ["Argentina", "AR", "Argentina"],
                            ["Namibia", "NA", "Namibia"],
                            ["New Delhi", "IN", "India"],
                            ["New York", "US", "United States Of America"],
                        ],
                        n = [];
                    for (i = 0; i < t.length; i++) ~(t[i][0] + " " + t[i][1]).toLowerCase().indexOf(e) && n.push(t[i]);
                    a(n);
                },
                renderItem: function (e, a) {
                    a = a.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                    var t = new RegExp("(" + a.split(" ").join("|") + ")", "gi");
                    return (
                        '<div class="autocomplete-suggestion" data-langname="' +
                        e[0] +
                        '" data-lang="' +
                        e[1] +
                        '" data-countryname="' +
                        e[2] +
                        '" data-val="' +
                        a +
                        '">' +
                        e[0].replace(t, "<b>$1</b>") +
                        "&nbsp;" +
                        e[2].replace(t, "<b>$1</b>") +
                        "</div>"
                    );
                },
                onSelect: function (e, a, t) {
                    var i = r.getAttribute("data-formid"),
                        n = r.id;
                    (document.getElementById(r.id).value = t.getAttribute("data-langname")),
                        n == "depar_city" + i
                            ? ((document.getElementById("frm_country" + i).value = t.getAttribute("data-lang")),
                              (document.getElementById("f_country" + i).value = t.getAttribute("data-countryname")),
                              (document.getElementById("countryfrm_full" + i).value = t.getAttribute("data-countryname")),
                              (document.getElementById("full_address" + i).value = t.getAttribute("data-lang") + "," + t.getAttribute("data-countryname")))
                            : n == "dest" + i && ((document.getElementById("country" + i).value = t.getAttribute("data-lang")), (document.getElementById("country_full" + i).value = t.getAttribute("data-countryname")));
                },
            });
        });
    });
