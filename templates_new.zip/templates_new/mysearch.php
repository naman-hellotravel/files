<?php
$data="silk route,sillery gaon,aritar,nathan valley,padamchen,rishikhola,zuluk";
$keyword="sikkim, ,and meghalaya";
if (!full_text_search($data,$keyword)){
	echo "exit";
}
function full_text_search($keyword, $description)
{
    if (!empty($keyword)) {
        $keyword = strtolower($keyword);
        $description = strtolower($description);
        $keyword_arr = explode(",", $keyword);
	print_r($keyword_arr);
        foreach ($keyword_arr as $value) {
                $value=trim($value);
            if(!$value)
               continue;
            if (is_numeric(@strpos($description, $value))) {
		echo "Dushyant";
                return true;
            }
        }
        return false;
    }
    return false;

}


?>
