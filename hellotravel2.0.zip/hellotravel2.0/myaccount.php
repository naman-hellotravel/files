<?php
require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
require("/home/indiamart/public_html/hellotravel-agents/includes/resize.php");
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
  require($full_path_to_public_program."/config/TplLoad.php");
  $smarty_obj = new TplLoad();
  require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");
   $is_cookieignore = 0;
   if(isset($_COOKIE['loginvalue'])){
    $loguserdata = check_valid_login();
      if(empty($loguserdata)){
                  header('location:./logout.php');
                  exit;
          }	 

   $tuid = $loguserdata["USER_ID"];
    
  }else if($lead_id != ""){
    $sqluser = dbprocess("SELECT USER_ID , LOGIN_ID , MCOUNTRY_CODE   FROM tbl_leads l , tbl_traveller_logins t where l.TUID = t.USER_ID and l.TBL_LEAD_ID = '".$lead_id."' ");
    if(mysql_num_rows($sqluser)){
    $is_cookieignore = 1;
      $userlogindata = mysql_fetch_assoc($sqluser);
          $tuid = $userlogindata["USER_ID"];
              $crypt_mail  = base64_encode($userlogindata["LOGIN_ID"]);
              $cookies_name = 'loginvalue';
              $crypt_mail = str_replace("=","",$crypt_mail);
              setcookie($cookies_name, $crypt_mail, time() + (10 * 365 * 24 * 60 * 60), "/",'hellotravel.com');
          $logincountry_code = $userlogindata["MCOUNTRY_CODE"] != "" ? $userlogindata["MCOUNTRY_CODE"] : "91";
              $cookie_name = 'countrycookie';
              $crypt_country = str_replace("+" , "" , $logincountry_code);
              $crypt_country = str_replace("=","",$crypt_country);
              setcookie($cookie_name, $crypt_country, time() + (23 * 24 * 60 * 60), "/",'hellotravel.com');
         
       
    }
    else{
      
                      header('location:./logout.php');
                      exit;
    }

  }
if(empty($tuid)){

	header('location:./logout.php');
                      exit;

}
 if($lead_id == ""){
    $userleaddata = getLastValidLead($tuid);
    $lead_id= $userleaddata;
 }
if(isset($_GET["verify"]) && !empty($_GET["verify"])){
      $encrypt = base64_decode($_GET["verify"]);
      $encryptarray = explode("@" , $encrypt);
      $verifyid = $encryptarray[0];
      $verifydate = date("Y-m-d" , strtotime($encryptarray[1]));
      $now = time(); // or your date as well
      $verifytime = strtotime($verifydate);
      $sql_select = dbprocess("select * from tbl_traveller_logins where USER_ID='".$verifyid."' and mobile_verified =  1");
      $userarray = mysql_fetch_assoc($sql_select);
      $datediff = $now - $verifytime;
      $datediff = round($datediff / (60 * 60 * 24));
      if($datediff <= 3 && $userarray["EMAIL_STATUS"] == 1){
        dbprocess("update tbl_traveller_logins set EMAIL_ID = NULL where EMAIL_ID = '".$userarray['TEMAIL_ID']."' ");
        dbprocess("update tbl_traveller_logins set EMAIL_ID =  '".$userarray['TEMAIL_ID']."' , TEMAIL_ID = NULL , EMAIL_STATUS = '0' where USER_ID = ".$verifyid." ");
      }else{
        $error = "Email Expired";
      }
  }


 $sql_select=dbprocess("select * from tbl_traveller_logins where USER_ID='".$tuid."' and mobile_verified = 1 ");
    $userarray = mysql_fetch_assoc($sql_select);

if(isset($_POST["userimg"]) && !empty($_POST["userimg"])){
  $file_name = $_FILES["file"]["name"];
  $file_type = pathinfo($file_name, PATHINFO_EXTENSION);
  $new_filename = "user_".date("Ymd").time().".".$file_type;
  $finfo = finfo_open(FILEINFO_MIME_TYPE);
  $mime = finfo_file($finfo, $_FILES['file']['tmp_name']);
  $valid_array = ['image/png','image/jpeg','image/jpeg','image/jpeg','image/gif','image/bmp','image/vnd.microsoft.icon','image/tiff','image/tiff','image/svg+xml','image/svg+xml' , 'text/plain' , 'application/pdf' , 'application/msword'];
  if(in_array($mime , $valid_array)){

  if(in_array(strtolower($file_type), [ 'jpeg', 'jpg', 'png'])) {
    $resizeObj = new ResizeImage($_FILES['file']['tmp_name']);
    $resizeObj->resizeTo(180, 180);
    $resizeObj->saveImage('/home/indiamart/public_html/hellotravel/hellotravel/config/images/travelerimages/'.$new_filename, "80");
    dbprocess("update tbl_traveller_logins set PROFILE_PIC = '".$new_filename."' where USER_ID = ".$tuid."");
  }else {
    echo 'Error : Only JPEG, PNG allowed';
  }

  }else {
    echo 'Error : Only JPEG, PNG allowed';
  }

}


  if(isset($_POST["updateuser"]) && !empty($_POST["updateuser"])){
     $fieldname = $_POST["fname"];
     $data = trim($_POST["data"]);
     if($fieldname == "EMAIL_ID"){
      $sql_check = dbprocess("select USER_ID from tbl_traveller_logins where EMAIL_ID = '".$data."' and USER_ID != ".$tuid." and mobile_verified = 1");
      if(mysql_num_rows($sql_check)){
        
        dbprocess("update tbl_traveller_logins set TEMAIL_ID = '".$data."' , EMAIL_ID = NULL where USER_ID = ".$tuid."");
        
      } else{
        
        dbprocess("update tbl_traveller_logins set EMAIL_ID = '".$data."' , TEMAIL_ID = NULL  where USER_ID = ".$tuid."");
      }
     }else{
     if(!empty($data) && $data != ""){
        dbprocess("update tbl_traveller_logins set $fieldname = '".$data."' where USER_ID = ".$tuid."");
     }
    }

  }

  if(isset($_POST["sendvefifylink"]) && !empty($_POST["sendvefifylink"]) ){
		verifytravelleremail($userarray["TEMAIL_ID"] , $tuid , $userarray["TRAVELLER_NAME"]);
   }

   
   

$sql_prefer=dbprocess("select * from tbl_traveller_preferences where USER_ID='".$tuid."'");
$userprefer = mysql_fetch_assoc($sql_prefer);




$meta = "My Account";
$userpass = $_COOKIE['userpass'];
$smarty_obj->assign('page','my_trips_new');
$smarty_obj->assign('meta_string' , $meta);
$smarty_obj->assign('pagename' , "My Account");
$smarty_obj->assign('is_cookieignore' , $is_cookieignore);
$smarty_obj->assign('userarray',$userarray);
$smarty_obj->assign('userprefer',$userprefer);
$smarty_obj->assign('userpass' , $userpass);
$smarty_obj->assign('selected' , "Selected");

$smarty_obj->display('hellotravel2.0/header_demo.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/myaccount.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');


?>