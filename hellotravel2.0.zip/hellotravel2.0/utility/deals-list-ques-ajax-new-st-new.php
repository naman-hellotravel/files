<?php
require('/home/indiamart/public_html/hellotravel-agents/includes/common.php');
    $solr_url = 'http://172.16.31.11:8983/solr/hellotravel_deals-new/select?q=fcp_uid%3A%22102277%22%20AND%20destinations_covered%3A%22'.$place_to.'%22';
    $jsondata = file_get_contents($solr_url);
    $mainData_new = json_decode($jsondata);
    $count = $mainData_new->response->numFound;
    $mainData_new = $mainData_new->response->docs;
    $packageDesign = '';
    if($count){
    	$packageDesignNew = array("mainData_new"=>$mainData_new,"place"=>Ucfirst($place_to),"status"=>$count);
   	$smarty_obj->assign('packageDesignnew',$packageDesignNew);
    }else{
  	$packageDesignNew = array("mainData_new"=>array(),"place"=>"","status"=>0);
   	$smarty_obj->assign('packageDesignnew',$packageDesignNew);

    }
    $questionDesignNew = getquesDesignnew($place_to,$pts_id_v,$ttd_id_v);
   $smarty_obj->assign('questiondesignnew',$questionDesignNew);

function getquesDesignnew($place,$pts_id_v=0,$ttd_id_v=0)
{
    $ques = array("What is the best time to visit $place","How to reach $place","What is $place famous for","Things to do in $place","What kind of trip is this $place best suited for","How many days should I plan for $place");
	
    $quesans = array();

    $place_array=array("shimla","goa","ooty","nainital","agra","dharamshala","wayanad","gangotri","somnath","mahabaleshwar");

        $place_lower=strtolower($place);
    if(in_array(strtolower($place),  $place_array)){
                #$ques = array("All");
    }
        $quest_con="";

        if($pts_id_v > 0 && !empty($pts_id_v)){
                $quest_con=" and  places_id=$pts_id_v ";
        }else if($ttd_id_v > 0 && !empty($ttd_id_v)){
                $quest_con=" and  dest_id=$ttd_id_v ";

        }

    foreach($ques as $key=>$val){
          $query = "select id,text_entered from tbl_question_answer where traveller_id=2329634 and text_entered like '%".$val."%' and status=1 $quest_con";
          if($val =='All'){
                $query = "select id,text_entered from tbl_question_answer where traveller_id=2329634 and status=1 and question_id=0 $quest_con";
          }
         $sql = dbprocess($query);
         if(mysql_num_rows($sql)){
                while($row=mysql_fetch_assoc($sql)){
                        $val=$row['text_entered'];
                        $rs = dbprocess("select text_entered from tbl_question_answer where question_id='".$row['id']."' and status=1;");
                        if(mysql_num_rows($rs))
                        {
                         $row = mysql_fetch_assoc($rs);
			 if($row['text_entered'] != ""){
                         $quesans[$val] = strip_tags($row['text_entered']);
			 }else{
			continue;
			 }
                        }
                 }
        }
        }
return $quesans;
}
?>

