<?php
require_once("/home/indiamart/public_html/hellotravel-agents/includes/package_relevency_module_list.php");
require_once("/home/indiamart/public_html/hellotravel-agents/includes/package_relevency_module_free.php");
require_once("/home/indiamart/public_html/hellotravel/includes/genrateTravelGuide.php");
include '/home/indiamart/public_html/hellotravel-agents/includes/common.php';
#exit;
if(isset($_REQUEST['function']) && $_REQUEST['function']=='autoloaddeals'){
$all_data = $_REQUEST['all_data'];

$rowsPerPage = $all_data['rowperpage'];	
$rowsPerPage_free = $all_data['rowperpage_free'];	
$pagenumber = $_REQUEST['pageno'];
if($pagenumber>1){
	$offset =  ($pagenumber - 1) * $rowsPerPage;
	$offset_free =  ($pagenumber - 1) * $rowsPerPage_free;
}
else{
	$offset =1;
	$offset_free =1;
}

$r=new package_relevence_module_list(array("type"=>"and","start"=>$offset ,"rows"=>$rowsPerPage));
$r_free=new package_relevence_module_free(array("type"=>"and","start"=>$offset_free ,"rows"=>$rowsPerPage_free));

$data =$r->get_packages($_REQUEST["filter_query"]);

$numfound_main=$data["count"];
if($numfound_main ==0){
$r_free=new package_relevence_module_free(array("type"=>"and","start"=>$offset_free ,"rows"=>25,"nodest"=>1));
}
$data_free =$r_free->get_packages($_REQUEST["filter_query"]);

$numfound_main=$data["count"];
$final_array_main=$data["result"];
$numfound_free=$data_free["count"];
$final_array_free=array();
$final_array_free=$data_free["result"];
#print_r(array("start"=>$offset ,"rows"=>$rowsPerPage,$_REQUEST));
$final_array_main5 = array_merge($final_array_main,$final_array_free);
$all_deals_data = array();
$all_deals_list = array();

$imgpath = "https://www.hlimg.com/images/deals/360X230/";
if($numfound_free >0 || $numfound_main > 0)
{
   // echo "soumya";
   $counter_premium=0;
    $premium_array_deals=array();
     $i=1;
    foreach($final_array_main5 as $val)
    {   
	    if($i==21){
		 break;   
	    }    
    $all_deals_data['destinations_covered_array'] = $val->destinations_covered;
    $all_deals_data['destinations_covered_text'] = $val->destinations_covered_text;
    $all_deals_data['departure_from'] = $val->departure_from;
    $all_deals_data['form_type'] = $val->form_type;
    $all_deals_data['nid_url'] = $val->nid.".html";
    $all_deals_data['nid'] = $val->nid;
     if($val->url){
       $all_deals_data['nid_url'] = $val->url;
      }
      $pns_num='';
        $pns_num_plus='';
        if(isset($_REQUEST["stat"]) && $_REQUEST["stat"] == '2'){
                $val->title= $val->title."--".$val->priority;
        }

        $all_deals_data['pstatuslc']=$val->pstatus;
        $package_count++;
        $all_deals_data['fcp_uidlc'] = $val->fcp_uid;
        $photo='';
        $deals_rating='';
        $p_symbol='';
        $p_value='';
        $photo_array=array();
        $all_deals_data['idlc'] = $val->id;
        $all_deals_data['destination_countrylc'] = $val->destination_country;
        if(count($destinations_themelc)==0){
            $all_deals_data['destinations_themelc']=$val->destinations_theme;
          }
        $all_deals_data['from_dtlc'] = $val->from_dt;
        $all_deals_data['to_dtlc'] = $val->to_dt;
        $all_deals_data['fcp_uidlc'] = $val->fcp_uid;
        $all_deals_data['ts_status'] = $val->ts_status;
        $all_deals_data['bap_status'] = $val->bap_status;
        $all_deals_data['inclusion_exclusionlc'] = array_filter(unserialize($val->inclusion_exclusion));
       $all_deals_data['inclusion_exclusionlc'] = array_slice($all_deals_data['inclusion_exclusionlc'], 0, 5, true);
        $all_deals_data['converted_pricelc'] = $val->price;
    if($_REQUEST[stat] == 2){
        $all_deals_data['titlelc'] = $val->tbl_login_companyname." ".$val->title;
    }else{
        $all_deals_data['titlelc'] = $val->title;
    }
    $all_deals_data['itinerary'] = $val->itinerary_space;
    $all_deals_data['form_version'] = $val->form_version;
        $all_deals_data['package_typelc'] = $val->package_type;
        $all_deals_data['durationlc']=$val->duration;
        $all_deals_data['group_deal'] = $val->group_deal;
        $all_deals_data['dest_leader_from_city'] = $val->dest_leader_from_city;
        $all_deals_data['dest_leader_to_city'] = $val->dest_leader_to_city;
        $all_deals_data['ptt_service_flag'] = $val->ptt_service_flag;
        $all_deals_data['booking_status'] = $val->booking_status;
        $all_deals_data['sponsored_status']=$val->sponsored_status;
        $all_deals_data['random_prices'] = $val->random_prices;
        //$destinations_coveredlc=$val->destinations_covered_text; #implode(',',$val->destinations_covered);
        $all_deals_data['tbl_login_companynamelc']  = $val->tbl_login_companyname;
        $all_deals_data['tbl_login_creditpointslc'] = $val->tbl_login_creditpoints;
        $all_deals_data['tbl_login_idlc'] = $val->tbl_login_id;
       $premium_package=0;
        
        $premium_array_deals[$val->nid]=1;
       
        $pns_numlc=isset($val->pns_num) ? $val->pns_num : '';
        $nidlc=$val->nid;
        $all_deals_data['nidlc'];
         $idd=$nidlc;
        $all_deals_data['pathlc'] = $val->path;
        $all_deals_data['p_symbol'] = 'INR';
    $all_deals_data['tour_days'] = $val->days;
    $all_deals_data['response_rate'] = $val->response_rate;
    $all_deals_data['star_rating_search'] = $val->star_rating_search;
        $p_value=$all_deals_data['converted_pricelc'];
    $all_deals_data['isonline'] = $val->isonline;
    if(!$p_value){
        $p_value=$val->converted_price;
    }

    $all_deals_data['p_value'] = number_format($p_value); 
    $photo=$imgpath.$all_deals_data['pathlc'];

    if(empty($all_deals_data['pathlc']))
    {
         $photo="https://www.hellotravel.com/hellotravel/images/holiday.png";
    }
    $all_deals_data['photo'] = $photo;
     $destination=$all_deals_data['destinations_covered_text'];
         $destination=preg_replace('/,$/','',$destination);
        $destination=preg_replace('/,,/',',',$destination);
        

        $nid=$nidlc;
        $dest_link_var="";
        $dest_explode=explode(",",$destination);
        $dest_explode = array_map('ucfirstfun', $dest_explode);
        $dest_explode = array_unique($dest_explode);
        $dest_exp_count=0;
        $dest_first= $dest_explode[0];


if(count($dest_explode)>=5)
{
if(in_array($place_to,$dest_explode))
{
    $pos=array_search($place_to,$dest_explode);
    if($pos>=4)
    {
        $random=rand(0,2);
        $temp=$dest_explode[$random];
        $dest_explode[$random]=$dest_explode[$pos];
        $dest_explode[$pos]=$temp;
    }

    }

}


$all_deals_data['pack_dest_comma_seprated'] = implode(", ",array_unique($dest_explode));
        $log_id=$tbl_login_idlc;

        $credit_points=$tbl_login_creditpointslc;
        $comp_name=$tbl_login_companynamelc;
        $comp_name=substr($company_name,20);


        if($pns_numlc != "" && !empty($pns_numlc)){
            $pns_num_plus="+".$pns_numlc;
            $pns_num=substr($pns_numlc,2);
            $pns_num="0".$pns_num;
              $destpns = strtolower(str_replace("," , "','" , $destinations_coveredlc));
                if($destpns != ""){
                $sdestpns = dbprocess("SELECT PNS_NO FROM `tbl_dest_pns` WHERE `DESTINATIONS` in ('".addslashes($destpns)."') and FK_USERID = '".$log_id."' and STATUS = '1' limit 1 ");
                 
                        if(mysql_num_rows($sdestpns)){
                                while($rdest = mysql_fetch_assoc($sdestpns)){
                                        $destpnsno = $rdest["PNS_NO"];
                                         $pns_num_plus="+91".$destpnsno;
                                         $pns_num="0".$destpnsno;

                                }
                           }
                        }
        }

	
        $all_deals_data['mobile_device'] = $mobile_device;
        $all_deals_list[] = $all_deals_data;
    }

}
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();
$smarty_obj->assign("baseurl",BASEURL_HT);
$smarty_obj->assign('deals_data',$all_deals_list);
$smarty_obj->display('hellotravel2.0/deals_listing_ltdes.tpl');

//print_r($all_deals_list);
//print_r($data);die;

}
if(isset($_REQUEST["rowsperpage"]) && !empty($_REQUEST["rowsperpage"])){
$offset=$_REQUEST["offset_auto"];
$lead_id=$_REQUEST["leadid_auto"];
$referal_id=$_REQUEST["referal_id"];

$rowsPerPage=$_REQUEST["rowsperpage"];


$r=new package_relevence_module(array("type"=>"and","start"=>$offset ,"rows"=>$rowsPerPage));
$args=json_decode($_REQUEST["filter_query"]);
$data =$r->get_packages($_REQUEST["filter_query"]);
$numfound_main=$data["count"];
$final_array_main=$data["result"]; 
#print_r(array($numfound_main,$final_array_main));
/*  $destination_query=$_REQUEST["destination_query"];
  $price_filter=$_REQUEST["price_filter"];
  $duration_filter=$_REQUEST["duration_filter"];
  $budget_filter=$_REQUEST["budget_filter"];
  $offset=$_REQUEST["offset_auto"];
  $rowsPerPage=$_REQUEST["rowsperpage"];
  $lead_id=$_REQUEST["leadid_auto"];
  $referal_id=$_REQUEST["referal_id"];

 $url="http://ht-search:2000/solr/hellotravel/select?q=$query$destination_query$price_filter$duration_filter$budget_filter&sort=changed+desc&start=$offset&rows=$rowsPerPage&wt=json&indent=true";
  
$url_0=str_replace(" ","%20",$url);

try{

$json_main = @file_get_contents($url_0);
}
catch(Exception $e) {

}
*/
#$final_array_main=json_decode($arr_main);

$sql_preferred=dbprocess("select DISTINCT TBL_LOGIN_UID FROM tbl_logins,tbl_package where tbl_login_id=fk_tbl_login_id and status='1' and TBL_LOGIN_STATUS = 'active' and TBL_LOGIN_UID!='0' and TBL_LOGIN_PACKAGE!='0'");

$sql_preferred_agent_uid=array();
$count_deal=0;
while($row_preferred_agent=mysql_fetch_array($sql_preferred))
{
    $sql_preferred_agent_uid[$count_deal]=$row_preferred_agent['TBL_LOGIN_UID'];
    $count_deal++;
}
$deals_array=array();
$no_record_found='';
$fcp_uid='';
$sort_price='';


$i=0;
$counter=0;
if($numfound_main>0)
{
    foreach($final_array_main as $val)
    {
	$counter++;
        $pns_num='';
        $pns_num_plus='';
        $photo='';
        $deals_rating='';
        $pstatuslc=0;
        $ts_status=0;
        $package_typelc=0;
        $photo_array=array();
        $pstatuslc=$val->pstatus;
        $package_count++;
        $fcp_uidlc=$val->fcp_uid;
        $photo='';
        $deals_rating='';
        $p_symbol='';
        $p_value='';

        $photo_array=array();
        $idlc=$val->id;
        $destination_countrylc=$val->destination_country;
        $from_dtlc=$val->from_dt;
        $to_dtlc=$val->to_dt;
        $fcp_uidlc=$val->fcp_uid;
        $inclusion_exclusionlc=$val->inclusion_exclusion;
        $converted_pricelc=$val->converted_price;
        $titlelc=$val->title;
        $package_typelc=$val->package_type;
	$tour_days = $val->days;

        //echo "test";
        //$duration1=$val->duration;
        //$duration2=explode("/",$duration1[0]);
        //$durationlc=$duration2[0]."/".$duration2[1];
        $durationlc=$val->duration;
        $ts_status=$val->ts_status;
        $bap_status=$val->bap_status;
        $destinations_coveredlc=$val->destinations_covered_text;
        $tbl_login_companynamelc=$val->tbl_login_companyname;
        $tbl_login_creditpointslc=$val->tbl_login_creditpoints;
        $tbl_login_idlc=$val->tbl_login_id;

        $pns_numlc=isset($val->pns_num) ? $val->pns_num : '';


        $nidlc=$val->nid;
        $pathlc=$val->path;
        $p_symbol='INR';
        $p_value=$converted_pricelc;
		$useragent=$_SERVER['HTTP_USER_AGENT'];

$imgpath = detect_mobile_device_new() ? "https://www.hlimg.com/images/deals/80X50/" : "https://www.hlimg.com/images/deals/180X135/" ;
			$photo=$imgpath.$pathlc;
			if(empty($pathlc))
			{
                            continue;
			}







        //inclusion icon//

        $explode_incluc_excl='';

        $explode_incluc_excl=explode('Exclu',$inclusion_exclusionlc);
 $icon='';
        if(stristr($explode_incluc_excl[0],'Flight'))
        {
            $icon.='&nbsp; <span data-tooltip="Flight"><i class="fa fa-plane cc5"></i> </span>';
        }
        else
        {
            $icon.='&nbsp; <span data-tooltip="Flight"><i class="fa fa-plane c9"></i> </span>';
        }
        if(stristr($explode_incluc_excl[0],'Accommodation'))
        {
            $icon.='&nbsp; <span data-tooltip="Accommodation"><i class="fa fa-bed cc5"></i> </span>';
        }
        else
        {
            $icon.='&nbsp; <span data-tooltip="Accommodation"><i class="fa fa-bed c9"></i> </span>';
        }

        if(stristr($explode_incluc_excl[0],'Meal'))
        {
            $icon.='&nbsp; <span data-tooltip="Meals"><i class="fa fa-glass-martini cc5"></i> </span>';
        }
        elseif(stristr($explode_incluc_excl[0],'Complimentary'))
        {
            $icon.='&nbsp; <span data-tooltip="Meals"><i class="fa fa-glass-martini cc5"></i> </span>';
        }
        else
        {
            $icon.='&nbsp; <span data-tooltip="Meals"><i class="fa fa-glass-martini c9"></i> </span>';
        }
        if(stristr($explode_incluc_excl[0],'Transport'))
        {
            $icon.='&nbsp; <span data-tooltip="Transport"><i class="fa fa-car cc5"></i> </span>';
        }
        elseif(stristr($explode_incluc_excl[0],'Tavera'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Indica'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Innova'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Qualis'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Taxi'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Cab'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        elseif(stristr($explode_incluc_excl[0],'Driver'))
        {
            $icon.="&nbsp;<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9NJREFUeNrMV91Pk2cU//WDFgpUkA46QwYj2EA0liDZhEzoBYboDbsgxhsSEw1ZDN4aL7zwlvgPjF2aYIhZ4rK7OYMdGQ0XzvgBzhQ2vkawWiwfChQK3fk9e9/ufUtBN2HdISfv+z7P0/M75zznC0symUQ2yP4+hxq+aXDLIyDcJFwn7BP2atsvhMPCj4RDwsEHXQ+W3iXTspvFAuiRxznhjuaK5hZ/mR8+jw8VBypQkleizsyvzmNqcQrhaBiPI48xODX4kyx/K9wvCkT/MbCAtsnjq7NHzn7ZWtWK+o/r38uFD+ce4t7v93B79PZ38vm1gP+Q8SCB0/l47/Hzwr/en7if/LfE31IGZWXC2Al0diQykvxQogzKygSeDtpGLfcCNA2clrdlBJYNj/CdD3HvO9x+hxg6ntVw3ecYSIHKwJ7nLGVStpYhf+exlqcdjN5MtLKxgltPb2Hs9Rhcdhc2k5umfavFCleOC3PLc6j9qBad/k7k2fNMZyhbIr1DsG4yz/UCEmCe7pQyd3+7iyeRJ7j6xVUcKjy0o2WTC5O4EbqBsvEytNe0m/YomxiS53Tp9zpwE4uDkUZfjqL3l14UOApgt9px+fPLu4KSKosqcanhEvqe9mFoZghriTV0f9YNX4lP7RNDgJuMwHWsSEZy2p2wWWyqGBQ6C+GwOeB2uuFxeZRr+eR3fDOO2aVZtba+uY7ImwiG/xjGUnwJJz85qZTWScOoM9ZqH8ugkaqKq3Ch/gJiazFlKRXgXefYctS+w+qAzWrDVnJLgVvkj+/5Ofk4UX4CC2sL6GroUl7QScNQ6HpUe/XaawyY8HwY5e5yXA9cV1yUW4R4Iq54eX1ZCadl/KZbeS3Xmq+ps3yfiE0oOTppGF4j8Dai2xgsZAL4vX7UeGp2vWPuH/MeQ2w1hpnFGYy/HsfG1saubfGFdJlPjcFDTem259HnONN3JrXOtOG6xWIx1fu3G28Rmgnh1M1TqfXTh0+rONGJnUxroyngsLQ2EzCDwlvg3abp0dKjKicZbLxTKkg3M+XYmYxUml9qcjXbp9a7U8CPpJ+2NZY3mn7oznVnbHvRlahSjJbScgJPL05vO1ucW2z6Zs/WBoYUcIhNPJ0SW4nUe62nVkXoamJV3Zuxj9Oq6oPVcNqcyqpnr56p9fQKp2GEjMBBTg5ijal6MTJ1ulh/ES2VLcq9OxEVGJgYwJUfr/yVcnIdRk9p00nQNAhI5+ju+bknuV9E2cTI1J36Oa4EJ4N73p0oUxuF+jOOPlkZBLI6+vyXw17Wxtv/30Cf1X9h9pP+FGAAvVfMSR3JOeUAAAAASUVORK5CYII=' alt='Transport'>";
        }
        else
        {
            $icon.='&nbsp; <span data-tooltip="Transport"><i class="fa fa-car c9"></i> </span>';
        }

        if(stristr($explode_incluc_excl[0],'Sightseeing'))
        {
            $icon.='&nbsp; <span data-tooltip="Sightseeing"><i class="fa fa-camera-retro cc5"></i> </span>';
        }
        elseif(stristr($explode_incluc_excl[0],'Sight seeing'))
        {
            $icon.='&nbsp; <span data-tooltip="Sightseeing"><i class="fa fa-camera-retro cc5"></i> </span>';
        }
        elseif(stristr($explode_incluc_excl[0],' site seeing '))
        {
            $icon.='&nbsp; <span data-tooltip="Sightseeing"><i class="fa fa-camera-retro cc5"></i> </span>';
        }
        else
        {
            $icon.='&nbsp; <span data-tooltip="Sightseeing"><i class="fa fa-camera-retro cc5"></i> </span>';
        }



        if($durationlc)
        {
            $exp_duration=explode('/',$durationlc);
            if($exp_duration[0]=="1 Days" || $exp_duration[0]=="2 Days" || $exp_duration[0]=="3 Days")
            {
                $form_duration=1;
            }
            elseif($exp_duration[0]=="4 Days" || $exp_duration[0]=="5 Days" || $exp_duration[0]=="6 Days" || $exp_duration[0]=="7 Days")
            {
                $form_duration=2;
            }
            elseif($exp_duration[0]=="8 Days" || $exp_duration[0]=="9 Days" || $exp_duration[0]=="10 Days" || $exp_duration[0]=="11 Days" || $exp_duration[0]=="12 Days" || $exp_duration[0]=="13 Days" || $exp_duration[0]=="14 Days")
            {
                $form_duration=3;
            }
            elseif($exp_duration[0]=="15 Days" || $exp_duration[0]=="16 Days" || $exp_duration[0]=="17 Days" || $exp_duration[0]=="18 Days" || $exp_duration[0]=="19 Days" || $exp_duration[0]=="20 Days" || $exp_duration[0]=="21 Days")
            {
                $form_duration=4;
            }
            else
            {
                $form_duration=5;
            }
        }

        $destination=$destinations_coveredlc;
        $nid=$nidlc;
        $dest_link_var="";
        $dest_explode=explode(",",$destination);
        $dest_exp_count=0;
        $dest_first= $dest_explode[0];

        foreach($dest_explode as $key=>$value)
        {

            $dest_status=1;
            $destination_value=trim(addslashes($value));
	    $modified_location_name=replace_location_str(strtolower(trim($value)));
            $dest_link_var=$dest_link_var."<a href='https://www.hellotravel.com/deals/".$modified_location_name."'>$value</a>,";

          #  $dest_link_var=$dest_link_var."<a href='https://www.hellotravel.com/deals/".strtolower(trim($value))."'>$value</a>,";
        }

        $dest_link_var=rtrim($dest_link_var,",");
        $pack_dest_comma_seprated=str_replace(",",", ",$dest_link_var);

        if($p_value>1000)
        {
            $itinerary_detail="I am interested in $title covering $destination for $duration at approx INR $p_value";
        }
        else
        {
            $itinerary_detail="I am interested in $title covering $destination for $duration";
        }

        $log_id=$tbl_login_idlc;
        $credit_points=$tbl_login_creditpointslc;

        $comp_name=$tbl_login_companynamelc;


        if($pns_numlc != "" && !empty($pns_numlc)){
			$pns_num_plus="+".$pns_numlc;
			$pns_num=substr($pns_numlc,2);

		$pns_num="0".$pns_num;

		}

        $book_now_array=array('97','2527','11906','23841','43362','41819','43660','12751','33396','32956','40915');
        if (in_array($fcp_uidlc, $book_now_array))
        {
            $book_now="yes";
        }
        else
        {
            $book_now="no";
        }
        if(in_array($fcp_uidlc, $sql_preferred_agent_uid))
        {
            $preferred_agent="yes";
        }
        else
        {
            $preferred_agent="no";
        }
// $deals_destinations_covered=trim($row_deals['destinations_covered']);
//$deals_destinations_covered=str_replace(",",", ",$deals_destinations_covered);
$title=ucwords(strtolower($titlelc));


      $design_div.= ' <tr>
        <td class="deal_lis ">
          <div class="card_list ' .($preferred_agent == 'yes' ? 'bgl' : '').'">
           				<div class="ww75 fl">

        					<a href="https://www.hellotravel.com/deals/'.$nid.'.html" onclick="ga(\'send\', \'event\', \'Packages\', \'deals_listing_page\',\'other_packages\');">
        					 <div class="w30_40 fl p_r">
        						<img src="'.$photo.'" alt="'.$title.'" class="pl_wimg" style="min-height:98px;">
                    <span class="lis_offer ldisb">

                      '.($ts_status == '1' ?
                    '<i data-tooltip="TrustSEAL Verified Agent" class="fl"><div class="trstS"></div></i>': '').'
                    </span>
                     <span class="lis_offer disb">

                       '.($ts_status == '1' ?
                     '<i data-tooltip="TrustSEAL Verified Agent" class="fl"><div class="trstS"></div></i>': '').'


                     '.($package_typelc == 1 && $pstatuslc == 1?
        ' <i data-tooltip="Silver Supplier" class="fl ml"><span class="c9 fa fa-star"></span></i>': '').'
        '.($package_typelc == 2 && $pstatuslc == 1?
       ' <i data-tooltip="Gold Supplier" class="fl ml"><span class="cc1 fa fa-star"></span></i>': '').'

       '.($package_typelc == 3 && $pstatuslc == 1?
      '<i data-tooltip="Platinum Supplier" class="fl ml"><span class="cc5 fa fa-star"></span></i> ': '').'
      '.($package_typelc == 5 && $pstatuslc == 1?
     '  <i data-tooltip="Starter Supplier" class="fl ml"><img src="https://www.hlimg.com/images/starter_supplier.png"  alt="Starter Supplier"></i>': '').'
      '.($package_typelc == 4 && $pstatuslc == 1?
     ' <i data-tooltip="Basic Supplier" class="fl ml"><span class="cc2 fa fa-star"></span></i>': '').'



                      		</span>
        					 </div>
                 </a>
        				   <div class="w70_60 fl pd10_5 f17_14 lh24_18">
                      <div class="lis_titl">
        						<a class="c6" href="https://www.hellotravel.com/deals/'.$nid.'.html" onclick="ga(\'send\', \'event\', \'Packages\', \'deals_listing_page\',\'other_packages\');">'.$title.'--'.$tbl_login_idl.'--'.$package_typelc.'</a>
                   </div>

        						'.($pack_dest_comma_seprated !=''? '<div class="lis_titl"><span class="f13_13">'.
         						 $pack_dest_comma_seprated.'</span>
                     <div class="cl"></div>
                    </div>':'').'
                     <div class="m5_0">
        				        <a class="a-lin f13_13" href="https://www.hellotravel.com/deals/'.$nid.'.html" onclick="ga(\'send\', \'event\', \'Packages\', \'deals_listing_page\',\'other_packages\');"><span class="c6">'.$tour_days.' days tour</span></a>
           						<a class="a-lin disb_bn_m" href="https://www.hellotravel.com/deals/'.$nid.'.html" onclick="ga(\'send\', \'event\', \'Packages\', \'deals_listing_page\',\'other_packages\');">
            						'.$icon.'
        						    </a>
                     </div>
                     '.($p_value >'1000'?'<div class="ldisb cl_g f16" style="padding-bottom:5px">&#x20B9;&nbsp;'.$p_value.'<sup>*</sup></div>':'<div class="cl_g lh40 fl pric_re ldisb">  Get Price</div>').'

         					</div>

       				   <div class="cl"></div>
                 </div>
                  <div class="ww25 fl" align="center">
       '.($p_value >'1000'?'	<div class="cl_g lh40 fl pric_re disb"> &#x20B9;&nbsp;'.$p_value.'<sup>*</sup></div>':'<div class="cl_g lh40 fl pric_re disb">  Get Price</div>').'
'.($referal_id == 'yes'?'<button id="sent_'.$nid.'" class="btn-s4 disb" style="background-color:#29a329;border:#29a329;display:none;" >Request sent</button> <a class="a-lin disb" id="'.$nid.'" onclick="duplicate_buy('.$lead_id.','.$nid.','.$tbl_login_idlc.'); ga(\'send\', \'event\', \'leads\', \'deals_listing_page\',\'enquire_now_button\');" href="javascript:void(0);"><button class="btn-s4">Enquire Now</button></a>':'<a class="a-lin disb" href="/plantour.php?prvt_id='.$tbl_login_idlc.'&d_id='.$nid.'" ><button class="btn-s4 fl_l">Enquire&nbsp;Now</button></a>').'

'.($referal_id == 'yes'?''.($pns_num != ''?'<a onclick="ga(\'send\', \'event\', \'PNS\', \'deals_listing\',\'call_now_btn\');" class="ldisb1  fr mr1 mt15 f14 b" href="tel:'.$pns_num_plus.'"><i class="fa fa-phone"></i> CALL</a>
       <div class="cl"></div>
        <a class="a-lin disb f20 mt15 cc2"  href="tel:'.$pns_num_plus.'"><i class="fa fa-phone"></i> '.$pns_num.'</a>':'').'':''.($pns_num != ''?'<a href="javascript:void(0);" onclick="ga(\'send\', \'event\', \'PNS\', \'deals_listing\',\'call_now_btn\'); data-qid="'.$pns_num_plus.'" id="ph_pop_'.$nid.'" id="ph_pop_'.$nid.'" open_popup(\''.$pns_num_plus.'\',\'ph_pop_'.$nid.'\');" class="ldisb1  fr mr1 mt15 f14 b" ><i class="fa fa-phone"></i> CALL</a>
               <div class="cl"></div>
                <a class="a-lin disb f20 mt15 cc2" data-qid="'.$pns_num_plus.'" onclick="open_popup(\''.$pns_num_plus.'\',\'dsk_pop_'.$pns_num_plus.'\');"  id="dsk_pop_'.$nid.'"  href="javascript:void(0);" ><i class="fa fa-phone"></i> '.$pns_num.'</a>':'').'').'

          '.($referal_id == 'yes'?'<a id="m_'.$nid.'"  class="ldisb1  fr mr1 mt15 cc5 f14 b" href="javascript:void(0);" style="display:none;" >&#10004; Sent</a><a id="d_'.$nid.'" onclick="duplicate_buy('.$lead_id.','.$nid.','.$tbl_login_idlc.');" class="ldisb1 fr mr1 mt15 c_e3 f14 b" href="javascript:void(0);" ><i class="fa fa-dashcube" id="di_'.$nid.'"></i> PLAN</a>  <!-- <a id="d_'.$nid.'" onclick="duplicate_buy('.$lead_id.','.$nid.','.$tbl_login_idlc.');" class="ldisb1 fr mr1 mt15 c_e3 f14 b" href="javascript:void(0);" ><i id="di_'.$nid.'" class="fa fa-dashcube"></i> PLAN 1</a>-->
          <a id="m_'.$nid.'"  class="ldisb1 fr mr1 mt15 cc5 f14 b" href="javascript:void(0);" style="display:none;">&#10004; Sent</a>':'<a href="/plantour.php?prvt_id='.$tbl_login_idlc.'&d_id='.$nid.'" onclick="ga(\'send\', \'event\', \'leads\', \'deals_listing_page\',\'plan_button\');" class="ldisb1 fr mr1 mt15 c_e3 f14 b" ><i class="fa fa-dashcube"></i> PLAN</a>').'






                      <div class="cl"></div>
                </div>
                    <div class="cl"></div>
                 </div>
                </td>
         			</tr>


        			</tr>';
if($counter> 0 && $counter%5 ==0){
if(detect_mobile_device_new()){
$design_div.='<tr>
<td bgcolor="#ffffff" style="background-color:#ffffff; border-color:#ffffff; padding:0; padding-bottom:10px">
  <div class="ldisb1" style="background-color:#fdfddf; height:98px;">

<ins class="adsbygoogle"
style="display:block"
data-ad-format="fluid"
data-ad-layout-key="-es+28-e3-3l+1i3"
data-ad-client="ca-pub-4534976970190809"
data-ad-slot="9960266998"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>
</div>
</td>
</tr>';
}else{
$design_div.='<tr>
<td bgcolor="#ffffff" style="background-color:#ffffff; border-color:#ffffff; padding:0; padding-bottom:10px">
  <div class="disb" style="background-color:#fdfddf; height:145px;">
        <ins class="adsbygoogle"
style="display:block"
data-ad-format="fluid"
data-ad-layout-key="-ga-2b+f+3i+n8"
data-ad-client="ca-pub-4534976970190809"
data-ad-slot="3259127279"></ins>

<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
  </script>
  </div>
</td>
</tr>';
}
}







        $i++;
    }


}
echo $design_div;
}

function ucfirstfun($value) {
    return ucfirst(trim($value));
}
?>
