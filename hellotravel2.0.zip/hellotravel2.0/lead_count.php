<?php
require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

function getPreviousDayTime()
{
    $end_time = strtotime('today');
    $start_time = strtotime('-1 day', $end_time);
    return array(
        'start' => date('Y-m-d 00:00:00', $start_time),
        'end' => date('Y-m-d 00:00:00', $end_time)
    );
}

$titlesQuery = "SELECT title FROM open_whatsapp_location WHERE status = 1";
$titlesResult = dbprocess($titlesQuery);
$titlesResultArray= array();
while ($row = mysql_fetch_assoc($titlesResult)) { 
    $titlesResultArray[]  = "(TBL_LEAD_DESTINATION_VALUE LIKE '%{$row['title']}%')";
}

$str = implode(' OR ' , $titlesResultArray);

$resultsArray = array();

$timeRange = getPreviousDayTime();



                $leadTotalQuery = "SELECT DATE(tlu.TBL_LEAD_RECD_DATE_TIME) AS date, COUNT(*) AS cnt 
                            FROM tbl_leads tlu
                            WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
                            AND FK_STATUSID NOT IN (0, 2, 1, 6, 16) 
                            AND ($str)
                            GROUP BY DATE(tlu.TBL_LEAD_RECD_DATE_TIME)";
                                               
        $leadTotalResult = dbprocess($leadTotalQuery);

        while ($row1 = mysql_fetch_assoc($leadTotalResult)) { 
            $date = $row1 ['date'];
            $count = $row1 ['cnt'];
            $resultsArray['whatsapp_lead_total'][$date] = $count;
        }


            $packageLeadsQuery = "SELECT DATE(tlu.TBL_LEAD_RECD_DATE_TIME) AS date, COUNT(*) AS cnt 
                        FROM tbl_leads tlu
                        WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
                        AND FK_STATUSID NOT IN (0, 2, 1, 6, 16) 
                        AND ($str)
                        AND (TBL_LEAD_FORMNAME ='list' OR TBL_LEAD_FORMNAME ='deal')
                        GROUP BY DATE(tlu.TBL_LEAD_RECD_DATE_TIME)";
    $packageLeadsResult = dbprocess($packageLeadsQuery);
    while ($row2 = mysql_fetch_assoc($packageLeadsResult)) {
        $date = $row2['date'];
        $count = $row2['cnt'];
        $resultsArray['whatsapp_package_leads'][$date] = $count;
    }


    $rejectedLeadsQuery = "SELECT DATE(tlu.TBL_LEAD_RECD_DATE_TIME) AS date, COUNT(*) AS cnt 
    FROM tbl_leads tlu
    WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
    AND FK_STATUSID IN (0, 2, 1, 6) 
    AND ($str)
    GROUP BY DATE(tlu.TBL_LEAD_RECD_DATE_TIME)";
    $rejectedLeadsResult = dbprocess($rejectedLeadsQuery);
    while ($row3 = mysql_fetch_assoc($rejectedLeadsResult)) {
        $date = $row3['date'];
        $count = $row3['cnt'];
        $resultsArray['rejected_leads'][$date] = $count;
    }



$previousDayParam = strtotime('-1 day', strtotime('today'));

for ($i = 1; $i <= 3; $i++) {
    $recommendationQuery = "SELECT COUNT(*) AS cnt 
                            FROM whatsapp_tbl_agent 
                            WHERE create_date LIKE '{$previousDayParam}' AND lead_id IN 
                                (SELECT lead_id 
                                 FROM whatsapp_tbl_agent 
                                 GROUP BY lead_id 
                                 HAVING COUNT(*) = {$i})
                            ";
    $recommendationResult = dbprocess($recommendationQuery);
    while ($row4 = mysql_fetch_assoc($recommendationResult)) {
        $count = $row4['cnt'];
        $resultsArray['recommendation'][$i] = $count;
    }
}

for ($i = 1; $i <= 3; $i++) {
    $soldByQuery = "SELECT COUNT(*) AS cnt 
                    FROM whatsapp_tbl_agent 
                    WHERE create_date LIKE '{$previousDayParam}' AND call_connected = 1 AND lead_id IN 
                        (SELECT lead_id 
                         FROM whatsapp_tbl_agent 
                         GROUP BY lead_id 
                         HAVING COUNT(*) = {$i})
                    ";
    $soldByResult = dbprocess($soldByQuery);
    while ($row5 = mysql_fetch_assoc($soldByResult)) {
        $count = $row5['cnt'];
        $resultsArray['sold_by'][$i] = $count;
    }
}

$hourly = "SELECT hour(tlu.TBL_LEAD_RECD_DATE_TIME) AS hour,count(*) AS cnt FROM tbl_leads tlu WHERE  tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' and ($str) and FK_STATUSID  not in (0,2,1,6,16) group by hour(tlu.TBL_LEAD_RECD_DATE_TIME)";


$r = dbprocess($hourly);
    $temp=0;
    while ($row6 = mysql_fetch_assoc($r)) {
        $count = $row6['cnt'];
        $hour= $row6['hour'];
        
        if($temp<$count){
            $temp = $count;
            $finalhour = $hour;
        }
        
    }
    $maximum['max_lead_on_hour'][$finalhour] = $temp;
    print_r($maximum);
    
    print_r($resultsArray);


?>








