<?php
$new_version_path = "http://local.hellotravel.noida/hellotravel2.0/";
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";

require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

require_once("/home/indiamart/public_html/hellotravel-agents/includes/traveller_personilization.php");
#require_once("/home/indiamart/public_html/hellotravel-agents/includes/package_relevency_module_list.php");
#require_once("/home/indiamart/public_html/hellotravel-agents/includes/package_relevency_module_branding.php");
#require_once("/home/indiamart/public_html/hellotravel-agents/includes/package_relevency_module_free.php");
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_list.php");
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_branding.php");
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_free.php");

require_once("/home/indiamart/public_html/hellotravel/includes/genrateTravelGuide.php");
include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoip.inc");
include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoipcity.inc");
include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoipregionvars.php");
require_once("/home/indiamart/public_html/hellotravel-agents/includes/geoipdecoder.php");
require_once("/home/indiamart/public_html/hellotravel/includes/pts_ttd_data.php");
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/list_module.php");

require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

foreach($prices as $k=>$v){
	$smarty_obj->assign('price'.$k,$v);
}
//print_r($agents);
foreach($agents as $k=>$v){
	$smarty_obj->assign('agent'.$k,$v);
}

foreach($durations as $k=>$v){
        $smarty_obj->assign('duration'.$k,$v);
}

foreach($budgets as $k=>$v){

        $smarty_obj->assign('budget'.$k,$v);
}
foreach($destination_theme as $k=>$v){
    $smarty_obj->assign('destinations_theme'.$k,$v);
}    

// set meta data//
$all_meta_data = getmetaschemadealslist();
$meta_new_latest = $all_meta_data['meta_new'];
$meta_description_new = $all_meta_data['meta_description'];
$smarty_obj->assign('list_meta',$meta_new_latest);
$smarty_obj->assign('meta_description',$meta_description_new);
$smarty_obj->assign("leadnoindex",$leadnoindex);


$smarty_obj->assign('ratingurlsubheading',$ratingurlsubheading);

$smarty_obj->assign('filter_args',json_encode($args));
$smarty_obj->assign('place_to_mmt',ucfirst($place_to_mmt_new_tmp_str));
$smarty_obj->assign("breadcrumb",$breadcrumb);
$smarty_obj->assign('pts_urll',$apts_url);
$smarty_obj->assign('ratingurlsubheading',$ratingurlsubheading);




$smarty_obj->assign("BASE_URL_DEALS","https://www.hellotravel.com/deals/");
$smarty_obj->assign("new_version_path",$new_version_path);
$smarty_obj->assign('place_to_desti',$place_to);
$place_to_uc = ucfirst($place_to);
$smarty_obj->assign('place_to',$place_to_uc);
$page="list";
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");
$smarty_obj->display('hellotravel2.0/header_demo.tpl');

function api_all_deals_data(){
	$deals_list = get_all_deals_data();
	return $deals_list;
	
}

$smarty_obj->assign("BASE_URL_DEALS_JS",$BASE_URL_DEALS);
$deals_data = api_all_deals_data();
$deals_data = json_decode($deals_data,true);
$smarty_obj->assign("num_of_record",$num_lead);
$smarty_obj->assign('filteravl',$filteravl);
$smarty_obj->assign('deals_data',$deals_data);
$smarty_obj->assign('hotel_data_h1_content',$hotel_data_h1_content);
if($place_to != ""){
 require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/utility/deals-list-ques-ajax-new-st-new.php");
}
$deals_about = get_deals_about_data();
$deals_about = json_decode($deals_about,true);
$smarty_obj->assign('deals_about',$deals_about['summary']);
$smarty_obj->display('hellotravel2.0/deals_listing_page.tpl');


function get_thing_to_do_data(){
	$thingsdata = get_thing_to_do();
	return $thingsdata;
}


$thingstodo = get_thing_to_do_data();
$thingstodo = json_decode($thingstodo,true);
$smarty_obj->assign('thingstodoplaces',$thingstodo);
if(count($thingstodo['thingstodoplaces'])>0){
$smarty_obj->display('hellotravel2.0/deals_listing_things_to_do.tpl');
}


function get_nearby_places(){
	return get_nearby_places_data();
}


$MostpplIdealDesign=get_nearby_places();

$MostpplIdealDesign=json_decode($MostpplIdealDesign,true);

$smarty_obj->assign("MostpplIdealDesign",$MostpplIdealDesign);
if(count($MostpplIdealDesign['nearbyplacesname'])>0){
$smarty_obj->display('hellotravel2.0/deals_popular_near.tpl');
}

function get_more_attraction_data(){
	$moredata = get_more_attraction();
	return $moredata;
}


$moredata = get_more_attraction_data();
$moredata = json_decode($moredata,true);
$smarty_obj->assign('thingstodoplaces',$moredata);
if(count($moredata['thingstodoplaces'])>0){
$smarty_obj->display('hellotravel2.0/deals_listing_things_to_do.tpl');
}



function get_tripideas_data(){
	return tripideas_data();
}


$tripdata = get_tripideas_data();
$tripdata = json_decode($tripdata,true);
$smarty_obj->assign("TravelTipsDesign",$tripdata['traveltips']);
$smarty_obj->assign("heading",$tripdata['heading']);
if(count($tripdata['traveltips'])>0){
$smarty_obj->display('hellotravel2.0/home_story_tips.tpl');
}


function get_also_explore_data(){
	return return_aloso_explore();
}


$also_explore=get_also_explore_data();
$also_explore=json_decode($also_explore,true);

if(count($also_explore['nearbyplacesname'])){
$smarty_obj->assign("MostpplIdealDesign",$also_explore);
$smarty_obj->display('hellotravel2.0/deals_popular_near.tpl');
}

function getReview(){
    $setReviewDgnDesign=getReviewDgn();
    if(isset($setReviewDgnDesign) && !empty($setReviewDgnDesign)){
       return $setReviewDgnDesign;
    }
}

$ReviewDesign=getReview();
$ReviewDesign=json_decode($ReviewDesign,true);
if(count($ReviewDesign['review'])){
$smarty_obj->assign("ReviewDesign",$ReviewDesign['review']);
$smarty_obj->assign("heading",$ReviewDesign['heading']);
$smarty_obj->display('hellotravel2.0/home_customer_review.tpl');
}

$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/footer_list_demo.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');

//$smarty_obj->display('deals_footer_js_code.tpl');



?>
