<?php

require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
require_once("/home/indiamart/public_html/hellotravel-agents/includes/traveller_personilization.php");
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_my.php");
require_once("/home/indiamart/public_html/hellotravel/includes/pts_ttd_data.php");

include_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/deal_module.php");

 $deal_id=getDealsDataurl();
$main_data=array();
$datadeals=getdealsDataById($deal_id);


$breadcrumbDesign=getBreadcrumb($datadeals);

$headerbannerDesign=getHeaderbanner($datadeals);

$headerdetailDesign=getHeaderDetail($datadeals);

$headerDescDesign=getHeaderDesc($datadeals);

$agentProfileDesign=getAgentProfile($datadeals);

$InclusionExclusion=getInclusionExclusion($datadeals);

$TermsCondition=getTermsCondition($datadeals);

$Highlight=getHighlight($datadeals);

$Itinerary=getItinerary($datadeals);
$Accommodation=getAccomondation($datadeals);
 
$Duration=getDuration($datadeals);
 
$Themes=getTheme($datadeals);

$TourLocation=getTourLocation($datadeals);
 
$PriceBreakup=getPriceBreakup($datadeals);

$Custreview=getCustreview($datadeals);
  
$SimilerDestData=getSimilerDestData($datadeals);

$thingstodo=getThingstodo($datadeals);

$EnquiryButton=getEnquiryButton($datadeals);


//=================Start Meta Title And description Code===================
if(!empty($datadeals)){

    if(isset($_COOKIE['leadvalue']))
    {
        $cookie_value=$_COOKIE['leadvalue'];
        $lead_value = base64_decode($cookie_value);
        $ref_page='yes';
    }

    $main_data['title'] = $datadeals["response"]["docs"][0]["title"];
    $main_data['nid'] = $datadeals["response"]["docs"][0]["nid"];
    $main_data['og_fb_image']=$headerbannerDesign[0];
    
    $title = $datadeals["response"]["docs"][0]["title"];
    $duration=$datadeals["response"]["docs"][0]["duration"];
    $price = $datadeals["response"]["docs"][0]["price"];

    $arr=explode("/",$duration);
    $new_duration=trim($arr[1]."/".$arr[0]);
    $meta_duration=$new_duration;
    $departure_from = $datadeals["response"]["docs"][0]["departure_from_text"];
    $meta_departure_country = $datadeals["response"]["docs"][0]["departure_country_name"];
    $meta_destinations_covered=$datadeals["response"]["docs"][0]['destinations_covered_text'];

    $meta_id=6+($d_id%4);
    $meta_string_araray=mysql_fetch_array(dbprocess("select * from tbl_meta_title where  meta_id=$meta_id"));
    $meta_string=$meta_string_araray['title'];
    $meta_string='TITLE | DESTINATION Trip Package for DURATION @ INR PRICE';
    if(strstr($meta_string,'TITLE')){
        $meta_string=str_replace("TITLE","$title",$meta_string);
    }

    if(strstr($meta_string,'DURATION')){
        $meta_string=str_replace("DURATION","$meta_duration",$meta_string);
    }

    if(stristr($departure_from,"anywhere")||(!strcmp($dest_frst,$dept_frst))){
        $meta_string=str_replace("from CITY, COUNTRY"," ",$meta_string);
    }

    $departure_from=$departure_from.", ".$meta_departure_country;
    if(strstr($meta_string,'CITY, COUNTRY'))        {
        if($departure_from){
        $meta_string=str_replace("CITY, COUNTRY","$departure_from",$meta_string);
        }
        else{
        $meta_string=str_replace("CITY, COUNTRY","",$meta_string);
        }
    }
    if(strstr($meta_string,'DESTINATION')){
        $meta_string=str_replace(",",", ",str_replace("DESTINATION","$meta_destinations_covered",$meta_string));
    }

    if(strstr($meta_string,'PRICE')){
            $meta_string=str_replace(",",", ",str_replace("PRICE",money_format('%i',$price),$meta_string));
        }

       
}
//=================End Meta Title And description Code===================

$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

function getImgeHostlive(){
    $host = ["www.hlimg.com" , "www.hlimg.com" , "www.hlimg.com"];
    $key  = array_rand($host , 1);
    return $host[$key];
}  

$host = getImgeHostlive ();

$smarty_obj->assign("imagehost",$host);

$page='deal';



require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");


$smarty_obj->assign("LgImgfolder",'738X538');
$smarty_obj->assign("SmImgfolder",'360X230');
$smarty_obj->assign("XsImgfolder",'300X200');
$smarty_obj->assign('main_data' , $main_data);
$smarty_obj->assign('meta_string' , $meta_string);
$smarty_obj->assign("breadcrumb",$breadcrumbDesign);
$smarty_obj->assign("headbanner",$headerbannerDesign);
$smarty_obj->assign("headerdetail",$headerdetailDesign);
$smarty_obj->assign("headerDesc",$headerDescDesign);
$smarty_obj->assign("agentProfile",$agentProfileDesign);
$smarty_obj->assign("inclExcl",$InclusionExclusion);
$smarty_obj->assign("TermsCondition",$TermsCondition);
$smarty_obj->assign("highlight",$Highlight);
$smarty_obj->assign("itinerary",$Itinerary);
$smarty_obj->assign("duration",$Duration);
$smarty_obj->assign("themes",$Themes);
$smarty_obj->assign("tourlocation",$TourLocation);
$smarty_obj->assign("priceBreakup",$PriceBreakup);
$smarty_obj->assign("accommodation",$Accommodation);
$smarty_obj->assign("custreview",$Custreview);

$smarty_obj->assign("similerDestData",$SimilerDestData);
$smarty_obj->assign("thingstodo",$thingstodo);
$smarty_obj->assign("enquirybutton",$EnquiryButton);

$smarty_obj->display('hellotravel2.0/header_demo.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/deals/deal2.0.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');


?>
