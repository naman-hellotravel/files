<?php
require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");

$smarty_obj = new TplLoad();


require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");

function getindiacity(){

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://172.16.31.12:8983/solr/hellotravel_ttd_pts/select?fl=country_name,dealscount,url,title,pts_url&q=NOT%20(dealscount:0)%20AND%20country_name:"India"%20AND%20type:"pts"&sort=title%20asc&rows=40000&indent=off');
  curl_setopt($ch, CURLOPT_PORT, 8983);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
  curl_setopt($ch, CURLOPT_TIMEOUT, '4');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

  $data = json_decode(curl_exec($ch), TRUE);

  curl_close($ch);

  return $data['response']['docs'];

 }


 $cities=getindiacity();


function getintercity(){

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://172.16.31.12:8983/solr/hellotravel_ttd_pts/select?fl=country_name,dealscount,url,title,pts_url&q=NOT%20(dealscount:0%20OR%20country_name:"India")%20AND%20type:"pts"&sort=country_name%20asc&rows=40000&indent=off');
  curl_setopt($ch, CURLOPT_PORT, 8983);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
  curl_setopt($ch, CURLOPT_TIMEOUT, '4');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

  $data = json_decode(curl_exec($ch), TRUE);

  curl_close($ch);

  return $data['response']['docs'];
 }

 $icities=getintercity();

 foreach($icities as $city){
   $icitylist[]=$city['country_name'];
 }
 

 $icitylistunique=array_unique($icitylist);
 $icitylistvalues=array_values($icitylistunique);
 $icitylistfilter=array_filter($icitylistvalues);
 
 
  foreach($icitylistfilter as $cityfilter){

     
    $cityarray=array();
    foreach($icities as $city){
    

     if(!empty($city['country_name'])){

      if($cityfilter==$city['country_name']){
  
          $cityarray[]=array('url'=>$city['url'],'title'=>$city['title']);

       }  
     }

  }

   $cityfilterArray[$cityfilter]=$cityarray;

 }

 //print_r($cityfilterArray);

//die;

$title="Sitemap | Hellotravel";
$canonical="https://www.hellotravel.com/hello-sitemap.php";

$smarty_obj->assign('title','0');
$smarty_obj->assign('default_meta',$title );
$smarty_obj->assign('default_canonical',$canonical );
$smarty_obj->assign('meta_string','Sitemap');
$smarty_obj->assign('pagename' , "Sitemap");
$smarty_obj->assign('page','sitemap');
$smarty_obj->assign('cities', $cities);
$smarty_obj->assign('icities', $cityfilterArray);

$smarty_obj->display('hellotravel2.0/header_demo.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/sitemap.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');

?>