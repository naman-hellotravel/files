<?php


require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

$page='contact-us';

require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");


 $smarty_obj->display('hellotravel2.0/header_demo.tpl');
 $smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
 $smarty_obj->display('hellotravel2.0/contact_demo.tpl');

 $smarty_obj->display('hellotravel2.0/footer_demo.tpl');
?>
