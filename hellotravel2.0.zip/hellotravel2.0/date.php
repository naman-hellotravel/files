<?php
require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

$currentDate = date("Y-m-d");

$sql = "SELECT * FROM tbl_event_upload WHERE status = 1 AND start_date < '$currentDate'";
$result = mysql_query($sql);


if (mysql_num_rows($result) > 0) {
    while ($row = mysql_fetch_assoc($result)) {
        $eventId = $row['id'];
        $newStartDate = date("Y-m-d", strtotime($row['start_date'] . " +1 year"));
        $newEndDate = date("Y-m-d", strtotime($row['end_date'] . " +1 year"));

        $updateSql = "UPDATE tbl_event_upload SET start_date = '$newStartDate', end_date = '$newEndDate', changed_datetime = NOW() WHERE id = '$eventId'";
        if (mysql_query($updateSql) === false) {
            echo "Error updating event with ID $eventId: " . mysql_error();
        }
        else{
            dbprocess($updateSql);
        }
    }
} else {
    echo "No events found with status 1 or all the event updated already";
}
?>


























<?php
// PHP code for linearly search x in arr[].

function search($arr, $n, $x)
{
	for($i = 0; $i < $n; $i++) {
		if($arr[$i] == $x)
			return $i;
	}
	return -1;
}

// Driver Code
$arr = array(2, 3, 4, 10, 40);
$x = 10;

// Function call
$result = search($arr, sizeof($arr), $x);
if($result == -1)
	echo "Element is not present in array";
else
	echo "Element is present at index " ,
								$result;


?>















$priceprod = array();

foreach ($contents as $g => $f)
{
  // use the key $g in the $priceprod array
  $priceprod[$g] = $f['price'];
}

// get the highest price
$maxprice = max($priceprod);

// find the key of the product with the highest price
$product_key = array_search($maxprice, $priceprod);

$product_with_highest_price = $contents[$product_key];








foreach ($contents as $g => $f)
{

    $priceprod[] = $f['price'];

}
$maxprice = max($priceprod);
p($maxprice);
