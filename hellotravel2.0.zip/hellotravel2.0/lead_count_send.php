<?php
require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

function getPreviousDayTime()
{
    $end_time = strtotime('today');
    $start_time = strtotime('-1 day', $end_time);
    return array(
        'start' => date('Y-m-d 00:00:00', $start_time),
        'end' => date('Y-m-d 00:00:00', $end_time)
    );
}


$titlesQuery = "SELECT title FROM open_whatsapp_location WHERE status = 1";
$titlesResult = dbprocess($titlesQuery);
$titlesResultArray= array();
while ($row = mysql_fetch_assoc($titlesResult)) { 
    $titlesResultArray[]  = "TBL_LEAD_DESTINATION_VALUE LIKE '%{$row['title']}%'";
}

$str = implode(' OR ' , $titlesResultArray);

$resultsArray = array();

$timeRange = getPreviousDayTime();



                $leadTotalQuery = "SELECT COUNT(*) AS cnt 
                            FROM tbl_leads tlu
                            WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
                            AND FK_STATUSID NOT IN (0, 2, 1, 6, 16) 
                            AND ($str)";
                                               
        $leadTotalResult = dbprocess($leadTotalQuery);

        while ($row1 = mysql_fetch_assoc($leadTotalResult)) { 
            $count = $row1 ['cnt'];
            $resultsArray['whatsapp_lead_total'] = $count;
        }


            $packageLeadsQuery = "SELECT COUNT(*) AS cnt 
                        FROM tbl_leads tlu
                        WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
                        AND FK_STATUSID NOT IN (0, 2, 1, 6, 16) 
                        AND ($str)
                        AND (TBL_LEAD_FORMNAME ='list' OR TBL_LEAD_FORMNAME ='deal')
                        ";
    $packageLeadsResult = dbprocess($packageLeadsQuery);
    while ($row2 = mysql_fetch_assoc($packageLeadsResult)) {
        $count = $row2['cnt'];
        $resultsArray['whatsapp_package_leads'] = $count;
    }


    $rejectedLeadsQuery = "SELECT COUNT(*) AS cnt 
    FROM tbl_leads tlu
    WHERE tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' 
    AND FK_STATUSID IN (0, 2, 1, 6) 
    AND ($str)";
    $rejectedLeadsResult = dbprocess($rejectedLeadsQuery);
    while ($row3 = mysql_fetch_assoc($rejectedLeadsResult)) {
        $count = $row3['cnt'];
        $resultsArray['rejected_leads'] = $count;
    }




for ($i = 1; $i <= 3; $i++) {
    $recommendationQuery = "SELECT COUNT(*) AS cnt 
                            FROM whatsapp_tbl_agent 
                            WHERE create_date LIKE '{$timeRange['start']}'  AND lead_id IN 
                                (SELECT lead_id 
                                 FROM whatsapp_tbl_agent 
                                 GROUP BY lead_id 
                                 HAVING COUNT(*) = {$i})
                            ";
    $recommendationResult = dbprocess($recommendationQuery);
    while ($row4 = mysql_fetch_assoc($recommendationResult)) {
        $count = $row4['cnt'];
        $resultsArray['recommendation'][$i] = $count;
    }
}

for ($i = 1; $i <= 3; $i++) {
    $soldByQuery = "SELECT COUNT(*) AS cnt 
                    FROM whatsapp_tbl_agent 
                    WHERE create_date LIKE '{$timeRange['start']}'  AND call_connected = 1 AND lead_id IN 
                        (SELECT lead_id 
                         FROM whatsapp_tbl_agent 
                         GROUP BY lead_id 
                         HAVING COUNT(*) = {$i})
                    ";
    $soldByResult = dbprocess($soldByQuery);
    while ($row5 = mysql_fetch_assoc($soldByResult)) {
        $count = $row5['cnt'];
        $resultsArray['sold_by'][$i] = $count;
    }
}

$hourly = "SELECT hour(tlu.TBL_LEAD_RECD_DATE_TIME) AS hour,count(*) AS cnt FROM tbl_leads tlu WHERE  tlu.TBL_LEAD_RECD_DATE_TIME >= '{$timeRange['start']}' AND tlu.TBL_LEAD_RECD_DATE_TIME <= '{$timeRange['end']}' and ($str) and FK_STATUSID  not in (0,2,1,6,16) group by hour(tlu.TBL_LEAD_RECD_DATE_TIME)";


$r = dbprocess($hourly);
    $temp=0;
    while ($row6 = mysql_fetch_assoc($r)) {
        $count = $row6['cnt'];
        $hour= $row6['hour'];
        
        if($temp<$count){
            $temp = $count;
            $finalhour = $hour;
        }
        
    }
    $maximum[$finalhour] = $temp;
    print_r($maximum);
    print_r($resultsArray);


    // $myfile = fopen("lead.txt", "a") or die("Unable to open file!");
    // $txt .= implode($resultsArray);
    // fwrite($myfile, $txt);
    // fclose($myfile);




$maximum = array(
    'key1' => 'value1',
    'key2' => 'value2',
    'key3' => 'value3'
);

$resultsArray = array(
    'data1' => 'result1',
    'data2' => 'result2',
    'data3' => 'result3'
);

$dataToAppend = array(
    'date' => $timeRange['start'],
    'maximum' => $maximum,
    'resultsArray' => $resultsArray
);

$jsonData = json_encode($dataToAppend);

$file = 'lead.txt';
file_put_contents($file, $jsonData . PHP_EOL, FILE_APPEND);

?>








