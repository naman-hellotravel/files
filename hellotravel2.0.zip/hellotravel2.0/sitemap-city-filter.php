<?php
require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");

$smarty_obj = new TplLoad();

require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");


$city=$_REQUEST['city'];
$filter=$_REQUEST['filter'];


$per_page_record=500;//Numberofentriestoshowinapage.
if(isset($_GET["page"])){
$page=$_GET["page"];
}
else{
$page=1;
}


// Start Pagination Code

$start_from=($page-1)*$per_page_record;

$filterurl=getsolrurlfuntion($filter);

$citydata=getcity($city);

if(!empty($citydata)){
 $pkgs=getpkgcount($filterurl['solrurl'],strtolower($citydata['title']),$per_page_record,$start_from);
}else{

$pkgs=array();
 
}

 
  foreach($pkgs['docs'] as $val){
    
    if($val['url']==''){
     $durl=$val['nid'].".html";
     }
     else{
      $durl=$val['url'];
     }
     $detailpages[]= array('title'=>$val['title'],'url'=>$durl);
     
   }

  
$total_records=$pkgs['numFound'];

$total_pages=ceil($total_records/$per_page_record);

// End Pagination Code


function getpkgcount($solrurl,$city,$record,$start_from){

$pattern = '/ /i';
$city = preg_replace($pattern, '%20', $city);

$city='"' . $city . '"';


 $ch = curl_init();

 // print_r("http://172.16.31.12:8983/solr/hellotravel_deals-new/select?fl=url,title,nid&q=destinations_covered:".$city.$solrurl."&rows=".$record."&start=".$start_from."");die;
 curl_setopt($ch, CURLOPT_URL, "http://172.16.31.12:8983/solr/hellotravel_deals-new/select?fl=url,title,nid&q=destinations_covered:".$city.$solrurl."&rows=".$record."&start=".$start_from."");
 curl_setopt($ch, CURLOPT_PORT, 8983);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
 curl_setopt($ch, CURLOPT_TIMEOUT, '4');
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

 $data = json_decode(curl_exec($ch), TRUE);

 curl_close($ch);

//print_r($data);die;
return $data['response'];


}


 function getsolrurlfuntion($url){
      $urlarr=$url;$metaurl='';

        if($urlarr=='budget3-luxury-5-star-hotel'){
          $solrurl=' AND budget:"Luxury (Above 5 Star Hotels)"';
          $metaurl='5 Star Hotel';
       }

       elseif($urlarr=='budget2-standard-4-star-hotel'){
          $solrurl=' AND budget:"Standard (3-5 Star Hotels)"';
           $metaurl='4 Star Hotel';
       }

       elseif($urlarr=='budget1-economy-3-star-hotel'){
          $solrurl=' AND budget:"Economy+(0-2 Star Hotels)"';
          $metaurl='3 Star Hotel';
       }

       elseif($urlarr=='duration1-1-3-days'){
          $solrurl=" AND days:[1 TO 3]";
          $metaurl='1-3 days';
       }

       elseif($urlarr=='duration2-4-7-days'){
          $solrurl=" AND days:[4 TO 7]";
          $metaurl='4-7 days';
       }

       elseif($urlarr=='duration3-8-14-days'){
          $solrurl=" AND days:[8 TO 14]";
          $metaurl='8-14 days';
       }

        elseif($urlarr=='duration4-2-3-weeks'){
         $solrurl=" AND days:[14 TO 21]";
         $metaurl='14-21 days';
      }

      elseif($urlarr=='duration5-3-plus-weeks'){
         $solrurl=" AND days:[22 TO 1000]";
         $metaurl='22+ days';
      }
      elseif($urlarr=='price1-less-10k'){
         $solrurl=" AND price_per_night:[0 TO 10000]";
         $metaurl="Price less than 10000";
         
      }
      elseif($urlarr=='price2-10k-25k'){
         $solrurl=" AND price_per_night:[10000 TO 25000]";
         $metaurl="Price 10000-25000";
         
      }
      elseif($urlarr=='price3-25k-50k'){
         $solrurl=" AND price_per_night:[25000 TO 50000]";
         $metaurl="Price 25000-50000";
         
      }
      elseif($urlarr=='price4-50k-plus'){
         $solrurl=" AND price_per_night:[50000 TO 100000]";
         $metaurl="Price 50000+";
      }

      elseif($urlarr=='agent2-4plusstar'){
         $solrurl=" AND star_rating_search:4 OR 5";
         $metaurl="4 Rated";
      }

      elseif($urlarr=='agent3-34star'){
         $solrurl=" AND star_rating_search:3";
         $metaurl="3-4 Rated";
      }

      elseif($urlarr=='theme-honeymoon'){
         $solrurl=' AND destinations_theme:"honeymoon"';
         $metaurl='honeymoon';
      }

      elseif($urlarr=='theme-adventure'){
         $solrurl=' AND destinations_theme:"adventure"';
         $metaurl='adventure';   
      }

      elseif($urlarr=='theme-beach'){
         $solrurl=' AND destinations_theme:"beach"';
         $metaurl='beach';
      }

      elseif($urlarr=='theme-hill-stations'){
         $solrurl=' AND destinations_theme:"hill-stations"';
         $metaurl='hill-stations';
      }

      elseif($urlarr=='theme-wildlife'){
         $solrurl=' AND destinations_theme:"wildlife"';
         $metaurl='wildlife';
      }

      elseif($urlarr=='theme-religious'){
         $solrurl=' AND destinations_theme:"religious"';
         $metaurl='religious';
      }
     
      else{
         $solrurl=' AND budget:"'.$urlarr.'"';
         $metaurl=$urlarr;
      }


      $pattern = '/ /i';
      $solrurlnew = preg_replace($pattern, '%20', $solrurl);

      
      return  array('solrurl'=>$solrurlnew,'metaurl'=>$metaurl,'urlarr'=>$urlarr);


 }



function getcity($city){
    $pattern = '/ /i';
    $city = preg_replace($pattern, '%20', $city);
    $city='"' . $city . '"';


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://172.16.31.12:8983/solr/hellotravel_ttd_pts/select?fl=country_name,dealscount,url,title,pts_url&q=type:%22pts%22%20%20AND%20url:".$city."");
    curl_setopt($ch, CURLOPT_PORT, 8983);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_TIMEOUT, '4');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    $data = json_decode(curl_exec($ch), TRUE);

    curl_close($ch);

    //print_r($data);
    return $data['response']['docs'][0];

   }

  


 if((empty($citydata))||(count($pkgs['docs'])=='0')){
     $noindex='1';
   }else{
     $noindex='0';
   }

$meta_filter=$filterurl['metaurl'];
$urlarr=trim($filterurl['urlarr']);
$city=trim($city);

$canonical="https://www.hellotravel.com/hellositemap/".$city."/". $urlarr."/";

$smarty_obj->assign('default_canonical',$canonical);
$smarty_obj->assign('default_meta',"Sitemap -" .$city ." Popular ". $meta_filter. "Package Details - Hellotravel");
$smarty_obj->assign('meta_string','Sitemap-city-filter');
$smarty_obj->assign('pagename' , "Sitemap-city-filter");
$smarty_obj->assign('page','sitemap-city-filter');
$smarty_obj->assign('noindex',$noindex);
$smarty_obj->assign('pageno',$page);
$smarty_obj->assign('city',$city);
$smarty_obj->assign('metacity',$citydata['title']);
$smarty_obj->assign('meta_filter',$meta_filter);
$smarty_obj->assign('filter',$filter);
$smarty_obj->assign('total_pages',$total_pages);
$smarty_obj->assign('detailpg',$detailpages); 
$smarty_obj->assign('total_records',$total_records); 
$smarty_obj->display('hellotravel2.0/header_demo.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/sitemap-city-filter.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');

?>
