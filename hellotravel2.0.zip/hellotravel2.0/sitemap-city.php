<?php
require_once("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");

$smarty_obj = new TplLoad();


require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");

$city=$_REQUEST['city'];


  $budgetArray=array('5 Star'=>'budget3-luxury-5-star-hotel','4 Star'=>'budget2-standard-4-star-hotel','3 Star'=>'budget1-economy-3-star-hotel');

  $duration_Array=array('1-3 days'=>'duration1-1-3-days','4-7 days'=>'duration2-4-7-days','8-14 days'=>'duration3-8-14-days','2-3 weeks'=>'duration4-2-3-weeks','3+ weeks'=>'duration5-3-plus-weeks');

  $price_Array=array('less than 10,000 '=>'price1-less-10k','10,000 - 25,000'=>'price2-10k-25k','25,000 - 50,000'=>'price3-25k-50k','50000+'=>'price4-50k-plus');

  $agent_Array=array('4+ Rated'=>'agent2-4plusstar','3 - 4 Rated'=>'agent3-34star');

  $themes_Array=array('Honeymoon'=>'theme-honeymoon','Adventure'=>'theme-adventure','Beach'=>'theme-beach','Hill Stations'=>'theme-hill-stations','Wildlife'=>'theme-wildlife','Religious'=>'theme-religious');



  function getindiacity($city){
    $pattern = '/ /i';
    $city = preg_replace($pattern, '%20', $city);
    $city='"' . $city . '"';

   //echo  "http://172.16.31.12:8983/solr/hellotravel_ttd_pts/select?fl=country_name,dealscount,url,title,pts_url&q=type:%22pts%22%20%20AND%20url:".$city."";die;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://172.16.31.12:8983/solr/hellotravel_ttd_pts/select?fl=country_name,dealscount,url,title,pts_url&q=type:%22pts%22%20%20AND%20url:".$city."");
    curl_setopt($ch, CURLOPT_PORT, 8983);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_TIMEOUT, '4');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    $data = json_decode(curl_exec($ch), TRUE);

    curl_close($ch);

    //print_r($data);die;
    return $data['response']['docs'][0];

   }

  

$citydata=getindiacity($city);


if(empty($citydata)){
  $noindex='1';
  $meta_city=$city;
}else{
  $noindex='0';
  $meta_city=$citydata['title'];
}
$meta_city=trim($meta_city);
$canonical="https://www.hellotravel.com/hellositemap/$meta_city";

$smarty_obj->assign('default_meta',"Sitemap -" .$meta_city. "- Hellotravel" );
$smarty_obj->assign('default_canonical',$canonical );
$smarty_obj->assign('meta_string','Sitemap-city');
$smarty_obj->assign('pagename' , "Sitemap-city");
$smarty_obj->assign('page','sitemap-city');

$smarty_obj->assign('noindex',$noindex);
$smarty_obj->assign('metacity',$meta_city);
$smarty_obj->assign('hcity',$citydata['title']);
$smarty_obj->assign('city',$citydata['url']);

$smarty_obj->assign('budgetfilter',$budgetArray);
$smarty_obj->assign('durationfilter',$duration_Array);
$smarty_obj->assign('pricefilter',$price_Array);
$smarty_obj->assign('agentfilter',$agent_Array);
$smarty_obj->assign('themesfilter',$themes_Array);

$smarty_obj->display('hellotravel2.0/header_demo.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
$smarty_obj->display('hellotravel2.0/sitemap-city.tpl');
$smarty_obj->display('hellotravel2.0/footer_demo.tpl');

?>