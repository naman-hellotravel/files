<?php


/****************************Top Banner***************************/
    function getBannerDgn($home_json){
        $main_data=array(); 
    
        $main_data["photos_slide"] = $home_json->photo_slide;
        
        if(isset($main_data["photos_slide"]) && count($main_data["photos_slide"])){
            
             $photos_slide=$main_data["photos_slide"];
                    return $photos_slide;
            }
    } 



/****************************Latest Updates For You***************************/
    function getLatestDgn($home_json){
        $main_data=array();  $return_data=array();
       
        $main_data["ideal_json"] = $home_json->ideal_json;
        if(isset($main_data["ideal_json"]) && count($main_data["ideal_json"])){
                $js_data_new=$main_data["ideal_json"]->latestptsttd;

                foreach ($js_data_new as $key => $val) {
                    
                    if($val->image_path!=''){
                    $stararray = array($val->star1 ,$val->star2 ,$val->star3 ,$val->star4 ,$val->star5);
                    $total_rating = array_sum($stararray);
                    $ratings = (5*$val->star5+4*$val->star4+3*$val->star3+2*$val->star2+1*$val->star1)/$total_rating;
		 
                    $total_rating = ($total_rating>0)?$total_rating:50;
                    $rating = floor($ratings);
                    $rating = ($rating>0)?$rating:5;
                    $rating = $rating;
                    $ratingCnt = $total_rating;

                    $title = ucfirst($val->title);
                    $link = ($val->type=='pts')?$val->pts_url:$val->ttd_url;
                    
                    $image_path = $val->image_path;

                    $str = $image_path;
                    
                    $pattern = "/https/i";
                    if(preg_match_all($pattern, $str, $matches)) {
                    $img_path=$image_path;
                    }
                    else
                    {
                    //$img_path="https://www.hlimg.com/images/things2do/738X538/".$image_path;
		    if($val->type=='pts'){
                     $img_path="https://www.hlimg.com/images/places2see/300X200/".$image_path;
                     }else{
                      $img_path="https://www.hlimg.com/images/things2do/300X200/".$image_path;
                     }
                    }
                    
                    $latest = array();
                    $latest["title"] = ucfirst($title);  
                    $latest["url"]   = $link;
                    
                    $latest["image"] = $img_path;
                    $latest["rating"] = $rating;
                    $latest["rating_count"] = $ratingCnt;
                    $return_data[] =     $latest;
                      
                  }
                }

                    return $return_data;
            }
    } 


 /***********************Trending Travel Stories AND tips************************/
    function getTravelTipsDgn(){
        $main_data=array(); $return_data=array();
        $travelntips = @file_get_contents("http://ht-search:2000/solr/hellotravel_story_new/select?q=story_type%3Amain&sort=changed_datetime_timestamp+DESC&rows=11&wt=json&indent=true"); 
        $main_data['travelntipsData'] = json_decode($travelntips);
       
            if(isset($main_data['travelntipsData']) && count($main_data['travelntipsData'])){
                $travelntipsData=$main_data['travelntipsData']->response->docs;
                foreach ($travelntipsData as $key => $value) {

                    if($value->image_path!=''){
                            $travelTips = array();
                            $travelTips["title"] = ucfirst($value->title);  
                            $travelTips["url"]   = "https://www.hellotravel.com/stories/".$value->url;
                            $travelTips["image"] = "https://www.hlimg.com/images/stories/300X200/".$value->image_path;
                            $travelTips["description"] = strip_tags($value->description);
                            $travelTips["datetime"] = $date=date("d F Y", strtotime($value->changed_datetime));
                            $return_data[] =     $travelTips;
                           
                    }
                    
               }
               
                return $return_data;   
            }
    }
    

/***********************India's 10 most Popular Destinations************************/

    function getmostpplDestDgn($home_json){
        $main_data=array(); global $home_json;
        
        $indmostppl = array();   
            foreach($home_json->indiasMostPplPlaces as $key=>$val){
              
                foreach($val as $value){
                    if($value->image!=''){
                    $indmost = array();
                    $indmost["title"] = ucfirst($value->place);  
                    $indmost["url"]   = $value->url;
                    $image = explode(",",$value->image);
                    $indmost["image"] = $image[0];
                    $indmost["price"] = $value->pts_price;
                    $indmost["state"] = $value->state;
                    $indmostppl[] =     $indmost;
                    }
                }
            }
            
           
            $main_data["indmostppl"] = $indmostppl; 
        
            if(isset($main_data["indmostppl"]) && !empty($main_data["indmostppl"])){
                $indmostpplData=$main_data["indmostppl"];
                return $indmostpplData; 
            }  
   }


/***********************Most Popular Ideal Destinations Near you************************/

    function getmostpplIdealDgn($home_json){
        $main_data=array(); 
        $main_data["ideal_json"] = $home_json->ideal_json;

        if(isset($main_data["ideal_json"]) && count($main_data["ideal_json"])){
            
            $data_res=array();
            $js_data=$main_data["ideal_json"];
            $js_data_new=$main_data["ideal_json"]->latestptsttd;
            $random="random_".rand(12341,102345)."+desc";   
            $deals="http://ht-search-new:8983/solr/hellotravel_deals-new/select?q=booking_status%3A1%20NOT%20(photo_status:0)&sort=$random&rows=10&wt=json&indent=true";
            $deals_pkg='http://ht-search-new:8983/solr/hellotravel_deals-new/select?q=(package_type:3%20OR%207)%20NOT%20(photo_status:0%20OR%20booking_status%3A1%20)&sort='.$random.'&rows=8&wt=json&indent=true&group.field=tbl_login_id&group.limit=1&group=true';
           
            $parse_data=parse_list_results($deals);   
            $parse_data_pkg=get_groups_data_result($deals_pkg,"tbl_login_id");
    
            $data_res=array_merge($parse_data["result"],$parse_data_pkg);
            $js_data->deals=$data_res;
           //print_r($js_data->deals);die;
            return $js_data;
           

        }

    }
    

/*************************************Holiday Theme**************************/
   function getHolidayThemeDgn($home_json){
        $main_data=array();
        $obj = new Places_data();
        $holidayTheme  = $home_json->holiday_theme;
        $holiday_theme = array();
        foreach($holidayTheme as $key=>$val){
            if($val->image!=''){
            $args = array("country"=>$userCountry,"themes"=>"$val->title");
            $result = $obj->getPlaces($args);
            if($result["count"] > 0){
         $holiday_theme[] = array("title"=>"$val->title","url"=>"https://www.hellotravel.com/$userCountry/$val->url-places","link"=>"https://www.hellotravel.com/$userCountry/$val->url-places","image"=>"https://www.hlimg.com/images/home-img/".$val->image,"destCnt"=>$result["count"]);
            }
          } 
        }
        $main_data["holiday_theme"]=$holiday_theme;
    
        
     if(isset($main_data["holiday_theme"]) && !empty($main_data["holiday_theme"])){
         $holiday_themeData =$main_data["holiday_theme"];
         return $holiday_themeData;
    }
   }

 /*************************************Review Happy Travelers**************************/

   function getReviewDgn($home_json){
    
    $main_data=array(); 
    $main_data["reviewsdata"] = $home_json->reviewsdata;
    if(isset($main_data["reviewsdata"]) && count($main_data["reviewsdata"])){
        $reviewData=$main_data["reviewsdata"];
       
        return $reviewData; 
    }

}

     
 /********************************Statewise Tourist Destinations*********************/
 function getIndStateDestDgn($home_json){
    $indian_states = array ('Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jammu & Kashmir',  'Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur',      'Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Tripura','Uttarakhand','Uttar Pradesh','West Bengal');
    $main_data=array(); 
        shuffle($indian_states);
        
        $random_3_state = $indian_states;
        $ppl_indian_tourist_destination = array();
        $counter=0;

        foreach($random_3_state as $val){
            
           
           $travelGuideObj = new Places_data();
           $returnData = $travelGuideObj->getPlaces(array("state"=>strtolower($val)));
        
           if($counter == 6){
               break;
           }
           if($returnData >0){
          
           $ppl_indian_tourist_destination["$val"] = $returnData;
           
           }
       $counter++; 

       }
       
       
        $main_data["ppl_indian_tourist_destination"] = $ppl_indian_tourist_destination; 
    
    if(isset($main_data["ppl_indian_tourist_destination"]) && count($main_data["ppl_indian_tourist_destination"])){
        $ppl_indian_tourist_destinationData=$main_data["ppl_indian_tourist_destination"];
        return $ppl_indian_tourist_destinationData; 
    }  

}
     
   
   
 /********************************Popular Tourist Countries*********************/
    function getIntDestDgn($home_json){
        $main_data=array(); 
        $travelGuideObj = new Places_data();

        $main_data["mostPplCountries"]  = $home_json->mostpplCountries;
            
            for($j=0;$j<count($main_data["mostPplCountries"]);$j++)
            {
                $t_country[]=$main_data["mostPplCountries"][$j]->title;

            }

        shuffle($t_country);
        $random_3_country = $t_country; 
        $ppl_international_t_destination = array();
        $counter = 0;
        foreach($random_3_country as $val){
            $returnData = $travelGuideObj->getPlaces(array("country"=>strtolower($val)));
            if($counter == 6){
                break;
            }
            if($returnData >0){
                $ppl_international_t_destination["$val"] = $returnData;
            }
            $counter++;
        }

        $main_data["ppl_international_t_destination"] = $ppl_international_t_destination;  

        if(isset($main_data["ppl_international_t_destination"]) && count($main_data["ppl_international_t_destination"])){
            $ppl_international_t_destinationData=$main_data["ppl_international_t_destination"];
            return $ppl_international_t_destinationData; 
        }  

    }


    function getTopAgentDgn($home_json){
      $main_data=array();$return_data=array();  
      $main_data["topagent"] = $home_json->topagent;
        
      if(isset($main_data["topagent"]) && count($main_data["topagent"])){
         foreach($main_data["topagent"] as $key => $val){
          
             if($val->fcpimgurl!=''){ 
                 $return_data[$key]=$val; 
                 
             }
         }
         return $return_data;
      }
    }


    function getPplAgentDgn($home_json){
      $main_data=array(); 
      $main_data["pplagent"] = $home_json->ppl_Agents;

      if(isset($main_data["pplagent"]) && count($main_data["pplagent"])){
        foreach($main_data["pplagent"] as $key => $val){
            if($val->path!=''){ 
                $return_data[$key]=$val; 
            }
        }
        return $return_data;
     }

    }



     /***********************Trending Travel Stories AND tips************************/
     function getEventDgn(){
        $main_data=array(); $return_data=array();
        $random="random_".rand(12341,102345)."+desc";  
        //$eventData= @file_get_contents("http://ht-search:2000/solr/hellotravel_events/select?q=status%3A1&sort=$random&rows=12&fl=title%2Cimage_path%2Ccity%2Ccountry_name%2Cstate%2Cvenue%2Curl%2Cstart_date%2Cend_date%2Ccategory&wt=json&indent=true");
         $today = date("Ymd");
         $eventData= @file_get_contents("http://ht-search:2000/solr/hellotravel_events/select?q=*%3A*+status%3A1+AND+start_date_long%3A%5B".$today."+TO+*%5D&sort=start_date_long+asc&fl=country_name%2Cid%2Ctitle%2Curl%2Cimage_path%2Cstart_date%2Cend_date%2Cvenue%2Cstate%2Ccity%2Ctag_theme%2Ccountry_iso_code&wt=json&indent=true&start=0&rows=11");

         
        $main_data['eventData'] = json_decode($eventData);
   
     
            if(isset($main_data['eventData']) && count($main_data['eventData'])){
                $eventData=$main_data['eventData']->response->docs;

             
                foreach ($eventData as $key => $value) {

                    if($value->image_path!=''){
                        
                            $eventTips = array();
                            $eventTips["title"] = ucfirst($value->title);  
                            $eventTips["url"]   = "https://www.hellotravel.com/".$value->url;
                            $eventTips["image"] = "https://www.hlimg.com/images/events/216X180/".$value->image_path;
                            // $eventTips["category"] = strip_tags($value->category);
                            $eventTips["city"] = ucwords($value->city);
                            $eventTips["state"] = ucwords($value->state);
                            $eventTips["country"] = ucwords($value->country_name);
                            
                            $eventTips["start_date"] = $date=date("d F Y", strtotime($value->start_date));
                            $eventTips["end_date"] = $date=date("d F Y", strtotime($value->end_date));
                            $now = time(); // or your date as well
                            $now=strtotime($value->end_date);
                            $your_date = strtotime($value->start_date);
                            $datediff = $now - $your_date;

                            $dayval= round($datediff / (60 * 60 * 24));
                            $eventTips["day"]=$dayval+1;

                            $return_data[] =     $eventTips;
                           
                    }
                    
               }
              
            //  print_r($return_data);die;
                return $return_data;   
            }
    }



    
  
?>
