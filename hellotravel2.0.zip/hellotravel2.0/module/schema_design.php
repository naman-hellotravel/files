<?php

require_once ("/home/indiamart/public_html/hellotravel-agents/includes/mask_lib.php"); 

$json_str=file_get_contents("/home/indiamart/public_html/hlimg-com/images/jsnew/data.txt");
$json_data = file_get_contents("/home/indiamart/public_html/hellotravel/includes/topjson/headerData.txt");

$object_header_link=json_decode($json_str);


//DT
// domestic leads//

$month = date("M");
$domestic_pack = array();
$n = 0;
$home_link_domestic=$object_header_link->home_link->domestic_trending->MONTH->$month;
$shuffleKeys = array_keys($home_link_domestic);
shuffle($shuffleKeys);
$counter=0;
$nav_schema_arrays = array();
foreach($shuffleKeys as $v){
	if($counter > 5){
		break;
	}
	$record=$home_link_domestic[$v];

        $country_name_places=$record->TBL_COUNTRY;
	$title_name_dom = $record->title;
        $url_plc=$record->url;
        $title_name_dom = $record->title;
        $url_title_plc="https://www.hellotravel.com/".strtolower(str_replace(' ','-', $country_name_places))."/".$url_plc;
        $domestic_pack[$counter] = array('title_domestic' => $title_name_dom, 'link_domestic' =>
            $url_title_plc);
        $counter++;
        //DT
        $nav_schema_arrays[] = array(
                            "@context"=>"https://schema.org",
                            "@type"=> "SiteNavigationElement",
                            "name"=> "$title_name_dom",
                            "url"=>"$url_title_plc"
                        );
        //dtend
}
// end domestic leads//


// international leads//

$international_pack = array();
$m = 0;
$home_link_international=$object_header_link->home_link->international_trending->MONTH->$month;
$shuffleKeys = array_keys($home_link_international);
shuffle($shuffleKeys);
$counter=0;
foreach($shuffleKeys as $v){
        if($counter > 5){
                break;
        }
	$record=$home_link_international[$v];
	$title_name_inter = $record->title;
    	$trend_link_inter = str_replace("http://","https://",strtolower($record->link));
    	$international_pack[$counter] = array('title_inter' => $title_name_inter, 'link_inter' =>
            $trend_link_inter);
    $counter++;
    //DT
    $nav_schema_arrays[] = array(
        "@context"=>"https://schema.org",
        "@type"=> "SiteNavigationElement",
        "name"=> "$title_name_inter",
        "url"=>"$trend_link_inter"
    );
    //dtEND
}
// end international leads//

# Top trip idea header start
$top_trip_idea_header = array();
$header_stories_count = 0;
$home_link_stories=$object_header_link->home_link->stories;
$shuffleKeys = array_keys($home_link_stories);
shuffle($shuffleKeys);
$counter=0;
foreach($shuffleKeys as $v){
	if($v == 'MONTH'){
		continue;
	}
        if($counter > 5){
                break;
        }

        $record=$home_link_stories[$v];
        $title_name_inter = $record->title;
        $trend_link_inter = str_replace("http://","https://",strtolower($record->link));
         $top_trip_idea_header[$counter] = array('title' => $title_name_inter, 'link' =>
            $trend_link_inter);
        $counter++;
        //DT
        $nav_schema_arrays[] = array(
            "@context"=>"https://schema.org",
            "@type"=> "SiteNavigationElement",
            "name"=> "$title_name_inter",
            "url"=>"$trend_link_inter"
        );
        //dtEND
}

# Top trip idea header end

//Events start
$events_header = array();
$home_link_event=$object_header_link->event_data;
$shuffleKeys = array_keys($home_link_event);
shuffle($shuffleKeys);
$counter=0;
foreach($shuffleKeys as $v){
        if($counter > 5){
                break;
        }
        $record=$home_link_event[$v];
        $title_name_inter = $record->title;
	$events_header[$counter]['title'] = $record->title;
        $events_header[$counter]['link'] = $record->link;
        $counter++;
        //DT
        $nav_schema_arrays[] = array(
            "@context"=>"https://schema.org",
            "@type"=> "SiteNavigationElement",
            "name"=> "$title_name_inter",
            "url"=>"https://www.hellotravel.com/$record->link"
        );
        //dtEND
}

/*
$sql_events = "SELECT id, title, url, start_date FROM tbl_event_upload WHERE STATUS = '1' AND start_date >= current_date order by rand() limit 0,5";

$rs_events = dbprocess($sql_events);
if (mysql_num_rows($rs_events)) {
    while ($row_events = mysql_fetch_array($rs_events)) {
        $events_header[$event_count]['title'] = $row_events['title'];
        $events_header[$event_count]['link'] = $row_events['url'];
        $event_count++;
    }
}
*/
$shuffleKeys = array_keys($theme_array_menu);
shuffle($shuffleKeys);
$newArray = array();
$footerthemes = array();
$j = 1;
foreach ($shuffleKeys as $key) {
    if ($j <= 6) {
        $newArray[$key] = $theme_array_menu[$key];
    } else if($j <= 12 ) {
        $footerthemes[$key] = $theme_array_menu[$key];
    }
    $j++;
}






/* DT HoneyMoon Array start*/
$honeymoon_array = array(array("name"=>"Top 20 Honeymoon Places In India in 2018","url"=>"https://www.hellotravel.com/stories/honeymoon-destinations-in-india"),
			array("name"=>"8 Best Honeymoon Places Outside India","url"=>"https://www.hellotravel.com/stories/8-best-honeymoon-places-outside-india"),
			array("name"=>"9 Top Winter Honeymoon Destinations in India","url"=>"https://www.hellotravel.com/stories/9-top-winter-honeymoon-destinations-in-india"),
			array("name"=>"Best honeymoon locations in India for a budget of 40k to 50k","url"=>"https://www.hellotravel.com/stories/best-honeymoon-locations-in-india-for-a-budget-of-40k-to-50k"),
            array("name"=>"5 Best Honeymoon Destinations in India for 5 days","url"=>"https://www.hellotravel.com/stories/5-best-honeymoon-destinations-in-india-for-5-days"),
            array("name"=>"9 Top Winter Honeymoon Destinations outside India","url"=>"https://www.hellotravel.com/stories/9-top-winter-honeymoon-destinations-outside-india"),
            array("name"=>"Best International honeymoon locations for a budget of 65k to 75k","url"=>"https://www.hellotravel.com/stories/best-international-honeymoon-locations-for-a-budget-of-65k-to-75k")
            );
            foreach($honeymoon_array as $honeymoon_arrays){
                $name = '';
                $url = '';
                $name = $honeymoon_arrays['name'];
                $url = $honeymoon_arrays['url'];
                $nav_schema_arrays[] = array(
                    "@context"=>"https://schema.org",
                    "@type"=> "SiteNavigationElement",
                    "name"=> "$name",
                    "url"=>"$url"
                );
            }
$Weekend_getaways_array = array(array("name"=>"Places to visit near Hyderabad","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-hyderabad"),
                                array("name"=>"Places to visit near Mumbai","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-mumbai"),
                                array("name"=>"Places to visit near Delhi","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-delhi"),
                                array("name"=>"Places to visit near Kolkata","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-kolkata"),
                                array("name"=>"Places to visit near Bangalore","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-bangalore"),
                                array("name"=>"Places to visit near Chennai","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-chennai")
        );
        foreach($Weekend_getaways_array as $honeymoon_arrays){
            $name = '';
            $url = '';
            $name = $honeymoon_arrays['name'];
            $url = $honeymoon_arrays['url'];
            $nav_schema_arrays[] = array(
                "@context"=>"https://schema.org",
                "@type"=> "SiteNavigationElement",
                "name"=> "$name",
                "url"=>"$url"
            );
        }
        // honeymoon end
        $bread_schema_arrays["@context"]= "https://schema.org";
        $bread_schema_arrays["@type"]= "BreadcrumbList";
        $bread_schema_arrays["itemListElement"][]=array("@type"=>"ListItem","position"=>1,"name"=>"Home","item"=>"https://www.hellotravel.com");
        if($dest_url>0)
        {
            $itemListElement=array("@type"=>"ListItem","position"=>2,"name"=>"$country_name","item"=>"https://www.hellotravel.com$country_urlVal");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
        if($ptc_url>0)
        {
            $itemListElement= array("@type"=>"ListItem","position"=>3,"name"=>"$state_name","item"=>"https://www.hellotravel.com$state_urlVal");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
        if(!empty($city_name))
        {
            $itemListElement=array("@type"=>"ListItem","position"=>4,"name"=>"$city_name","item"=>"https://www.hellotravel.com$city_urlVal");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
        if($main_data['page'] == 'things_2do_detail')
        {
        $itemListElement=array("@type"=>"ListItem","position"=>5,"name"=>"$main_title","item"=>"https://www.hellotravel.com$country_urlVal/$final_url_value");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
        if($main_data['page'] == 'deal')
        {
            $actual_link = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $itemListElement=array("@type"=>"ListItem","position"=>3,"name"=>"Tour packages","item"=>"$actual_link");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
                                if($page == 'story')
        {
            $itemListElement= array("@type"=>"ListItem","position"=>2,"name"=>"Trip Ideas","item"=>"https://www.hellotravel.com/stories");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
            $itemListElement= array("@type"=>"ListItem","position"=>3,
            "name"=>"$main_title","item"=>"https://www.hellotravel.com/stories/$final_url_value");
            $bread_schema_arrays["itemListElement"][]=$itemListElement;
        }
        $jsonencodeb = json_encode($bread_schema_arrays);
        $schematagbread = ' <script type="application/ld+json">'.$jsonencodeb.'</script>';
        
        //bread end

$organization_array = array(
    '@context'=>'https://schema.org',
    '@type'=> 'Organization',
    'url'=>'https://www.hellotravel.com',
    'logo'=>'https://www.hellotravel.com/sites/all/themes/newswire/images/logo-header.png',
    'telephone'=>'8048735999',
    'email'=>'helpdesk@hellotravel.com',
    'sameAs'=>array(
        'https://www.facebook.com/hellotravel',
        'https://twitter.com/hellotravel',
        'https://www.instagram.com/hellotravelofficial'),
    'address'=>array('@type'=>'PostalAddress','name'=>'E-75, 2nd Floor, Sector 63, Noida - 201301, Uttar Pradesh')
    );
    $jsonencodeorg = json_encode($organization_array);
    $schematagorg = ' <script type="application/ld+json">'.$jsonencodeorg.'</script>';

    $smarty_obj->assign('SchemaTagOrgDesign', $schematagorg);

  









?>
