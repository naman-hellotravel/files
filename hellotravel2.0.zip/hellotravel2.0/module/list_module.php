<?php
$page_type_section = "ads";
$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";

$duration_hash = array("1-3-days"=>array("NAME"=>"1-3-days","SOLR_ARGS"=>"1-3","CNT"=>1,"LABEL_NAME"=>"1 3 days","META"=>"1 to 3 days"),"4-7-days"=>array("NAME"=>"4-7-days","SOLR_ARGS"=>"4-7","CNT"=>2,"LABEL_NAME"=>"4-7 days","META"=>"4 to 7 days"),"8-14-days"=>array("NAME"=>"8-14-days","SOLR_ARGS"=>"8-14","CNT"=>3,"LABEL_NAME"=>"8-14 days","META"=>"8 to 14 days",),"2-3-weeks"=>array("NAME"=>"2-3-weeks","SOLR_ARGS"=>"14-21","CNT"=>4,"LABEL_NAME"=>"2-3 Weeks","META"=>"3 to 3 weeks"),"3-plus-weeks"=>array("NAME"=>"3-plus-weeks","SOLR_ARGS"=>"22-*","CNT"=>5,"LABEL_NAME"=>"3 Weeks +","META"=>"3+ weeks"));

$price_hash = array("less-10k"=>array("NAME"=>"less-10k","SOLR_ARGS"=>array("min_price"=>"*","max_price"=>10000),"CNT"=>1),"10k-25k"=>array("NAME"=>"10k-25k","SOLR_ARGS"=>array("min_price"=>"10000","max_price"=>25000),"CNT"=>2),"25k-50k"=>array("NAME"=>"25k-50k","SOLR_ARGS"=>array("min_price"=>"25000","max_price"=>50000),"CNT"=>3),"50k-plus"=>array("NAME"=>"50k-plus","SOLR_ARGS"=>array("min_price"=>"50000","max_price"=>"*"),"CNT"=>4));

$budgetpernight_hash = array("2k"=>array("NAME"=>"2k","SOLR_ARGS"=>array("min_price"=>"*","max_price"=>2000),"CNT"=>1),"3k"=>array("NAME"=>"3k","SOLR_ARGS"=>array("min_price"=>"*","max_price"=>3000),"CNT"=>2),"5k"=>array("NAME"=>"5k","SOLR_ARGS"=>array("min_price"=>"*","max_price"=>5000),"CNT"=>3));

$agent_hash = array("trustseal"=>array("NAME"=>"trustseal","SOLR_ARGS"=>array("ts_status"=>"1"),"CNT"=>1),"4plusstar"=>array("NAME"=>"4plusstar","SOLR_ARGS"=>array("star_rating_search"=>"4 OR 5"),"CNT"=>2),"34star"=>array("NAME"=>"34star","SOLR_ARGS"=>array("star_rating_search"=>"3"),"CNT"=>3));

$booking_hash = array("1"=>array("NAME"=>"booking","SOLR_ARGS"=>array("booking_status"=>"1"),"CNT"=>1));

$budget_hash = array("economy"=>array("NAME"=>"economy-3-star-hotel","SOLR_ARGS"=>"Economy+(0-2 Star Hotels)","CNT"=>1,"LABEL_NAME"=>"Economy"),"standard"=>array("NAME"=>"standard-4-star-hotel","SOLR_ARGS"=>"Standard ( 3-5 Star Hotels)","CNT"=>2,"LABEL_NAME"=>"Standard"),"luxury"=>array("NAME"=>"luxury-5-star-hotel","SOLR_ARGS"=>"Luxury (Above 5 Star Hotels)","CNT"=>3 , "LABEL_NAME"=>"Luxury"));

$budget_hashx = array("economy-3-star-hotel"=>array("NAME"=>"economy-3-star-hotel","SOLR_ARGS"=>"Economy+(0-2 Star Hotels)","CNT"=>1,"LABEL_NAME"=>"Economy","META"=>"3 star"),"standard-4-star-hotel"=>array("NAME"=>"standard-4-star-hotel","SOLR_ARGS"=>"Standard ( 3-5 Star Hotels)","CNT"=>2,"LABEL_NAME"=>"Standard","META"=>"4 star"),"luxury-5-star-hotel"=>array("NAME"=>"luxury-5-star-hotel","CNT"=>3,"SOLR_ARGS"=>"Luxury (Above 5 Star Hotels)","LABEL_NAME"=>"Luxury","META"=>"5 star"));

$destination_theme_hashx = array("honeymoon"=>array("NAME"=>"honeymoon","SOLR_ARGS"=>"honeymoon","CNT"=>1),"adventure"=>array("NAME"=>"adventure","SOLR_ARGS"=>"adventure","CNT"=>2),"beach"=>array("NAME"=>"beach","SOLR_ARGS"=>"beach","CNT"=>3),"hill"=>array("NAME"=>"hill-stations","SOLR_ARGS"=>"hill stations","CNT"=>4),"wildlife"=>array("NAME"=>"wildlife","SOLR_ARGS"=>"wildlife","CNT"=>5),"religious"=>array("NAME"=>"religious","SOLR_ARGS"=>"religious","CNT"=>6));

//code block//
$ptsobj = new Pts_Ttd_Data(array("type" => "pts"));
$ip = getIPfromXForwarded();
$reader = new Geo_Reader($ip);
$ip_details = $reader->getIpdetails();
$ip_city_name=$ip_details['city'];
$count_new=0;
$pageURL= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];


if($_REQUEST['cityloc_to']!=''){
  $string  = $_REQUEST['cityloc_to'];
  if(strstr($string,"--") || strstr($string,"---") ||  strstr($string,"----") || substr($string, -1, 1) == '-' || substr($string, 0, 1) == '-'){
         $string = preg_replace('/-+/', '-', $string);
         $string = trim($string,'-');
         header("HTTP/1.1 301 Moved Permanently");
         header('Location: http://'.$_SERVER["SERVER_NAME"].'/deals/'.$string);
         exit;
  }
}

//check filter status true | False 
$filteravl='0';
if(preg_match("/\/q\//ism",$_SERVER["REQUEST_URI"])){
        $filteravl='1';
}

$con_place=array();
$con_place_value="";
$canonical=0;
$primiumhtml = "";
$destinations_themelc=array();
$listrowhtml =  '';
$mobile_device=0;
$mobile_device=detect_mobile_device_new() ;

$travelguidedesc = "";
$similarplacesdata=array();
$placerating = "5";
$placerating_count="";



$link='https://';
$link.= $_SERVER['HTTP_HOST'];
$link.= $_SERVER['REQUEST_URI'];


if(preg_match('/place_to=[^&]*/',$_SERVER["REQUEST_URI"],$con_place)){
    $con_place_value=$con_place[0];


}else if(preg_match('/place_to=.*$/',$_SERVER["REQUEST_URI"],$con_place)){
    $con_place_value=$con_place[0];

}




$con_place_value_old = $con_place_value;

$request_uri=$_SERVER["REQUEST_URI"];

if($con_place_value != ""){
    $con_place_value=preg_replace('/\&/','',$con_place_value);
    $con_place_value = str_replace('-+-','-s-',$con_place_value);
    $con_place_value=preg_replace('/place_to=/','',$con_place_value);
    $request_uri=str_replace($con_place_value_old,'',$request_uri);
    $request_uri=str_replace('?','/'.$con_place_value.'?',$request_uri);
    $request_uri=str_replace('?&','?',$request_uri);
    $request_uri=str_replace('&&','&',$request_uri);

}else if(preg_match('/\-\+\-/',$request_uri)){
    $canonical=1;
        $request_uri=$_SERVER["REQUEST_URI"];
        $request_uri=str_replace('-+-','-s-',$request_uri);
}
else{
    if(preg_match('/((price)|(budget)|(duration))\d{1,}/i',$request_uri) && !preg_match('/[\?]/',$request_uri)){
      //   $nometa_index=1;
    }elseif(preg_match('/(-\+-)|(%20-%20)|(---)/',$request_uri)){
        $nometa_index=1;
    }

}


$meta_add_page_num='';
$meta_add_page='';
$meta_add=explode('page=',$pageURL);
$meta_add_arr=explode("/",$pageURL);
$ads_flag=0;
if(in_array("$page_type_section",$meta_add_arr)){
    $ads_flag=1;
}

$request_uri="https://www.hellotravel.com".$request_uri;
//change code
$request_uri="http://local.hellotravel.noida".$request_uri;
$request_uri= preg_replace("([\?]{1,}$)", "", $request_uri);

$meta_add_page_num=explode('&',$meta_add[1]);

if(!empty($meta_add_page_num[0]))
{
    $meta_add_page=" | page ".$meta_add_page_num[0]." | ";
}
 $referer=$_SERVER['HTTP_REFERER'];
$imgpath = "https://www.hlimg.com/images/deals/360X230/";

    $place_to='';
    $place_from='';
    $clause='';
    $clause_from='';
    $clause_to='';
    $check_clause_to='';

    $star='';
   $themes='';
 
    $durations=array();
    $star1='';
    $star2='';
    $star3='';
    $star4='';
    $star5='';

    $clause_star='';
    $clause_duration='';
    $clause_star_rate='';
    $clause_budget='';
    $price_clause='';
    $comma_separated_uid='';
    $star_price='';
    $comma_separated='';
    $clause_prices='';
    $prices=array();
    $agents=array();
 
    $ref_page='';

    if(isset($_COOKIE['leadvalue']))
    {
    $cookie_value=$_COOKIE['leadvalue'];
     $lead_value = base64_decode($cookie_value);
    $ref_page='yes';
    }

// $referer='thanks.php';
if (strpos($referer, 'thanks.php') !== false)
{
  if($lead_value !='')
    {
    $connect_val=fetch_one_column_from_table("tbl_leads", "TBL_LEAD_CONNECTED", 'TBL_LEAD_ID', $lead_value);
    }
    $user_name = "<script>document.write(username)</script>";
     $referer_trips='<td>Hi '.ucfirst($user_name).', here, we have more recommended packages for you. Please enquire to get quotes.';
}

$all_filter_data=array();
    $duration_filter =array();
    $duration_url = $_SERVER['REQUEST_URI'];
    $filter_case = "";
    $filter_array_name=array();
    preg_match_all("/duration.-(\d+-\d*\w*-*\w+)/", $duration_url, $output_array);
    if(isset($output_array[1]) && !empty($output_array[1]))
    {
    $durationarr = $output_array[1];
    //print_r($durationarr);die;
    array_push($filter_array_name,"Duration");      
    foreach($durationarr as $data){
            if(isset($duration_hash[$data]) && !empty($duration_hash[$data])){
            $duration_obj=$duration_hash[$data];
            $durations[$duration_obj["CNT"]]=$duration_obj["NAME"];
            array_push($duration_filter,$duration_obj["SOLR_ARGS"]);
        }
    }
    }
$all_filter_data['duration_filter'] = $duration_filter;


    $price_filter = array();
    preg_match_all("/price.-(\d*\w*-\d*\w+)/", $duration_url, $output_array);
        
    if(isset($output_array[1]) && !empty($output_array[1]))
    {
    $pricearr = $output_array[1];
    array_push($filter_array_name,"Price");     
    foreach($pricearr as $data){
         if(isset($price_hash[$data]) && !empty($price_hash[$data])){
                        $price_obj=$price_hash[$data];
                        $prices[$price_obj["CNT"]]=$price_obj["NAME"];
                        array_push($price_filter,$price_obj["SOLR_ARGS"]);
                }
    
    }
    }
    $all_filter_data['price_filter'] = $price_filter;

    $agentstar_filter = array();
    preg_match_all("/agent.-(\w+)/", $duration_url, $output_array);
        // print_r($output_array);
        // exit;
    if(isset($output_array[1]) && !empty($output_array[1]))
    {
       // echo "soumya";
    $stararr = $output_array[1];
    //print_r($stararr);
    array_push($filter_array_name,"Agents");        
    foreach($stararr as $data){
         if(isset($agent_hash[$data]) && !empty($agent_hash[$data])){
                        $agent_obj=$agent_hash[$data];
                        $agents[$agent_obj["CNT"]]=$agent_obj["NAME"];
                        array_push($agentstar_filter,$agent_obj["SOLR_ARGS"]);
                }
    
    }
    }
    $all_filter_data['agentstar_filter'] = $agentstar_filter;
    
    $budgetpernight_filter = array();
    preg_match_all("/budgetpernight.-(\w+)/", $duration_url, $output_array);
        
    if(isset($output_array[1]) && !empty($output_array[1]))
    {
       // echo "soumya";
    $budgetpernight_arr = $output_array[1];
    //print_r($stararr);
    array_push($filter_array_name,"Hotel");     
    foreach($budgetpernight_arr as $data){
         if(isset($budgetpernight_hash[$data]) && !empty($budgetpernight_hash[$data])){
                        $budgetpernight_obj=$budgetpernight_hash[$data];
                        $budgetprnight[$budgetpernight_obj["CNT"]]=$budgetpernight_obj["NAME"];
                        array_push($budgetpernight_filter,$budgetpernight_obj["SOLR_ARGS"]);
                }
    
    }
    }
    //print_r($agentstar_filter);exit;
   // $all_filter_data['budgetpernight_filter'] = $budgetpernight_filter;
    $budget_filter = array();
    $budget_case = "";
    $budgets=array();
    preg_match_all("/budget.-(\w+)/", $duration_url, $output_array);
    if(isset($output_array[0]) && !empty($output_array[0]))
    {
    $budgetarr = $output_array[1];
     array_push($filter_array_name,"Hotel");        
    #print_r($budgetarr);
    foreach($budgetarr as $data){
        //$dataarr=explode('=',$data);
        //$data=$dataarr[1];
        #print_r($budget_hash[$data]);

         if(isset($budget_hash[$data]) && !empty($budget_hash[$data])){
                        $budget_obj=$budget_hash[$data];
                        $budgets[$budget_obj["CNT"]]=$budget_obj["NAME"];
                        array_push($budget_filter,$budget_obj["SOLR_ARGS"]);
                }

    }
    
    }
    $all_filter_data['budget_filter'] = $budget_filter;
    //DT
    $destination_theme_filter=array();
    $destination_theme=array();
    preg_match_all("/theme-(\w+)/",$duration_url, $output_array);
    if(isset($output_array[0]) && !empty($output_array[0]))
    {
        $destinations_theme_arr = $output_array[1];
    array_push($filter_array_name,"Theme");     
        foreach($destinations_theme_arr as $data){
            if(isset($destination_theme_hashx[$data]) && !empty($destination_theme_hashx[$data])){
                $destination_theme_obj=$destination_theme_hashx[$data];
                $destination_theme[$destination_theme_obj["CNT"]]=$destination_theme_obj["NAME"];
               array_push($destination_theme_filter,$destination_theme_obj["SOLR_ARGS"]);
            }
        }
    }
    $all_filter_data['destination_theme_filter'] = $destination_theme_filter;
   $all_filter_data=array_filter($all_filter_data);


if(count($all_filter_data)>1){
    $temp_array =array();
foreach($all_filter_data as $key=> $list) {
    if(count($list)>1){
    if($key=='duration_filter'){
        $daysval = implode(' days, ', $all_filter_data['duration_filter']) . ' days' . $popdaysval;
    $temp_array['duration_filter'] = $daysval; 
    $temp_array['duration_filter']  =preg_replace("/\-\*/is","",$temp_array['duration_filter']);
    $temp_array['duration_filter'] = preg_replace("/22/ism","22+", $temp_array['duration_filter']);
       }
    if($key=='budget_filter'){
        $temparray = array();
        foreach($list as $temp){
           if(preg_match("/Economy/ism",$temp)){
                $temparray[] = "3 Star";
           }
           else if(preg_match("/Standard/ism",$temp)){
                $temparray[] = "4 Star";
           }
           else if(preg_match("/Luxury/ism",$temp)){
                $temparray[] = "5 Star";
           }

        }
        $startvald = implode(', ', $temparray);
    $temp_array['budget_filter'] = $startvald;

      } 
    if($key=='price_filter'){
    $pricevala  = array();
    foreach($list as $fil_price){
        if($fil_price['max_price']==10000){
           $pricevala[] = "less than ".$fil_price['max_price'];
        }
        elseif(!is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']."+";
        }
        else{
          $pricevala[] = $fil_price['min_price']." - ".$fil_price['max_price'];
        }
    }
    
       $maxpriceval = implode(", ",$pricevala);     
    $temp_array['price_filter'] = "Price ".$maxpriceval;

      }
      if($key=='agentstar_filter'){
    $temparr = array();
    $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    foreach($list as $agentsearch){
       if(preg_match("/^(\d)/is",$agentsearch['star_rating_search'],$resultagent)){
        if($resultagent[1]==4){
                $temparr[] = $resultagent[1]."+";
        }
        else{
         $temparr[] = $resultagent[1]." - 4";
        }
           }

    }
    //$popratingval = array_pop($temparr);
     //$ratingval  = implode(', ', $temparr) . ' and ' . $popratingval;
     $ratingval  = implode(', ', $temparr);
       $temp_array['agentstar_filter'] = $ratingval;
      }
      if($key=='destination_theme_filter'){
    $all_filter_data['destination_theme_filter'] = array_map("ucfirst",$all_filter_data['destination_theme_filter']);
        $daysval = implode(', ', $all_filter_data['destination_theme_filter']);
    $temp_array['destination_theme_filter'] = $daysval;
      }

    }
    else{   
    if($key=='duration_filter'){
     $daysval = $list[0];
    $temp_array['duration_filter'] = $daysval; 
    $temp_array['duration_filter']  =preg_replace("/\-\*/is","",$temp_array['duration_filter']);
    $temp_array['duration_filter'] = preg_replace("/22/ism","22+", $temp_array['duration_filter']);
     $temp_array['duration_filter'] =  $temp_array['duration_filter']." days";
       }
    if($key=='budget_filter'){
    $hotelstartd = $list[0];
     if(preg_match("/Economy/ism",$hotelstartd)){
                $startvald = "3 Star";
           }
           else if(preg_match("/Standard/ism",$hotelstartd)){
                $startvald = "4 Star";
           }
           else if(preg_match("/Luxury/ism",$hotelstartd)){
                $startvald = "5 Star ";
           }

    $temp_array['budget_filter'] = $startvald;

      } 
    if($key=='price_filter'){
    $minpriceval = $list[0]['min_price'];
        $maxpriceval = $list[0]['max_price'];
        if($maxpriceval==10000){
           $maxpriceval = "Price less than $maxpriceval";
        }
    elseif(!is_numeric($maxpriceval)){
        $maxpriceval = "Price ".$minpriceval."+";
    }
        else{
           $maxpriceval = "Price ".$minpriceval." - ".$maxpriceval;
        }

    $temp_array['price_filter'] = $maxpriceval;

      }
      if($key=='agentstar_filter'){
    $agentratinval = $list[0]['star_rating_search'];
        if(preg_match("/^(\d)/is",$agentratinval,$resultagent)){
                $ratingval = $resultagent[1];
        }
    if($ratingval==4){      
        $ratingval = $ratingval."+";
    }
    else{
         $ratingval = $ratingval." - 4";
    }
       $temp_array['agentstar_filter'] = $ratingval;
      }
      if($key=='destination_theme_filter'){
        $daysval = $list[0];
    $temp_array['destination_theme_filter'] = ucfirst($daysval);
      }


    }
  
}
$con ='';
if($temp_array['destination_theme_filter']==''){
$temp_array['destination_theme_filter'] = "Holiday";
}
if($temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating";
}
elseif($temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!=''  && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['price_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." with ".$temp_array['budget_filter']." Rating";
}
elseif( $temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating";
}
elseif( $temp_array['duration_filter']!=''  && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." with ".$temp_array['budget_filter']." Rating";
}
elseif(isset($$temp_array['price_filter'])  && isset($temp_array['duration_filter'])){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."";
}
elseif($temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."";
}
elseif($temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['budget_filter']." Rating";
}
elseif(isset($temp_array['duration_filter'])){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']."";
}
elseif($temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for Agents ".$temp_array['agentstar_filter']." Rated";

}







/*if($temp_array['duration_filter']!='' && $temp_array['price_filter']==''){
$con .="Packages for ".$temp_array['duration_filter']." days ";
}
if($temp_array['price_filter']!='' && $temp_array['duration_filter']!=''){
$con .="Packages for ".$temp_array['duration_filter']." days, ";
}
if($temp_array['price_filter']!=''){
$con .="Price less than ".$temp_array['price_filter']." ";
}
if($temp_array['budget_filter']!=''){
$con .="with ".$temp_array['budget_filter']." Star Rating ";
}
if($temp_array['agentstar_filter']!=''){
$con .=" And Agents ".$temp_array['agentstar_filter']."+ Rated";
}*/
$meta_new ="Search & Compare $num_lead $meta_to $con";
$hotel_data_h1_content = "Showing $num_lead $meta_to $con";
$meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $con";

//"3575 Manali Honeymoon Packages for 1-3 days, Price less than 10,000 with 4 Star Rating and Agents 4+ Rated"
}
elseif(count($all_filter_data)==1){
      if(count($all_filter_data['duration_filter'])>1){
    $popdaysval = array_pop($all_filter_data['duration_filter']);
    $popdaysval = preg_replace("/\-\*/is","+",$popdaysval);
    $daysval = implode(' days, ', $all_filter_data['duration_filter']) . ' days and ' . $popdaysval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages for $daysval days";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages for $daysval days";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages for $daysval days.";
      }
      elseif(count($all_filter_data['duration_filter'])==1){
    $daysval = preg_replace("/\-\*/is","+",$all_filter_data['duration_filter'][0]);
    $meta_new="Search & Compare $num_lead $meta_to Holiday Packages for $daysval days";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages for $daysval days";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages for $daysval days.";
      } 
      if(count($all_filter_data['budget_filter'])>1){
    $temparray = array();
    foreach($all_filter_data['budget_filter'] as $temp){
       if(preg_match("/Economy/ism",$temp)){
            $temparray[] = "3 Star";
           }
       else if(preg_match("/Standard/ism",$temp)){
        $temparray[] = "4 Star";
       }
       else if(preg_match("/Luxury/ism",$temp)){
                $temparray[] = "5 Star ";
           }

        }
    $pophotelstartd = array_pop($temparray);
    $startvald = implode(', ', $temparray) . ' and ' . $pophotelstartd;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels with $startvald  Rating";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels with $startvald  Rating";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels with $startvald Rating.";

      }
      elseif(count($all_filter_data['budget_filter'])==1){
        $hotelstartd = $all_filter_data['budget_filter'][0];
    if(preg_match("/Economy/ism",$hotelstartd)){
                $startvald = 3;
           }
           else if(preg_match("/Standard/ism",$hotelstartd)){
                $startvald = 4;
           }
           else if(preg_match("/Luxury/ism",$hotelstartd)){
                $startvald = 5;
           }

        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating.";
      } 
     if(count($all_filter_data['price_filter'])>1){
    $pricevala  = array();
    foreach($all_filter_data['price_filter'] as $fil_price){
        if(is_numeric($fil_price['min_price']) && is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']." - ".$fil_price['max_price'];
        }
        else if(is_numeric($fil_price['min_price']) && !is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']."+";
        }
        else if(!is_numeric($fil_price['min_price']) && is_numeric($fil_price['max_price'])){
            $pricevala[] = "Price less than ".$fil_price['max_price'];
        }
    }
    $popratingval = array_pop($pricevala);
         $maxpriceval  = implode(', ', $pricevala) . ' and ' . $popratingval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages by Price $maxpriceval";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages by Price $maxpriceval";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages by Price $maxpriceval.";

      }
      elseif(count($all_filter_data['price_filter'])==1){
        $minpriceval = $all_filter_data['price_filter'][0]['min_price'];
        $maxpriceval = $all_filter_data['price_filter'][0]['max_price'];
    if($maxpriceval==10000){
       $maxpriceval = "Price less than $maxpriceval";
    }
    elseif(!is_numeric($maxpriceval)){
        $maxpriceval = "Price ".$minpriceval."+"; 
    }
    else{
       $maxpriceval = "Price ".$minpriceval." - ".$maxpriceval;
    }
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages by $maxpriceval";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages by $maxpriceval";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages by $maxpriceval.";
      } 
      if(count($all_filter_data['agentstar_filter'])>1){
    $temparr = array();
    $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    foreach($all_filter_data['agentstar_filter'] as $agentsearch){
       if(preg_match("/^(\d)/is",$agentsearch['star_rating_search'],$resultagent)){
        if($resultagent[1]==4){
            $temparr[] = $resultagent[1]."+";
        }
        elseif($resultagent[1]==3){
                        $temparr[] = $resultagent[1]. " - 4";
                }
           }

    }
    $popratingval = array_pop($temparr);
     $ratingval  = implode(', ', $temparr) . ' and ' . $popratingval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated.";

      }
      elseif(count($all_filter_data['agentstar_filter'])==1){
        $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    if(preg_match("/^(\d)/is",$agentratinval,$resultagent)){
        $ratingval = $resultagent[1];
        if($resultagent[1]==4){
                        $ratingval = $resultagent[1]."+";
                }
                else if($resultagent[1]==3){
                        $ratingval = $resultagent[1]. " - 4";
                }

    }
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated.";
      } 
      if(count($all_filter_data['destination_theme_filter'])>1){
    $all_filter_data['destination_theme_filter'] = ucwords(implode("| ",$all_filter_data['destination_theme_filter']));
    $all_filter_data['destination_theme_filter'] = explode ("| ",$all_filter_data['destination_theme_filter']);
        $popdaysval = array_pop($all_filter_data['destination_theme_filter']);
        $daysval = implode(', ', $all_filter_data['destination_theme_filter']) . ' and ' . $popdaysval;
    $meta_new="Search & Compare $num_lead $meta_to $daysval Packages";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $daysval Packages.";
        $hotel_data_h1_content =  "Showing $num_lead $meta_to $daysval Packages";
      }
      elseif(count($all_filter_data['destination_theme_filter'])==1){
        $daysval = ucfirst($all_filter_data['destination_theme_filter'][0]);
        $meta_new="Search & Compare $num_lead $meta_to $daysval Packages";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $daysval Packages.";
        $hotel_data_h1_content =  "Showing $num_lead $meta_to $daysval Packages";
      }


 }




    //India's most popular places
    $indmostppl = array();   
    foreach($home_json->indiasMostPplPlaces as $key=>$val){
        foreach($val as $value){
          $indmost = array();
          $indmost["title"] = ucfirst($value->place);  
          $indmost["url"]   = $value->url;
          $image = explode(",",$value->image);
          $indmost["image"] = $image[0];
          $indmost["price"] = $value->pts_price;
          $indmost["state"] = $value->state;
          $indmostppl[] =     $indmost;
         }
    }
   // print_r($indmostppl);die;   

if(!empty($string)){
    $place_to_str = $string;
    $arr=explode('/q/',$place_to_str);
    $place_to=$arr[0];
if(preg_match('/^q\//',$place_to)){
    $place_to='';
}else{
    $arr=explode('/q/',$_SERVER['REQUEST_URI']);
    $place_to=$arr[0];
    $place_to=str_replace('/'.$page_type_section.'/','',$place_to);
    $place_to= urldecode($place_to);
        if(!empty($place_to) && preg_match('/\s/',$place_to)){
            $request_uri= urldecode($request_uri);
            $request_uri=str_replace(' ','-', $request_uri);
            print_r($request_uri);
            header("Location: $request_uri");
            exit;
        }
    }
}elseif(isset($_REQUEST['place_to'])){
    $canonical=1;
    $place_to=$_REQUEST['place_to'];
}

if(strpos($place_to, "?") !== false){
    $place_toq = explode("?",$place_to);
    $place_to = $place_toq[0]; 
}    


    $place_to_r=$place_to;
    $place_to_show=str_replace("-s-",",",$place_to);
    $place_to_show=str_replace("- -",",",$place_to_show);
    $place_to_show=str_replace("-"," ",$place_to_show);
    $place_to = rtrim(stripslashes(strip_tags($place_to)), ',');
    $place_from=$_REQUEST['place_from'];
    $place_from = rtrim(stripslashes(strip_tags($place_from)), ',');

    $place_to=str_replace("-s-",",",$place_to);
    $place_to=str_replace("- -"," ",$place_to);
    $place_to=str_replace("-"," ",$place_to);

    $place_to=str_replace("\'","",$place_to);
    $place_to=str_replace("'","",$place_to);
    $place_to=str_replace("%","",$place_to);

    $place_from=str_replace("'","",$place_from);
    $place_from=str_replace("%","",$place_from);

    $footer_text_pre="";
    $place_to_uc="";

    $place_to=ltrim($place_to);
    $place_to=rtrim($place_to);
    $title_month='';





  $place_to=trim($place_to);

    $default_banner_link="";

    $travel_with=array();
    $travel_with_star_price=array();
    $clause_star_rate_price='';
    $place_from_str='';
    $place_to_str='';
    $clause_from_list_1='';
    $clause_from_list_2='';
    $clause_to_list_1='';
    $clause_to_list_2='';
    $query="";
    $state_name = "";
    $country_name="";
    $city_name="";
    $country_iso_code = "";
    $state_urlVal ="";
    $placestosee = "";
    $placestosee_arr = array();

    if(!empty($place_to) && $place_to!="To")
    {

    if(stristr($place_to, ',') !== FALSE)
    {
        $place_to_str=str_replace(",","','",$place_to);
        $place_to_strs=str_replace(",","','",$place_to);
        #$solr_to_strs=str_replace(","," OR ",$place_to);
        $solr_to_strs=$solr_to_strs;
    }
    else
    {
        $place_to_str=$place_to;
        $place_to_strs=$place_to;
        $solr_to_strs=$place_to;
    }
  
    $destination_arg=$solr_to_strs;

    }

    $solr_from_str="";
    if(!empty($place_from) && $place_from!="From")
    {

    if(stristr($place_from, ',') !== FALSE)
    {
        $place_from_str=str_replace(",","','",$place_from);
        $solr_from_str=str_replace(","," OR ",$place_from);
        $solr_from_str="(".$solr_from_str.")";
    }
    else
    {
        $place_from_str=$place_from;
        $solr_from_str="(".$place_from.")";
    }

    $query.="+AND+departure_from:".$solr_from_str;
    }



    $pstatus="";
    if(empty($query))
    {
        $query.="*:*";
    }
    $rand=mt_rand();
$pstatus.="&sort=random_$rand+desc";
$data=array();
$sorting_val='';
if(isset($_REQUEST["sortval"])){
 $sorting_val=trim($_REQUEST["sortval"]);
 //exit;
}


//Get all Deals Listing data

$all_deals_leasting = array();

if(empty($place_to)){
    $t=new traveller_personilization();
    $r=new package_relevence_module_list(array("type"=>"and","nodest"=>"1","rows"=>"25"));
         $guess_dest="";
         $personal_id=$r->get_vid_data();
         if(!empty($personal_id["vid"]) || !empty($personal_id["uid"])){
        $per=$t->get_personalisation_data(array("vid"=>$personal_id["vid"],"uid"=>$personal_id["uid"]));
     foreach($per as $key=>$arr){
        if(isset($arr["destinations"]) && !empty($arr["destinations"])){
            $guess_dest=$arr["destinations"];
            
            break;
          }
         }
        }
        if(empty($guess_dest)){
             $vid_list=$r->getVidfromIp();
             $per=$t->get_personalisation_data(array("vid"=>$vid_list));
            
              foreach($per as $key=>$arr){
                if(isset($arr["destinations"]) && !empty($arr["destinations"])){
                        $guess_dest=$arr["destinations"];
                        break;
                }
               }
 
        }
    $guess_dest=str_replace('India,','',$guess_dest);
    $guess_dest=str_replace('india,','',$guess_dest);
    $guess_dest=str_replace("'","",$guess_dest);
    
    $args=array("destinations"=>$guess_dest, "from_location"=>$solr_from_str,"stars"=>$budget_filter,"prices"=>$price_filter,"themes"=>"","agents"=>$agentstar_filter,"booking"=>$booking_filter,"budgetpernight"=>$budgetpernight_filter,"sort"=>$sorting_val,"duration"=>$duration_filter,"destinations_theme"=>$destination_theme_filter,"rows"=>30,"nodest"=>"1");
    $data =$r->get_packages($args);
}else{
    $place_to=str_replace("'","",$place_to);
$args=array("destinations"=>$place_to, "from_location"=>$solr_from_str,"stars"=>$budget_filter,"prices"=>$price_filter,"themes"=>"","agents"=>$agentstar_filter,"booking"=>$booking_filter,"budgetpernight"=>$budgetpernight_filter,"sort"=>$sorting_val,"duration"=>$duration_filter,"destinations_theme"=>$destination_theme_filter,"rows"=>30);

$r=new package_relevence_module_list(array("type"=>"and" ,"rows"=>"11"));

$data =$r->get_packages($args);



}

//paid data
$final_array_main5=$data["result"];



$pr=new package_relevence_module_branding(array("type"=>"and","nodest"=>"0","premium_pkg"=>1));
if(empty($place_to)){
$pr=new package_relevence_module_branding(array("type"=>"and","nodest"=>"1","premium_pkg"=>1));
}
$ptt_obj=new package_relevence_module_branding(array("type"=>"and","nodest"=>"0","ptt_ads"=>1,"rows"=>3));
if(empty($place_to)){
    $ptt_obj=new package_relevence_module_branding(array("type"=>"and","nodest"=>"1","ptt_ads"=>1,"rows"=>3));
}
    
$travelguidedesc = "";
$similarplacesdata=array();
$placerating = "5";
$placerating_count="";
$data_ptt =$ptt_obj->get_packages($args);
$data_premium =$pr->get_packages($args);

//print_r($data_premium);die;

$total_no_deals=0;
$numfound_main5_premium=$data_premium["count"];
$total_no_deals=$data_premium["total_count"];
$numfound_main5_ptt=$data_ptt["count"];
#print_r(array("PTT",$numfound_main5_ptt));
$final_array_main5_ptt=$data_ptt["result"];

#echo "<!--".$total_no_deals."-->";
$final_array_main5_premium=$data_premium["result"];

ksort($final_array_main5_premium);


$numfound_main5=$data["count"];
#print_r(array("PAID",$numfound_main5));
$total_no_deals=$total_no_deals+$numfound_main5+$numfound_main5_free+$numfound_main5_ptt;
$fflead_count=5;
if($total_no_deals < 15){
    $fflead_count=20-$total_no_deals;
}
$free_obj=new package_relevence_module_free(array("type"=>"and","nodest"=>"0","free_client"=>1,"rows"=>$fflead_count));
if(empty($place_to)){
    $free_obj=new package_relevence_module_free(array("type"=>"and","nodest"=>"1","free_client"=>1,"rows"=>$fflead_count));
}

$data_free =$free_obj->get_packages($args);
//print_r($data_free);die;
$numfound_main5_free=$data_free["count"];
$total_no_deals+=$numfound_main5_free;
$final_array_main5_free=$data_free["result"];

$num_lead=$total_no_deals;

$final_array_main_ptt_pre=array();
$final_array_main5=array_merge($final_array_main5,$final_array_main5_free);
$place_to=str_replace(',',' ,',$place_to);
if($numfound_main5_ptt > 0 && $final_array_main5_premium>0){
    $final_array_main5=array_merge($final_array_main5_ptt,$final_array_main5);
    foreach($final_array_main5_premium as $val_arr){
      $final_array_main5=array_merge($val_arr,$final_array_main5);
    }
   // exit;
}
elseif($numfound_main5_premium > 0 && $numfound_main5_ptt==0){
    foreach($final_array_main5_premium as $val_arr){
        $final_array_main5=array_merge($val_arr,$final_array_main5);
          }
}
elseif($numfound_main5_premium == 0 && $numfound_main5_ptt>0){
  $final_array_main5=array_merge($final_array_main5_ptt,$final_array_main5);
}

$all_deals_data = array();
$all_deals_list = array();
if($numfound_main5>0 || $numfound_main5_premium > 0 || $total_no_deals > 0)
{
   // echo "soumya";
   $counter_premium=0;
    $premium_array_deals=array();
    $dest_count=1;
    $rowcount_new=1;
    if($_REQUEST["stat"] == 2){
#        echo "<pre/>"; print_r($final_array_main5);exit;
    }
$place_to_mmt_new=explode(',',$place_to);
if(count($place_to_mmt_new) > 3){
$place_to_mmt_new_tmp=array_slice($place_to_mmt_new,0,3);

}else{
 $place_to_mmt_new_tmp=$place_to_mmt_new;
}
$place_to_mmt_new_tmp_str=implode(',',$place_to_mmt_new_tmp);
    
    foreach($final_array_main5 as $val)
    {   
        
    $all_deals_data['destinations_covered_array'] = $val->destinations_covered;
    $all_deals_data['destinations_covered_text'] = $val->destinations_covered_text;
    $all_deals_data['departure_from'] = $val->departure_from;
    $all_deals_data['form_type'] = $val->form_type;
    $all_deals_data['nid_url'] = $val->nid.".html";
    $all_deals_data['nid'] = $val->nid;
     if($val->url){
       $all_deals_data['nid_url'] = $val->url;
      }
      $pns_num='';
        $pns_num_plus='';
        if(isset($_REQUEST["stat"]) && $_REQUEST["stat"] == '2'){
                $val->title= $val->title."--".$val->priority;
        }

        $all_deals_data['pstatuslc']=$val->pstatus;
        $package_count++;
        $all_deals_data['fcp_uidlc'] = $val->fcp_uid;
        $photo='';
        $deals_rating='';
        $p_symbol='';
        $p_value='';
        $photo_array=array();
        $all_deals_data['idlc'] = $val->id;
        $all_deals_data['destination_countrylc'] = $val->destination_country;
        if(count($destinations_themelc)==0){
            $all_deals_data['destinations_themelc']=$val->destinations_theme;
          }
        $all_deals_data['from_dtlc'] = $val->from_dt;
        $all_deals_data['to_dtlc'] = $val->to_dt;
        $all_deals_data['fcp_uidlc'] = $val->fcp_uid;
        $all_deals_data['ts_status'] = $val->ts_status;
        $all_deals_data['bap_status'] = $val->bap_status;
        $all_deals_data['inclusion_exclusionlc'] = array_filter(unserialize($val->inclusion_exclusion));
        $all_deals_data['converted_pricelc'] = $val->price;
    if($_REQUEST[stat] == 2){
        $all_deals_data['titlelc'] = $val->tbl_login_companyname." ".$val->title;
    }else{
        $all_deals_data['titlelc'] = $val->title;
    }
    $all_deals_data['itinerary'] = $val->itinerary_space;
    $all_deals_data['form_version'] = $val->form_version;
        $all_deals_data['package_typelc'] = $val->package_type;
        $all_deals_data['durationlc']=$val->duration;
        $all_deals_data['group_deal'] = $val->group_deal;
        $all_deals_data['dest_leader_from_city'] = $val->dest_leader_from_city;
        $all_deals_data['dest_leader_to_city'] = $val->dest_leader_to_city;
        $all_deals_data['ptt_service_flag'] = $val->ptt_service_flag;
        $all_deals_data['booking_status'] = $val->booking_status;
        $all_deals_data['sponsored_status']=$val->sponsored_status;
        $all_deals_data['random_prices'] = $val->random_prices;
        //$destinations_coveredlc=$val->destinations_covered_text; #implode(',',$val->destinations_covered);
        $all_deals_data['tbl_login_companynamelc']  = $val->tbl_login_companyname;
        $all_deals_data['tbl_login_creditpointslc'] = $val->tbl_login_creditpoints;
        $all_deals_data['tbl_login_idlc'] = $val->tbl_login_id;
       $premium_package=0;
        
        $premium_array_deals[$val->nid]=1;
       
        $pns_numlc=isset($val->pns_num) ? $val->pns_num : '';
        $nidlc=$val->nid;
        $all_deals_data['nidlc'];
         $idd=$nidlc;
        $all_deals_data['pathlc'] = $val->path;
        $all_deals_data['company_logo'] = isset($val->company_logo)?$val->company_logo:'';
        $all_deals_data['p_symbol'] = 'INR';
    $all_deals_data['tour_days'] = $val->days;
    $all_deals_data['response_rate'] = $val->response_rate;
    $all_deals_data['review_count'] = isset($val->review_count)?$val->review_count:'';
    $all_deals_data['max_price'] = isset($val->max_price)?$val->max_price:'';
    $all_deals_data['star_rating_search'] = $val->star_rating_search;
        $p_value=$all_deals_data['converted_pricelc'];
    $all_deals_data['isonline'] = $val->isonline;
    if(!$p_value){
        $p_value=$val->converted_price;
    }
    if($all_deals_data['max_price']<=$p_value){
            $all_deals_data['max_price']='';
    }
    $all_deals_data['p_value'] = number_format($p_value); 
    $photo=$imgpath.$all_deals_data['pathlc'];

    if(empty($all_deals_data['pathlc']))
    {
         $photo="https://www.hellotravel.com/hellotravel/images/holiday.png";
    }
    $all_deals_data['photo'] = $photo;
     $destination=$all_deals_data['destinations_covered_text'];
         $destination=preg_replace('/,$/','',$destination);
        $destination=preg_replace('/,,/',',',$destination);
        

        $nid=$nidlc;
        $dest_link_var="";
        $dest_explode=explode(",",$destination);
        $dest_explode = array_map('ucfirstfun', $dest_explode);
        $dest_explode = array_unique($dest_explode);
        $dest_exp_count=0;
        $dest_first= $dest_explode[0];


if(count($dest_explode)>=5)
{
if(in_array($place_to,$dest_explode))
{
    $pos=array_search($place_to,$dest_explode);
    if($pos>=4)
    {
        $random=rand(0,2);
        $temp=$dest_explode[$random];
        $dest_explode[$random]=$dest_explode[$pos];
        $dest_explode[$pos]=$temp;
    }

    }

}


$all_deals_data['pack_dest_comma_seprated'] = implode(", ",array_unique($dest_explode));
        $log_id=$tbl_login_idlc;

        $credit_points=$tbl_login_creditpointslc;
        $comp_name=$tbl_login_companynamelc;
        $comp_name=substr($company_name,20);


        if($pns_numlc != "" && !empty($pns_numlc)){
            $pns_num_plus="+".$pns_numlc;
            $pns_num=substr($pns_numlc,2);
            $pns_num="0".$pns_num;
              $destpns = strtolower(str_replace("," , "','" , $destinations_coveredlc));
                if($destpns != ""){
                $sdestpns = dbprocess("SELECT PNS_NO FROM `tbl_dest_pns` WHERE `DESTINATIONS` in ('".addslashes($destpns)."') and FK_USERID = '".$log_id."' and STATUS = '1' limit 1 ");
                 
                        if(mysql_num_rows($sdestpns)){
                                while($rdest = mysql_fetch_assoc($sdestpns)){
                                        $destpnsno = $rdest["PNS_NO"];
                                         $pns_num_plus="+91".$destpnsno;
                                         $pns_num="0".$destpnsno;

                                }
                           }
                        }
        }


        $all_deals_data['mobile_device'] = $mobile_device;
        $all_deals_list[] = $all_deals_data;
    }

}



//print_r($all_deals_list);die;
 function get_all_deals_data(){
    global $all_deals_list;
   return json_encode($all_deals_list);
}


//get Deals List About Section

$sth=dbprocess("select summery,modify_summary,id from tbl_placestosee_upload where title='$place_to_r' and status='1'");
    $rows=mysql_fetch_array($sth);  
    $summary=$rows["modify_summary"];
    $pts_id_v=$rows["id"];
    if(empty($summary)){
      $mtype='dest';  
      $sth=dbprocess("select url,summery,modify_summary,id from tbl_destination_upload where title='$place_to' and status='1'");
      $rows=mysql_fetch_array($sth);
      $summary=$rows["modify_summary"];
      
  }
  

  function get_deals_about_data(){
    global  $summary;
    return json_encode(array("summary"=>$summary));
  }



  if(isset($place_to) && !empty($place_to)){ 
  require_once("/home/indiamart/public_html/hellotravel-agents/includes/Destination.class.php");  
  $destobj    =  new Dest_Data(array("type"=>$type)); 
  $solrurl  = "http://ht-search:8983/solr/hellotravel_ttd_pts/select?q=type%3Apts+AND+status%3A1+AND+pts_url%3A*%2F$place_to_r&wt=json&fl=%2A&sort=&rows=50"; 
  $json_main_data = @file_get_contents($solrurl);
  $data_main = json_decode($json_main_data, true); 
  if($data_main['response']['numFound']>0){
    $ptsvisitdata = $data_main['response']['docs'][0];
    $morethingstodoplaces = $destobj->get_ptsttd(array("type"=>"ttd","title"=>$place_to_r));
    $gacode = "new-placestosee-detail";
    if(strtolower($ptsvisitdata["title"]) == strtolower($ptsvisitdata["state"])){
        $mtype="state";
    }else{
        $mtype="pts";
    }
    $thingstodoplaces = thingstododesign($morethingstodoplaces , $ptsvisitdata["ttdcount"] , $gacode,'less');  
    $morethingstodoplaces = thingstododesign($morethingstodoplaces , $ptsvisitdata["ttdcount"] , $gacode,'more');  
     
     if(isset($ptsvisitdata["near_by_places"]) && count($ptsvisitdata["near_by_places"])){ 
     //print_r($ptsvisitdata["near_by_places"]);die;     
        $near_by_places   = nearbydesign(array_slice($ptsvisitdata["near_by_places"] , 1 , 11) , $ptsvisitdata["destination"] , $gacode);

      }


      if(isset($ptsvisitdata["peoplealsovist"]) && count($ptsvisitdata["peoplealsovist"])){
            $alsovist =  peoplealsovist($ptsvisitdata["peoplealsovist"] , $gacode,$gacode3);
           
       }
       $reviews           = getReviewsPts(array("title" => strtolower($ptsvisitdata["title"]) , "type" => 'pts' , "main_id" => $ptsvisitdata["main_id"]));
    
    
      $story_pts   = $ptsobj->getstories(array("title" => strtolower($ptsvisitdata["title"]),"rows"=>7));
      //print_r($story_pts); die;
      if($story_pts["count"] != 0){         
        $tripideas    = storydesign($story_pts["result"] , $gacode,'trip-ideas-listing');
    }

    }



    if($ptsvisitdata["title"]!=''){
   $country_url = ''; 
   $country =  isset($ptsvisitdata["country_name"])?trim($ptsvisitdata["country_name"]):'';
   if($country!=''){
        $country_url = BASEURL_HT.strtolower(str_replace(" " , "-" , $ptsvisitdata["country_name"]));
   }
   $destination = isset($ptsvisitdata['title'])?trim($ptsvisitdata['title']):'';

   $breadcrumb =array();
   if($country!=''){
    $breadcrumb['links'][0]['url'] = $country_url;
    $breadcrumb['links'][0]['name'] = $country;
    }

    if($destination){
        $breadcrumb['title']['name'] = ucfirst($destination)." Tours";
    }
    else{
      $breadcrumb['title']['name'] = " Tour Packages";   
    }
    //print_r($breadcrumb);die;

}

// sub heading code//

    if( $mtype == 'dest'){
        $apts_url="https://www.hellotravel.com/".$dest_url;
        $ratingurlsubheading = $apts_url."?#rating";
    }else{
          $apts_url="https://www.hellotravel.com/".$ptsvisitdata["pts_url"];

    }

    if(count($reviews) > 0  && $mtype != "state" ){
        $ratingurlsubheading=$apts_url."/traveller-reviews";

    }
    else{
        $ratingurlsubheading="javascript:void(0);";
    }


   
   
    if($place_to && ($data_main['response']['numFound']<=0)){
     $leadnoindex='NOINDEX, NOFOLLOW';
    }elseif($num_lead <=10){
         $leadnoindex='NOINDEX';
    }

}

$place_to_mmt_new=explode(',',$place_to);
if(count($place_to_mmt_new) > 3){
$place_to_mmt_new_tmp=array_slice($place_to_mmt_new,0,3);
}else{
 $place_to_mmt_new_tmp=$place_to_mmt_new;
}

$place_to_mmt_new_tmp_str=implode(',',$place_to_mmt_new_tmp);
function get_thing_to_do(){
    global $thingstodoplaces, $place_to;
   return json_encode(array("thingstodoplaces"=>$thingstodoplaces,"heading"=>"Things to do in ".ucfirst($place_to)));
}

function get_more_attraction(){
    global $morethingstodoplaces,$place_to;
   return json_encode(array("thingstodoplaces"=>$morethingstodoplaces,"heading"=>"More ".ucfirst($place_to)." Attractions"));
}
function ucfirstfun($value) {
    return ucfirst(trim($value));
}
   

function thingstododesign($thingsarray , $ttdcount, $gacode,$ttype){
    $array = array();
    if(count($thingsarray)){
        $i = 1;
        $html = "";
        $mhtml = "";
        $lhtml = "";
        foreach($thingsarray as $value){
         $temparray= array();   
        $good_for = "";
        $host = getImgeHost();
        $value['image_path']=get_base_64_only_image($value['image_path']);
      if (strpos($value['image_path'], 'https') !== false) {
         $imagepath = $value['image_path'];
        }else{
         $imagepath = "https://www.hlimg.com/images/things2do/300X200/".$value['image_path'];
        }
        $className = 'iname2';
        $spanClass = 'fl w28 p1 ptv1 p_r';
        $imageclass = 'class="ht205"';
        if($i==1){
          $className = 'iname1';
          $spanClass = 'fl w44 p1 ptv1 p_r';
          $imageclass = 'class="ht500"';
        }
     
        if($i<=10 && $ttype=="less"){
        $temparray['url'] = "https://www.hellotravel.com/india/".$value['url'];
        $temparray['image'] = $imagepath;
        $temparray['title'] = $value['title'];
        }else if($i>10 && $ttype=="more"){

            $temparray['url'] = "https://www.hellotravel.com/india/".$value['url'];
            $temparray['image'] = $imagepath;
            $temparray['title'] = $value['title'];
        }
       
          $i = $i+1;
          $array[] = $temparray;
        }
        
        }
        $array = array_values(array_filter($array));
    return $array;
}


function get_nearby_places_data(){
    global $near_by_places;

    return json_encode(array("nearbyplacesname"=>$near_by_places,"heading"=>"Popular Nearby Places"));

}

function nearbydesign($placevalarray, $dest, $gacode){
    $html = "";
    if(count($placevalarray)){
      $i=1;
      $array = array();
      foreach($placevalarray as $placeval){
        $temp = array();
        $nearobj = explode("#solr#" , $placeval);
        $host = getImgeHost();
        if($i<=10){
           // print_r($nearobj);
          $temp['destination_sub_url'] = $nearobj[5];
          $temp['destination_sub'] = $nearobj[1];
          $temp['state'] = $nearobj[2];
          $temp['image'] = $nearobj[0];
          $temp['rating'] = $nearobj[4];
          $array[] = $temp;
        }
        $i++;
      }
    }
    //die;
return $array;
}


function tripideas_data(){
    global $tripideas, $place_to;
    return json_encode(array("traveltips"=>$tripideas,"heading"=>ucfirst($place_to)." Travel guide"));
}
function storydesign($storyarry , $gacode,$ga_code3){
    $array = array();
    if(count($storyarry)){
      $i=1;
        foreach($storyarry as $val){
            //print_r($val);die;
            $travelTips = array();
            $val->image_path=get_base_64_only_image($val->image_path);
            $ellipsisClass='';
                        $gtitle = $val->title; 
            if(str_word_count($val->title)>8){
               $ellipsisClass="ellipsis";
                           $stitle = explode(" ",$val->title);
                           $gtitle = implode(" ",array_slice($stitle,0,8)); 
            }
                    if($val->image_path!=''){
                        $val->image_path='https://www.hlimg.com/images/stories/300X200/'.$val->image_path;
                    }
                    else{
                       $val->image_path='https://www.hlimg.com/images/holiday.png'; 
                    }
                    $today = date('Y-m-d');
                    //Assign a date in 'Y-m-d' format
                    $futureDate = explode(" ",$val->changed_datetime)[0];
                    //Calculate the date difference based on timestamp values
                    $difference = strtotime($today) - strtotime($futureDate) ;
                    //Calculate difference in days
                    $days = abs($difference/(60 * 60)/24);
                    if($i<=8){
                        if($days)
                        $travelTips["title"] = ucfirst($val->title);  
                        $travelTips["url"]   = "https://www.hellotravel.com/stories/".$val->url;
                        $travelTips["image"] = $val->image_path;
                        $travelTips["description"] = strip_tags($val->description);
                        if($days<365){
                        $travelTips["datetime"] = $date=date("d M Y", strtotime($val->changed_datetime));
                        }
                        else{
                             $travelTips["datetime"] ='';   
                        }
                        $array[] = $travelTips;
                    }
                    $i++;
        }
    }
   // print_r($array);die;
       return $array;
}
  

  function return_aloso_explore(){
    global $alsovist;
    return json_encode(array("nearbyplacesname"=>$alsovist,"heading"=>"You may also explore"));
  } 

 function peoplealsovist($alsoarray , $gacode,$gacode3){
    $array = array();
    if(count($alsoarray)){
        foreach($alsoarray as $val){
            $temp = array();
    $visit = explode("#solr#" , $val);
    $visit=preg_replace("/300X200/","216X180",$visit);
    //print_r($visit);
   $state = $visit[3];
   if($state == ""){
       $state = $visit[5];
   }
   if($visit[0]==''){
       $visit[0]='https://www.hlimg.com/images/holiday.png';
   }
    $host = getImgeHost();
   
     $temp['destination_sub_url'] = $visit[4];
          $temp['destination_sub'] = $visit[1];
          //$temp['state'] = $nearobj[2];
          $temp['image'] = $visit[0];
          $temp['rating'] = $visit[2];
          $array[] = $temp;
        }
    }
    
return $array;
}  


function getReviewDgn(){
    global $place_to, $reviews;
    return json_encode(array("review"=>$reviews,"heading"=>"Latest ".ucfirst($place_to)." Tour Reviews"));

}

function getReviewsPts($args){
        $review_array = array();
    $clause  = " and  `city`='".$args["title"]."' ";
    if($args["type"] == "ttd"){
         $clause  = " and  ttd_id='".$args["main_id"]."' ";
    }else if($args["type"] == "evt"){
        $clause  = " and  evt_id='".$args["main_id"]."' ";
    }
        $sql_rev=sldbprocess("select if(fk_uid > 0,1,0) b,if(place_experience !='',1,0) a,fk_uid,place_experience,place_name,fk_vid,must_see,comfortable_wear,eat_nearby,washroom,parking_facility,id_card,place_name,overall_exp_rating,fk_lead_id,best_time,entrance,camera,created FROM tbl_testimonial_places where feedback_status=1 $clause and overall_exp_rating >'3.5' order by created desc,b desc limit 10");
            if(mysql_num_rows($sql_rev)>0)
            {
                $rev_counter = 0;
                while($row_rev=mysql_fetch_assoc($sql_rev))
                {
                    $value_money='';
                    $clean='';
                    $ent='';
                    $wash='';
                    $lock='';
                    $cam='';
                    $best_time='';
                    $lead_name='';
                    $lead_id='';
                    $lead_city='';
                    $lead_country='';
                    $name_an='';
                    $tuid=0;
                    $lead_id=$row_rev['fk_lead_id'];
                    $tuid=$row_rev['fk_uid'];
                    $place_name=$row_rev['place_name'];
                    $description=$row_rev['place_experience'];
                    $overall_exp_rating=$row_rev['overall_exp_rating'];
                    $created= date('d M Y', strtotime($row_rev['created']));
                    if($row_rev['money_value']>=3)
                    {
                    $value_money='It was a value for money experience. ';
                    }
                    if($row_rev['clean']=='Yes')
                    {
                    $clean=$place_name.' is a very neat & clean sight. ';
                    }
                    if($row_rev['eat_nearby']=='Yes')
                    {
                    $food='It has easy and good availability of food & drinks. ';
                    }
                if($row_rev['best_time'] != '')
                {
                    $best_time='Best time to visit is ' .$row_rev['best_time']. '. ';
                }
                if($row_rev['entrance'] == 'YES')
                {
                    $ent='To enter, you have to pay entrance fee. ';
                }
                else
                {
                    $ent='There is no entrance fee. ';
                }
                if($row_rev['washroom'] == 'YES')
                {
                    $wash='Washroom facilities are easily available. ';
                }
                else
                {
                    $wash='Washroom facility is not so good. ';
                }
                    if($row_rev['camera_allowed'] == 'YES')
                {
                    $cam='You can carry your camera along. ';
                }
                else
                {
                    $cam='No photography is allowed here. ';
                }

                if($overall_exp_rating==5)
                {
                    $remark='Excellent';
                }
                elseif($overall_exp_rating==4)
                    {
                    $remark='Very Good';
                }
                    elseif($overall_exp_rating==3)
                    {
                    $remark='Good';
                }
                    elseif($overall_exp_rating==2)
                    {
                    $remark='Average';
                }
                    elseif($overall_exp_rating==1)
                    {
                    $remark='Poor';
                }
                        if($tuid != 0 || $lead_id != 0)
                        {
                        $lead_cl="";
                        if($tuid != 0 && $lead_id != 0)
                        {
                            $lead_cl=" (tbl_lead_id='".$lead_id."' or TUID='".$tuid."')";
                            }
                            elseif($tuid != 0 && $lead_id == 0)
                            {
                            $lead_cl=" TUID='".$tuid."'";
                            }
                            elseif($tuid == 0 && $lead_id != 0)
                            {
                                $lead_cl=" tbl_lead_id='".$lead_id."'";
                                }
                        $sql_find_name=sldbprocess("select TBL_LEAD_NAME,TBL_LEAD_CITY,FK_TBL_COUNTRY from tbl_leads where  $lead_cl limit 1");
                        if(mysql_num_rows($sql_find_name)==0)
                        {
                            $sql_find_name=sldbprocess("select TBL_LEAD_NAME,TBL_LEAD_CITY,FK_TBL_COUNTRY from tbl_leads_archive where $lead_cl limit 1");
                            }
                            if(mysql_num_rows($sql_find_name)>0)
                            {
                            $row_lead_detail=mysql_fetch_assoc($sql_find_name);
                            $lead_name=ucfirst($row_lead_detail['TBL_LEAD_NAME']);
                                $lead_city=$row_lead_detail['TBL_LEAD_CITY'];
                                $lead_country=$row_lead_detail['FK_TBL_COUNTRY'];
                            }
                            if(mysql_num_rows($sql_find_name)==0 && $tuid != 0)
                            {
                                $sql_find_name=sldbprocess("select TRAVELLER_NAME,login_city from tbl_traveller_logins where USER_ID='".$tuid."'");
                                if(mysql_num_rows($sql_find_name)>0)
                                {
                                $row_lead_detail=mysql_fetch_assoc($sql_find_name);
                                $lead_name=ucfirst($row_lead_detail['TRAVELLER_NAME']);
                                $lead_city=$row_lead_detail['login_city'];

                                }
                                }
                                $friends_list=array('Arpit Goel','Pankaj','Gaurav','Sahil','Prajesh ','Daya Singh','Danish Ali','Prashant Kumar','Mohit Awasthi','Sakshi Tuneja','Manoj Verma','Priyank Kumar Bansal','Aman','Raushan Kumar','kashif khan','Sumit Singh','Rakesh Tuhania','Divya','Soumya','Preetesh','Rahul','Tina','Raghini','Geetika','Akanksha Tiwari','Kashika','Ankita Singh','Ramesh Singh','Dushyant Chauhan','Ujjwal Vats','Deepak Goel');
                                $winner_nam = array_rand($friends_list, 1);
                                if($lead_name == '')
                                {
                                $lead_name = $friends_list[$winner_nam];
                                }
                            }
                    if($rev_counter == '1' || $rev_counter == '6' )
                    {
                    $review_text='My overall experience in '.$main_title.' was '.$remark.'. '.$best_time .$food;
                    }
                    elseif($rev_counter == '2' || $rev_counter == '7')
                    {
                        $review_text=$clean.$wash.$ent;
                    }
                    elseif($rev_counter == '3' || $rev_counter == '8')
                    {
                    $review_text=$cam.$best_time.$clean;
                    }
                    elseif($rev_counter == '4' || $rev_counter == '9')
                    {
                    $review_text='My overall experience in '.$main_title.' was '.$remark.'. '.$ent.$food;
                    }
                    elseif($rev_counter == '5' || $rev_counter == '10')
                    {
                    $review_text=$best_time.$wash. 'My overall experience in '.$main_title.' was '.$remark;
                    }
                    if($lead_name == '')
                    {
                        $lead_name='Hellotravel user';
                    }
                    if($description != '')
                    {
                    $review_text=$description;
                    }
                    if($review_text != '')
                    {
                        $review_array[$rev_counter]=array('lead_name'=>$lead_name,
                                    'lead_city'=>$lead_city,
                                    'lead_country'=>$lead_country,
                                    'review_text'=>$review_text,
                                    'star_rating'=>$overall_exp_rating,
                                    'created'=>$created);
                        $rev_counter++;
                    }
                    }
                }
                return $review_array;
    }

function getImgeHost(){
    return "www.hlimg.com";
    $host = ["www.hlimg.com" , "www.hlimg.com" , "www.hlimg.com"];
    $key  = array_rand($host , 1);
    return $host[$key];
}


function get_base_64_only_image($path){
  if(preg_match('/\.(jpg|jpeg|gif|png|bmp)/i',$path)){
          return $path;
  }else{
      return "holiday.png";
  }
}
 
 function getmetaschemadealslist(){
    $all_meta_pass = array();
    Global $prices, $durations, $budgets, $price_hash, $duration_hash, $budgets, $budget_hashx,$place_to ,$meta_add_page, $num_lead, $all_filter_data, $filter_array_name, $temp_array;
    //print_r($budget_hashx);
    $meta='';
    foreach($prices as $k=>$v){
        $meta.="&#8377;".$price_hash["$v"]["NAME"].", ";    
    }
    foreach($durations as $k=>$v){
        $meta.=$duration_hash[$v]["META"].", ";
    }
    foreach($budgets as $k=>$v){
        $meta.=$budget_hashx[$v]["META"].", ";
    }

    $meta_to="";
    if(!empty($place_to) && $place_to!="To")
    {
        $meta_to=ucfirst(strtolower($place_to));
    }

    $all_meta_pass['meta'] = $meta;

    if(!empty($meta))
    { 
        $meta_tag="Book ".$meta." Holiday Tour Packages".$meta_add_page." - HelloTravel";
    }
    else
    {   
        $meta_tag="Tour Packages, Book Tour Packages Online, Holiday Packages, Travel Package and Deals ".$meta_add_page."- HelloTravel";
    }
    
    $all_meta_pass['meta_tag'] = $meta_tag;

    $meta_new="";
    $meta_description="";
    $meta_to = " ".$meta_to." ";
   
    $all_meta_pass['meta'] = $meta;
    $all_meta_pass['meta_to'] = $meta_to;
    $all_meta_pass['num_lead'] = $num_lead;
   
    if(!empty($meta_to)){
        if($num_lead > 5){
            $meta_description=$meta_to." Tour Packages - Best offers on ".$meta_to." trip packages at HelloTravel. Book customized ".$meta_to." holiday packages from ".$num_lead." deals for ".$meta_to." holiday vacation packages.";
        }else{
            $meta_description=$meta_to." Tour Packages - Best offers on ".$meta_to." trip packages at HelloTravel. Book customized ".$meta_to." holiday packages from deals for ".$meta_to." holiday vacation packages.";
        }
    }else{
        if($num_lead > 5){
            $meta_description="Tour Packages - Best offers on trip packages at HelloTravel. Book customized holiday packages ".$num_lead." from deals for holiday vacation packages.";
        }else{
            $meta_description="Tour Packages - Best offers on trip packages at HelloTravel. Book customized holiday packages from deals for holiday vacation packages.";
        }
    }
    $meta_description=preg_replace('/\s\s+/',' ',$meta_description);
    $all_meta_pass['meta_description'] = $meta_description;
    
    $all_filter_data=array_filter($all_filter_data);
    
    if($num_lead > 5){
    $f_counter=count($filter_array_name);
    if($f_counter > 0){
        $temp_counter=0;
        $filter_array_name_temp=array();
        foreach($filter_array_name as $r=>$c){
            $temp_counter++;
            if($temp_counter == $f_counter && $f_counter > 1){
                array_push($filter_array_name_temp," and ".$c); 
            }else{
                if($temp_counter ==1){
                array_push($filter_array_name_temp,$c); 
                }else{
                array_push($filter_array_name_temp,", ".$c);    
                }
            }
        }
        $meta_new='Search & Compare '.$num_lead.$meta_to.' Holiday Packages & Hotels By '.implode("",$filter_array_name_temp);
    }else{  
    $meta_new= $meta_to."Tour Packages ".date("Y")." - Book".$meta_to."Packages at Best Price";
        $meta_new=trim($meta_new);
    }
        

}else{
    $meta_to=preg_replace('/^\s/','',$meta_to);
    if($num_lead > 1){
            $meta_new=$num_lead.$meta_to."Tour Packages |".$meta_to."Holiday Packages | HelloTravel";
        }else{
            $meta_new=$meta_to."Tour Packages |".$meta_to."Holiday Packages | HelloTravel";
    }



}
    if($num_lead>=1){
if(count($all_filter_data)>1){

    $temp_array =array();
foreach($all_filter_data as $key=> $list) {
    if(count($list)>1){
    if($key=='duration_filter'){
        $daysval = implode(' days, ', $all_filter_data['duration_filter']) . ' days' . $popdaysval;
    $temp_array['duration_filter'] = $daysval; 
    $temp_array['duration_filter']  =preg_replace("/\-\*/is","",$temp_array['duration_filter']);
    $temp_array['duration_filter'] = preg_replace("/22/ism","22+", $temp_array['duration_filter']);
       }
    if($key=='budget_filter'){
        $temparray = array();
        foreach($list as $temp){
           if(preg_match("/Economy/ism",$temp)){
                $temparray[] = "3 Star";
           }
           else if(preg_match("/Standard/ism",$temp)){
                $temparray[] = "4 Star";
           }
           else if(preg_match("/Luxury/ism",$temp)){
                $temparray[] = "5 Star";
           }

        }
        $startvald = implode(', ', $temparray);
    $temp_array['budget_filter'] = $startvald;

      } 
    if($key=='price_filter'){
    $pricevala  = array();
    foreach($list as $fil_price){
        if($fil_price['max_price']==10000){
           $pricevala[] = "less than ".$fil_price['max_price'];
        }
        elseif(!is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']."+";
        }
        else{
          $pricevala[] = $fil_price['min_price']." - ".$fil_price['max_price'];
        }
    }
    
       $maxpriceval = implode(", ",$pricevala);     
    $temp_array['price_filter'] = "Price ".$maxpriceval;

      }
      if($key=='agentstar_filter'){
    $temparr = array();
    $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    foreach($list as $agentsearch){
       if(preg_match("/^(\d)/is",$agentsearch['star_rating_search'],$resultagent)){
        if($resultagent[1]==4){
                $temparr[] = $resultagent[1]."+";
        }
        else{
         $temparr[] = $resultagent[1]." - 4";
        }
           }

    }
    
     $ratingval  = implode(', ', $temparr);
       $temp_array['agentstar_filter'] = $ratingval;
      }
      if($key=='destination_theme_filter'){
    $all_filter_data['destination_theme_filter'] = array_map("ucfirst",$all_filter_data['destination_theme_filter']);
        $daysval = implode(', ', $all_filter_data['destination_theme_filter']);
    $temp_array['destination_theme_filter'] = $daysval;
      }

    }
    else{   
    if($key=='duration_filter'){
     $daysval = $list[0];
    $temp_array['duration_filter'] = $daysval; 
    $temp_array['duration_filter']  =preg_replace("/\-\*/is","",$temp_array['duration_filter']);
    $temp_array['duration_filter'] = preg_replace("/22/ism","22+", $temp_array['duration_filter']);
     $temp_array['duration_filter'] =  $temp_array['duration_filter']." days";
       }
    if($key=='budget_filter'){
    $hotelstartd = $list[0];
     if(preg_match("/Economy/ism",$hotelstartd)){
                $startvald = "3 Star";
           }
           else if(preg_match("/Standard/ism",$hotelstartd)){
                $startvald = "4 Star";
           }
           else if(preg_match("/Luxury/ism",$hotelstartd)){
                $startvald = "5 Star ";
           }

    $temp_array['budget_filter'] = $startvald;

      } 
    if($key=='price_filter'){
    $minpriceval = $list[0]['min_price'];
        $maxpriceval = $list[0]['max_price'];
        if($maxpriceval==10000){
           $maxpriceval = "Price less than $maxpriceval";
        }
    elseif(!is_numeric($maxpriceval)){
        $maxpriceval = "Price ".$minpriceval."+";
    }
        else{
           $maxpriceval = "Price ".$minpriceval." - ".$maxpriceval;
        }

    $temp_array['price_filter'] = $maxpriceval;

      }
      if($key=='agentstar_filter'){
    $agentratinval = $list[0]['star_rating_search'];
        if(preg_match("/^(\d)/is",$agentratinval,$resultagent)){
                $ratingval = $resultagent[1];
        }
    if($ratingval==4){      
        $ratingval = $ratingval."+";
    }
    else{
         $ratingval = $ratingval." - 4";
    }
       $temp_array['agentstar_filter'] = $ratingval;
      }
      if($key=='destination_theme_filter'){
        $daysval = $list[0];
    $temp_array['destination_theme_filter'] = ucfirst($daysval);
      }


    }
  
}
$con ='';
if($temp_array['destination_theme_filter']==''){
$temp_array['destination_theme_filter'] = "Holiday";
}
if($temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']."  with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['price_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating";
}
elseif($temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages with ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!=''  && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['price_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." with ".$temp_array['budget_filter']." Rating";
}
elseif( $temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!='' && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."  with ".$temp_array['budget_filter']." Rating";
}
elseif( $temp_array['duration_filter']!=''  && $temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." with ".$temp_array['budget_filter']." Rating";
}
elseif(isset($$temp_array['price_filter'])  && isset($temp_array['duration_filter'])){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter'].", ".$temp_array['price_filter']."";
}
elseif($temp_array['price_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['duration_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']." and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif( $temp_array['budget_filter']!='' && $temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['budget_filter']." Rating and Agents ".$temp_array['agentstar_filter']." Rated";
}
elseif($temp_array['price_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['price_filter']."";
}
elseif($temp_array['budget_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['budget_filter']." Rating";
}
elseif(isset($temp_array['duration_filter'])){
$con .="".$temp_array['destination_theme_filter']." Packages for ".$temp_array['duration_filter']."";
}
elseif($temp_array['agentstar_filter']!=''){
$con .="".$temp_array['destination_theme_filter']." Packages for Agents ".$temp_array['agentstar_filter']." Rated";

}

$meta_new ="Search & Compare $num_lead $meta_to $con";
$hotel_data_h1_content = "Showing $num_lead $meta_to $con";
$meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $con";
//echo $meta_new." ".$hotel_data_h1_content." ".$meta_description;die;
//"3575 Manali Honeymoon Packages for 1-3 days, Price less than 10,000 with 4 Star Rating and Agents 4+ Rated"
}
elseif(count($all_filter_data)==1){

      if(count($all_filter_data['duration_filter'])>1){
    $popdaysval = array_pop($all_filter_data['duration_filter']);
    $popdaysval = preg_replace("/\-\*/is","+",$popdaysval);
    $daysval = implode(' days, ', $all_filter_data['duration_filter']) . ' days and ' . $popdaysval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages for $daysval days";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages for $daysval days";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages for $daysval days.";
      }
      elseif(count($all_filter_data['duration_filter'])==1){
    $daysval = preg_replace("/\-\*/is","+",$all_filter_data['duration_filter'][0]);
    $meta_new="Search & Compare $num_lead $meta_to Holiday Packages for $daysval days";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages for $daysval days";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages for $daysval days.";
      } 
      if(count($all_filter_data['budget_filter'])>1){
    $temparray = array();
    foreach($all_filter_data['budget_filter'] as $temp){
       if(preg_match("/Economy/ism",$temp)){
            $temparray[] = "3 Star";
           }
       else if(preg_match("/Standard/ism",$temp)){
        $temparray[] = "4 Star";
       }
       else if(preg_match("/Luxury/ism",$temp)){
                $temparray[] = "5 Star ";
           }

        }
    $pophotelstartd = array_pop($temparray);
    $startvald = implode(', ', $temparray) . ' and ' . $pophotelstartd;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels with $startvald  Rating";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels with $startvald  Rating";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels with $startvald Rating.";

      }
      elseif(count($all_filter_data['budget_filter'])==1){
        $hotelstartd = $all_filter_data['budget_filter'][0];
    if(preg_match("/Economy/ism",$hotelstartd)){
                $startvald = 3;
           }
           else if(preg_match("/Standard/ism",$hotelstartd)){
                $startvald = 4;
           }
           else if(preg_match("/Luxury/ism",$hotelstartd)){
                $startvald = 5;
           }

        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating";

    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels with $startvald Star Rating.";
      } 
     if(count($all_filter_data['price_filter'])>1){
    $pricevala  = array();
    foreach($all_filter_data['price_filter'] as $fil_price){
        if(is_numeric($fil_price['min_price']) && is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']." - ".$fil_price['max_price'];
        }
        else if(is_numeric($fil_price['min_price']) && !is_numeric($fil_price['max_price'])){
            $pricevala[] = $fil_price['min_price']."+";
        }
        else if(!is_numeric($fil_price['min_price']) && is_numeric($fil_price['max_price'])){
            $pricevala[] = "Price less than ".$fil_price['max_price'];
        }
    }
    $popratingval = array_pop($pricevala);
         $maxpriceval  = implode(', ', $pricevala) . ' and ' . $popratingval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages by Price $maxpriceval";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages by Price $maxpriceval";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages by Price $maxpriceval.";

      }
      elseif(count($all_filter_data['price_filter'])==1){
        $minpriceval = $all_filter_data['price_filter'][0]['min_price'];
        $maxpriceval = $all_filter_data['price_filter'][0]['max_price'];
    if($maxpriceval==10000){
       $maxpriceval = "Price less than $maxpriceval";
    }
    elseif(!is_numeric($maxpriceval)){
        $maxpriceval = "Price ".$minpriceval."+"; 
    }
    else{
       $maxpriceval = "Price ".$minpriceval." - ".$maxpriceval;
    }
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages by $maxpriceval";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages by $maxpriceval";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages by $maxpriceval.";
      } 
      if(count($all_filter_data['agentstar_filter'])>1){
    $temparr = array();
    $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    foreach($all_filter_data['agentstar_filter'] as $agentsearch){
       if(preg_match("/^(\d)/is",$agentsearch['star_rating_search'],$resultagent)){
        if($resultagent[1]==4){
            $temparr[] = $resultagent[1]."+";
        }
        elseif($resultagent[1]==3){
                        $temparr[] = $resultagent[1]. " - 4";
                }
           }

    }
    $popratingval = array_pop($temparr);
     $ratingval  = implode(', ', $temparr) . ' and ' . $popratingval;
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
        $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated.";

      }
      elseif(count($all_filter_data['agentstar_filter'])==1){
        $agentratinval = $all_filter_data['agentstar_filter'][0]['star_rating_search'];
    if(preg_match("/^(\d)/is",$agentratinval,$resultagent)){
        $ratingval = $resultagent[1];
        if($resultagent[1]==4){
                        $ratingval = $resultagent[1]."+";
                }
                else if($resultagent[1]==3){
                        $ratingval = $resultagent[1]. " - 4";
                }

    }
        $meta_new="Search & Compare $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
    $hotel_data_h1_content = "Showing $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated";
    $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to Holiday Packages & Hotels by Agents $ratingval Rated.";
      } 
      if(count($all_filter_data['destination_theme_filter'])>1){
    $all_filter_data['destination_theme_filter'] = ucwords(implode("| ",$all_filter_data['destination_theme_filter']));
    $all_filter_data['destination_theme_filter'] = explode ("| ",$all_filter_data['destination_theme_filter']);
        $popdaysval = array_pop($all_filter_data['destination_theme_filter']);
        $daysval = implode(', ', $all_filter_data['destination_theme_filter']) . ' and ' . $popdaysval;
    $meta_new="Search & Compare $num_lead $meta_to $daysval Packages";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $daysval Packages.";
        $hotel_data_h1_content =  "Showing $num_lead $meta_to $daysval Packages";
      }
      elseif(count($all_filter_data['destination_theme_filter'])==1){
        $daysval = ucfirst($all_filter_data['destination_theme_filter'][0]);
        $meta_new="Search & Compare $num_lead $meta_to $daysval Packages";
        $meta_description = "At HelloTravel you will find a wide range of $num_lead $meta_to $daysval Packages.";
        $hotel_data_h1_content =  "Showing $num_lead $meta_to $daysval Packages";
      }


 }
}

$meta_new = preg_replace("/\s+/ism"," ",$meta_new);
$hotel_data_h1_content = preg_replace("/\s+/ism"," ",$hotel_data_h1_content);
$meta_description = preg_replace("/\s+/ism"," ",$meta_description);
if(!empty($place_to))
{
    $meta_tag .=", ".$place_to." Tour Booking Guide | HelloTravel";
}else{
    $meta_tag .=", Tour Booking Guide | HelloTravel";
}
$all_meta_pass['meta_new'] = $meta_new;
$all_meta_pass['hotel_data_h1_content'] = $hotel_data_h1_content;
$all_meta_pass['meta_description'] = $meta_description;
return $all_meta_pass;
}



  
?>
