<?php
// ini_set('display_errors', 'On');
//  error_reporting(E_ALL);

require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header_module.php");
$BASE_URL_DEALS = "http://local.hellotravel.noida/ads";
$new_version_path = "https://www.hellotravel.com/hellotravel2.0/";
function PackageDgn(){
    $setPackageDesign=getPackageDgn();
    if(isset($setPackageDesign) && !empty($setPackageDesign)){
       return json_encode($setPackageDesign);die;
    }
}


function DestinatonDgn(){
    $setDestinatonDesign=getDestinatonDgn();
    if(isset($setDestinatonDesign) && !empty($setDestinatonDesign)){
       return json_encode($setDestinatonDesign);die;
    }
}

function TripIdeasDgn(){
    $setTripIdeasDesign=getTripIdeasDgn();
    if(isset($setTripIdeasDesign) && !empty($setTripIdeasDesign)){
       return json_encode($setTripIdeasDesign);die;
    }
}

function SightseeingDgn(){
    $setSightseeingDesign=getSightseeingDgn();
    if(isset($setSightseeingDesign) && !empty($setSightseeingDesign)){
       return json_encode($setSightseeingDesign);die;
    }
}


function FooterSectionDgn(){
    $setFooterSectionDesign=getFooterSectionDgn();
    if(isset($setFooterSectionDesign) && !empty($setFooterSectionDesign)){
       return json_encode($setFooterSectionDesign);die;
    }
}

function SchemaNavTagDgn(){
    $setSchemaNavTagDesign=getSchemaNavTagDgn();
    if(isset($setSchemaNavTagDesign) && !empty($setSchemaNavTagDesign)){
        return json_encode($setSchemaNavTagDesign);die;
     }
}

function BreadSchemaTagDgn(){
    $setBreadSchemaTagDesign=getBreadSchemaTagDgn();
    if(isset($setBreadSchemaTagDesign) && !empty($setBreadSchemaTagDesign)){
        return json_encode($setBreadSchemaTagDesign);die;
     }
}

function OrgSchemaTagDgn(){
    $setOrgSchemaTagDesign=getOrgSchemaTagDgn();
    if(isset($setOrgSchemaTagDesign) && !empty($setOrgSchemaTagDesign)){
        return json_encode($setOrgSchemaTagDesign);die;
     }
}


function AutoSuggationDgn(){
    $setAutoSuggationDesign=getAutoSuggationDgn();
    // print_r($setAutoSuggationDesign);die;
    if(isset($setAutoSuggationDesign) && !empty($setAutoSuggationDesign)){
        return json_encode($setAutoSuggationDesign);die;
     }
}



function UserDataDgn(){
    $setUserData=getUserData();
    // print_r($setAutoSuggationDesign);die;
    if(isset($setUserData) && !empty($setUserData)){
        return json_encode($setUserData);die;
     }
}

$UserDataDesign=UserDataDgn();
$UserData=json_decode($UserDataDesign,true);



$AutoSuggationDesign=AutoSuggationDgn();
$AutoSuggationDesign=json_decode($AutoSuggationDesign,true);


$PackageDesign=PackageDgn();
$PackageDesign=json_decode($PackageDesign,true);

$DestinatonDesign=DestinatonDgn();
$DestinatonDesign=json_decode($DestinatonDesign,true);


$TripIdeasDesign=TripIdeasDgn();
$TripIdeasDesign=json_decode($TripIdeasDesign,true);

$SightseeingDesign=SightseeingDgn();
$SightseeingDesign=json_decode($SightseeingDesign,true);

$FooterSectionDesign=FooterSectionDgn();
$FooterSectionDesign=json_decode($FooterSectionDesign,true);

$SchemaNavTagDesign=SchemaNavTagDgn();

$BreadSchemaTagDesign=BreadSchemaTagDgn();

$OrgSchemaTagDesign=OrgSchemaTagDgn();

$OrgSchemaTagDesign = ' <script type="application/ld+json">'.$OrgSchemaTagDesign.'</script>';
$smarty_obj->assign('SchemaTagOrgDesign', $OrgSchemaTagDesign);
$smarty_obj->assign('new_version_path', $new_version_path);

$SchemaNavTagDesign =  ' <script type="application/ld+json">'.$SchemaNavTagDesign.'</script>';
$smarty_obj->assign('SchemaNavTagDesign', $SchemaNavTagDesign);

//coment by kamlesh as discus nand sir
//$BreadSchemaTagDesign = ' <script type="application/ld+json">'.$BreadSchemaTagDesign.'</script>';
//$smarty_obj->assign('BreadSchemaTagDesign', $BreadSchemaTagDesign);

$monthname_str="";
for ($i = 0; $i <= 5; $i++) {
	$monthname_str.='<span class="fl w33d pd05"><a href="javascript:void(0);"  class="mon1 leadjourney-checkbox-afterpost" action_type="journeymonth" data_value="'.date("F", strtotime( date( "Y-m-01" )." +$i months")).'">'.date("F", strtotime( date( "Y-m-01" )." +$i months")).'</a></span>';
}
// $main_data['referal_id']=$ref_page;
// $main_data['lead_id']=$lead_value;

// $designStory = getstorymonthwise();
// $lang_canonical_urls=get_lang_canonical_urls();

$baseimgurl='https://2.hlimg.com/images/hellotravel2.0/';
$smarty_obj->assign('baseurl', BASEURL_HT);
$smarty_obj->assign('baseimgurl',$baseimgurl);

// $smarty_obj->assign('international_pack', $international_pack);


 $smarty_obj->assign('ref', $_SERVER['HTTP_REFERER']);
// $smarty_obj->assign('domestic_pack', $domestic_pack);
// $smarty_obj->assign('top_trip_idea_header', $top_trip_idea_header);
// $smarty_obj->assign('events_header', $events_header);
// $smarty_obj->assign('events_header_count', count($events_header));
// $smarty_obj->assign('theme_array_count', count($newArray));
// $smarty_obj->assign('themes_array', $newArray);
// $smarty_obj->assign('ReferreRvariable', $ReferreRvariable);


$smarty_obj->assign('page', $UserData['page']);
$smarty_obj->assign('monthname_str', $monthname_str);
$smarty_obj->assign('traveller_name', $UserData['traveller_name']);
$smarty_obj->assign('client_email', $UserData['client_email']);
$smarty_obj->assign('client_login', $UserData['client_login']);
$smarty_obj->assign('country_code_no', $UserData['country_code_no']);
$smarty_obj->assign('ip_city_name', $UserData['ip_city_name']);
$smarty_obj->assign('ip_country_name', $UserData['ip_country_name']);
$smarty_obj->assign('lead_city', $UserData['lead_city']);
$smarty_obj->assign('contact_num', $UserData['contact_num']);
$smarty_obj->assign('last_lead', $UserData['last_lead']);

$uri_check=$_SERVER{SCRIPT_URI};
$script_parent_url_clonical="https://www.hellotravel.com".$_SERVER{SCRIPT_URL};
$smarty_obj->assign('script_parent_url_clonical',$script_parent_url_clonical);


$smarty_obj->assign('uid_client', base64_encode($UserData['uid_client']));
$smarty_obj->assign('uid_client_dec', $UserData['uid_client']);
// $smarty_obj->assign('entry_cookie', $entry_cookie);
$smarty_obj->assign('travelerpic', $UserData['travelerpic']);
$smarty_obj->assign('privacy', $UserData['privacy']);
$smarty_obj->assign('select_agent_list', $UserData['select_agent']);
$smarty_obj->assign('loggedvalue', $UserData['loggedvalue']);
$smarty_obj->assign('loginvalue', $UserData['cookie_value']);
$smarty_obj->assign('loginpassword', $UserData['cookie_pass']);
$smarty_obj->assign('pop_referer_url', $_SERVER["HTTP_REFERER"]);
$pop_self_url=$_SERVER["SCRIPT_URI"];
$pop_self_url=str_replace("http:","https:",$pop_self_url);
$smarty_obj->assign('pop_self_url', $pop_self_url);
$smarty_obj->assign('pagesource', $pop_self_url);
$smarty_obj->assign("PackageDesign",$PackageDesign);
$smarty_obj->assign("DestinatonDesign",$DestinatonDesign);
$smarty_obj->assign("TripIdeasDesign",$TripIdeasDesign);
$smarty_obj->assign("SightseeingDesign",$SightseeingDesign);
$smarty_obj->assign("FooterSectionDesign",$FooterSectionDesign);
$smarty_obj->assign("AutoSuggationDesign", $AutoSuggationDesign);
$smarty_obj->assign('entry_cookieVal', $UserData['entry_cookieVal']);
$smarty_obj->assign('mytripcode', $UserData['crypt']);

// $smarty_obj->loadFilter('output', 'trimwhitespace');



?>
