<?php

 function getDealsDataurl(){

  $get_url=substr($_SERVER['REQUEST_URI'],1);
  $exploded_val=explode("/",$get_url);
  $explode_d_id=explode(".",$exploded_val[1]);
  $d_id=$explode_d_id[0];

  $d_id=$_REQUEST['deal_id'];
   $t_status='';
$pattern="/^\d+$/";
   if ((preg_match($pattern, $d_id) == 0)){

        $d_row=get_nid_from_url($d_id);
        $d_id=$d_row["nid"];
        $t_status=$d_row["status"];
}else{
        $url_args=get_url_from_nid($d_id);
        $url_deals_r=$url_args["url"];
        $t_status=$url_args["status"];
        if($url_deals_r != "" && $t_status==1){
        header("HTTP/1.1 301 Moved Permanently");
          header("Location: https://www.hellotravel.com/deals/".$url_deals_r);
          exit();
        }

	
}
  return $d_id;
 }


function get_nid_from_url($url){
        $url=$url.".html";
        $dealdsth=dbprocess("select status,nid from tbl_deals where  url='$url'");
if(mysql_num_rows($dealdsth) > 0){
        $deal_url=mysql_fetch_array($dealdsth);
        return  $deal_url;
}else{
        array('status'=>'0',nid=>0);
}

}

function get_url_from_nid($nid){
        $url=$url.".html";
        $dealdsth=dbprocess("select status,url from tbl_deals where  nid='$nid'");
if(mysql_num_rows($dealdsth) > 0){
        $deal_url=mysql_fetch_array($dealdsth);
        return  $deal_url;
}else{
        array('status'=>'0',url=>"");
}

}


function getdealsDataById($d_id){
$filter_query_args=array();$return_data=array();
$stat=$_REQUEST['stat'] || '0';
$archive_package=0;
$main_data = array();
$pattern="/^\d+$/";
 if ((preg_match($pattern, $d_id) == 0))
 {
    header("HTTP/1.0 404 Not Found");
        include_once("not-found.php");
		exit;
}
if($d_id == '' && empty($d_id)){
	header("HTTP/1.0 404 Not Found");
        include_once("not-found.php");
		exit;
}

$t_status=fetch_one_column_from_table("tbl_deals","status",'nid',$d_id);
if($t_status != 1){
           
 header("HTTP/1.0 404 Not Found");
    include_once("not-found.php");
      exit;
}


if(isset($_COOKIE['leadvalue']))
{
    $cookie_value=$_COOKIE['leadvalue'];
    $lead_value = base64_decode($cookie_value);
    $ref_page='yes';
}



$filternid = '&fq=nid%3A"'.$d_id.'"';
$query = "*:*";
$query=str_replace(":","%3A",$query);
   #$url_0="http://localhost:8983/solr/hellotravel_test/select?q=$query$filternid&wt=json&indent=true"; 
   //$url_0="http://ht-search-new:8983/solr/hellotravel_deals-new/select?q=$query$filternid&wt=json&indent=true";
   $url_0="http://172.16.31.12:8983/solr/hellotravel_deals-new_v2/select?q=$query$filternid&wt=json&indent=true";
   $url_0=str_replace(" ","%20",$url_0);

   //print_r($url_0);die;
   
   $json_main = @file_get_contents($url_0);

$data = json_decode($json_main, true); 

$num_found = $data["response"]["numFound"];
if($num_found == 0){
	if($num_found == 0){
		header("HTTP/1.0 404 Not Found");
        include_once("not-found.php");
		exit;
	}
}else{

    $return_data=$data;
}

return $return_data;

}




 function getBreadcrumb($data){
  
  $main_data=array(); $return_data=array();
  $main_country_iso_code=$data["response"]["docs"][0]['destination_country'];
  
  $country_name = fetch_one_column_from_table("tbl_country","TBL_COUNTRY",'TBL_COUNTRY_ISO_CODE',$main_country_iso_code);
  $main_data['destinations_country_name'] = ucfirst($country_name);
  $main_data['destinations_country_url'] = str_replace(" ","-",strtolower($country_name));
  $dest_expp =  explode("," , $data["response"]["docs"][0]["destinations_covered_text"]);
  $main_data['destinations_covered_city'] = ucfirst(rtrim($dest_expp[0],', ')) ;
  $main_data['destinations_covered_url'] = str_replace(" ","-",strtolower($dest_expp[0]));
  $title = $data["response"]["docs"][0]["title"];
  $main_data['title']=$title; 

  
  $return_data['links'][]=array('name'=>$main_data['destinations_country_name'],'url'=>BASEURL_HT.$main_data['destinations_country_url']);
  $return_data['links'][]=array('name'=>$main_data['destinations_covered_city'],'url'=>BASEURL_HT.'deals/'.$main_data['destinations_covered_url']);
  $return_data['title']=array('name'=>$title);
 
  return $return_data;
}


function getHeaderbanner($data){
  $return_data=array();
  $photo_gallery_trim=$data["response"]["docs"][0]["images"];

  if(!empty($photo_gallery_trim))
  {
   $photo_gallery  =  $photo_gallery_trim;
 
  if(count($photo_gallery)>0)
  {   
    $photo_gallery = array_map(addRq ,$photo_gallery);
    $random_photo_keys = array_rand($photo_gallery,1);
    $photos_array = $photo_gallery[$random_photo_keys];
  }
  $return_data=$photo_gallery;
  }

  return $return_data;
  
}


function getHeaderDetail($data){

  $return_data=array();$return_data['rating']=0;
  $return_data['title'] = $data["response"]["docs"][0]["title"];

  $star_rating_sum = $data["response"]["docs"][0]['rating_total_sum'];
  $star_rating_count = $data["response"]["docs"][0]['travel_with_count'];
	$total_star_rating=$star_rating_sum/20;
  $return_data['review']=$star_rating_count;

	 if($star_rating_count>0){
      $rating=$total_star_rating/$star_rating_count;
      $return_data['rating']=round($rating);
   }

   $dest_expp =  explode("," , $data["response"]["docs"][0]["destinations_covered_text"]);
 
   $dest_arr_ph = array_map(addDes_ph ,$dest_expp);
  
   $return_data['destinations_covered']=  $dest_arr_ph;

   return $return_data;
}



function getHeaderDesc($data){

  $return_data=array();
   $return_data['price'] = number_format($data["response"]["docs"][0]["price"]);
   $return_data['day_tour'] = $data["response"]["docs"][0]["days"];
   $budget = $data["response"]["docs"][0]["budget"];
   
   $return_data['budget']='';

   if($budget!=''){
     if($budget=='1'){
      $return_data['budget']='Standard';
     }elseif($budget=='2'){
      $return_data['budget']='Luxury';
     }
   }

   $tour_type = $data["response"]["docs"][0]["form_type"];
   $return_data['tour_type']='';

   if($tour_type!=''){
    if($tour_type=='1'){
     $return_data['tour_type']='Fixed Tour';
    }elseif($tour_type=='2'){
     $return_data['tour_type']='Customized';
    }
  }

  
   return $return_data;
}

function getAgentProfile($data){

 
  $return_data=array();
  $return_data['rating']=0;
  $log_uid = $data["response"]["docs"][0]["fcp_uid"];
  $dst = fetch_one_column_from_table("tbl_dst","url",'uid',$log_uid);

  $return_data['company_name'] = $data["response"]["docs"][0]["tbl_login_companyname"];
  $return_data['company_url'] = $dst;
  $image = $data["response"]["docs"][0]["company_logo"];

  if(!empty($image)){
  $return_data['company_image']="https://www.hlimg.com/images/logo/".$image;
  }else{
    $return_data['company_image']="https://www.hlimg.com/images/travelerimages/uuserdefault.png";
  }

  $return_data['bookings'] = $data["response"]["docs"][0]['bookings'];
  
  $star_rating_sum = $data["response"]["docs"][0]['rating_total_sum'];
  $star_rating_count = $data["response"]["docs"][0]['travel_with_count'];
	$total_star_rating=$star_rating_sum/20;
  $return_data['review']=$star_rating_count;

	 if($star_rating_count>0){
      $rating=$total_star_rating/$star_rating_count;
      $return_data['rating']=round($rating);

   }
  $return_data['member_since'] = $data["response"]["docs"][0]["member_since"];
  $return_data['member_month'] = $data["response"]["docs"][0]["member_month"];

  return $return_data;

}

function getItinerary($data){

  $return_data=array();$itrdataall=array();
  $itinerary=$data["response"]["docs"][0]['itinerary'];
  
  if(!empty($itinerary)){
    $itinerary=unserialize($itinerary);
  }else{
    $itinerary=array();
  }
 
  //print_r($itinerary);die;
  foreach($itinerary as $itr){
    $itrdata=array();
    $day=$itr['iti_day'];
    $itrdata['day']=str_replace("day","Day ",$day);
    $itrdata['iti_city']=ucwords($itr['iti_city']);
    $iti_city_url = ucfirst(rtrim($itrdata['iti_city'],', ')) ;
    $iti_city_url = str_replace(" ","-",strtolower($iti_city_url));
    $itrdata['iti_city_url']=BASEURL_HT.'deals/'.$iti_city_url;
 
    $similar=$itr['similar'];
    if($similar=='yes'){
      $itrdata['iti_hotel']=ucwords($itr['iti_hotel']).' Or Similar';
    }else{
     $itrdata['iti_hotel']=ucwords($itr['iti_hotel']);
    }
    
    $pattern="/^\d+$/";
    $rating=$itr['iti_hotel_star'];

   if((preg_match($pattern, $rating) == 1)){
    $itrdata['iti_hotel_star']=$itr['iti_hotel_star'];
    $itrdata['iti_show_star']='yes';
    }else{
    $iti_hotel_star = str_replace("_"," ",strtolower($itr['iti_hotel_star']));
    $itrdata['iti_hotel_star']=ucwords($iti_hotel_star); 
    }    


    $itrdata['iti_description']=$itr['iti_description'];
    
     foreach($itr['sights'] as $sights){
      $sightsdata=array();
      $sightsdata['iti_sight_name']=ucwords($sights['iti_sight_name']);
      $sightsdata['iti_sight_desc']=$sights['iti_sight_desc'];
      $iti_sight_day_duration=$sights['iti_sight_day_duration'];
      $sightsdata['iti_sight_day_duration']=str_replace("_"," ",$iti_sight_day_duration);
      
      $itrdata['sights'][]=$sightsdata;
     }
   
    $itrdataall[]=$itrdata;

  }

  $return_data['contents']=$itrdataall;  
  $return_data['heading']='Itinerary';
 
  //print_r($return_data);die;
  return $return_data;

   

}




function getInclusionExclusion($data){
  $return_data=array();
  $inclusion_exclusion_val = $data["response"]["docs"][0]["inclusion_exclusion"];

  $hook_form = $data["response"]["docs"][0]["hook_form"];
	$form_type = $data["response"]["docs"][0]["form_type"];
  $form_version = $data["response"]["docs"][0]["form_version"];
 
  $return_data['contents']['hook_form']=$hook_form;
  $return_data['contents']['form_type']=$form_type;

  $return_data['contents']['form_version']=$form_version;
  $inclusion_exclusion = unserialize($inclusion_exclusion_val);
 
  $exarray=array('Sightseeing','Transfers','Breakfast');
  $excludeArr=array();
   foreach($exarray as $val){
    if (in_array($val, $inclusion_exclusion)){
    //   if (($key = array_search($val, $inclusion_exclusion)) !== false) {
    //     //unset($inclusion_exclusion[$key]);
    // }
    }else{
      $excludeArr[]=$val;
    }
   }

  


  $return_data['contents']['exclusion']=$excludeArr;
  $return_data['contents']['inclusion']=$inclusion_exclusion;  
  $return_data['heading']='Included/Excluded ';

  //print_r($return_data);die;
  return $return_data;

}

function getHighlight($data){

  $return_data=array();
  $highlight = $data["response"]["docs"][0]["highlight"];
  if(!empty($highlight)){
  $highlight = unserialize($highlight);
  }else{
   $highlight=array();
  }
  $return_data['contents']=$highlight;  
  $return_data['heading']='Highlights ';

  return $return_data;

}
  
function getTermsCondition($data){
  $return_data=array();$return_dataDiv=array();$termsarray=array();
  $form_version = $data["response"]["docs"][0]["form_version"];
  $deals_terms = $data["response"]["docs"][0]["deals_terms_condition"];

  if($deals_terms)
  {
          $termsarray = unserialize($deals_terms);
          foreach($termsarray as $key=>$val){
            $termsdata=array();
                       
           if($val['booking_checked']==1){

            if($val['days']==''){
             
              $termsdata=$val['refund_prcnt'].'% advance to be paid for booking of the total tour package cost.';
            }else if($val['days']!=''){
              $days=$val['days'];
             
              $termsdata=$val['refund_prcnt']." Refund will be made within  working $days days from the date of receipt of the cancellation.";
            }
            $return_data[]=$termsdata;

           }
          
          }
         
    $return_dataDiv['header']='Terms and Conditions';
    $return_dataDiv['contents']=$return_data;
  
    return $return_dataDiv; die;
  }

}


function getAccomondation($data){
   $Accomondation=getItinerary($data);
   //print_r($Accomondation);die;
   
   $Accomondation['heading']='Accommodation';

   return $Accomondation;die;
  
}


function getDuration($data){
  $return_data=array();
  $duration = $data["response"]["docs"][0]["duration"];

  $return_data['heading']='Durations';
  $return_data['contents']=$duration;

  return $return_data;die;

}


function getTheme($data){
  $return_data=array();$theme=array();
  $theme = $data["response"]["docs"][0]["themes"];
  
  $return_data['heading']='Theme';
  $return_data['contents']=$theme;

  return $return_data;die;

}


function getTourLocation($data){
  $return_data=array();$theme=array();
  $dest_expp =  explode("," , $data["response"]["docs"][0]["destinations_covered_text"]);
 
  $dest_arr_ph = array_map(addDes_ph ,$dest_expp);
 
  $destinations =  $dest_arr_ph;


  $return_data['heading']="Tour's Destination";
  $return_data['contents']=$destinations;
  //print_r($return_data);die;
  return $return_data;die;

}


function getPriceBreakup($data){
  $return_data=array();$pricearrayall=array();
  $price_struct =  $data["response"]["docs"][0]["price_struct_data"];
  $price_struct=(unserialize($price_struct));

  
    foreach($price_struct as $price){
      $pricearray=array();

      $pricearray['price']=number_format($price['price']);
      $pricearray['month']=$price['month_assign'];
      $pricearray['tax']=$price['tax'];
      $blackout_date=explode(",",$price['date_rage_blackout_date']);
      $pricearrayall[]=$pricearray;

    }
    $return_data['blackout_date']=$blackout_date;
    $return_data['heading']='Price Detail';
    $return_data['contents']=$pricearrayall;

    //print_r($return_data);die;
    
    return $return_data;die;

}


function getCustreview($data){
  $return_data=array();$return_data['rating']=0;
  $log_uid = $data["response"]["docs"][0]["fcp_uid"];

  $star_rating_sum = $data["response"]["docs"][0]['rating_total_sum'];
  $star_rating_count = $data["response"]["docs"][0]['travel_with_count'];
 
  $star_rating_count_1 = $data["response"]["docs"][0]['star_rating_count_1'];
  $star_rating_count_2 = $data["response"]["docs"][0]['star_rating_count_2'];
  $star_rating_count_3 = $data["response"]["docs"][0]['star_rating_count_3'];
  $star_rating_count_4 = $data["response"]["docs"][0]['star_rating_count_4'];
  $star_rating_count_5 = $data["response"]["docs"][0]['star_rating_count_5'];

  $total_star_rating=$star_rating_sum/20;
  $return_data['review']=$star_rating_count;



  $return_data['log_uid']=BASEURL_HT."fcp_reviews.php?id=".$log_uid;

	 if($star_rating_count>0){
    $rating=$total_star_rating/$star_rating_count;
    $return_data['rating']=round($rating);
   }
   
  
   if($return_data['rating']==5){
    $return_data['ratingtext']='Excellent';
   }elseif($return_data['rating']==4){
    $return_data['ratingtext']='Very Good';
   }elseif($return_data['rating']==3){
    $return_data['ratingtext']='Average';
   }elseif($return_data['rating']==2){
    $return_data['ratingtext']='Poor';
   }elseif($return_data['rating']==1){
    $return_data['ratingtext']='Terrible';
   }

          //traveler reviews
          if($log_uid != 0)
          {
          $rev_counter=1;
    $sql_rev=dbprocess("SELECT * FROM `tbl_testimonial` WHERE `travel_with`='".$log_uid."' and status=1 and star_rating >= 60 AND  `issue_resolve_traveler`=0  and status_verify='1' order by rand() limit 3");
   //$sql_rev=dbprocess("SELECT * FROM `tbl_testimonial` WHERE travel_with=43511 AND status=1 and star_rating >= 60 AND `issue_resolve_traveler`=0 and status_verify='1' order by rand() limit 3");   
  if(mysql_num_rows($sql_rev)>0)
          {
              while($row_rev=mysql_fetch_assoc($sql_rev))
              {
  
  
          $lead_name='';
          $lead_id='';
          $lead_city_rev='';
          $lead_country='';
          $name_an='';
          $review_text='';
          $description='';
          $lead_id=$row_rev['lead_id'];
          $review_post_dt=$row_rev['review_post'];
          $description=$row_rev['body'];
          $overall_exp_rating=$row_rev['star_rating']/20;
  

          
      $leadid_val="tbl_lead_id=".$lead_id;
     
       //$leadid_val="tbl_lead_id=6473284";
          if($lead_id != 0){
                 $sql_lead_detail=dbprocess("select TBL_LEAD_NAME,TBL_LEAD_CITY,FK_TBL_COUNTRY from tbl_leads where " .$leadid_val." limit 1");
                 if(mysql_num_rows($sql_lead_detail)==0)
                 {
                   $sql_lead_detail=dbprocess("select TBL_LEAD_NAME,TBL_LEAD_CITY,FK_TBL_COUNTRY from tbl_leads_archive where " .$leadid_val." limit 1");
                 }
                $row_lead_detail=mysql_fetch_assoc($sql_lead_detail);
  
               
                $lead_name=ucfirst($row_lead_detail['TBL_LEAD_NAME']);
                $lead_city_rev=addplc_rev($row_lead_detail['TBL_LEAD_CITY']);
                $lead_country=$row_lead_detail['FK_TBL_COUNTRY'];
                $lead_img='';
          }
  


          if(!empty($lead_img)){
            $lead_img="https://www.hlimg.com/images/travelerimages/uuserdefault.png";
            }else{
              $lead_img="https://www.hlimg.com/images/travelerimages/uuserdefault.png";
            }
  
            if($lead_name==''){
              $lead_name='Traveller';
            }
            if($description != '')
            {
              $review_text=$description;
            }
            if($review_text == '')
            {
              $review_text = ' ';
            }
             if($review_text != '')
            {
                  $review_array[$rev_counter]=array('lead_name'=>$lead_name,
                              'lead_city_rev'=>$lead_city_rev,
                              'lead_country'=>$lead_country,
                              'review_text'=>$review_text,
                              'star_rating'=>$overall_exp_rating,
                              'review_post'=>date("d F Y h:i A", strtotime($review_post_dt)),
                              'lead_image'=>$lead_img,
  
                              );
                  $rev_counter++;
              }
              
              }
          }
        }


        $return_data['heading']='Review';
        $return_data['contents']=$review_array;
        $return_data['star_rating_count_1']=$star_rating_count_1;
        $return_data['star_rating_count_2']=$star_rating_count_2;
        $return_data['star_rating_count_3']=$star_rating_count_3;
        $return_data['star_rating_count_4']=$star_rating_count_4;
        $return_data['star_rating_count_5']=$star_rating_count_5;
         //print_r($return_data);die;
        return $return_data;die;
       
  
}

function addplc_rev($sValue){
  $anchor=mysql_real_escape_string(strtolower(trim($sValue)));

  $sql_plc=dbprocess("select url,country_iso_code from tbl_placestosee_upload where title='".$anchor."' and status=1  limit 1");
if(mysql_num_rows($sql_plc)>0)
{
 $row_plc=mysql_fetch_assoc($sql_plc);
 $url_plc=$row_plc['url'];
 $code1=$row_plc['country_iso_code'];
                  if(!empty($code1))
    {
        $sql_country_name_places5 = mysql_fetch_array(dbprocess("select TBL_COUNTRY from tbl_country where TBL_COUNTRY_ISO_CODE ='$code1'"));
        $country_name_places=$sql_country_name_places5['TBL_COUNTRY'];
    }

$url_title_plc="https://www.hellotravel.com/".strtolower(str_replace(' ','-', $country_name_places))."/".$url_plc;

   return "<a style='text-decoration:none' href='$url_title_plc' target='_blank'>$sValue</a>";
}
else
{
  return $sValue;
}

 }


function getSimilerDestData($data){
    
    $return_data=array();
    $Sreturn_data=array();
    $filter_query_args=array();
   
    $filter_query_args["destinations_covered"]=implode(',',$data["response"]["docs"][0]["destinations_covered"]);
	  $filter_query_args["destinations_covered"]=preg_replace('/,india/','',$filter_query_args["destinations_covered"]);
    $themes=$data["response"]["docs"][0]['themes'];
    $filter_query_args["days"]=array($data["response"]["docs"][0]["days"].'-'.$data["response"]["docs"][0]["days"]);
    if(!empty($themes)){
    $themes = implode(", ",$themes);
    $filter_query_args["themes"]=$themes;
    }
    $filter_query_args["userid"]=$data["response"]["docs"][0]["tbl_login_id"];
  
  
    $ex_logins=array();
    $ex_logins[$filter_query_args["userid"]]=1;
   

    $simmilar_packages_arr=array("result"=>array(),"count"=>3);
   
		$r=new package_relevence_module_my(array("type"=>"and","rows"=>8,"exclude_login"=>implode(' OR ',array_keys($ex_logins))));
		$filter_query=array();
		#$filter_query["duration"]=$filter_query_args["days"];
		$filter_query["destinations"]=$filter_query_args["destinations_covered"];
		$filter_query["themes"]=$filter_query_args["themes"];
  
    $filter_query["day_flag"]="1";
   
    $simmilar_packages=$r->get_packages($filter_query);
    
		if(count($simmilar_packages["result"]) > 0)
		$simmilar_packages_arr["result"][1]=$simmilar_packages["result"];

		$filter_query["day_flag"]="2";
    $simmilar_packages=$r->get_packages($filter_query);
		if(count($simmilar_packages["result"]) > 0)	
		$simmilar_packages_arr["result"][2]=$simmilar_packages["result"];
		
		$filter_query["day_flag"]="3";
		$simmilar_packages=$r->get_packages($filter_query);
		if(count($simmilar_packages["result"]) > 0)
		$simmilar_packages_arr["result"][3]=$simmilar_packages["result"];	
		
        


    $packageArrayAll=array();$ex_loginsAll=array();
    foreach($simmilar_packages_arr as $simmilar_packages){
      foreach($simmilar_packages as $val){
        
       foreach($val as $v){
        if($v->path!=''){
         $packageArray=array();$tag='';  
         $ex_logins[$v->tbl_login_id]=1; 
         $packageArray['title']=$v->title;
         $packageArray['place']=implode(', ',$v->destinations_covered);
         $packageArray['price']=number_format($v->price);
         $packageArray["url"]   = BASEURL_HT.'deals/'.$v->id.'.html';
         $packageArray['duration']=$v->duration;
         $packageArray['days']=$v->days .' Days';;
         $packageArray['rating']=$v->star_rating_search;
         $packageArray['review']=$v->travel_with_count;
         $packageArray['image']="https://www.hlimg.com/images/deals/360X230/".$v->path;
        if($v->group_deal==1 && $v->sponsored_status=='1')
        {
          $tag='PREMIUM';
        }else if($v->ptt_service_flag==1 ||  $v->ptt_service_flag=='2'){
            $tag='HIGHLIGHTED';
        }
         $packageArray['tag']=$tag;


         $packageArrayAll[]=$packageArray;
         $ex_loginsAll[]=$ex_logins;

           }
        }
      }

    }

   
    $dest_expp =  explode("," , $data["response"]["docs"][0]["destinations_covered_text"]);
    $destinations_covered_city = ucfirst(rtrim($dest_expp[0],', ')) ;
    $destinations_covered_url = str_replace(" ","-",strtolower($dest_expp[0]));

    $Sreturn_data['viewAlltitle']='View All '.$destinations_covered_city.' Tour Packages';
    $Sreturn_data['viewAllurl']=BASEURL_HT.'deals/'.$destinations_covered_url;
    $Sreturn_data['heading']='Similar Tour Packages';
    $Sreturn_data['contents']=$packageArrayAll;


    // ==================Start Code For Destinations Design=====================

    $Dreturn_data=array();
    $destination_packages_arr=array("result"=>array(),"count"=>3);		
		$r=new package_relevence_module_my(array("type"=>"and","rows"=>8,"exclude_login"=>implode(' OR ',array_keys($ex_logins))));
		$filter_query=array();
        	$filter_query["destinations"]=$filter_query_args["destinations_covered"];
#		$filter_query["days_group"]="1";
         	$filter_query["day_flag"]="1"; 
		$destination_packages=$r->get_packages($filter_query);
		if(count($destination_packages["result"]) > 0)
		$destination_packages_arr["result"][1]=$destination_packages["result"];

		$filter_query["day_flag"]="2";
                $destination_packages=$r->get_packages($filter_query);
		if(count($destination_packages["result"]) > 0)
		$destination_packages_arr["result"][2]=$destination_packages["result"];

    		$filter_query["day_flag"]="3";
                $destination_packages=$r->get_packages($filter_query);
		if(count($destination_packages["result"]) > 0)
		$destination_packages_arr["result"][3]=$destination_packages["result"];

 //print_r($destination_packages_arr);die;

  
      $DpackageArrayAll=array();
      foreach($destination_packages_arr as $destination_package){
        foreach($destination_package as $val1){
          
         foreach($val1 as $v1){
          if($v1->path!=''){
           
           $DpackageArray=array();$tag='';   
           $DpackageArray['title']=$v1->title;
           $DpackageArray['place']=implode(', ',$v1->destinations_covered);
           $DpackageArray['price']=number_format($v1->price);
           $DpackageArray["url"]   = BASEURL_HT.'deals/'.$v1->id.'.html';
           $DpackageArray['duration']=$v1->duration;
           $DpackageArray['days']=$v1->days .' Days';
           $DpackageArray['rating']=$v1->star_rating_search;
           $DpackageArray['review']=$v1->travel_with_count;
           $DpackageArray['image']="https://www.hlimg.com/images/deals/360X230/".$v1->path;
          if($v1->group_deal==1 && $v1->sponsored_status=='1')
          {
            $tag='PREMIUM';
          }else if($v->ptt_service_flag==1 ||  $v->ptt_service_flag=='2'){
              $tag='HIGHLIGHTED';
          }
           $packageArray['tag']=$tag;
  
  
           $DpackageArrayAll[]=$DpackageArray;
             }
          }
        }
  
      }
  
 
   
      

      $meta_destinations_covered=$data["response"]["docs"][0]['destinations_covered_text'];
      $title_dest_cov=  str_replace(",",", ",$meta_destinations_covered);
      $meta_destinations_covered = $meta_destinations_covered ;
	    $modified_location_name=replace_location_str(strtolower($meta_destinations_covered));
      $small_destinations_covered = $modified_location_name;

  
      $Dreturn_data['viewAlltitle']='View All '.$title_dest_cov.' Tour Packages';
      $Dreturn_data['viewAllurl']=BASEURL_HT.'deals/'.$small_destinations_covered;
      $Dreturn_data['heading']='Tour Packages For '.$title_dest_cov;
      $Dreturn_data['contents']=$DpackageArrayAll;


    // ==================Start Code For Destinations Design=====================
           $return_data['similer']=$Sreturn_data;
           $return_data['destination']=$Dreturn_data;
           //print_r($return_data);die;
           return $return_data; die;
    

    }





      function getThingstodo($data){
        $return_data=array();
        $destinations_covered_comma= "'".implode("','", array_map("addslashes" , $data["response"]["docs"][0]["destinations_covered"]))."'";

        $things_to_do_images=array();
	   
        $sql_rel_popular=dbprocess("select id,title,url,city,country_iso_code,image_path,image_site_name,displ_rating from tbl_thingstodo_upload where city in ($destinations_covered_comma) and status='1' order by rand() limit 0,8 ");

        $count_row=mysql_num_rows($sql_rel_popular);
        $ttd=0;
        if($count_row>0)
        {
            while($row=mysql_fetch_array($sql_rel_popular))
            {
                $id_popular=$row['id'];
                $title_popular=$row['title'];
                $url_popular=$row['url'];
                $city_popular=$row['city'];
                $country_iso_code_popular=$row['country_iso_code'];
                $image_path_popular=$row['image_path'];
                $photo_site_name_popular=$row['image_site_name'];
                $displ_rating = $row['displ_rating'];
                if(!empty($country_iso_code_popular))
                {
                    $sql_country = mysql_fetch_array(dbprocess("select TBL_COUNTRY from tbl_country where TBL_COUNTRY_ISO_CODE ='$country_iso_code_popular'"));
                    $country_name = strtolower($sql_country['TBL_COUNTRY']);
                    $country_name=str_replace(" ","-",$country_name);
                }
                $url_link_popular=$country_name."/".$url_popular;
                $image_path_url_popular="https://www.hlimg.com/images/things2do/300X200/".$image_path_popular;
    $base_64_image=get_base_64($image_path_url_popular);
    $image_path_url_popular=$base_64_image;

                if(!empty($city_popular))
                {$city_popular_esc=mysql_real_escape_string($city_popular);

                     $sql_plc1=dbprocess("select url,country_iso_code,ranking_score from tbl_placestosee_upload where title='". $city_popular_esc."' and country_iso_code='".$country_iso_code_popular."' and status=1  limit 1");
            if(mysql_num_rows($sql_plc1)>0)
            {
             $row_plc1=mysql_fetch_assoc($sql_plc1);
             $url_plc1=$row_plc1['url'];
                                 #$ranking_score=$row_plc1['ranking_score'];       
                                 $ranking_score=$count_row;       
            $url_title_plc1="https://www.hellotravel.com/".strtolower(str_replace(' ','-', $country_name))."/".$url_popular;



            }
                }
                $things_to_do_images[$ttd]=array('title'=>$title_popular,
                                        'image'=>$image_path_url_popular,
                                        'link'=>$url_title_plc1,
                                        'city_pop'=>$city_popular,
                                        'url'=>$url_title_plc1,
                                        'rating'=>$displ_rating,
                                        'ranking_score'=>$ranking_score


                                    );
                $ttd++;
            }
        }

      $dest_expp =  $data["response"]["docs"][0]["destinations_covered_text"];

      

      $return_data['heading']='Similar Places';
      $return_data['contents']=$things_to_do_images;
      return $return_data;die;

      }


 function getEnquiryButton($data){
  $return_data=array();
  $pns_number = $data["response"]["docs"][0]["pns_num"];
	if(!empty($pns_number) && $pns_number != ''){
                    $pns_num_plus="+".$pns_number;
                    $pns_num=substr($pns_number,2);
                    $pns_num_all = $pns_number;
		    $pns_num = "0".$pns_num;
			 $destpns = strtolower($destinations_covered_comma);
                if($destpns != ""){
                $sdestpns = dbprocess("SELECT PNS_NO FROM `tbl_dest_pns` WHERE `DESTINATIONS` in (".$destpns.") and FK_USERID = '".$data["response"]["docs"][0]['tbl_login_id']."' and STATUS = '1' limit 1 ");

                        if(mysql_num_rows($sdestpns)){
                                while($rdest = mysql_fetch_assoc($sdestpns)){
                                        $destpnsno = $rdest["PNS_NO"];
                                         $pns_num_plus="+91".$destpnsno;
                                         $pns_num="0".$destpnsno;
                                         $pns_num_all = $destpnsno;

                                }
                           }
                        }
         }else{
                $pns_num_plus = "+918048736393";
                $pns_num = "08048736393";
                $pns_num_all = "918048736393"; 
         }
  
  $return_data['pns_num']=$pns_num;
  $return_data['pns_num_all']=$pns_num_all;
  $return_data['pns_num_plus']=$pns_num_plus;
  $return_data['nid']=$data["response"]["docs"][0]['nid'];
  $return_data['login_id_deal']=$data["response"]["docs"][0]['tbl_login_id'];

  //print_r($return_data);die;

  return $return_data;die;

 }



function addRq($sValue) {
    $sValue=rawurlencode($sValue);
   return  get_base_64("https://www.hlimg.com/images/deals/360X230/".$sValue);

}

function addDes($sValue){
  $return_data=array();
  $anchor=strtolower(trim($sValue));
  $modified_location_name=replace_location_str($anchor);
   $return_data['url']=BASEURL_HT.'deals/'.$modified_location_name; 
   $return_data['name']=$sValue;
    return $return_data;
 }

  function addDes_ph($sValue){
   $return_data=array();
   $anchor=strtolower(trim($sValue));
   $modified_location_name=replace_location_str($anchor);
   $return_data['url']=BASEURL_HT.'deals/'.$modified_location_name;
   $return_data['name']=ucfirst($sValue);
   
   return $return_data;
  }


function get_base_64($path){
	if(preg_match('/\.(jpg|jpeg|gif|png|bmp)/i',$path)){
	return $path;
	}else{
		return "https://www.hlimg.com/images/holiday.png";
	}
	if($path == ""){
		return "";
	}
	$type = pathinfo($path, PATHINFO_EXTENSION);
	$data = file_get_contents($path);
	if($data == ""){
		return "";
	}
	$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
	return $base64;
}





?>







