<?php
include_once("/home/indiamart/public_html/hellotravel-agents/includes/con.php");
include_once("/home/indiamart/public_html/hellotravel-agents/includes/page_history_module.php");
include_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module.php");
class traveller_personilization{
function get_personalisation_data($args){
$a=new page_history_engine();
$vid=$args["vid"];
$uid=$args["uid"];
if(!$uid){
	$sth=dbprocess("select tbl_uid from traveler_vid_uid_map where tbl_vid='$vid'");
	$row=mysql_fetch_assoc($sth);
	$uid=$row["tbl_uid"];

}
$x=$a->create_query(array('vid'=>$vid,'uid'=>$uid,"fl"=>"id,fk_uid,fk_vid,pageurl,pageval,pageid"));
$r=$x["result"];
$story_array=array();
$deals_array=array();
$places_array=array();
$things_array=array();

foreach($r as $r1){
	if($r1->pageval == "story"){
		array_push($story_array,$r1->pageid);
	}elseif($r1->pageval == "deal"){
		array_push($deals_array,$r1->pageid);
	}elseif($r1->pageval == "things_2see_detail"){
		array_push($places_array,$r1->pageid);
	}elseif($r1->pageval == "things_2do_detail"){
		array_push($things_array,$r1->pageid);
	}
}



$all_data=array();
if(count($story_array) > 0){
	$all_data["story"]=$this->getfunction($story_array);
}

#$deals_array=array(80768,82385,50013);

if(count($deals_array) > 0){
#	$deals_array=array(80768,82385,50013);
        $all_data["deals"]=$this->get_deals_data($deals_array);
}

#$places_array=array(3963,3959,3955);
if(count($places_array) > 0){
        $all_data["places"]=$this->get_places2see($places_array);
}


#$things_array=array(21199,21197,21195);
if(count($things_array) > 0){
      $all_data["things"]=$this->get_things2do($things_array);
}

 return $all_data;
}

function get_deals_data($deals_array){
	$str=implode(',',$deals_array);
        $query="select * from tbl_deals where nid in ($str)";
	$sth=dbprocess($query);
	$destinations=array();
	$themes=array();
	$prices=array();
	$durations=array();
	$deals=array("destinations"=>"","themes"=>"","prices"=>"","duration"=>"");
	while($r=mysql_fetch_assoc($sth)){
		$dest=explode(',',$r[destinations_covered]);
		foreach($dest as $d){
		$destinations[$d]=1;     	
		}

		$theme=explode(',',$r["themes"]);
		foreach($theme as $t){
		$themes[$t]=1;     	
		}
		if($r["days"])
		$durations[$r["days"]]=1;
		if($r["price"])
		$prices[$r["price"]]=1;
	}
	$return_status=array("status"=>"1");
	if(count($destinations)>0 ){
		$return_status["destinations"]=implode(',',array_keys($destinations));
	}
	if(count($themes)>0 ){
		$return_status["themes"]=implode(',',array_keys($themes));
	}
	if(count($prices)>0 ){
		$return_status["prices"]=implode(',',array_keys($prices));
	}
	if(count($durations)>0 ){
		$return_status["duration"]=implode(',',array_keys($durations));
	}
	return $return_status;
}	


function get_places2see($places_array){
	$str=implode(',',$places_array);
	$query="select tag_theme,state,title  from tbl_placestosee_upload where id in ($str)";
	$sth=dbprocess($query);
	$themes=array();
	$destinations=array();;
	while($r=mysql_fetch_assoc($sth)){
		$tag_theme=$r["tag_theme"];
		$state=$r["state"];	
		$title=$r["title"];
		$tag_theme=explode(',',$r["tag_theme"]);
                foreach($tag_theme as $r){
                        $r=trim($r,' ');
                        if(! $r)
                        continue;
                        $themes[$r]=1;
                        
                }
		
	$destinations[$state]=1;
	$destinations[$title]=1;
			
	}
	$return_status=array("status"=>0,"destinations"=>"","themes"=>"");
	if(count($themes) > 0 || count($destinations) > 0){
		$return_status["destinations"]=implode(',',array_keys($destinations));		
		$return_status["themes"]=implode(',',array_keys($themes));
		$return_status["status"]=1;		
	}
	return $return_status;
		
}

function get_things2do($places_array){
        $str=implode(',',$places_array);
        $query="select tag_theme,state,city from tbl_thingstodo_upload where id in ($str)";
        $sth=dbprocess($query);
        $themes=array();
        $destinations=array();;
        while($r=mysql_fetch_assoc($sth)){
                $tag_theme=$r["tag_theme"];
                $state=$r["state"];     
                $title=$r["city"];
                $tag_theme=explode(',',$r["tag_theme"]);
                foreach($tag_theme as $r){
                        $r=trim($r,' ');
                        if(! $r)
                        continue;
                        $themes[$r]=1;
                        
                }
                
        $destinations[$state]=1;
        $destinations[$title]=1;
                        
        }
        $return_status=array("status"=>0,"destinations"=>"","themes"=>"");
        if(count($themes) > 0 || count($destinations) > 0){
                $return_status["destinations"]=implode(',',array_keys($destinations));          
                $return_status["themes"]=implode(',',array_keys($themes));
                $return_status["status"]=1;             
        }
	return $return_status;
                
}

function getsubfunction($story_array){
	$str=implode(',',$story_array);
	$query="select destination_sub,city_name,tag_theme,country_name from tbl_sub_story tss ,tbl_story_upload tsp where tss.fk_id=tsp.id and tss.image_ref in ($str)";
	$sth=dbprocess($query);	
	$destinations=array();;
	$themes=array();;
	while($row=mysql_fetch_assoc($sth)){
		$tag_theme=explode(',',$row["tag_theme"]);
		foreach($tag_theme as $r){
			$r=trim($r,' ');
			if(! $r)
			continue;
			$themes[$r]=1;
			
                }
		$city_name=$row["destination_sub"];
                if(empty($city_name)){
                $city_name=$row["city_name"];
                }

		if($city_name)
		$destinations[$city_name]=1;
		$country_name=$row["country_name"];
		if($country_name)
		$destinations[$country_name]=1;

	}
	$return_params=array("status"=>0,"destinations"=>"","themes"=>"");
	if(count($destinations) > 0 || count($themes) > 0){
		$return_params["destinations"]=implode(',',array_keys($destinations));		
		$return_params["themes"]=implode(',',array_keys($themes));
		$return_params["status"]=1;		
	}
	return $return_params;
}


function getfunction($story_array){
	$str=implode(',',$story_array);
	$query="select destination_sub,city_name,tag_theme,country_name from tbl_sub_story tss ,tbl_story_upload tsp where tss.fk_id=tsp.id and tsp.id in ($str)";
	$sth=dbprocess($query);	
	$destinations=array();;
	$themes=array();;
	while($row=mysql_fetch_assoc($sth)){
		$tag_theme=explode(',',$row["tag_theme"]);
		foreach($tag_theme as $r){
			$r=trim($r,' ');
			if(! $r)
			continue;
			$themes[$r]=1;
			
                }
		$city_name=$row["destination_sub"];
                if(empty($city_name)){
                $city_name=$row["city_name"];
                }

		if($city_name)
		$destinations[$city_name]=1;
		$country_name=$row["country_name"];
		if($country_name)
		$destinations[$country_name]=1;

	}
	$return_params=array("status"=>0,"destinations"=>"","themes"=>"");
	if(count($destinations) > 0 || count($themes) > 0){
		$return_params["destinations"]=implode(',',array_keys($destinations));		
		$return_params["themes"]=implode(',',array_keys($themes));
		$return_params["status"]=1;		
	}
	return $return_params;
}
/* function get_related_package_data(){
	 $t=new traveller_personilization();
	 $per=$t->get_personalisation_data(array("vid"=>"450764","uid"=>1598111));
	 $r=new package_relevence_module(array("type"=>"and"));
	 print_r($per["story"]["destinations"]);
	 print_r($r->get_packages($per["story"]));
 }*/
}
#$t=new traveller_personilization();
#$per=$t->get_personalisation_data(array("vid"=>"450764","uid"=>1598111));
#$r=new package_relevence_module(array("type"=>"and"));
#print_r($per["story"]["destinations"]);
#print_r($r->get_packages($per["story"]));
?>
