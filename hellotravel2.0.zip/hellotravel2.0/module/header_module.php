<?php
    require_once ("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
    require_once ("/home/indiamart/public_html/hellotravel-agents/includes/mask_lib.php");
    include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoip.inc");
    include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoipcity.inc");
    include_once("/home/indiamart/public_html/hellotravel/serveform/inc/geoipregionvars.php");

    $json_data = file_get_contents("/home/indiamart/public_html/hellotravel/includes/topjson/headerData.txt");
    $json_str=file_get_contents("/home/indiamart/public_html/hlimg-com/images/jsnew/data.txt");
   

    $json_data=json_decode($json_data);

    $top50country = $json_data->top50country;
    $top100pts    = $json_data->top100pts;

    $object_header_link=json_decode($json_str);


/****************************Menu Tour Packages***************************/

    function  getPackageDgn(){
        $main_data=array();$return_data=array();
      
        global $top50country; global $top100pts;
        $top30pts = array_slice($top100pts,0,30);
        shuffle($top30pts);
        $top30pts = array_slice($top30pts,0,16);
        usort($top30pts,"count_lead_compare");
     
        $top30country = array_slice($top50country,0,30);
        shuffle($top30country);
        $top30country = array_slice($top30country,0,16);
        usort($top30country,"count_lead_compare");
     
        
        $main_data["top30pts"] = $top30pts;
        
        $main_data["top30country"] = $top30country;

        if(isset($main_data["top30pts"]) && isset($main_data["top30country"])){
            $return_data["top30country"] = array_slice($main_data["top30country"],0,16);
            $return_data["top30pts"] = array_slice($main_data["top30pts"],0,16);

            return $return_data;

        }
    }


/****************************Menu Destinaton ***************************/

    function getDestinatonDgn(){
         $main_data=array();$return_data=array();

        $destStatic = json_decode('[{"title": "Shimla","url": "shimla"},{"title": "Manali","url": "manali"},{"title": "Darjeeling","url": "darjeeling"},{"title": "Munnar","url": "munnar"},{"title": "Goa","url": "goa"},{"title": "Ooty","url": "ooty"},{"title": "Kerala","url": "kerala"},{"title": "Kufri","url": "kufri"},{"title": "Thekkady","url": "thekkady"}]');

        $destcntryStatic = json_decode('[{"title": "Singapore","url": "singapore"},{"title": "Malaysia","url": "malaysia"},{"title": "Thailand","url": "thailand"},{"title": "Nepal","url": "nepal"},{"title": "Sri Lanka","url": "sri-lanka"},{"title": "Bhutan","url": "bhutan"},{"title": "Maldives","url": "maldives"}]'); 

        global $top50country; global $top100pts;
             
        $main_data["destStaticpts"] =$destStatic;
        $main_data["destDynamicpts"]=$top100pts; 
        $main_data["destcntryStatic"] = $destcntryStatic;
        $main_data["destcntryDynamic"] = $top50country;
        if(isset($main_data["destStaticpts"]) && isset($main_data["destDynamicpts"]) && isset($main_data["destcntryDynamic"])){
        $main_data["destDynamicpts"] = array_slice($main_data["destDynamicpts"],0,16);
        $main_data["destcntryDynamic"] = array_slice($main_data["destcntryDynamic"],0,16);
        $destPts = array_merge($main_data["destStaticpts"],$main_data["destDynamicpts"]);
        $destCntry =array_merge($main_data["destcntryStatic"],$main_data["destcntryDynamic"]);     
        
        $return_data['destPts']=$destPts;
        $return_data['destCntry']=$destCntry;

        return $return_data;

        }

    }

/****************************Menu Trip Ideas ***************************/
    function getTripIdeasDgn(){
        global $json_data;$main_data=array();
        
        $main_data["tripppl"] = $json_data->tripIDEAS->ppl;
        $main_data["triplatest"] = $json_data->tripIDEAS->latest;
        
        if(isset($main_data["triplatest"]) && isset($main_data["tripppl"])){
            $main_data["triplatest"] = array_slice($main_data["triplatest"],0,8);
            $main_data["tripppl"]    = array_slice($main_data["tripppl"],0,8);
            $tripIdeasData = array_merge($main_data["tripppl"],$main_data["triplatest"]);

            return $tripIdeasData;
           
        }

    }


/****************************Menu Sightseeing ***************************/
    function getSightseeingDgn(){
        $main_data=array();$returndata=array();
    
        $weekend_static=json_decode('[{"title":"Delhi","url1":"delhi","url":"stories/weekend-getaways-around-delhi"},{"title":"Bangalore","url1":"bangalore","url":"stories/weekend-getaways-around-bangalore"},{"url":"stories/weekend-getaways-around-chennai","title":"Chennai","url1":"chennai"},{"title":"Hyderabad","url1":"hyderabad","url":"stories/weekend-getaways-around-hyderabad"},{"title":"Kolkata","url1":"kolkata","url":"stories/weekend-getaways-around-kolkata"},{"title":"Mumbai","url1":"mumbai","url":"stories/weekend-getaways-around-mumbai"},{"title":"Pune","url1":"pune","url":"stories/10-best-places-to-visit-near-pune"},{"title":"Ahmedabad","url1":"ahmedabad","url":"stories/best-weekend-getaways-places-to-visit-near-ahmedabad"},{"title":"Baroda","url":"stories/best-weekend-getaways-places-to-visit-near-baroda"},{"title":"Asansol","url1":"asansol","url":"stories/best-weekend-getaways-places-to-visit-near-asansol"},{"title":"Assam","url1":"assam","url":"stories/best-weekend-getaways-places-to-visit-near-assam"},{"title":"Aurangabad","url1":"aurangabad","url":"stories/best-weekend-getaways-places-to-visit-near-aurangabad"},{"title":"Bagdogra","url1":"bagdogra","url":"stories/best-weekend-getaways-places-to-visit-near-bagdogra"},{"title":"Bareilly","url1":"bareilly","url":"stories/best-weekend-getaways-places-to-visit-near-bareilly"},{"title":"Agra","url1":"agra","url":"stories/best-weekend-getaways-places-to-visit-in-agra"},{"title":"Ajmer","url1":"ajmer","url":"stories/best-weekend-getaways-places-to-visit-near-ajmer"},{"title":"Aligarh","url1":"Aligarh","url":"stories/best-weekend-getaways-places-to-visit-near-aligarh"},{"title":"Allahabad","url1":"allahabad","url":"stories/best-weekend-getaways-places-to-visit-near-allahabad"},{"title":"Alwar","url1":"alwar","url":"stories/best-weekend-getaways-places-to-visit-near-alwar"},{"title":"Amritsar","url1":"amritsar","url":"stories/best-weekend-getaways-places-to-visit-near-amritsar"},{"title":"Amravati","url1":"amravati","url":"stories/best-weekend-getaways-places-to-visit-near-amravati"},{"title":"Ambala","url1":"ambala","url":"stories/best-weekend-getaways-places-to-visit-near-ambala"},{"title":"Anand","url1":"anand","url":"stories/best-weekend-getaways-places-to-visit-near-anand"}]');
        $destStatic = json_decode('[{"title": "Shimla","url": "shimla"},{"title": "Manali","url": "manali"},{"title": "Darjeeling","url": "darjeeling"},{"title": "Munnar","url": "munnar"},{"title": "Goa","url": "goa"},{"title": "Ooty","url": "ooty"},{"title": "Kerala","url": "kerala"},{"title": "Kufri","url": "kufri"},{"title": "Thekkady","url": "thekkady"}]');
        global $top100pts;
        $main_data["destStaticpts"] =$destStatic;
        $main_data["destDynamicpts"]=$top100pts; 
        if(isset($main_data["destStaticpts"]) && isset($main_data["destDynamicpts"])){

            $main_data["destDynamicpts"] = array_slice($main_data["destDynamicpts"],0,16);
            $destPts = array_merge($main_data["destStaticpts"],$main_data["destDynamicpts"]);

            $returndata['destPts']=$destPts;
            $returndata['weekend_static']=$weekend_static;

            return $returndata;

        }
    

    }

/****************************Menu Themes ***************************/
    function getThemeDgn(){
        global $json_data; $main_data=array(); $returndata=array();
      
        $main_data["themes"] = $json_data->theme;
        
        $returndata['honeymoon'] = array_slice($main_data["themes"]->Honeymoon,0,8);
        $returndata['beach']   = array_slice($main_data["themes"]->beach,0,8);
        $returndata['hill_station'] = array_slice($main_data["themes"]->hill_stations,0,8);
        $returndata['Adventure']    = array_slice($main_data["themes"]->Adventure,0,8);
        return $returndata;
    }

/****************************Search Auto Suggation ***************************/
    function getAutoSuggationDgn(){
        $main_data=array(); $returndata=array();

        global $top50country; global $top100pts;
      
        $top10pts = array_slice($top100pts,0,30);
        shuffle($top10pts);
        $top10pts = array_slice($top10pts,0,10);
        usort($top10pts,"count_lead_compare");

        $top5country = array_slice($top50country,0,10);
        shuffle($top10pts);
        $top5country = array_slice($top5country,0,5);
        usort($top5country,"count_lead_compare");
        $autosuggData = array();
        $counter = 1;
        foreach($top10pts as $key=>$val){
            $autosuggDatadup =array();
            if($counter <= 4){
                $autosuggDatadup["tranding"] = "1";
            }
            $autosuggDatadup["title"] = $val->title;
            $autosuggDatadup["url"]  = $val->url;
            $autosuggData[] = $autosuggDatadup;
            $counter++;
        }
        $counter = 1;
        foreach($top5country as $key=>$val){
            $autosuggDatadup =array();
            if($counter <= 2){
                $autosuggDatadup["tranding"] = "1";
            }
            $autosuggDatadup["title"] = $val->title;
            $autosuggDatadup["url"]  = $val->url;
            $autosuggDatadup["type"] = "dest";
            $autosuggData[] = $autosuggDatadup;
            $counter++;
        }

        $main_data["auto_searchSuggest"] = $autosuggData;
        $autosuggestdesign = "";
        if(isset($main_data["auto_searchSuggest"]) && !empty($main_data["auto_searchSuggest"])){
            $autosuggestdesign = $main_data["auto_searchSuggest"];
            return $autosuggestdesign;
        }
    }
 
/****************************Menu Schema Nav Tag ***************************/

    function getSchemaNavTagDgn(){
        
        global $object_header_link; $main_data=array(); $returndata=array();

        $month = date("M");

        /***********Start  domestic leads*************/
        $domestic_pack = array();
        $n = 0;
        $home_link_domestic=$object_header_link->home_link->domestic_trending->MONTH->$month;
        $shuffleKeys = array_keys($home_link_domestic);
        shuffle($shuffleKeys);
        $counter=0;
        $nav_schema_arrays = array();
        foreach($shuffleKeys as $v){
        if($counter > 5){
        break;
        }
        $record=$home_link_domestic[$v];

        $country_name_places=$record->TBL_COUNTRY;
        $title_name_dom = $record->title;
        $url_plc=$record->url;
        $title_name_dom = $record->title;
        $url_title_plc="https://www.hellotravel.com/".strtolower(str_replace(' ','-', $country_name_places))."/".$url_plc;
        $domestic_pack[$counter] = array('title_domestic' => $title_name_dom, 'link_domestic' =>
        $url_title_plc);
        $counter++;
        
        $nav_schema_arrays[] = array(
                        "@context"=>"https://schema.org",
                        "@type"=> "SiteNavigationElement",
                        "name"=> "$title_name_dom",
                        "url"=>"$url_title_plc"
                    );
       
        }

       
      
        /***********End domestic leads*************/


        /***********Start international leads********/

        $international_pack = array();
        $m = 0;
        $home_link_international=$object_header_link->home_link->international_trending->MONTH->$month;
        $shuffleKeys = array_keys($home_link_international);
        shuffle($shuffleKeys);
        $counter=0;
        foreach($shuffleKeys as $v){
        if($counter > 5){
            break;
        }
        $record=$home_link_international[$v];
        $title_name_inter = $record->title;
        $trend_link_inter = str_replace("http://","https://",strtolower($record->link));
        $international_pack[$counter] = array('title_inter' => $title_name_inter, 'link_inter' =>
        $trend_link_inter);
        $counter++;
        
        $nav_schema_arrays[] = array(
        "@context"=>"https://schema.org",
        "@type"=> "SiteNavigationElement",
        "name"=> "$title_name_inter",
        "url"=>"$trend_link_inter"
        );
        
        }

       
        /***********End international leads*************/

        $top_trip_idea_header = array();
        $header_stories_count = 0;
        $home_link_stories=$object_header_link->home_link->stories;
        $shuffleKeys = array_keys($home_link_stories);
        shuffle($shuffleKeys);
        $counter=0;
        foreach($shuffleKeys as $v){
        if($v == 'MONTH'){
        continue;
        }
        if($counter > 5){
            break;
        }

        $record=$home_link_stories[$v];
        $title_name_inter = $record->title;
        $trend_link_inter = str_replace("http://","https://",strtolower($record->link));
        $top_trip_idea_header[$counter] = array('title' => $title_name_inter, 'link' =>
        $trend_link_inter);
        $counter++;
        
        $nav_schema_arrays[] = array(
        "@context"=>"https://schema.org",
        "@type"=> "SiteNavigationElement",
        "name"=> "$title_name_inter",
        "url"=>"$trend_link_inter"
        );
        
        }

      

        $events_header = array();
        $home_link_event=$object_header_link->event_data;
        $shuffleKeys = array_keys($home_link_event);
        shuffle($shuffleKeys);
        $counter=0;


        foreach($shuffleKeys as $v){
        if($counter > 5){
            break;
        }
        $record=$home_link_event[$v];
        $title_name_inter = $record->title;
        $events_header[$counter]['title'] = $record->title;
        $events_header[$counter]['link'] = $record->link;
        $counter++;
        //DT
        $nav_schema_arrays[] = array(
        "@context"=>"https://schema.org",
        "@type"=> "SiteNavigationElement",
        "name"=> "$title_name_inter",
        "url"=>"https://www.hellotravel.com/$record->link"
        );
      
        }

        $theme_array_menu = array(
            "Adventure Destinations" => "adventure",
            "Beach Destinations" => "beach",
            "Honeymoon Destinations" => "honeymoon",
            "Luxury Destinations" => "luxury",
            "Wildlife Destinations" => "wildlife",
            "Offbeat Destinations" => "offbeat",
            "Romantic Destinations" => "romantic",
            "Friends Destinations" => "friends",
            "Family Destinations" => "family",
            "Spa & Wellness Destinations" => "spa_and_wellness",
            "Religious Destinations" => "religious",
            "Cruise Destinations" => "cruise",
            "Weekend Getaways" => "weekend_getaways",
            "Hill Stations" => "hill_stations",
            "Historical Destinations" => "historical_places",
            "Culture & Heritage Destinations" => "culture_and_heritage",
            "Nature Destinations" => "nature",
            "Water Activities" => "water_activities");

        $shuffleKeys = array_keys($theme_array_menu);
        shuffle($shuffleKeys);
        $newArray = array();
        $footerthemes = array();
        $j = 1;
        foreach ($shuffleKeys as $key) {
        if ($j <= 6) {
        $newArray[$key] = $theme_array_menu[$key];
        } else if($j <= 12 ) {
        $footerthemes[$key] = $theme_array_menu[$key];
        }
        $j++;
        }



        $honeymoon_array = array(array("name"=>"Top 20 Honeymoon Places In India in 2018","url"=>"https://www.hellotravel.com/stories/honeymoon-destinations-in-india"),
        array("name"=>"8 Best Honeymoon Places Outside India","url"=>"https://www.hellotravel.com/stories/8-best-honeymoon-places-outside-india"),
        array("name"=>"9 Top Winter Honeymoon Destinations in India","url"=>"https://www.hellotravel.com/stories/9-top-winter-honeymoon-destinations-in-india"),
        array("name"=>"Best honeymoon locations in India for a budget of 40k to 50k","url"=>"https://www.hellotravel.com/stories/best-honeymoon-locations-in-india-for-a-budget-of-40k-to-50k"),
        array("name"=>"5 Best Honeymoon Destinations in India for 5 days","url"=>"https://www.hellotravel.com/stories/5-best-honeymoon-destinations-in-india-for-5-days"),
        array("name"=>"9 Top Winter Honeymoon Destinations outside India","url"=>"https://www.hellotravel.com/stories/9-top-winter-honeymoon-destinations-outside-india"),
        array("name"=>"Best International honeymoon locations for a budget of 65k to 75k","url"=>"https://www.hellotravel.com/stories/best-international-honeymoon-locations-for-a-budget-of-65k-to-75k")
        );
        foreach($honeymoon_array as $honeymoon_arrays){
            $name = '';
            $url = '';
            $name = $honeymoon_arrays['name'];
            $url = $honeymoon_arrays['url'];
            $nav_schema_arrays[] = array(
                "@context"=>"https://schema.org",
                "@type"=> "SiteNavigationElement",
                "name"=> "$name",
                "url"=>"$url"
            );
        }


        $Weekend_getaways_array = array(array("name"=>"Places to visit near Hyderabad","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-hyderabad"),
                            array("name"=>"Places to visit near Mumbai","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-mumbai"),
                            array("name"=>"Places to visit near Delhi","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-delhi"),
                            array("name"=>"Places to visit near Kolkata","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-kolkata"),
                            array("name"=>"Places to visit near Bangalore","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-bangalore"),
                            array("name"=>"Places to visit near Chennai","url"=>"https://www.hellotravel.com/stories/weekend-getaways-around-chennai")
        );
        foreach($Weekend_getaways_array as $honeymoon_arrays){
        $name = '';
        $url = '';
        $name = $honeymoon_arrays['name'];
        $url = $honeymoon_arrays['url'];
        $nav_schema_arrays[] = array(
            "@context"=>"https://schema.org",
            "@type"=> "SiteNavigationElement",
            "name"=> "$name",
            "url"=>"$url"
        );
        }

        return $nav_schema_arrays;

    }


    function getBreadSchemaTagDgn(){
    global $page; 
    $main_data['page']=$page;$dest_url='';$ptc_url='';
    $bread_schema_arrays["@context"]= "https://schema.org";$city_name='';
    $bread_schema_arrays["@type"]= "BreadcrumbList";
    $bread_schema_arrays["itemListElement"][]=array("@type"=>"ListItem","position"=>1,"name"=>"Home","item"=>"https://www.hellotravel.com");
    if($dest_url>0)
    {
        $itemListElement=array("@type"=>"ListItem","position"=>2,"name"=>"$country_name","item"=>"https://www.hellotravel.com$country_urlVal");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if($ptc_url>0)
    {
        $itemListElement= array("@type"=>"ListItem","position"=>3,"name"=>"$state_name","item"=>"https://www.hellotravel.com$state_urlVal");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if(!empty($city_name))
    {
        $itemListElement=array("@type"=>"ListItem","position"=>4,"name"=>"$city_name","item"=>"https://www.hellotravel.com$city_urlVal");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if($main_data['page'] == 'things_2do_detail')
    {
    $itemListElement=array("@type"=>"ListItem","position"=>5,"name"=>"$main_title","item"=>"https://www.hellotravel.com$country_urlVal/$final_url_value");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if($main_data['page'] == 'deal')
    {
        $actual_link = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $itemListElement=array("@type"=>"ListItem","position"=>3,"name"=>"Tour packages","item"=>"$actual_link");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if($page == 'story')
    {
        $itemListElement= array("@type"=>"ListItem","position"=>2,"name"=>"Trip Ideas","item"=>"https://www.hellotravel.com/stories");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
        $itemListElement= array("@type"=>"ListItem","position"=>3,
        "name"=>"$main_title","item"=>"https://www.hellotravel.com/stories/$final_url_value");
        $bread_schema_arrays["itemListElement"][]=$itemListElement;
    }
    if($page == 'listpage')
    {
            $bread_schema_arrays["itemListElement"]=array(array("@type"=>"ListItem","position"=>1,"name"=>"Home","item"=>"https://www.hellotravel.com"),array("@type"=>"ListItem","position"=>2,"name"=>"deals","item"=>"https://www.hellotravel.com/deals"));

    }


     return $bread_schema_arrays;
    
  }

/**********************************OrgSchemaTag**********************************/
    function getOrgSchemaTagDgn(){
        $organization_array = array(
        '@context'=>'https://schema.org',
        '@type'=> 'Organization',
        'url'=>'https://www.hellotravel.com',
        'logo'=>'https://www.hellotravel.com/sites/all/themes/newswire/images/logo-header.png',
        'telephone'=>'8048735999',
        'email'=>'helpdesk@hellotravel.com',
        'sameAs'=>array(
        'https://www.facebook.com/hellotravel',
        'https://twitter.com/hellotravel',
        'https://www.instagram.com/hellotravelofficial'),
        'address'=>array('@type'=>'PostalAddress','name'=>'E-75, 2nd Floor, Sector 63, Noida - 201301, Uttar Pradesh')
        );

       return $organization_array;

    }


/****************************Menu Footer Section ***************************/

    function getFooterSectionDgn(){
        global $json_data;$main_data=array();$return_data=array();
        $top100pts     = $json_data->top100pts;

        $top30pts = array_slice($top100pts,0,30);
        shuffle($top30pts);
        $top30pts = array_slice($top30pts,0,16);
        usort($top30pts,"count_lead_compare");

        $l30pts = $json_data->l30pts; 
        shuffle($l30pts); 
        $l30pts = array_slice($l30pts,0,30); 

        $l30story = $json_data->l30story; 
        shuffle($l30story); 
        $l30story = array_slice($l30story,0,30);

        $l30ttd = $json_data->l30ttd; 
        shuffle($l30ttd); 
        $l30ttd = array_slice($l30ttd,0,30);


        $main_data["top30pts"] = $top30pts;
        $main_data["l30pts"] = $l30pts;
        $main_data["l30story"] = $l30story;
        $main_data["l30ttd"] = $l30ttd;

	return $main_data;
         
    }




    
    function getUserData(){
    global $page;
    $GDPR = ['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','UK'];

    $main_data=array();$return_data=array();
    $main_data['page']=$page;
    $main_data['traveller_name']='';$main_data['client_email']='';$main_data['client_login']='';$main_data['country_code_no']='';
    $main_data['ip_city_name']=''; $main_data['ip_country_name']='';$main['lead_city']='';$main_data['contact_num']='';
    $main_data['last_lead']='';$main_data['uid_client']='';$main_data['travelerpic']='';$main_data['privacy']='';
    $main_data['select_agent']='';$main_data['loggedvalue']='';$main_data['cookie_value']='';$main_data['cookie_pass']='';
    $main_data['entry_cookieVal']='';$main_data['crypt']='';$main_data['referal_url']='';$main_data['ReferreRvariable']='';
    $main_data['check_cookie']='';$main_data['crypt']='';

    

    $ip=getIPfromXForwarded();
    $ip_details=get_countryCity($ip);
    $ip_country_iso=$ip_details['country_code'];
    $country_iso=$ip_country_iso;
    $country_code=mysql_fetch_array(dbprocess("select TBL_COUNTRY_CODE from tbl_country where TBL_COUNTRY_ISO_CODE='".$ip_country_iso."'"));
    $country_code_no="+".$country_code['TBL_COUNTRY_CODE'];
    $ip_country_name=$ip_details['country'];
    $ip_city_name=$ip_details['city'];

    $main_data['country_code_no']=$country_code_no;
    $main_data['ip_country_name']=$ip_country_name;
    $main_data['ip_city_name']=$ip_city_name;

    $lead_city='';

    

    $privacy = 0;
    if(in_array($country_iso , $GDPR)){
        $privacy = 1;
    }
    $main_data['privacy']=$privacy;


    if(!isset($_SESSION['TIMESTAMP']) || empty($_SESSION['TIMESTAMP']))
    {
        $_SESSION['TIMESTAMP'] = time();
    }

    $_SESSION['EXITTIME'] = time()+30;

    $referal_url = $_SERVER["HTTP_REFERER"];
    $ReferreRvariable;
    $check_cookie='';

    if(!empty($referal_url))
    {
            if(!strstr($referal_url,"hellotravel.com"))
            {
                    $_SESSION["REREFERGOOGLE"] = "true";
            }
    }

    $ReferreRvariable = $_SESSION["REREFERGOOGLE"];
    $main_data['ReferreRvariable']=$ReferreRvariable;

    if(!isset($_COOKIE["countrycookie"]) ){
        $cookie_name = 'countrycookie';
        $countryval =  "91";
        setcookie($cookie_name, $countryval, time() + (23 * 24 * 60 * 60), "/",'hellotravel.com');
    }


  //***********************Start Check if exist LoginValue*************************

    if (isset($_COOKIE['loginvalue']) || isset($_SESSION['loginvalue'])) {
    $cookie_value = !empty($_COOKIE['loginvalue'])  || $_COOKIE['loginvalue'] != '' ? $_COOKIE['loginvalue'] : $_SESSION['loginvalue'] ;
    $cookie_pass = !empty($_COOKIE['userpass'])  || $_COOKIE['userpass'] != '' ? $_COOKIE['userpass'] : $_SESSION['userpass'] ;
    $ccountry_code = isset($_COOKIE["countrycookie"]) && !empty($_COOKIE["countrycookie"]) ? $_COOKIE["countrycookie"] : "91";
    $email_value = trim(base64_decode($cookie_value));
    $loggedvalue = mask_email_phone_from_description_ne($email_value);

    $main_data['cookie_value']=$cookie_value;
    $main_data['cookie_pass']=$cookie_pass;
    $main_data['loggedvalue']=$loggedvalue;

  
    if(check_mail($email_value)){
    //  echo "this is email is of login client".$dcrypt_value;
    if(validateEmail($email_value))
    {
        
    $sql_client = "select * from tbl_traveller_logins where EMAIL_ID='" . $email_value ."'";
    $rs_details = dbprocess($sql_client);
    while ($row_client = mysql_fetch_array($rs_details)) {
        $client_name = $row_client['TRAVELLER_NAME'];
        $uid_client = $row_client['USER_ID'];
        $traveller_name = ucwords(strtolower($client_name)) == "" ?  "User" : ucwords(strtolower($client_name));
        $travelerpic =  $row_client["PROFILE_PIC"];
        $lead_id = $row_client['FK_LEAD_ID'];
        $client_email = $row_client['EMAIL_ID'];
        $client_login = $row_client['LOGIN_ID'];

        $main_data['uid_client']=$uid_client;
        $main_data['traveller_name']=$traveller_name;
        $main_data['travelerpic']=$travelerpic;
        $main_data['client_email']=$client_email;
        $main_data['client_login']=$client_login;

        $lead_city = $row_client["login_city"];

        

        if($lead_id == 0)
        {
            $sql_leads = dbprocess("select FK_TBL_LEAD_ID, FK_TBL_LEAD_PHONE , TBL_LEAD_CITY FROM tbl_leads l, tbl_leads_data ld where l.TBL_LEAD_ID = ld.FK_TBL_LEAD_ID and FK_TBL_LEAD_EMAIL = '".$email_value."' order by FK_TBL_LEAD_ID limit 1");
            if(mysql_num_rows($sql_leads))
            {
                $rows_leads = mysql_fetch_array($sql_leads);
                $lead_id = $rows_leads['FK_TBL_LEAD_ID'];
                $contact_num = $rows_leads['FK_TBL_LEAD_PHONE'];
        if(empty($lead_city))
                $lead_city = $rows_leads['TBL_LEAD_CITY'];
                $rs_update = dbprocess("update tbl_traveller_logins set FK_LEAD_ID='".$lead_id."', STATUS='1' where EMAIL_ID='".$email_value."' ");
                $check_cookie = 'yes';
            }
        }else{

            $leadsdata = dbprocess("SELECT  FK_TBL_LEAD_PHONE , TBL_LEAD_CITY FROM tbl_leads l, tbl_leads_data ld where l.TBL_LEAD_ID = ld.FK_TBL_LEAD_ID and TBL_LEAD_ID = '".$lead_id."' ");
            $q = mysql_fetch_assoc($leadsdata);
            $contact_num = $q['FK_TBL_LEAD_PHONE'];
        if(empty($lead_city))
            $lead_city = $q['TBL_LEAD_CITY'];
        }
        if($ip_country_name != "" && strtolower($ip_country_name) == strtolower("india"))
        {
            $contact_num = substr($contact_num , -10,10);
        }
        else
        {
            $person_contact_array = explode("-",$contact_num);
            $contact_num = $person_contact_array[1];
        }
        $_SESSION["USER_NAME"] = $client_name;
        $_SESSION["EMAIL"] = $client_email;
        $_SESSION["LEADID"] = $lead_id;
        $_SESSION["CONTACT_NO"] = $contact_num;
        $_SESSION["LEAD_CITY"] = $lead_city;
    if($lead_id)
    {
        $str1 = substr($lead_id, -3);
        $str2 = substr($lead_id, 0, strlen($lead_id) - 3);
        $email_char = substr($client_email, strpos($client_email, "@") - 1, 1);
        $new_lead_id = $str1 . $email_char . $str2;
        $crypt = base64_encode($new_lead_id);
        $main_data['crypt']=$crypt;

    }
    $check_cookie = 'yes';
    }

    $sql_check = "SELECT TBL_LEADS_EMAIL_VERIFIED FROM  tbl_leads,tbl_leads_data WHERE TBL_LEAD_ID=FK_TBL_LEAD_ID and FK_TBL_LEAD_EMAIL ='" .
        $email_value . "' order by TBL_LEAD_ID desc limit 1 ";
    $rs_check = dbprocess($sql_check);
    while ($row_check = mysql_fetch_row($rs_check)) {
        $email_check = $row_check['TBL_LEADS_EMAIL_VERIFIED'];

        if ($email_check == 2 || $email_check == 5 || $email_check == 9) {
            setcookie("loginvalue", "", time() - 3600 * 24 * 2, "/", 'hellotravel.com');
            //unset($_COOKIE['loginvalue']);
            $sql_update = "update tbl_traveller_logins set STATUS=0 where EMAIL_ID='".$email_value."'";
            $udate_table = dbprocess($sql_update);
            $traveller_name = '';
            $check_cookie ='';
        }
    }
    }
    }else if(ctype_digit($email_value)){
        $sql_client = "select * from tbl_traveller_logins where LOGIN_ID ='" . $email_value ."' and MCOUNTRY_CODE = '+".$ccountry_code."'  ";
        $rs_details = dbprocess($sql_client);
        while ($row_client = mysql_fetch_array($rs_details)) {
            $client_name = $row_client['TRAVELLER_NAME'];
        $uid_client = $row_client['USER_ID'];
        $traveller_name = ucwords(strtolower($client_name)) == "" ?  "User" : ucwords(strtolower($client_name));
            $lead_id = $row_client['FK_LEAD_ID'];
            $client_email = $row_client['EMAIL_ID'];
            $client_login = $row_client['LOGIN_ID'];
            $travelerpic =  $row_client["PROFILE_PIC"];
            $lead_city = $row_client["login_city"];
            $main_data['uid_client']=$uid_client;
            $main_data['traveller_name']=$traveller_name;
            $main_data['travelerpic']=$travelerpic;
            $main_data['client_email']=$client_email;
            $main_data['client_login']=$client_login;
 
            if($lead_id == 0 && $lead_id == "NULL" && $client_email != '' && $client_email != null && $client_email != "NULL" && $client_email != "null")
            {
                $sql_leads = dbprocess("select FK_TBL_LEAD_ID, FK_TBL_LEAD_PHONE , TBL_LEAD_CITY FROM tbl_leads l, tbl_leads_data ld where l.TBL_LEAD_ID = ld.FK_TBL_LEAD_ID and FK_TBL_LEAD_EMAIL = '".$client_email."' order by FK_TBL_LEAD_ID limit 1");
                if(mysql_num_rows($sql_leads))
                {
                    $rows_leads = mysql_fetch_array($sql_leads);
                        $lead_id = $rows_leads['FK_TBL_LEAD_ID'];
                    $contact_num = $rows_leads['FK_TBL_LEAD_PHONE'];
            if(empty($lead_city))
                    $lead_city = $rows_leads['TBL_LEAD_CITY'];
                    $rs_update = dbprocess("update tbl_traveller_logins set FK_LEAD_ID='".$lead_id."', STATUS='1' where EMAIL_ID='".$client_email."' ");
                    $check_cookie = 'yes';
                }
            }else if($lead_id != 0 && $lead_id != "NULL"){

                    $leadsdata = dbprocess("SELECT  FK_TBL_LEAD_PHONE , TBL_LEAD_CITY FROM tbl_leads l, tbl_leads_data ld where l.TBL_LEAD_ID = ld.FK_TBL_LEAD_ID and TBL_LEAD_ID = '".$lead_id."' ");
                    $q = mysql_fetch_assoc($leadsdata);
                    $contact_num = $q['FK_TBL_LEAD_PHONE'];
            if(empty($lead_city))
                    $lead_city = $q['TBL_LEAD_CITY'];
            }
            if($ip_country_name != "" && strtolower($ip_country_name) == strtolower("india"))
            {
                    $contact_num = substr($contact_num , -10,10);
            }
            else
            {
                    $person_contact_array = explode("-",$contact_num);
                    $contact_num = $person_contact_array[1];
            }

            $_SESSION["USER_NAME"] = $client_name ;
            $_SESSION["EMAIL"] = $client_email;
            $_SESSION["LEADID"] = $lead_id;
            $_SESSION["CONTACT_NO"] = $contact_num;
            $_SESSION["LEAD_CITY"] = $lead_city;
            if($lead_id != 0 && $lead_id != "NULL")
            {
                $str1 = substr($lead_id, -3);
                $str2 = substr($lead_id, 0, strlen($lead_id) - 3);
                $email_char = substr($client_email, strpos($client_email, "@") - 1, 1);
                $new_lead_id = $str1 . $email_char . $str2;
                $crypt = base64_encode($new_lead_id);
                $main_data['crypt']=$crypt;

            }
            $check_cookie = 'yes';
            }

        if($contact_num == '' || $contact_num == "NULL"){
            $contact_num = $email_value;
        }
        if($client_email != '' && $client_email != null && $client_email != "NULL" && $client_email != "null"){
            $sql_check = "SELECT TBL_LEADS_EMAIL_VERIFIED FROM  tbl_leads,tbl_leads_data WHERE TBL_LEAD_ID=FK_TBL_LEAD_ID and FK_TBL_LEAD_EMAIL ='" .
            $email_value . "' order by TBL_LEAD_ID desc limit 1 ";
            $rs_check = dbprocess($sql_check);
            while ($row_check = mysql_fetch_row($rs_check)) {
                $email_check = $row_check['TBL_LEADS_EMAIL_VERIFIED'];

                if ($email_check == 2 || $email_check == 5 || $email_check == 9) {
                    setcookie("loginvalue", "", time() - 3600 * 24 * 2, "/", 'hellotravel.com');
                    $sql_update = "update tbl_traveller_logins set STATUS=0 where EMAIL_ID='".$email_value."'";
                    $udate_table = dbprocess($sql_update);
                    $traveller_name = '';
                    $check_cookie ='';
                    }
            }
        }


    }
     
    
        $main_data['lead_city']=$lead_city;
        $main_data['contact_num']=$contact_num; 
        $_SESSION["contact_num"] = $contact_num; 
        
    }

    //***********************Close Check if exist LoginValue*************************


    //***********************Start if exist uid_client *************************
    $last_lead='';
    if($uid_client != '')
    {
    $last_lead_val;
    $last_lead_val=getLastValidLead($uid_client);
    if($last_lead_val != '')
    {
        $chk_connection=dbprocess("select fk_parentuserid from tbl_lead_purchase where fk_leadid='".$last_lead_val."'");
        $chk_travel_date=dbprocess("select TBL_LEAD_TRAVEL_DATE from tbl_leads where TBL_LEAD_ID='".$last_lead_val."'");
        if(mysql_num_rows($chk_travel_date)>0)
        {
            $row_travel_date=mysql_fetch_assoc($chk_travel_date);
        $travel_date_chk=$row_travel_date['TBL_LEAD_TRAVEL_DATE'];
        }

        $sql_test=dbprocess("select TUID from tbl_testimonial where lead_id='".$last_lead_val."'");
        if(mysql_num_rows($sql_test)==0 && mysql_num_rows($chk_connection)>0 && $travel_date_chk<date('Y-m-d'))
        {
        $last_lead=base64_encode($last_lead_val);
    $counter=1;
    $sql_chk_lead=dbprocess("select TBL_LEAD_ID,FK_STATUSID from tbl_leads where TUID='".$uid_client."' and TBL_LEAD_ID>='".$last_lead_val."' order by TBL_LEAD_ID asc limit 15");
    if(mysql_num_rows($sql_chk_lead)>0)
    {
    while($row_chk_lead=mysql_fetch_assoc($sql_chk_lead))
    {
    $leadid_val=$row_chk_lead['TBL_LEAD_ID'];

    $status_val=$row_chk_lead['FK_STATUSID'];
    if($status_val == 3 && $counter>1)
    {
    break;
    }

    //echo "select TBL_LOGIN_COMPANYNAME,TBL_LOGIN_UID,TBL_LOGIN_ID from tbl_logins,tbl_lead_purchase where tbl_logins.TBL_LOGIN_ID= tbl_lead_purchase.FK_PARENTUSERID and tbl_lead_purchase.FK_LEADID='$leadid_val'";
        $res1=dbprocess("select distinct TBL_LOGIN_COMPANYNAME,TBL_LOGIN_UID,TBL_LOGIN_ID from tbl_logins,tbl_lead_purchase where tbl_logins.TBL_LOGIN_ID= tbl_lead_purchase.FK_PARENTUSERID and tbl_lead_purchase.FK_LEADID='$leadid_val'");


        if($res1)
        {



        $comp_id = "";
            $agentcount = 0;
            while($rs =  mysql_fetch_object($res1))
            {


            $select_agent .= '<option value="'.$rs->TBL_LOGIN_ID.'"  >'.$rs->TBL_LOGIN_COMPANYNAME.'</option>';


            }

        }
        $counter++;
    }
    }
        }
    }

    }

    $main_data['last_lead']=$last_lead;
  //***********************Close if exist uid_client *************************



//***********************Start if exist check_cookie *************************
    $entry_cookieVal='';
    if (empty($check_cookie))
    {
    $entry_cookieName = 'entry-page';
    if (isset($_COOKIE['entry-page']) && !empty($_COOKIE['entry-page']))
    {
    $entry_cookieVal = $_COOKIE['entry-page'];
    if($entry_cookieVal == 'page1')
    {
        $entry_cookieVal = 'page2';
        setcookie($entry_cookieName, $entry_cookieVal, time() + (2 * 60 * 60), "/",'hellotravel.com');
    }
    elseif($entry_cookieVal == 'page2')
    {
        $entry_cookieVal = 'page3';
        setcookie($entry_cookieName, $entry_cookieVal, time() + (2 * 60 * 60), "/",'hellotravel.com');
    }
    elseif($entry_cookieVal == 'page3')
    {
        $entry_cookieVal = 'page4';
        setcookie($entry_cookieName, $entry_cookieVal, time() + (2 * 60 * 60), "/",'hellotravel.com');
    }
    elseif($entry_cookieVal == 'page4')
    {
        $entry_cookieVal = 'page5';
        setcookie($entry_cookieName, $entry_cookieVal, time() + (2 * 60 * 60), "/",'hellotravel.com');
    }
    }
    else{
        $entry_cookieVal = 'page1';
    setcookie($entry_cookieName, $entry_cookieVal, time() + (2 * 60 * 60), "/",'hellotravel.com');
    }

    }

    $main_data['entry_cookieVal']=$entry_cookieVal;
   //***********************Close if exist check_cookie *************************
   
     return $main_data;

    }


    function count_lead_compare($a,$b){
    if ($a->count_lead == $b->lead_gen) {
                    return 0;
            }
            return ($b->count_lead < $a->count_lead) ? -1 : 1;
    }


    function check_mail($email){
        
        if (preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $email))
            {
                return true;
    
        } else {
                return false;
            }
    }

    function get_countryCity($ipAddr)
    {
        $gi = geoip_open("/var/lib/GeoIP/GeoIP.dat",GEOIP_STANDARD);
        $ipDetail['country_code']=geoip_country_code_by_addr($gi, $ipAddr);
        $ipDetail['country']=geoip_country_name_by_addr($gi, $ipAddr);
        geoip_close($gi);

        $gi = geoip_open("/var/lib/GeoIP/GeoLiteCity.dat",GEOIP_STANDARD);
        $record = geoip_record_by_addr($gi,$ipAddr);
        if(!empty($record->city))
            $ipDetail['city']=$record->city;
        else
            $ipDetail['city']='NA';
        return $ipDetail;

    }


    

?>
