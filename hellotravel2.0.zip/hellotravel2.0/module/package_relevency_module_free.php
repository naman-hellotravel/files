<?php
$inc_path="/home3/indiamart/public_html/hellotravel-agents";
require_once($inc_path.'/includes/con.php');
require_once("/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_my.php");
class package_relevence_module_free Extends package_relevence_module_my{
	function __construct($args){
		$this->args=$args;
		$this->destinations=array();
		
	}
      function get_packages($args_pkg){
	    $duration_arr=array();
	    if($args_pkg["duration"]){
		    $duration_arr=$args_pkg["duration"];
		   // print_r($duration_arr);
	    }
	    $destinations="";
	    if($args_pkg["destinations"]){
	    	$destinations=$args_pkg["destinations"];
	    }
	    $themes="";
           if($args_pkg["themes"]){
                $themes=$args_pkg["themes"];
           }
	   $prices="";	
 	   if($args_pkg["prices"]){
	       $prices_arr=$args_pkg["prices"];
	      // print_r($prices_arr);
           }
	   $budget="";
	   if($args_pkg["budget"]){
                $budget=$args_pkg["budget"];
           }
		$fromdestination="";
	   if($args_pkg["from_location"]){
                $fromdestination=$args_pkg["from_location"];
           }
	   $themes_str="";
	   if($args_pkg["themes"]){
                $themes_str=$args_pkg["themes"];
           }
           $star_rating=array();
           if($args_pkg["stars"]){
                $star_rating=$args_pkg["stars"];
           }
           $agents_rating=array();
           if($args_pkg["agents"]){
		$agents_rating=$args_pkg["agents"];
		//print_r($agents_rating);
		//exit;
           }
           /*$booking_arr=array();
           if($args_pkg["booking"]){
		$booking_arr=$args_pkg["booking"];
		//print_r($agents_rating);
		//exit;
           }*/
           $budgetpernight_arr=array();
           if($args_pkg["budgetpernight"]){
		$budgetpernight_arr=$args_pkg["budgetpernight"];
		//print_r($budgetpernight_rating);
		//exit;
           }
           $sorting='';
           if($args_pkg["sort"]){
		$sorting=$args_pkg["sort"];
		$sorting_cond=$this->find_sort_cond($sorting);
	   }else{
		$sorting_cond='priority asc,score desc';   
	   }


	  $destinations_theme=array();
	   if(isset($args_pkg["destinations_theme"])){
		   $destinations_theme=$args_pkg["destinations_theme"];
	   }
        $user_id=0;
	
	   if($args_pkg["user_id"]){
                $user_id=$args_pkg["user_id"];
           }

	   $and_query='';
	    $args=$this->args;
	    if($args["type"] == 'and'){
		$and_query_arr=array();
	   	if(!empty($prices_arr) && count($prices_arr) > 0){
                       $price_query_arr=array();
                       foreach($prices_arr as $price){	
			      // print_r($price);
	   		$price_query=$this->create_price_query($price); 
			array_push($price_query_arr,$price_query);
                        }
			array_push($and_query_arr,'('.implode(' OR ',$price_query_arr).')');
	   	}
	   	if(!empty($budgetpernight_arr) && count($budgetpernight_arr) > 0){
                       $budgetpernight_arr_query=array();
                       foreach($budgetpernight_arr as $budgetpernight){	
			      // print_r($price);
	   		 $budgetpernight_query=$this->create_budgetpernight_query($budgetpernight); 
			array_push($budgetpernight_arr_query,$budgetpernight_query);
                        }
			array_push($and_query_arr,'('.implode(' OR ',$budgetpernight_arr_query).')');
	   	}
		$destinationquery=$this->create_destination_query($destinations);
		if(!empty($destinationquery)){
		     array_push($and_query_arr,$destinationquery);
		}

		array_push($and_query_arr,'(group_deal:0 AND package_type:0)');
	//	print_r($and_query_arr);exit;
                  $duration_query_arr=array();
                if(!empty($duration_arr)){
                foreach($duration_arr as $duration){
	        if(preg_match('/-/',$duration)){	
	   	    $durationquery=$this->create_duration_query($duration);
		     array_push($duration_query_arr,$durationquery);
                }
                }
                 array_push($and_query_arr,'('.implode(' OR ',$duration_query_arr).')');
                }

                if(!empty($star_rating)){
                          $star_query_arr=array();
                        foreach($star_rating as $star){
                  	$star_query='(budget:"'.$star.'")'; 
		     array_push($star_query_arr,$star_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$star_query_arr).')');
                }

                if(!empty($agents_rating)){
                          $agent_query_arr=array();
                        foreach($agents_rating as $agent){
				//print_r($agent);
		    $agent_query=$this->create_agent_query($agent); 
			array_push($agent_query_arr,$agent_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$agent_query_arr).')');
                }
                /*if(!empty($booking_arr)){
                          $booking_query_arr=array();
                       $booking_query_arr[]='booking_status:1';
                       array_push($and_query_arr,'('.implode(' OR ',$agent_query_arr).')');
                }*/
		if(!empty($user_id)){
			array_push($and_query_arr,'(tbl_login_id:'.$user_id.')');	
		}
		if(!empty($destinations_theme) && count($destinations_theme) > 0){
			$theme_query_arr=array();
                        foreach($destinations_theme as $theme){
                  	$theme_query='(destinations_theme:"'.$theme.'")'; 
		     	array_push($theme_query_arr,$theme_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$theme_query_arr).')');
		}

		if(count($and_query_arr) > 0){
			$and_query=implode(' AND ' , $and_query_arr);
		}

                 
	    }else{
				$and_query_arr=array();
				array_push($and_query_arr,'(group_deal:0 AND package_type:0)');
				if(count($and_query_arr) > 0){
					$and_query=implode(' AND ' , $and_query_arr);
				}
			}

	   $destquery=$this->create_destination_boost_query($destinations);
	   $this->destinations=$this->get_array($destinations);
	   $themesquery=$this->create_themes_query($themes_str);
	   $agent_city_query=$this->create_agentcity_query($destinations);
	   $agent_city_query_with_from=$this->create_agent_travelcity_query($fromdestination);
	   $boost_query=$this->create_boosting_query($destinations);
	   $query_array=array();  
	   $dest_themes_array=array(); 
	   if(!empty($destquery)){
		array_push($query_array,$destquery);
		array_push($dest_themes_array,$destquery);
	   }
	  foreach($duration_arr as $duration){
	     	$duration_boost_query=$this->create_duration_boost_query($duration);
	    	if(! empty( $duration_boost_query)){
			array_push($query_array,'('.$duration_boost_query.')');
	    	}  
          }
	    if(! empty($themesquery) ){
                array_push($query_array,'('.$themesquery.')');
		array_push($dest_themes_array,'('.$themesquery.')');
            }
  	    if(! empty($agent_city_query) ){
                array_push($query_array,'('.$agent_city_query.')');
            }
	    
	     if(! empty($agent_city_query_with_from) ){
                array_push($query_array,'('.$agent_city_query_with_from.')');
            }
            if(isset($args["nodest"]) && !empty($args["nodest"]) && $args["nodest"]==1){

	    	array_push($query_array," (group_deal:0 AND package_type:0) ");
            }else{
	    	array_push($query_array," (group_deal:0 OR package_type:0) ");
            }
	  	$solr_query=implode(' OR ',$query_array); 

	    if(!empty($durationquery)){
	   		 
	    }
		if(!empty($and_query)){
			if(!empty($solr_query)){
				$solr_query='('.$solr_query.') AND ('.$and_query.')';
			}else{
				$solr_query=$and_query;
			}
		}else{
			if(count($dest_themes_array) > 0){
				$dest_themes_query= implode(' OR ',$dest_themes_array);
				if(!empty($dest_themes_query)){
				$solr_query='('.$solr_query.') AND ('.$dest_themes_query.')';
				}

			}
                }
	
		if(isset($args_pkg["booking"]) && $args_pkg["booking"] == 1){
			$solr_query= $solr_query." AND (booking_status:1) ";
		}
	
		if(!empty($solr_query)){
		$argssclass=$this->args;
		if(isset($argssclass["exclude_no_photo"]) && $argssclass["exclude_no_photo"] == '1'){
		if(isset($argssclass["exclude_login"]) && !empty($argssclass["exclude_login"])){
			$tbl_login_id=$argssclass["exclude_login"];
			$solr_query="($solr_query) NOT (fk_roleid:\"24\" OR  tbl_login_id:(".$tbl_login_id." OR 630) OR photo_status:\"0\")";
		}else{
			$solr_query="($solr_query) NOT (fk_roleid:\"24\" OR tbl_login_id:(630) OR photo_status:\"0\")";
		}
		}else{
		if(isset($argssclass["exclude_login"]) && !empty($argssclass["exclude_login"])){
                        $tbl_login_id=$argssclass["exclude_login"];
                        $solr_query="($solr_query) NOT (fk_roleid:\"24\" OR tbl_login_id:(".$tbl_login_id." OR 630))";
                }else{
                        $solr_query="($solr_query) NOT (fk_roleid:\"24\" OR tbl_login_id:(630))";
                }
		}
	  if(isset($args["premium_pkg"]) && $args["premium_pkg"] ==1){
                  if(!empty($destinations)){
                 	$premiumquery=$this->create_destination_primium_query($destinations);
			$solr_query="((".$solr_query.") AND $premiumquery  AND (path:*))";
		  }else{
			$solr_query="((".$solr_query.") AND (priority:0) AND (path:*))";
		  }
	  }
	  
		$query="{!".$boost_query."} ($solr_query)";	
		}else{
		if(isset($args["premium_pkg"]) && $args["premium_pkg"] ==1){
			$query="{!".$boost_query."} ((*:*) AND (priority:0) AND (path:*))";
		}else{
			$query="{!".$boost_query."} (*:*)";
		}	
		}
		if(isset($args_pkg["days_group"]) && !empty($args_pkg["days_group"])){

			return $this->execute_query_grops_days($query,$args_pkg["days_group"]);	
			
		}else{
          //  echo $query;
			return $this->execute_query($query,$sorting_cond);
		}
      }


}
#$r=new package_relevence_module(array("type"=>"and"));
#print_r($r->get_packages(array("destinations"=>"corbett,ramnagar")));

#$r->get_packages(array("destinations"=>"delhi,rempur ","duration"=>array("3-8",'10-115'),"themes"=>"honymoon,hill station","from_location"=>"bombay,test","stars"=>array("Economy (0-2 Star Hotels)","Economy (0-2 Star Hotels)"),"prices"=>array(array("min_price"=>1000,"max_price"=>100000),array("min_price"=>1000,"max_price"=>100000))));
#	$r->get_packages(array("destinations"=>"delhi,rempur ","themes"=>"honymoon,hill station","from_location"=>"bombay,test","stars"=>array("Economy (0-2 Star Hotels)","Economy (0-2 Star Hotels)"),"prices"=>array(array("min_price"=>1000,"max_price"=>100000),array("min_price"=>1000,"max_price"=>100000))));
?>


