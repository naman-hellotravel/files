<?php
$inc_path="/home3/indiamart/public_html/hellotravel-agents";
require_once($inc_path.'/includes/con.php');
require_once('/home/indiamart/public_html/hellotravel/hellotravel2.0/module/package_relevency_module_my.php');
class package_relevence_module_branding Extends package_relevence_module_my{
	function __construct($args){
		$this->args=$args;
		$this->destinations=array();
		
	}
      function get_packages($args_pkg){
	    $duration_arr=array();
	    if($args_pkg["duration"]){
		    $duration_arr=$args_pkg["duration"];
		   // print_r($duration_arr);
	    }
	    $destinations="";
	    if($args_pkg["destinations"]){
	    	$destinations=$args_pkg["destinations"];
	    }
	    $themes="";
           if($args_pkg["themes"]){
                $themes=$args_pkg["themes"];
           }
	   $prices="";	
 	   if($args_pkg["prices"]){
	       $prices_arr=$args_pkg["prices"];
	      // print_r($prices_arr);
           }
	   $budget="";
	   if($args_pkg["budget"]){
                $budget=$args_pkg["budget"];
           }
		$fromdestination="";
	   if($args_pkg["from_location"]){
                $fromdestination=$args_pkg["from_location"];
           }
	   $themes_str="";
	   if($args_pkg["themes"]){
                $themes_str=$args_pkg["themes"];
           }
           $star_rating=array();
           if($args_pkg["stars"]){
                $star_rating=$args_pkg["stars"];
           }
           $agents_rating=array();
           if($args_pkg["agents"]){
		$agents_rating=$args_pkg["agents"];
		//print_r($agents_rating);
		//exit;
           }
           /*$booking_arr=array();
           if($args_pkg["booking"]){
		$booking_arr=$args_pkg["booking"];
		//print_r($agents_rating);
		//exit;
           }*/
           $budgetpernight_arr=array();
           if($args_pkg["budgetpernight"]){
		$budgetpernight_arr=$args_pkg["budgetpernight"];
		//print_r($budgetpernight_rating);
		//exit;
           }
           $sorting='';
           if($args_pkg["sort"]){
		$sorting=$args_pkg["sort"];
		$sorting_cond=$this->find_sort_cond($sorting);
	   }else{
		$sorting_cond='priority asc,score desc';   
	   }


	  $destinations_theme=array();
	   if(isset($args_pkg["destinations_theme"])){
		   $destinations_theme=$args_pkg["destinations_theme"];
	   }
        $user_id=0;
	
	   if($args_pkg["user_id"]){
                $user_id=$args_pkg["user_id"];
           }

	   $and_query='';
	    $args=$this->args;
	    if($args["type"] == 'and'){
		$and_query_arr=array();
	   	if(!empty($prices_arr) && count($prices_arr) > 0){
                       $price_query_arr=array();
                       foreach($prices_arr as $price){	
			      // print_r($price);
	   		$price_query=$this->create_price_query($price); 
			array_push($price_query_arr,$price_query);
                        }
			array_push($and_query_arr,'('.implode(' OR ',$price_query_arr).')');
	   	}
	   	if(!empty($budgetpernight_arr) && count($budgetpernight_arr) > 0){
                       $budgetpernight_arr_query=array();
                       foreach($budgetpernight_arr as $budgetpernight){	
			      // print_r($price);
	   		 $budgetpernight_query=$this->create_budgetpernight_query($budgetpernight); 
			array_push($budgetpernight_arr_query,$budgetpernight_query);
                        }
			array_push($and_query_arr,'('.implode(' OR ',$budgetpernight_arr_query).')');
	   	}
		$destinationquery=$this->create_destination_query($destinations);
		if(!empty($destinationquery)){
		     array_push($and_query_arr,$destinationquery);
		}
                  $duration_query_arr=array();
                if(!empty($duration_arr)){
                foreach($duration_arr as $duration){
	        if(preg_match('/-/',$duration)){	
	   	    $durationquery=$this->create_duration_query($duration);
		     array_push($duration_query_arr,$durationquery);
                }
                }
                 array_push($and_query_arr,'('.implode(' OR ',$duration_query_arr).')');
                }

                if(!empty($star_rating)){
                          $star_query_arr=array();
                        foreach($star_rating as $star){
                  	$star_query='(budget:"'.$star.'")'; 
		     array_push($star_query_arr,$star_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$star_query_arr).')');
                }

                if(!empty($agents_rating)){
                          $agent_query_arr=array();
                        foreach($agents_rating as $agent){
				//print_r($agent);
		    $agent_query=$this->create_agent_query($agent); 
			array_push($agent_query_arr,$agent_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$agent_query_arr).')');
                }
                /*if(!empty($booking_arr)){
                          $booking_query_arr=array();
                       $booking_query_arr[]='booking_status:1';
                       array_push($and_query_arr,'('.implode(' OR ',$agent_query_arr).')');
                }*/
		if(!empty($user_id)){
			array_push($and_query_arr,'(tbl_login_id:'.$user_id.')');	
		}
		if(!empty($destinations_theme) && count($destinations_theme) > 0){
			$theme_query_arr=array();
                        foreach($destinations_theme as $theme){
                  	$theme_query='(destinations_theme:"'.$theme.'")'; 
		     	array_push($theme_query_arr,$theme_query);
                        }
                       array_push($and_query_arr,'('.implode(' OR ',$theme_query_arr).')');
		}

		if(count($and_query_arr) > 0){
			$and_query=implode(' AND ' , $and_query_arr);
		}

                 
	    }

	   $destquery=$this->create_destination_boost_query($destinations);
	   $this->destinations=$this->get_array($destinations);
	   $themesquery=$this->create_themes_query($themes_str);
	   $agent_city_query=$this->create_agentcity_query($destinations);
	   $agent_city_query_with_from=$this->create_agent_travelcity_query($fromdestination);
	   $boost_query=$this->create_boosting_query($destinations);
	   $query_array=array();  
	   $dest_themes_array=array(); 
	   if(!empty($destquery)){
		array_push($query_array,$destquery);
		array_push($dest_themes_array,$destquery);
	   }
	  foreach($duration_arr as $duration){
	     	$duration_boost_query=$this->create_duration_boost_query($duration);
	    	if(! empty( $duration_boost_query)){
			array_push($query_array,'('.$duration_boost_query.')');
	    	}  
          }
	    if(! empty($themesquery) ){
                array_push($query_array,'('.$themesquery.')');
		array_push($dest_themes_array,'('.$themesquery.')');
            }
  	    if(! empty($agent_city_query) ){
                array_push($query_array,'('.$agent_city_query.')');
            }
	    
	     if(! empty($agent_city_query_with_from) ){
                array_push($query_array,'('.$agent_city_query_with_from.')');
            }
            $nopackage_query_clause= "";
           
	    if(isset($args["premium_pkg"]) && $args["premium_pkg"] ==1){
                $nopackage_query_clause=" package_type:* OR ";
            }
 
	   if(isset($args["nodest"]) && !empty($args["nodest"]) && $args["nodest"]==1){

	    array_push($query_array," (group_deal:1^100 OR group_deal:2^100 OR package_type:3^6 OR  package_type:6^6 OR  package_type:2^6 package_type:1^6 OR package_type:4^6 OR package_weight:0  OR package_type:7^10 OR package_type:39^20 OR package_type:38^20 OR package_type:23^20 OR package_type:24^20 OR package_type:40^20 OR package_type:37^20) ");
            }else{
	    array_push($query_array," (group_deal:1^100 OR group_deal:2^100 OR package_type:3^6 OR package_type:6^6 OR package_type:2^4 package_type:1^2 OR package_type:4^2 OR package_weight:0 OR package_type:7^10 OR package_type:7^10 OR package_type:39^20 OR package_type:38^20 OR package_type:23^20 OR package_type:24^20 OR package_type:40^20 OR package_type:37^20) ");
            }
	  	$solr_query=implode(' OR ',$query_array); 

	    if(!empty($durationquery)){
	   		 
	    }
		if(!empty($and_query)){
			if(!empty($solr_query)){
				$solr_query='('.$solr_query.') AND ('.$and_query.')';
			}else{
				$solr_query=$and_query;
			}
		}else{
			if(count($dest_themes_array) > 0){
				$dest_themes_query= implode(' OR ',$dest_themes_array);
				if(!empty($dest_themes_query)){
				$solr_query='('.$solr_query.') AND ('.$dest_themes_query.')';
				}

			}
                }
	
		if(isset($args_pkg["booking"]) && $args_pkg["booking"] == 1){
			$solr_query= $solr_query." AND (booking_status:1) ";
		}
	
		if(!empty($solr_query)){
		$argssclass=$this->args;
		if(isset($argssclass["exclude_no_photo"]) && $argssclass["exclude_no_photo"] == '1'){
		if(isset($argssclass["exclude_login"]) && !empty($argssclass["exclude_login"])){
			$tbl_login_id=$argssclass["exclude_login"];
			$solr_query="($solr_query) NOT (fk_roleid:\"24\" OR tbl_login_id:(".$tbl_login_id." OR 630) OR photo_status:\"0\")";
		}else{
			$solr_query="($solr_query) NOT (fk_roleid:\"24\" OR  tbl_login_id:(630) OR photo_status:\"0\")";
		}
		}else{
		if(isset($argssclass["exclude_login"]) && !empty($argssclass["exclude_login"])){
                        $tbl_login_id=$argssclass["exclude_login"];
                        $solr_query="($solr_query) NOT (fk_roleid:\"24\" OR  tbl_login_id:(".$tbl_login_id." OR 630))";
                }else{
                        $solr_query="($solr_query) NOT (fk_roleid:\"24\" OR  tbl_login_id:(630))";
                }
		}
	  if(isset($args["premium_pkg"]) && $args["premium_pkg"] ==1){
               /*   if(!empty($destinations)){
                 	$premiumquery=$this->create_destination_primium_query($destinations);
			$solr_query="((".$solr_query.") AND $premiumquery  AND (path:*))";
		  }else{*/
			$solr_query="((".$solr_query.") AND (priority:0 OR priority:1) AND (path:*))";
		/*  }*/
	  }
		if($args["ptt_ads"] == '1'){
			$sorting_cond='ptt_changed desc';
			$solr_query="((".$solr_query.") AND (ptt_service_flag:1) AND (path:*))"; 
		}
	  
		$query="{!".$boost_query."} ($solr_query)";	
		}else{
		if(isset($args["premium_pkg"]) && $args["premium_pkg"] ==1){
			$query="{!".$boost_query."} ((*:*) AND (priority:0 OR priority:1) AND (path:*))";
		}elseif($args["ptt_ads"] == '1'){
			$sorting_cond='ptt_changed desc';
			$solr_query="((".$solr_query.") AND (ptt_service_flag:1) AND (path:*))"; 
		}else{
			$query="{!".$boost_query."} (*:*)";
		}	
		}
        if($args["premium_pkg"] && $args["premium_pkg"] ==1){
			return $this->execute_query_premium_groups($query,'group_deal');
		}elseif(isset($args_pkg["days_group"]) && !empty($args_pkg["days_group"])){

			return $this->execute_query_grops_days($query,$args_pkg["days_group"]);	
			
		}else{
			return $this->execute_query($query,$sorting_cond);
		}
      }

   
  
    
   


   	
   

function create_destination_primium_query($destinations){
        $destinations_arr=$this->get_array($destinations);
  $args=$this->args;
        if(count($destinations_arr) > 0){
                $dest_query=implode('"^8 OR "',$destinations_arr);
                $first_dest_query=implode('"^100000 OR "',$destinations_arr);
                $dest_query='"'.$dest_query.'"^8';
                $first_dest_query='"'.$first_dest_query.'"^100000';
           if(isset($args["nodest"]) && !empty($args["nodest"]) && $args["nodest"]==1){
      $dest_query='(first_pkg_city:('.$first_dest_query.') AND (priority:0))';
    }else{
      $dest_query='(first_pkg_city:('.$first_dest_query.') AND (priority:0))';
    }

        }
        return $dest_query;
   }


function create_destination_boost_query($destinations){
	$destinations_arr=$this->get_array($destinations);
  $args=$this->args;
	if(count($destinations_arr) > 0){
		$dest_query=implode('"^8 OR "',$destinations_arr);
		$first_dest_query=implode('"^100000 OR "',$destinations_arr);
		$dest_query='"'.$dest_query.'"^8';
		$first_dest_query='"'.$first_dest_query.'"^100000';
	   if(isset($args["nodest"]) && !empty($args["nodest"]) && $args["nodest"]==1){
      $dest_query='(destinations_covered:('.$dest_query.' OR *) OR (first_pkg_city:('.$first_dest_query.') AND (priority:(0 OR 1))))';
    }else{
      $dest_query='(destinations_covered:('.$dest_query.') OR (first_pkg_city:('.$first_dest_query.') AND (priority:(0 OR 1))))';
    }
	
	}
	return $dest_query;		
   }

 

	function find_similar_places($state,$theme){
			//echo $state;
		   // print_r($theme);
			if(count($theme)){
				 //   echo "ss";
					$theme_data=ucwords($theme[0]);
					 $theme_cl='tag_theme_array:"'.$theme_data.'" AND type:pts';
			 }
			$state=strtolower($state);
	$query = $theme_cl.' AND (state:"'.$state.'"^100 OR state:*) NOT title:"'.$state.'"';
			 $postdata = http_build_query(
															array(
																			'q' => $query,
																			'wt' => 'json',
																			'rows'=>10,
																			'start'=>0,
																			'fl'=>"title"
																	 )
															);
	
	  $opts = array('http' =>
															array(
																			'method'  => 'POST',
																			'header'  => 'Content-type: application/x-www-form-urlencoded',
																			'content' => $postdata
																	 )
													 );
								
							$url="http://ht-search-new:8983/solr/hellotravel_ttd_pts/select";
							$context  = stream_context_create($opts);
							// print_r($opts);
							// exit;
							try{
			
							$result = file_get_contents($url, false, $context);
			 
							$travel_guide=$this->parse_results($result,"",$query);
											return  $travel_guide;
							}catch(Exception $e){
											return array();
											return array("count"=>"0","result"=>[],"ErrorMassage"=>$e,"status"=>'0',"query"=>$query);
							}
											return  $travel_guide;
	}
	   function parse_results($result,$leadid,$query,$ptt_ads = '0'){
                $object=json_decode($result);
                $header=$object->responseHeader;
                $results=$object->response;
                $count=$results->numFound;
		if($count == 0){
		#$myfile = fopen("/home/indiamart/statlogs/dealsresponse/dealsdata_".date("Ymd").".txt", "a");
     #           fwrite($myfile, "$result\n");
      #          fclose($myfile);
		}
                $arra=$results->docs;
                 $checkpurchase=0;
                $thisargs=$this->args;

                $result_array=array();
                foreach($arra as $a){

                   array_push($result_array,$a);
                }
                return array("count"=>$count,"result"=>$result_array,"ErrorMassage"=>"Execute Query","status"=>'1');
        }


        function parse_group_results($result){
                $object=json_decode($result);
                $header=$object->responseHeader;
                $results=$object->response;
                $count=$results->numFound;
                $arra=$results->docs;
                $groups=$object->grouped->destinations_covered->groups;
                $result_array=array();
                foreach($groups as $a){
                        $type=$a->groupValue;
                        $arr=$a->doclist->docs;
			if(!isset($result_array[$type])){
                        $result_array[$type]=array();
			}
                        foreach($arr as $row){
				
			        $destcovered_arr=$row->destinations_covered;
				$group_types=$this->check_destination($destcovered_arr);
                                array_push($result_array[$type],$row);
				foreach($group_types as $dtype){
				if(!isset($result_array[$dtype])){
                        	$result_array[$dtype]=array();
                                array_push($result_array[$dtype],$row);
				}else{
                                array_push($result_array[$dtype],$row);
				}
				}
                        }
                          
                        //$agent_id=$a->id;
                        //$result_array["$agent_id"]=1;
                        //array_push($result_array,$a->id);
                }

                return array("count"=>count($result_array),"result"=>$result_array,"ErrorMassage"=>"Execute Query","status"=>'1');
        }

    function check_destination($destination_covered){
	$destination_search=$this->destinations;
	$grouped_array=array();
	if(count($destination_search) > 0){
		foreach($destination_search as $dest){
			if(in_array($dest,$destination_covered)){
				array_push($grouped_array,$dest);	
			}
		}
	}
	return $grouped_array;
    }

    function getBrowserVid(){
	    if(isset($_COOKIE["vid"]) && !empty($_COOKIE["vid"])){
		    return base64_decode($_COOKIE["vid"]);
	    }
            return "";
    }

    function getUserUidFromVid($vid){
          $query="select tbl_uid from traveler_vid_uid_map where tbl_vid='$vid'";
          $sth= dbprocess($query);
           if(mysql_num_rows($sth) >0){
                  $row=mysql_fetch_assoc($sth);
		  $uid=$row["tbl_uid"];
           }
	 return $uid;
    }
    
    function get_vid_data(){
             $vid=$this->getBrowserVid();
	     $uid=$this->getUserUidFromVid($vid);
             return(array("vid"=>$vid,'uid'=>$uid));
    }
    
    function getVidFromIp(){
	 $ip=sf_getIPfromXForwarded();
          return $this->getVidByIp($ip);
    }

     function getVidByIp($ip){
          $query="select tbl_vid from traveler_vid_uid_map where tbl_network_ip='$ip'";
          $sth= dbprocess($query);
          $vid=array();
           if(mysql_num_rows($sth) >0){
                 while( $row=mysql_fetch_assoc($sth)){
		  array_push($vid,$row["tbl_vid"]);
                 }
           }
	 return implode(',',$vid);
    }
    function find_sort_cond($val){
	    $value='';
	
	    if($val=="popularity"){
		    $value="score desc,priority asc";
	    }
	    elseif($val=="pricelh"){
		    $value="price asc";
	    }
	    elseif($val=="pricehl"){
		    $value="price desc";
	    }
	    elseif($val=="durationlh"){
		    $value="days asc";
	    }
	    elseif($val=="durationhl"){
		    $value="days desc";
	    }
	    return $value;
    }
    function show_inbetween_filters($type,$dest_search,$themes){
	$theme_filter='';
       if(count($theme)>0)
      $themes=array_unique($themes);
	$theme_array=array('hill stations','beach','honeymoon','religious','adventure','wildlife');
	if($type==1){
	    if($dest_search == ''){
		$heading='<div class="f17 c3 mt1"><i class="fa fa-search c_blue"></i> Popular searches</div>';
		$theme_filter='<a href="javascript:void(0);"  onclick="rating_val(\'honeymoon\',this.className);" class="sear_scrol_d new_ch bbb_n"> Honeymoon </a>
		<a href="javascript:void(0);"  onclick="rating_val(\'hill-stations\',this.className);" class="sear_scrol_d new_ch bbb_n"> Hill Stations </a>
		<a href="javascript:void(0);"  onclick="rating_val(\'beach\',this.className);" class="sear_scrol_d new_ch bbb_n"> Beach </a>
		<a href="javascript:void(0);"  onclick="rating_val(\'religious\',this.className);" class="sear_scrol_d new_ch bbb_n"> Religious </a>';
   
	    }elseif(count($themes)>0){
		foreach($themes as $them_val){
		if(in_array($them_val,$theme_array)){
		 $theme_filter .= "<a href=\"javascript:void(0);\"  onclick=\"rating_val('".str_replace(' ','',strtolower($them_val))."',this.className);\" class=\"sear_scrol_d new_ch\">".ucfirst($them_val)."</a>";
		}
		}
	    }
	    if($dest_search != ''){
	       $heading='<div class="f17 c3 mt1"><i class="fa fa-search c_blue"></i> Popular search for '.ucfirst($dest_search).' tour packages </div>';
	    }
	  $html='<tr> <td class="deal_lis">
	   
	   '.$heading.'
	   <div class="sear_scrol mb1 mt1">
	       <a href="javascript:void(0);"  onclick="rating_val(\'duration1\',this.className);" class="sear_scrol_d new_ch bbb_n"> 1-3 Days </a> 
	       <a href="javascript:void(0);"  onclick="rating_val(\'duration2\',this.className);" class="sear_scrol_d new_ch bbb_n"> 4-7 Days </a> 
	       '.$theme_filter.'
	       <a href="javascript:void(0);"  onclick="rating_val(\'budget3\',this.className);" class="sear_scrol_d new_ch bbb_n"> 4 Star Hotel</a>
	       <a href="javascript:void(0);"  onclick="rating_val(\'budget3\',this.className);" class="sear_scrol_d new_ch bbb_n"> 5 Star Hotel</a>
	       <a href="javascript:void(0);"   onclick="rating_val(\'budgetpernight1\',this.className);" class="sear_scrol_d new_ch bbb_n"> 2K Per Night </a>
	       <a href="javascript:void(0);"  onclick="rating_val(\'budgetpernight2\',this.className);" class="sear_scrol_d new_ch bbb_n"> 3K Per Night </a>
	       <a href="javascript:void(0);"  onclick="rating_val(\'budgetpernight3\',this.className);" class="sear_scrol_d new_ch bbb_n"> 5K Per Night </a>
	       <a href="javascript:void(0);"  onclick="rating_val(\'price1\',this.className);" class="sear_scrol_d new_ch bbb_n"> Under 10K</a>
	       <a href="javascript:void(0);"  onclick="rating_val(\'price2\',this.className);" class="sear_scrol_d new_ch bbb_n"> 10K-25K</a>
	     <div class="cl"></div>
	   </div>
	   </td></tr>'; 
	}
   return $html; 
    }
function show_reqform($place,$offset){
	$var='sharereq'.$offset;
	$var_vl='required'.$offset;
	$data_arr["0"]='<div class="mt1" style="background-color:#0431a6; padding:20px 5px 30px; ">
	<div class="f25 c1 lh28" align="center">Did not find what you were looking for?</div>
	<div align="center" class="mt3" ><a id="reqrequired'.$offset.'" href="javascript:void(0);" onclick="check_post_destination_none(\''.$place.'\',\''.$place.'\',\'\',\'\',\''.$var_vl.'\');" class="nd_hinp_btn1">Tell us your requirement</a> <a href="javascript:void(0)" class="c3" id="sentrequired'.$offset.'" style="text-decoration:none;display:none;">Sent</a></div>
<div class="cl"></div>
</div>';
	$data_arr["1"]='<div class="mt1" style="padding:20px 5px 30px; box-shadow:0 0 5px 2px #ddd">
	<div class="f25 c6 lh28" align="center">Let <span class="c3 b">hellotravel</span> find perfect agent for you</div>
	
	<div class="mt3">
		<div class="fl w33a agnStep" align="center"><span>1</span><div class="f17 c3 mt1">Tell us requirement</div></div>
		<div class="fl w33a agnStep" align="center"><span>2</span><div class="f17 c3 mt1">Get agent details</div></div>
		<div class="fl w33a agnStep" align="center"><span>3</span><div class="f17 c3 mt1">Book your Packages</div></div>
	<div class="cl"></div>
	</div>
	
	
	
	<div align="center"  class="mt3"><a id="reqsharereq'.$offset.'" href="javascript:void(0);" onclick="check_post_destination_none(\''.$place.'\',\''.$place.'\',\'\',\'\',\''.$var.'\');" class="nd_hinp_btn1">Share requirement</a><a href="javascript:void(0)" class="c3" id="sentsharereq'.$offset.'" style="text-decoration:none;display:none;">Sent</a></div>
<div class="cl"></div>
</div>';
	$k = array_rand($data_arr);
	 $v = $data_arr[$k];
	 return $v;
}
function getTravelGuide_new($args){
	$place = $args->place;
	$place_url = str_replace(" ", "-" , strtolower($place));
	$state = $args->state;
	$state_url = str_replace(" ", "-" , strtolower($state));
	$country_name = $args->country_name;
	$country_name_url = str_replace(" ", "-" , strtolower($country_name));
	$url = $args->url;
	$type = $args->type;
	$images = $args->image;
	 $ttd_count = $args->ttd_count;
	$pts_count = $args->pts_count;
	$pts_price = $args->pts_price;
	$agents_count = $args->agents_count;
	$review_count = $args->review_count;
	$best_tym_dt = $args->best_tym_dt;
	$rating_count = $args->rating_count;
	$star1_count  = $args->star1_count;
	$star2_count  = $args->star2_count;
	$star3_count  = $args->star3_count;
	$star4_count  = $args->star4_count;
	$star5_count  = $args->star5_count;
	$event_count  = $args->event_count;
	$event_url    = $args->event_url;
	$rating       = $args->rating;
	$deals_count       = $args->deals_count;
	$leadcount       = $args->leadcount;
	$imagesarray  = explode("," , $images);
	$imagesurl = "";
	if($ttd_count >0){
		$ttd_list_url="https://www.hellotravel.com/".$country_name_url."/".$place_url."/things-to-do";
	}
	if($pts_count >0 && $type == 'dest'){
		 $pts_list_url="https://www.hellotravel.com/".$country_name_url."/places-to-visit";
	}
	elseif($pts_count >0 && $type  == 'pts'){
	 $pts_list_url="https://www.hellotravel.com/".$country_name_url."/".$place_url."/places-to-visit";
	}
	if($type == "pts"){
		$imagesurl = "https://www.hlimg.com/images/places2see/300X200/";
	}else{
		
		$imagesurl = "https://www.hlimg.com/images/destinations/300X200/";
	}

    $html = "";
//     $html='

    





// <div class="h_scrol_d2a"> <a href="javascript:void(0)" id="reqcardagent_1" class="c3" style="text-decoration:none;" onclick=""> <div class="f14 c3 t_linkm">67<br> <span class="lis_titl f11 c6">Agents</span></div> </a> <a href="javascript:void(0)" class="c3" id="sentcardagent_1" style="text-decoration:none;display:none;"> <div class="f14 c3 t_linkm">67<br> <span class="lis_titl f11 c6">Enquiry Sent</span></div> </a> </div>

// ';
	$html .= '<div class="f17 mt1 c3">Travel Guide</div>			
    <div class="h_scrol">';
	if ($ttd_count > 0 && $type == "pts"){
	 $k = array_rand($imagesarray);
         $v = $imagesarray[$k];
	$html .= ' <div class="h_scrol_d2a"> <a href="'.$ttd_list_url.'" target="_blank" onclick="ga(\'send\', \'event\',\'listicle-page\',\'stories\',\'travel-guide-things-to-do-card\');" class="c3" style="text-decoration:none"> <div class="f14 c3 t_linkm">
    '.$ttd_count.'<br> <span class="lis_titl f11 c6">Things to do</span> </div> </a> </div>';
	}
	
	 if ($pts_count >  0 && $pts_list_url != ''){

         $html .= ' <div class="h_scrol_d2a"> <a href="'.$pts_list_url.'" target="_blank" onclick="ga(\'send\', \'event\',\'listicle-page\',\'stories\',\'travel-guide-things-to-do-card\');" class="c3" style="text-decoration:none"> <div class="f14 c3 t_linkm">
    '.$pts_count.'<br> <span class="lis_titl f11 c6">Places to visit</span> </div> </a> </div>';
	   }
	 if ($deals_count >  0){
        $html .= '<div class="h_scrol_d2a"> <a href="https://www.hellotravel.com/deals/'.$place_url.'" target="_blank" onclick="" class="c3" style="text-decoration:none"> <div class="f14 c3 t_linkm">'.$deals_count.'<br> <span class="lis_titl f11 c6">Packages</span> </div> </a> </div>';
	   }
	$mothnsstr = substr(get_selected_month($best_tym_dt) ,0 , 3);
	if ($url != '' && $mothnsstr != ""){
$html .='<div class="h_scrol_d2a"> <a href="'.$url.'" target="_blank" onclick="" class="c3" style="text-decoration:none"> <div class="f14 c3 t_linkm">'.strtoupper($mothnsstr).'<br> <span class="lis_titl f11 c6">Best time to visit</span></div> </a> </div>';
	
	}
    if($leadcount > 0){
        // 	  $priceurl = get_price_url($pts_price);
        
        	   $html .='<div class="h_scrol_d2a"> <a href="javascript:void(0)" id="reqcardvisit" class="c3" onclick="check_post_destination_none(\''.$place.'\',\''.$place.'\',\'\',\'\',\'cardvisit\');" style="text-decoration:none"> <div class="f14 c3 t_linkm">'.$leadcount.'<br> <span class="lis_titl f11 c6">Visited</span></div> </a> <a href="javascript:void(0)" class="c3" id="sentcardvisit" style="text-decoration:none;display:none;"> <div class="f14 c3 t_linkm">'.$leadcount.'<br> <span class="lis_titl f11 c6">Sent</span></div> </a> </div>';
                }
	if($agents_count > 0){
// 	 $html .='<li> <a href="javascript:void(0)" id="reqtravelverify" onclick="check_post_destination_none(\''.$place.'\',\''.$place.'\',\'\',\'\',\'travelverify\');ga(\'send\', \'event\', \'leads\', \'deals_listing_page\',\'travel-guide-verified-agents-card\');" style="text-decoration:none" > <div class="box_card"> <div class="p_r story_img" > <img alt="" src="https://www.hlimg.com/images/df_image.gif" data-src="'.$imagesurl.$v.'" style="height:180px;"/><div class="p_imgtit1"><div class="f17" style="margin-top:-20px">Verified Agents</div>
//   <div class="f60 mt2">'.$agents_count.'</div>
// <button class="mt3" >Explore</button></div> </div> </div> </a><a href="javascript:void(0);" id="senttravelthigns" style="text-decoration:none;display:none;" > <div class="box_card"> <div class="p_r story_img" > <img alt="" src="https://www.hlimg.com/images/df_image.gif" data-src="'.$imagesurl.$v.'" style="height:180px;"/><div class="p_imgtit1"><div class="f17" style="margin-top:-20px">Verified Agents</div>
//   <div class="f60 mt2">'.$agents_count.'</div>
// <button class="mt3" >Sent/button></div> </div> </div> </a> </li>';
$html .='<div class="h_scrol_d2a"> <a href="javascript:void(0)" id="reqtravelverify" class="c3" style="text-decoration:none;" onclick="check_post_destination_none(\''.$place.'\',\''.$place.'\',\'\',\'\',\'travelverify\');"> <div class="f14 c3 t_linkm">'.$agents_count.'<br> <span class="lis_titl f11 c6">Agents</span></div> </a> <a href="javascript:void(0)" class="c3" id="senttravelthigns" style="text-decoration:none;display:none;"> <div class="f14 c3 t_linkm">'.$agents_count.'<br> <span class="lis_titl f11 c6">Sent</span></div> </a> </div>';
	}


	$html .= '<div class="cl"></div></div>';
	return $html; 
  }
  function getsimilardatadesign($args,$place_to){
	$html.='<div class="f17 c3 mt1">Other places like '.ucfirst($place_to).'</div>	
				<div class="sear_scrol mb1 mt1">';
				  
	  foreach($args as $data){
		$html.='<a href="https://www.hellotravel.com/deals/'.strtolower(str_replace(' ','-',$data)).'"  class="sear_scrol_d">'.substr($data,0,15).' </a> ';
	  }
	  $html.=' <div class="cl"></div>
	  </div>';
	  return $html;
  }
function execute_query_premium_groups($query,$group_field="group_deal"){
                $solr_url=$this->get_solr_url();
                $solr_port=$this->get_solr_port();
                $thisargs=$this->args;
		$rows=20;
		$start=0;
		$argsclass=$this->args;
		if(empty($group_field) || $group_field == 1){
			$group_field="group_deal";
		}
		if(isset($argsclass["rows"])){
			$rows=$argsclass["rows"];
                }
		#$argsclass=$this->args;
		if(isset($argsclass["start"])){
                        $start=$argsclass["start"];
                }
		

		$fields="url,form_type,form_version,itinerary_space,itinerary,title_space,travel_with_count,destinations_theme,pstatus,fcp_uid,id,destination_country,from_dt,to_dt,ts_status,bap_status,inclusion_exclusion,converted_price,package_type,title,duration,price,destinations_covered,tbl_login_companyname,tbl_login_creditpoints,tbl_login_id,pns_num,nid,path,days,destinations_covered_text,response_rate,member_since,isonline,priority,booking_status,random_prices,destination_leader,group_deal,dest_leader_from_city,dest_leader_to_city,departure_from,sponsored_status,star_rating_search,form_version,form_type,max_price";
              //  $fields="destination_leader";
           // $fields="pstatus,fcp_uid,id,destination_leader,package_type,title";

				$random="random_".rand(12341,102345)." desc";	
				$post_array=array(
                                        'q' => $query,
                                        'wt' => 'json',
                                        'rows'=>$rows,
          				'start'=>0,
                                        'fl'=>"$fields",
					sort=>"priority asc,destination_leader asc,$random",
                    'group.sort'=>"priority asc,destination_leader asc,$random",
                    //priority asc, score desc, $random
					'group'=>"true",
					"group.limit"=>4,
					"group.field"=>$group_field
					 
                                     );
		
				     $postdata = http_build_query($post_array);
				     #print_r($postdata);
                $opts = array('http' =>
                                array(
                                        'method'  => 'POST',
                                        'header'  => 'Content-type: application/x-www-form-urlencoded',
                                        'content' => $postdata
                                     ));

                $url=$solr_url.":".$solr_port."/solr/hellotravel_deals-new_v2/select";
                $context  = stream_context_create($opts);
               // print_r($opts);exit;
                try{
	//echo $url."?".$postdata;exit;
		$json_main= file_get_contents($url, false, $context);
		
	//	print_r($json_main);
		//exit;
		$return_array=array();
        	$data= json_decode($json_main);
		$total_count=0;
            $groups=$data->grouped->group_deal->groups;
            //print_r($groups);exit;
        	foreach($groups as $rows){
			if($rows->groupValue != 0){
				$total_count+=$rows->doclist->numFound;	
				if($rows->groupValue==1){
					$return_array[$rows->groupValue]=array_slice($rows->doclist->docs,0,3);
        			}else{
                    			$return_array[$rows->groupValue]=$rows->doclist->docs;
        			}
            		}
               }
        krsort($return_array);
    //    print_r($return_array);exit;
		return array("count"=>count($return_array),"result"=>$return_array,"ErrorMassage"=>$e,"status"=>'0',"query"=>$query,"total_count"=>$total_count);
        	
		
                }catch(Exception $e){
                        return array("count"=>"0","result"=>[],"ErrorMassage"=>$e,"status"=>'0',"query"=>$query,"total_count"=>0);
                }
        }



}
#$r=new package_relevence_module(array("type"=>"and"));
#print_r($r->get_packages(array("destinations"=>"corbett,ramnagar")));

#$r->get_packages(array("destinations"=>"delhi,rempur ","duration"=>array("3-8",'10-115'),"themes"=>"honymoon,hill station","from_location"=>"bombay,test","stars"=>array("Economy (0-2 Star Hotels)","Economy (0-2 Star Hotels)"),"prices"=>array(array("min_price"=>1000,"max_price"=>100000),array("min_price"=>1000,"max_price"=>100000))));
#	$r->get_packages(array("destinations"=>"delhi,rempur ","themes"=>"honymoon,hill station","from_location"=>"bombay,test","stars"=>array("Economy (0-2 Star Hotels)","Economy (0-2 Star Hotels)"),"prices"=>array(array("min_price"=>1000,"max_price"=>100000),array("min_price"=>1000,"max_price"=>100000))));
?>


