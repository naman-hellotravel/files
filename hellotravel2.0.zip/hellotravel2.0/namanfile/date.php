<?php
require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

$currentDate = date("Y-m-d");

$sql = "SELECT * FROM tbl_event_upload WHERE status = 1 AND start_date < '$currentDate'";
$result = mysql_query($sql);


if (mysql_num_rows($result) > 0) {
    while ($row = mysql_fetch_assoc($result)) {
        $eventId = $row['id'];
        $newStartDate = date("Y-m-d", strtotime($row['start_date'] . " +1 year"));
        $newEndDate = date("Y-m-d", strtotime($row['end_date'] . " +1 year"));

        $updateSql = "UPDATE tbl_event_upload SET start_date = '$newStartDate', end_date = '$newEndDate', changed_datetime = NOW() WHERE id = '$eventId'";
        if (mysql_query($updateSql) === false) {
            echo "Error updating event with ID $eventId: " . mysql_error();
        }
        else{
            dbprocess($updateSql);
        }
    }
} else {
    echo "No events found with status 1 or all the event updated already";
}
?>




