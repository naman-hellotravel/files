<?php

require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");

$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();


require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");
$title="Terms & Conditions | Hello Travel";

$link_can=link_canonical($_SERVER['REQUEST_URI']);


$smarty_obj->assign("ogtitle",$title);
$smarty_obj->assign("ogurl",$link_can);
$smarty_obj->assign("ogimage","https://www.hellotravel.com/hellotravel/images/holiday.png");


#$smarty_obj->assign("metadescription",$metadescription);
$smarty_obj->assign("script_parent_url_clonica",$link_can);
$smarty_obj->assign("canonical","1");
$smarty_obj->assign("con_request_uri",$link_can);



$smarty_obj->assign('default_meta',$title );
#$smarty_obj->assign('default_canonical',$canonical);
 $smarty_obj->display('hellotravel2.0/header_demo.tpl');
 $smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
 $smarty_obj->display('hellotravel2.0/term_demo.tpl');
 $smarty_obj->display('hellotravel2.0/footer_demo.tpl');
?>
