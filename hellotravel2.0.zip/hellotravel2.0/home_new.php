<?php

require("/home/indiamart/public_html/hellotravel/includes/placestosee_solr.php");
require("/home/indiamart/public_html/hellotravel-agents/includes/common.php");
$home_json = file_get_contents("/home/indiamart/public_html/hellotravel/includes/topjson/home_json_newcopy.txt");
$home_json = json_decode($home_json);

include_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/home_module.php");

function getBanner($home_json){
    $setBannerDesign=getBannerDgn($home_json);
    if(isset($setBannerDesign) && !empty($setBannerDesign)){
       return json_encode($setBannerDesign);die;
    }
}

function getLatest($home_json){
    $setLatestDesign=getLatestDgn($home_json);
    if(isset($setLatestDesign) && !empty($setLatestDesign)){
       return json_encode($setLatestDesign);die;
    }
}

function getTravelTips(){
    $setTravelTipsDesign=getTravelTipsDgn($home_json);
    if(isset($setTravelTipsDesign) && !empty($setTravelTipsDesign)){
       return json_encode($setTravelTipsDesign);die;
    }
}


function getmostpplDest($home_json){
    $setmostpplDestDesign=getmostpplDestDgn($home_json);
    if(isset($setmostpplDestDesign) && !empty($setmostpplDestDesign)){
       return json_encode($setmostpplDestDesign);die;
    }
}

function getmostpplIdeal($home_json){
    $setmostpplIdealDesign=getmostpplIdealDgn($home_json);
    if(isset($setmostpplIdealDesign) && !empty($setmostpplIdealDesign)){
       return json_encode($setmostpplIdealDesign);die;
    }
}

function getHolidayTheme($home_json){
    $setHolidayThemeDesign=getHolidayThemeDgn($home_json);
    if(isset($setHolidayThemeDesign) && !empty($setHolidayThemeDesign)){
       return json_encode($setHolidayThemeDesign);die;
    }
}

function getReview($home_json){
    $setReviewDgnDesign=getReviewDgn($home_json);
    if(isset($setReviewDgnDesign) && !empty($setReviewDgnDesign)){
       return json_encode($setReviewDgnDesign);die;
    }
}



function getIndStateDest($home_json){
    $setIndStateDestDesign=getIndStateDestDgn($home_json);
    if(isset($setIndStateDestDesign) && !empty($setIndStateDestDesign)){
       return json_encode($setIndStateDestDesign);die;
    }
}


function getIntDest($home_json){
    $setIntDestDesign=getIntDestDgn($home_json);
    if(isset($setIntDestDesign) && !empty($setIntDestDesign)){
       return json_encode($setIntDestDesign);die;
    }
}


function getTopAgent($home_json){
    $setTopAgentDesign=getTopAgentDgn($home_json);
    if(isset($setTopAgentDesign) && !empty($setTopAgentDesign)){
       return json_encode($setTopAgentDesign);die;
    }
}


function getPplAgent($home_json){
    $setPplAgentDesign=getPplAgentDgn($home_json);
    if(isset($setPplAgentDesign) && !empty($setPplAgentDesign)){
       return json_encode($setPplAgentDesign);die;
    }
}



function getEvent(){
    $setEventDesign=getEventDgn();
    if(isset($setEventDesign) && !empty($setEventDesign)){
       return json_encode($setEventDesign);die;
    }
}


// function mapimg($value){
   
//     $html = '<img data-src="'.$value.'"  src = "https://www.hlimg.com/images/df_image.gif" class="rotating-item rotating-item_x b_img" style="height:100%;">';
//     return $html;
// }

function getImgeHost(){
    $host = ["www.hlimg.com" , "www.hlimg.com" , "www.hlimg.com"];
    $key  = array_rand($host , 1);
    return $host[$key];
}    
function getImgeHostlive(){
    $host = ["www.hlimg.com" , "www.hlimg.com" , "www.hlimg.com"];
    $key  = array_rand($host , 1);
    return $host[$key];
}  


$BannerDesign=getBanner($home_json);
$BannerDesign=json_decode($BannerDesign,true);
 


$full_path_to_public_program = "/home/indiamart/public_html/hellotravel/hellotravel";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();


$host = getImgeHostlive ();

$smarty_obj->assign("imagehost",$host);

$page='home';

require_once("/home3/indiamart/public_html/hellotravel/hellotravel2.0/module/header.php");

$smarty_obj->assign("LgImgfolder",'738X538');
$smarty_obj->assign("SmImgfolder",'360X230');
$smarty_obj->assign("XsImgfolder",'300X200');
$smarty_obj->assign("DXsImgfolder",'360X230');
$smarty_obj->assign("BannerDesign",$BannerDesign);

 $smarty_obj->display('hellotravel2.0/header_demo.tpl');
 $smarty_obj->display('hellotravel2.0/home_demo.tpl');

 
 
 $LatestDesign=getLatest($home_json);
 $LatestDesign=json_decode($LatestDesign,true);
 $smarty_obj->assign("LatestDesign",$LatestDesign);
 $smarty_obj->display('hellotravel2.0/home_latest_update.tpl');


 $TravelTipsDesign=getTravelTips();
 $TravelTipsDesign=json_decode($TravelTipsDesign,true);
 $smarty_obj->assign("TravelTipsDesign",$TravelTipsDesign);
 $smarty_obj->display('hellotravel2.0/home_story_tips.tpl');

 $MostpplDestDesign=getmostpplDest($home_json);
 $MostpplDestDesign=json_decode($MostpplDestDesign,true);
 $smarty_obj->assign("MostpplDestDesign",$MostpplDestDesign);
 $smarty_obj->display('hellotravel2.0/home_top_destination.tpl');


 $MostpplIdealDesign=getmostpplIdeal($home_json);
 $MostpplIdealDesign=json_decode($MostpplIdealDesign,true);
 $smarty_obj->assign("MostpplIdealDesign",$MostpplIdealDesign);
 $smarty_obj->display('hellotravel2.0/home_deals.tpl');
 $array_data=array("type"=>"pts","title"=>"Popular India's Destinations","data"=>$MostpplIdealDesign["india"]);
 $smarty_obj->assign("array_data", $array_data);
 $smarty_obj->display('hellotravel2.0/home_out.tpl');
  

$array_data=array("type"=>"pts","title"=>"Most Popular International Destinations","data"=>$MostpplIdealDesign["outsideindia"]);
 $smarty_obj->assign("array_data", $array_data);
 
 $smarty_obj->display('hellotravel2.0/home_out.tpl');



 $array_data=array("type"=>"story","title"=>"Visa On Arrival Countries For Indians","data"=>$MostpplIdealDesign["visa"]);
 $smarty_obj->assign("array_data", $array_data);
 $smarty_obj->display('hellotravel2.0/home_out.tpl');


 $ReviewDesign=getReview($home_json);
 $ReviewDesign=json_decode($ReviewDesign,true);
 $smarty_obj->assign("ReviewDesign",$ReviewDesign);
 $smarty_obj->display('hellotravel2.0/home_customer_review.tpl');

 $smarty_obj->display('hellotravel2.0/home_howit_works.tpl');
 
 $HolidayTheme=getHolidayTheme($home_json);
 $HolidayTheme=json_decode($HolidayTheme,true);
 $smarty_obj->assign("HolidayTheme",$HolidayTheme);
 $smarty_obj->display('hellotravel2.0/home_holiday_theme.tpl');

 $IndStateDestDesign=getIndStateDest($home_json);
 $IndStateDestDesign=json_decode($IndStateDestDesign,true);
 $array_data=array("type"=>"state","title"=>"Statewise Tourist Destinations","data"=>$IndStateDestDesign);
 $smarty_obj->assign("array_data", $array_data);
 $smarty_obj->assign("array_data", $array_data);


# $smarty_obj->assign("IndStateDestDesign",$IndStateDestDesign);
 $smarty_obj->display('hellotravel2.0/home_statewise_destination.tpl');



 $IntDestDesign=getIntDest($home_json);
 $IntDestDesign=json_decode($IntDestDesign,true);
 $smarty_obj->assign("IntDestDesign",$IntDestDesign);
 $smarty_obj->display('hellotravel2.0/home_countrywise_destination.tpl');


 $TopAgentDesign=getTopAgent($home_json);
 $TopAgentDesign=json_decode($TopAgentDesign,true);
 $PplAgentDesign=getPplAgent($home_json);
 $PplAgentDesign=json_decode($PplAgentDesign,true);
 $smarty_obj->assign("PplAgentDesign",$PplAgentDesign);
 $smarty_obj->assign("TopAgentDesign",$TopAgentDesign);
 $smarty_obj->display('hellotravel2.0/home_our_clients.tpl');

 $EventDesign=getEvent();
 $EventDesign=json_decode($EventDesign,true);
 $smarty_obj->assign("EventDesign",$EventDesign);
 $smarty_obj->display('hellotravel2.0/home_event.tpl');
//  $smarty_obj->display('home_pack_dest_act.tpl');
$smarty_obj->display('hellotravel2.0/home_enquiry_form.tpl');
 $smarty_obj->display('hellotravel2.0/footer_demo.tpl');
?>
